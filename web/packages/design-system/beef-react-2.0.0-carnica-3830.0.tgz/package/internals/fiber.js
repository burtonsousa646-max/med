// NOTE: Добавление react-is может увеличить стабильность решения в определении типа элемента,
//   однако также расширит размер бандла

export var isFiberNodeKey = function isFiberNodeKey(key) {
  return key.startsWith('__reactFiber$') || key.startsWith('__reactInternalInstance$') || key.startsWith('__reactContainer');
};
export var getInstanceFromNode = function () {
  var fiberKey;
  var getFiberKey = function getFiberKey(domNode) {
    fiberKey = Object.keys(domNode).find(isFiberNodeKey);
    return fiberKey;
  };
  return function (domNode) {
    return domNode[fiberKey || getFiberKey(domNode)];
  };
}();
export var getFiberNodeType = function getFiberNodeType(fiberNode) {
  return fiberNode.type;
};
export var getFiberProps = function getFiberProps(fiberNode) {
  return fiberNode.memoizedProps;
};
export var getFiberProp = function getFiberProp(fiberNode, propName) {
  var _getFiberProps;
  return (_getFiberProps = getFiberProps(fiberNode)) === null || _getFiberProps === void 0 ? void 0 : _getFiberProps[propName];
};
export var isDomFiberNode = function isDomFiberNode(fiberNode) {
  return typeof getFiberNodeType(fiberNode) === 'string';
};
export var isRootFiberNode = function isRootFiberNode(fiberNode) {
  return fiberNode.return === null;
};
export var getFiberNodeFromClassComponent = function getFiberNodeFromClassComponent(classComponent) {
  return classComponent._reactInternals;
};
/**
 * Для обычных узлов stateNode хранит указатель на DOM-элемент
 *   Однако для корневого узла, ссылка хранится дальше - в containerInfo
 */
export var getDomNodeFromFiber = function getDomNodeFromFiber(fiberNode) {
  var node = fiberNode === null || fiberNode === void 0 ? void 0 : fiberNode.stateNode;
  return node instanceof HTMLElement ? node : node === null || node === void 0 ? void 0 : node.containerInfo;
};
export function getFiberNodeFromDOM(domNode) {
  if (!domNode) return null;
  return getInstanceFromNode(domNode) || getFiberNodeFromDOM(domNode.parentNode);
}
export function getFiberNodeParent(fiberNode) {
  if (fiberNode && fiberNode.return) {
    return fiberNode.return; // This is the parent Fiber node
  }
  return null; // Return null if there is no parent
}