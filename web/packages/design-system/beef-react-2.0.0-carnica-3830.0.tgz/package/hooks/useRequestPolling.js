import _asyncToGenerator from "@babel/runtime/helpers/asyncToGenerator";
import _regeneratorRuntime from "@babel/runtime/regenerator";
import React, { useCallback, useEffect } from 'react';
export function useRequestPolling(fn) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$interval = _ref.interval,
    interval = _ref$interval === void 0 ? 500 : _ref$interval;
  var timeout = React.useRef(undefined);
  clearTimeout(setTimeout(function () {
    return 1;
  }));
  var reset = useCallback(function () {
    return clearTimeout(timeout.current);
  }, []);
  var run = useCallback(function () {
    var instant = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
    reset();
    timeout.current = window.setTimeout(/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
      return _regeneratorRuntime.wrap(function (_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 1;
            return fn();
          case 1:
            run();
          case 2:
          case "end":
            return _context.stop();
        }
      }, _callee);
    })), instant ? 0 : interval);
  }, [fn, interval, reset]);
  useEffect(function () {
    run(true);
    return reset;
  }, [run, reset]);
}