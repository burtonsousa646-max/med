const TEST_TYPE_PATTERNS = {
  a11y: '/__tests__/.*\\.a11y\\.(test|spec)\\.[tj]sx?$',
  snapshot: '/__tests__/.*\\.snapshot\\.(test|spec)\\.[tj]sx?$',
  test: '/__tests__/(?!.*.(?:a11y|snapshot).(?:test|spec).[tj]sx?$).*.(?:test|spec).[tj]sx?$'
};
const getTestRegex = () => {
  const testType = process.env.TEST_TYPE;
  // без TEST_TYPE или с неизвестным значением - гоняем всё, как раньше
  return TEST_TYPE_PATTERNS[testType] || '/__tests__/.*\\.((a11y|snapshot)\\.)?(test|spec)\\.[tj]sx?$';
};
const getCoverageDirectory = () => {
  if (!process.env.WORKDIR) return './coverage';
  const base = `${process.env.CI_PROJECT_DIR}/${process.env.FOLDER}/${process.env.PACKAGE}/coverage`;
  return process.env.TEST_TYPE ? `${base}/${process.env.TEST_TYPE}` : base;
};
const getJunitOutputName = () => {
  if (!process.env.WORKDIR) return 'junit.xml';
  return process.env.TEST_TYPE ? `${process.env.PACKAGE}-${process.env.TEST_TYPE}-junit.xml` : `${process.env.PACKAGE}-junit.xml`;
};
module.exports = {
  getTestRegex,
  getCoverageDirectory,
  getJunitOutputName
};