import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["min", "max", "direction", "containerRef", "disabled", "loading", "value", "onChange", "view", "containerProps", "className", "id", "onBlur", "onKeyDown"];
import React, { forwardRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { IconMinusRoundStroked, IconPlusRoundStroked } from '@carnica/graphics';
import { Spinner } from "../Spinner";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { useStepperControls } from "./hooks/useStepperControls";
import { useStepperInput } from "./hooks/useStepperInput";
var cnStepper = cnBem('stepper', styles);
export var Stepper = /*#__PURE__*/forwardRef(function (props, ref) {
  var min = props.min,
    max = props.max,
    _props$direction = props.direction,
    direction = _props$direction === void 0 ? 'horizontal' : _props$direction,
    containerRef = props.containerRef,
    disabled = props.disabled,
    loading = props.loading,
    value = props.value,
    onChange = props.onChange,
    _props$view = props.view,
    view = _props$view === void 0 ? 'primary' : _props$view,
    containerProps = props.containerProps,
    className = props.className,
    id = props.id,
    onBlur = props.onBlur,
    onKeyDown = props.onKeyDown,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useStepperInput = useStepperInput({
      value: value,
      onChange: onChange,
      max: max,
      min: min,
      onBlur: onBlur,
      onKeyDown: onKeyDown
    }),
    inputRef = _useStepperInput.inputRef,
    inputProps = _useStepperInput.inputProps,
    tempValue = _useStepperInput.tempValue;
  var _useStepperControls = useStepperControls({
      onChange: onChange,
      value: value,
      tempValue: tempValue,
      min: min,
      max: max,
      loading: loading,
      disabled: disabled
    }),
    prev = _useStepperControls.prev,
    next = _useStepperControls.next;
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, containerProps || {}, {
    className: cnStepper({
      direction: direction,
      disabled: disabled,
      view: view
    }, [className]),
    ref: containerRef,
    tagName: "div",
    "data-t-id": "components-Stepper"
  }), /*#__PURE__*/React.createElement(IconMinusRoundStroked, _extends({}, prev, {
    "aria-controls": id,
    "aria-label": "\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435",
    className: cnStepper('control'),
    color: prev.disabled ? 'disabled' : 'primary',
    size: "s",
    tagName: "button",
    type: "button",
    "data-t-id": "components-Stepper"
  })), loading ? /*#__PURE__*/React.createElement(Spinner, {
    "aria-label": "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F",
    view: "dark-yellow"
  }) : /*#__PURE__*/React.createElement("input", _extends({}, otherProps, inputProps, {
    "aria-label": otherProps['aria-label'] || 'Поле ввода количества',
    "aria-valuemax": max,
    "aria-valuemin": min,
    "aria-valuenow": tempValue,
    className: cnStepper('input'),
    disabled: loading || disabled,
    id: id,
    inputMode: "tel",
    max: max,
    min: min,
    ref: combineRefs([ref, inputRef]),
    role: "spinbutton",
    type: "number"
  })), /*#__PURE__*/React.createElement(IconPlusRoundStroked, _extends({}, next, {
    "aria-controls": id,
    "aria-label": "\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435",
    className: cnStepper('control'),
    color: next.disabled ? 'disabled' : 'primary',
    size: "s",
    tagName: "button",
    type: "button"
  })));
});