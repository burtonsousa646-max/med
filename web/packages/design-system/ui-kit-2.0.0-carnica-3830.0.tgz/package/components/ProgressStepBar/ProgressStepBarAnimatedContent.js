import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "animationKey"];
import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
var variants = {
  initial: {
    opacity: 0
  },
  animate: {
    opacity: 1
  },
  exit: {
    opacity: 1
  }
};
export var ProgressStepBarAnimatedContent = function ProgressStepBarAnimatedContent(_ref) {
  var children = _ref.children,
    animationKey = _ref.animationKey,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    mode: "popLayout",
    "data-t-id": "components-ProgressStepBar"
  }, /*#__PURE__*/React.createElement(motion.span, _extends({
    animate: "animate",
    exit: "exit",
    initial: "initial",
    key: animationKey,
    transition: {
      duration: 0.2,
      ease: [0.2, 0.0, 0.0, 1.0]
    },
    variants: variants
  }, props), children));
};