import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["convertFile", "placeholder", "accept", "maxFiles", "maxFileSize", "multiple", "disabled", "view", "value", "deleteMode", "onChange", "className"],
  _excluded2 = ["file", "attributes", "ref"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useMemo } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { Text } from "../Text";
import styles from "./styles.module.css";
import { defaultConverFile, getPlaceholder, valueToArray } from "./utils";
import { File } from "../File";
import { useFileInput } from "./hooks/useFileInput";
var cnFileInput = cnBem('file-input', styles);
export var FileInputField = /*#__PURE__*/forwardRef(function (props, ref) {
  var convertFile = props.convertFile,
    placeholderProp = props.placeholder,
    accept = props.accept,
    maxFiles = props.maxFiles,
    maxFileSize = props.maxFileSize,
    multiple = props.multiple,
    disabled = props.disabled,
    _props$view = props.view,
    view = _props$view === void 0 ? 'primary' : _props$view,
    value = props.value,
    _props$deleteMode = props.deleteMode,
    deleteMode = _props$deleteMode === void 0 ? 'undoable' : _props$deleteMode,
    onChange = props.onChange,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var fileList = useMemo(function () {
    return valueToArray(value).map(function (el) {
      return _objectSpread(_objectSpread({}, convertFile ? convertFile(el) : defaultConverFile(el, maxFileSize)), {}, {
        file: el
      });
    });
  }, [convertFile, maxFileSize, value]);
  var placeholder = useMemo(function () {
    return getPlaceholder({
      placeholder: placeholderProp,
      accept: accept,
      maxFileSize: maxFileSize,
      multiple: multiple
    });
  }, [placeholderProp, accept, maxFileSize, multiple]);
  var _useFileInput = useFileInput({
      multiple: multiple,
      onChange: onChange,
      value: value,
      disabled: disabled,
      accept: accept,
      maxFileSize: maxFileSize,
      maxFiles: maxFiles
    }),
    inputRef = _useFileInput.inputRef,
    containerProps = _useFileInput.containerProps,
    onDeleteFile = _useFileInput.onDeleteFile,
    handleChange = _useFileInput.handleChange,
    isDragging = _useFileInput.isDragging;
  var onPlaceholderClick = function onPlaceholderClick(e) {
    e.preventDefault();
    if (!disabled) {
      var _inputRef$current;
      (_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 || _inputRef$current.click();
    }
  };
  return /*#__PURE__*/React.createElement("div", _extends({}, containerProps, {
    className: cnFileInput('wrapper', {
      disabled: disabled,
      view: view,
      active: isDragging
    }, [className]),
    "data-t-id": "components-FileInput"
  }), /*#__PURE__*/React.createElement("input", _extends({}, otherProps, {
    accept: Array.isArray(accept) ? accept.join(', ') : accept,
    className: cnFileInput('field'),
    disabled: disabled,
    multiple: multiple,
    onChange: handleChange,
    ref: combineRefs([ref, inputRef]),
    type: "file"
  })), Boolean(fileList.length) && /*#__PURE__*/React.createElement("div", {
    className: cnFileInput('list'),
    role: "list"
  }, fileList.map(function (_ref) {
    var file = _ref.file,
      attributes = _ref.attributes,
      refParam = _ref.ref,
      params = _objectWithoutProperties(_ref, _excluded2);
    var onRemove = function onRemove(e) {
      var _params$onRemove;
      (_params$onRemove = params.onRemove) === null || _params$onRemove === void 0 || _params$onRemove.call(params, e);
      onDeleteFile(e, file);
    };
    return /*#__PURE__*/React.createElement(File, _extends({}, attributes, params, {
      deleteMode: deleteMode,
      key: cnFileInput('file', {
        name: file.name
      }),
      onRemove: onRemove,
      ref: refParam,
      role: "listitem",
      view: view === 'primary' ? 'secondary' : 'primary'
    }));
  })), placeholder && /*#__PURE__*/React.createElement(Text, {
    align: "center",
    "aria-label": "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0444\u0430\u0439\u043B\u044B",
    className: cnFileInput('placeholder', {
      disabled: disabled
    }),
    color: disabled ? 'disabled' : 'secondary',
    onClick: onPlaceholderClick,
    role: "button",
    tabIndex: 0,
    variant: "caption-medium"
  }, placeholder));
});