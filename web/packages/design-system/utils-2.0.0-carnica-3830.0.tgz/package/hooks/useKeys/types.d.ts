import { TKeyCode } from '../../types/KeyCodes';
export type UseKeysHandlers = Partial<Record<TKeyCode, (e: KeyboardEvent) => void>>;
export type UseKeysEventType = 'keydown' | 'keyup';
export type UseKeys = (handlers: UseKeysHandlers, element?: Document | React.RefObject<HTMLElement> | null, type?: UseKeysEventType) => void;
//# sourceMappingURL=types.d.ts.map