import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "progressBarClassName", "duration", "autoPlay", "loop", "children", "swiperOptions", "infinite", "invertBar", "pauseOnHover", "withControls", "intersectionActivate", "onSwiperInit", "onChangeSlide", "onMouseLeave", "onMouseEnter", "onNavigationClick", "mode", "controlsResponseArea", "shouldRender"],
  _excluded2 = ["swiperNodeRef", "activeSlide", "changeSwiperSlide"];
import React, { forwardRef, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { withRenderCondition } from '@beef/react';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { ProgressBar } from "../ProgressBar";
import styles from "./styles.module.css";
import 'swiper/css';
import { BannerCore } from "./BannerCore";
import { useIsAutoplayActive, useProgressBar, useSwiper, useVirtualSlides } from "./hooks";
var cnBanner = cnBem('banner', styles);
var BannerRender = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    progressBarClassName = props.progressBarClassName,
    _props$duration = props.duration,
    duration = _props$duration === void 0 ? 2000 : _props$duration,
    _props$autoPlay = props.autoPlay,
    autoPlay = _props$autoPlay === void 0 ? true : _props$autoPlay,
    _props$loop = props.loop,
    loop = _props$loop === void 0 ? true : _props$loop,
    children = props.children,
    swiperOptions = props.swiperOptions,
    infinite = props.infinite,
    invertBar = props.invertBar,
    pauseOnHover = props.pauseOnHover,
    withControls = props.withControls,
    intersectionActivate = props.intersectionActivate,
    onSwiperInit = props.onSwiperInit,
    onChangeSlide = props.onChangeSlide,
    onMouseLeave = props.onMouseLeave,
    onMouseEnter = props.onMouseEnter,
    onNavigationClick = props.onNavigationClick,
    mode = props.mode,
    controlsResponseArea = props.controlsResponseArea,
    shouldRender = props.shouldRender,
    otherProps = _objectWithoutProperties(props, _excluded);
  useDeprecationWarning({
    infinite: {
      value: infinite,
      newPropKey: 'loop={true}'
    }
  });
  var containerRef = useRef(null);
  var nodes = useVirtualSlides({
    children: children,
    loop: loop,
    mode: mode
  });
  var slides = React.Children.count(children);
  var _useIsAutoplayActive = useIsAutoplayActive({
      containerRef: containerRef,
      onMouseEnter: onMouseEnter,
      onMouseLeave: onMouseLeave,
      intersectionActivate: intersectionActivate,
      pauseOnHover: pauseOnHover
    }),
    progressBarHidden = _useIsAutoplayActive.progressBarHidden,
    isPlay = _useIsAutoplayActive.isPlay,
    setIsActive = _useIsAutoplayActive.setIsActive,
    options = _useIsAutoplayActive.options;
  var _useSwiper = useSwiper({
      mode: mode,
      setIsProgressActive: setIsActive,
      autoPlay: autoPlay,
      loop: loop,
      onChangeSlide: onChangeSlide,
      slides: slides,
      onSwiperInit: onSwiperInit,
      swiperOptions: swiperOptions,
      withControls: withControls,
      originalSlidesCount: slides
    }),
    swiperNodeRef = _useSwiper.swiperNodeRef,
    activeSlide = _useSwiper.activeSlide,
    changeSwiperSlide = _useSwiper.changeSwiperSlide,
    swiperParams = _objectWithoutProperties(_useSwiper, _excluded2);
  var progressBarProps = useProgressBar({
    autoPlay: autoPlay,
    duration: duration,
    loop: loop,
    isActive: isPlay,
    activeSlide: activeSlide,
    slides: slides,
    changeSlide: changeSwiperSlide
  });
  return /*#__PURE__*/React.createElement(BannerCore, _extends({}, otherProps, {
    className: cnBanner({
      mode: mode
    }, [className]),
    containerContent: slides > 1 ? /*#__PURE__*/React.createElement(ProgressBar, _extends({
      className: cnBanner('progress', {
        hidden: mode === 'default' ? false : progressBarHidden
      }, [progressBarClassName]),
      invert: invertBar,
      style: _defineProperty({}, '--banner-slides', nodes.length)
    }, progressBarProps)) : null,
    controlsResponseArea: controlsResponseArea,
    onNavigationClick: onNavigationClick,
    ref: combineRefs([ref, containerRef]),
    slideClass: cnBanner('slide', {
      mode: mode
    }, ['swiper-slide', swiperOptions === null || swiperOptions === void 0 ? void 0 : swiperOptions.slideClass]),
    swiperNodeRef: swiperNodeRef,
    withControls: withControls && slides > 1,
    wrapperClass: swiperOptions === null || swiperOptions === void 0 ? void 0 : swiperOptions.wrapperClass
  }, swiperParams, options, {
    "data-t-id": "components-Banner"
  }), nodes);
});
export var Banner = withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref2) {
    var children = _ref2.children;
    return !!React.Children.count(children);
  }
})(BannerRender);