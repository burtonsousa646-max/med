import React from 'react';
import type { Fiber } from '../types';
export declare function withFiber(): <T extends Record<string, any>>(WrappedComponent: React.ComponentType<T & {
    fiber: Fiber;
}>) => (props: Omit<T, "fiber">) => React.JSX.Element;
//# sourceMappingURL=withFiber.d.ts.map