import { UseManyRefsElements, UseManyRefsParams, UseManyRefsResult } from './types';
export declare const useManyRefs: <ELEMENT, ESTIMATE extends UseManyRefsElements = number>(elements: ESTIMATE, params?: UseManyRefsParams<ESTIMATE>) => UseManyRefsResult<ELEMENT, ESTIMATE>;
//# sourceMappingURL=useManyRefs.d.ts.map