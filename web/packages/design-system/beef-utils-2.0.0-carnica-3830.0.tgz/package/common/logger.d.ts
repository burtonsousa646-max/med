export declare class AdvancedLogger {
    private logs;
    private uniqueKey;
    warnOnce(payload: any, uuid?: number | string): void;
    errorOnce(payload: any, uuid?: number | string): void;
}
//# sourceMappingURL=logger.d.ts.map