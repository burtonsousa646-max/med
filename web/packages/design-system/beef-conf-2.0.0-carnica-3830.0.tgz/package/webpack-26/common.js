export var isCtor = function isCtor(cls) {
  return typeof cls === 'function' && typeof (cls === null || cls === void 0 ? void 0 : cls.constructor) === 'function';
};