import type { Plugin } from './types';
import type { Rule, RuleSetFull } from './useRule';
export declare const PRIVATE_BUILDER_API: {
    build: <R>(fn: () => R) => R;
    assertBuilding: (name: string) => void;
    replaceConfig: <V extends Record<PropertyKey, any>>(arg: V) => V;
    buildConfig: <A, B extends Record<PropertyKey, any>>(initial: A, replaceConfig: B) => (A & B) | undefined;
    replaceRule: (rule: Rule, replacementRule: RuleSetFull | undefined) => void;
    excludeRule: (rule: Rule) => symbol;
    replacePlugin: (PluginCls: Plugin, replacementPlugin: any) => any;
    excludePlugin: (PluginCls: Plugin) => undefined;
    buildRules: (originalRules?: RuleSetFull[], extendRules?: RuleSetFull[]) => RuleSetFull[];
    buildPlugins: (originalPlugins: any[], extendPlugins: any[]) => any[];
};
//# sourceMappingURL=builder.internals.d.ts.map