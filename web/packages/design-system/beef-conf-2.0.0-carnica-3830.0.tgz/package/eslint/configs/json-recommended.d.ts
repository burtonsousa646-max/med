declare let _extends: string[];
export { _extends as extends };
export declare let parser: string;
export declare let rules: {
    'jsonc/sort-keys': (string | {
        allowLineSeparatedGroups: boolean;
        caseSensitive: boolean;
        minKeys: number;
        natural: boolean;
    })[];
    'no-irregular-whitespace': string;
};
//# sourceMappingURL=json-recommended.d.ts.map