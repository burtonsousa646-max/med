import { DefaultBodyType, MockedRequest, RestHandler } from 'old-msw';
import { Directory, Route } from './types';
export type { Directory, Route };
export declare const readStub: (filePath: string, isJSON: boolean) => any;
export declare const convertRoutesToMswHandlers: (routesPath: string) => RestHandler<MockedRequest<DefaultBodyType>>[];
//# sourceMappingURL=converter.d.ts.map