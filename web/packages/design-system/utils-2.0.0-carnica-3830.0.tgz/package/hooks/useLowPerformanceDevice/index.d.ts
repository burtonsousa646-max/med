export * from './useLowPerformanceDevice';
//# sourceMappingURL=index.d.ts.map