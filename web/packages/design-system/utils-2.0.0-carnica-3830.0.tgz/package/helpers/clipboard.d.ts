interface IClipboardData {
    interval?: number;
    onFinally: (status: boolean) => void;
    text: string;
}
interface IShareData {
    text: string;
    title: string;
    url: string;
}
export declare const canUseShare: () => boolean;
export declare const canUseClipboard: () => boolean;
export declare const shareData: (data: IShareData) => void;
export declare const clipboardData: ({ text, onFinally, interval }: IClipboardData) => void;
export {};
//# sourceMappingURL=clipboard.d.ts.map