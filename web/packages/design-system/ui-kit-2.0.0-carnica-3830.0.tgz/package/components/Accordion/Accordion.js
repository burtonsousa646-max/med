import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "className", "summaryClassName", "label", "labelTagName", "children", "size", "id", "onLabelClick", "closeIcon", "openIcon", "closeRotate", "openRotate", "iconClassName", "initialIsOpen", "summaryProps", "summaryRef"];
import React, { forwardRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { Text } from "../Text";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { contentVariantMap, labelVariantMap } from "./utils";
import { AccordionIcon } from "./AccordionIcon";
import { useAccordion } from "./hooks/useAccordion";
var cnAccordion = cnBem('accordion', styles);
var getSummaryId = function getSummaryId(id, summaryId) {
  if (summaryId) {
    return summaryId;
  }
  if (id) {
    return "".concat(id, "-summary");
  }
  return undefined;
};
var AccordionRender = function AccordionRender(props, ref) {
  var isOpenProp = props.isOpen,
    className = props.className,
    summaryClassName = props.summaryClassName,
    label = props.label,
    labelTagName = props.labelTagName,
    children = props.children,
    _props$size = props.size,
    size = _props$size === void 0 ? 'l' : _props$size,
    id = props.id,
    onLabelClick = props.onLabelClick,
    closeIcon = props.closeIcon,
    openIcon = props.openIcon,
    closeRotate = props.closeRotate,
    openRotate = props.openRotate,
    iconClassName = props.iconClassName,
    initialIsOpen = props.initialIsOpen,
    summaryProps = props.summaryProps,
    summaryRefProp = props.summaryRef,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useAccordion = useAccordion({
      isOpen: isOpenProp,
      onLabelClick: onLabelClick,
      initialIsOpen: initialIsOpen
    }),
    isOpen = _useAccordion.isOpen,
    detailsRef = _useAccordion.detailsRef,
    contentRef = _useAccordion.contentRef,
    summaryRef = _useAccordion.summaryRef,
    onClick = _useAccordion.onClick,
    actualOpen = _useAccordion.actualOpen;
  var summaryId = getSummaryId(id, summaryProps === null || summaryProps === void 0 ? void 0 : summaryProps.id);
  var panelId = id ? "".concat(id, "-panel") : undefined;
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnAccordion({
      isOpen: actualOpen,
      size: size
    }, [className]),
    id: id,
    open: isOpen,
    ref: combineRefs([ref, detailsRef]),
    tagName: "details",
    "data-t-id": "components-Accordion"
  }), /*#__PURE__*/React.createElement("summary", _extends({
    "aria-label": "".concat(isOpen ? 'Скрыть' : 'Показать', " \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435"),
    id: summaryId
  }, summaryProps, {
    "aria-controls": panelId,
    "aria-expanded": isOpen ? 'true' : 'false',
    className: cnAccordion('top', summaryClassName),
    onClick: onClick,
    ref: combineRefs([summaryRef, summaryRefProp]),
    tabIndex: 0,
    "data-t-id": "components-Accordion"
  }), /*#__PURE__*/React.createElement(Text, {
    color: "primary",
    tagName: labelTagName,
    variant: labelVariantMap[size]
  }, label), /*#__PURE__*/React.createElement(AccordionIcon, {
    className: cnAccordion('icon', [typeof iconClassName === 'function' ? iconClassName(isOpen) : iconClassName]),
    closeIcon: closeIcon,
    closeRotate: closeRotate,
    isOpen: actualOpen,
    openIcon: openIcon,
    openRotate: openRotate
  })), /*#__PURE__*/React.createElement(Text, {
    "aria-labelledby": summaryId,
    className: cnAccordion('content'),
    color: "tertiary",
    id: panelId,
    ref: contentRef,
    role: "region",
    tagName: "div",
    variant: contentVariantMap[size]
  }, children));
};
export var Accordion = /*#__PURE__*/forwardRef(AccordionRender);