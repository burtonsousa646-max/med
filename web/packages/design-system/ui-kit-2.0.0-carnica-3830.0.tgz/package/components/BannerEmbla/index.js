import _extends from "@babel/runtime/helpers/extends";
import React, { forwardRef } from 'react';
import { Banner as Component } from "./Banner";
var defineBanner = function defineBanner(mode) {
  return /*#__PURE__*/forwardRef(function (props, ref) {
    return /*#__PURE__*/React.createElement(Component, _extends({
      mode: mode
    }, props, {
      ref: ref,
      "data-t-id": "components-BannerEmbla"
    }));
  });
};
export var BannerEmbla = defineBanner('default');
export var BannerGroupEmbla = defineBanner('group');