/**
 * Returns a promise, that resolves after next animation frame renders
 */
export var waitForLayout = function waitForLayout() {
  return new Promise(function (res) {
    requestAnimationFrame(function () {
      setTimeout(res);
    });
  });
};