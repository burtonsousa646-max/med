import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import React, { useEffect, useRef } from 'react';
import { canUseDom, cnBem } from '@carnica/utils';
import { useFlag } from '@carnica/utils/hooks';
import { Text } from "../../Text";
import { StatusViewIndicator } from "../StatusViewIndicator";
import styles from "../styles.module.css";
import { StatusViewActions } from "../StatusViewActions";
import { statusViewPropState } from "../types";
import { StatusViewAnimateBlock } from "../StatusViewAnimateBlock";
var cnStatusView = cnBem('status-view', styles);
export var StatusViewContent = function StatusViewContent(props) {
  var title = props.title,
    subTitle = props.subTitle,
    _props$state = props.state,
    state = _props$state === void 0 ? statusViewPropState[0] : _props$state,
    icon = props.icon,
    children = props.children,
    additionalContent = props.additionalContent,
    actions = props.actions,
    loading = props.loading,
    loadingOptions = props.loadingOptions,
    wrapperRef = props.wrapperRef,
    convertAction = props.convertAction,
    actionGetters = props.actionGetters;
  var _useFlag = useFlag(!loading),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isStaticIndicatorVisible = _useFlag2[0],
    setIsStaticIndicatorVisible = _useFlag2[1];
  var indicatorRef = useRef(null);
  useEffect(function () {
    if (loading) {
      setIsStaticIndicatorVisible.off();
    }
  }, [loading]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusViewIndicator, {
    className: cnStatusView('indicator', {
      type: 'static',
      visible: isStaticIndicatorVisible
    }),
    icon: icon,
    ref: indicatorRef,
    state: state,
    "data-t-id": "StatusView-StatusViewContent"
  }), typeof loading === 'boolean' && canUseDom() && /*#__PURE__*/React.createElement(StatusViewAnimateBlock, {
    anchorRef: indicatorRef,
    className: cnStatusView('indicator', {
      type: 'dynamic',
      visible: !isStaticIndicatorVisible
    }),
    icon: icon,
    loading: loading,
    loadingOptions: loadingOptions,
    onAnimationFinished: setIsStaticIndicatorVisible.on,
    state: state,
    wrapperRef: wrapperRef
  }), /*#__PURE__*/React.createElement("div", {
    className: cnStatusView('title')
  }, title && /*#__PURE__*/React.createElement(Text, {
    align: "center",
    color: "primary",
    variant: "headline-small"
  }, title), subTitle && /*#__PURE__*/React.createElement(Text, {
    align: "center",
    color: "secondary",
    variant: "body-small"
  }, subTitle)), /*#__PURE__*/React.createElement(StatusViewActions, {
    actions: actions,
    className: cnStatusView('actions'),
    convertAction: convertAction,
    getters: actionGetters
  }), children && /*#__PURE__*/React.createElement("div", {
    className: cnStatusView('container')
  }, children), additionalContent && /*#__PURE__*/React.createElement("div", {
    className: cnStatusView('content')
  }, additionalContent));
};