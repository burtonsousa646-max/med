import React from 'react';
export declare function defineProps<F, D>(finalProps?: F, defaultProps?: D): <T>(WrappedComponent: React.ComponentType<T>) => React.ForwardRefExoticComponent<React.PropsWithoutRef<Omit<T, keyof D | keyof F> & Partial<T & D>> & React.RefAttributes<HTMLElement>>;
//# sourceMappingURL=defineProps.d.ts.map