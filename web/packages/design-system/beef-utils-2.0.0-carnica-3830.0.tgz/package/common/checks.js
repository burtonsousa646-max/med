export function isPlainObject(obj) {
  return Object.prototype.toString.call(obj) === '[object Object]';
}
export var isPromise = function isPromise(inst) {
  return !!inst && typeof inst.then === 'function';
};
export var isFunction = function isFunction(func) {
  return typeof func === 'function';
};
export var isDateValid = function isDateValid(date) {
  return !Number.isNaN(date.getTime());
};