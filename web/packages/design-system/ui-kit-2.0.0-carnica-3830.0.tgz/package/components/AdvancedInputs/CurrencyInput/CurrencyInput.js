import { compose } from '@beef/utils';
import { defineProps } from '@beef/react';
import { Input } from "../../Input";
import { withMaskedInput } from "../../../hocs/withMaskedInput";
export var currencyMask = {
  mask: [{
    mask: 'num',
    lazy: false,
    blocks: {
      num: {
        mask: Number,
        scale: 2,
        thousandsSeparator: ' ',
        padFractionalZeros: false,
        min: 0,
        normalizeZeros: true,
        radix: ',',
        mapToRadix: ['.']
      }
    }
  }],
  autofix: true,
  lazy: true
};
export var CurrencyInput = compose(defineProps({}, {
  postFix: '₽',
  placeholder: '100'
}), withMaskedInput(currencyMask))(Input);