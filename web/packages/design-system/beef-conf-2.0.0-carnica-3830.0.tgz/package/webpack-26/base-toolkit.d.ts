import { DefinePlugin, EnvironmentPlugin } from 'webpack';
import TerserPlugin from 'terser-webpack-plugin';
import CopyWebpackPlugin from 'copy-webpack-plugin';
import CircularDependencyPlugin from 'circular-dependency-plugin';
import { WebpackManifestPlugin } from 'webpack-manifest-plugin';
import type { TerserPluginTyped } from './types';
import { BeefManifestPlugin } from '../webpack/beefManifestPlugin';
import { BeefCacheBuildDependencyPlugin } from '../webpack/BeefCacheBuildDependencyPlugin';
export { BeefCacheBuildDependencyPlugin, BeefManifestPlugin };
export declare const baseToolkit: {
    _loaders: {
        babel: string;
    };
    rules: {
        code: RegExp;
    };
    readonly loaders: {
        babel: {
            loader: string;
            options: {
                cacheDirectory: boolean;
                rootMode: string;
            };
            exclude: any;
        };
        asset: {
            type: string;
        };
    };
    plugins: {
        CopyWebpackPlugin: typeof CopyWebpackPlugin;
        CircularDependencyPlugin: typeof CircularDependencyPlugin & {
            failOnError: CircularDependencyPlugin;
            warnOnError: CircularDependencyPlugin;
        };
        WebpackManifestPlugin: typeof WebpackManifestPlugin;
        BeefManifestPlugin: typeof BeefManifestPlugin;
        BeefCacheBuildDependencyPlugin: typeof BeefCacheBuildDependencyPlugin;
        EnvironmentPlugin: typeof EnvironmentPlugin;
        TerserPlugin: typeof TerserPlugin & TerserPluginTyped & {
            eraseComments: any;
        };
        DefinePlugin: typeof DefinePlugin;
    };
    readonly options: {
        monorepoExcludes: RegExp;
        monorepoIncludes: RegExp;
        version: string;
        filePattern: (isProduction?: boolean) => string;
        cwd: string;
    };
};
//# sourceMappingURL=base-toolkit.d.ts.map