declare const _exports: {
    overrides: ({
        overrides: ({
            extends: any[];
            rules: {};
            files: string[];
        } | {
            extends: any[];
            files: string[];
        })[];
        plugins: string[];
        parser: string;
        extends: any[];
        files: string[];
    } | {
        overrides: ({
            extends: any[];
            rules: {};
            files: string[];
        } | {
            extends: any[];
            files: string[];
        })[];
        parser: string;
        extends: any[];
        files: string[];
    } | {
        extends: string[];
        parser: string;
        rules: {
            'jsonc/sort-keys': (string | {
                allowLineSeparatedGroups: boolean;
                caseSensitive: boolean;
                minKeys: number;
                natural: boolean;
            })[];
            'no-irregular-whitespace': string;
        };
        files: string[];
    })[];
    root: boolean;
    plugins: string[];
    env: {
        browser: boolean;
        jest: boolean;
        node: boolean;
        es2020: boolean;
    };
    settings: {
        'import/cache': {
            lifetime: string;
        };
        'import/extensions': string[];
        'import/resolver': {
            'babel-module': {
                babelOptions: {
                    rootMode: string;
                };
            };
            node: {};
            exports: {};
        };
    };
    ignorePatterns: string[];
};
export = _exports;
//# sourceMappingURL=hybrid.config.d.ts.map