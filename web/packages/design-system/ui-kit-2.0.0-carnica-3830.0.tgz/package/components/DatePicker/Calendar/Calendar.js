import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["value", "range", "onChange", "onClear", "minDate", "maxDate", "disableDates", "additionalControls", "className", "locale", "completeButtonProps", "isComposed", "isAnimationFinished", "type"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { AnimatePresence, motion } from 'framer-motion';
import { ru } from 'date-fns-new/locale';
import { withRenderFlag } from '@beef/react';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import { Button } from "../../Button";
import { MotionComponent } from "../../../modules/MotionComponent";
import { ModeToggle } from "../ModeToggle";
import styles from "./styles.module.css";
import { useCalendar } from "../hooks/useCalendar";
import { CalendarBlockDay, CalendarBlockMonth, CalendarBlockYear } from "../CalendarBlocks";
var cnCalendar = cnBem('calendar', styles);
var getCalendarBlock = function getCalendarBlock(mode, type) {
  if (mode === 'year') {
    return CalendarBlockYear;
  }
  return type === 'date' ? CalendarBlockDay : CalendarBlockMonth;
};
var isValueEmpty = function isValueEmpty(value) {
  return Array.isArray(value) ? !value.find(Boolean) : !value;
};
var Div = withRenderFlag(MotionComponent);
export var CalendarRender = function CalendarRender(props, ref) {
  var valueProp = props.value,
    range = props.range,
    onChange = props.onChange,
    onClearProp = props.onClear,
    minDate = props.minDate,
    maxDate = props.maxDate,
    disableDates = props.disableDates,
    additionalControls = props.additionalControls,
    className = props.className,
    _props$locale = props.locale,
    locale = _props$locale === void 0 ? ru : _props$locale,
    completeButtonProps = props.completeButtonProps,
    isComposed = props.isComposed,
    isAnimationFinished = props.isAnimationFinished,
    _props$type = props.type,
    type = _props$type === void 0 ? 'date' : _props$type,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  var _useCalendar = useCalendar({
      value: valueProp,
      onChange: onChange,
      range: range,
      locale: locale,
      onClear: onClearProp
    }),
    value = _useCalendar.value,
    mode = _useCalendar.mode,
    currentVisibleDate = _useCalendar.currentVisibleDate,
    setMode = _useCalendar.setMode,
    setValue = _useCalendar.setValue,
    setCurrentVisibleDate = _useCalendar.setCurrentVisibleDate,
    onComplete = _useCalendar.onComplete,
    onClear = _useCalendar.onClear;
  var blockProps = _objectSpread({
    locale: locale,
    disableDates: disableDates,
    maxDate: maxDate,
    minDate: minDate,
    onChange: setValue,
    range: range,
    value: value,
    currentVisibleDate: currentVisibleDate,
    isComposed: isComposed,
    setCurrentVisibleDate: setCurrentVisibleDate,
    isAnimationFinished: isAnimationFinished
  }, mode === 'year' ? {
    changeMode: function changeMode() {
      return setMode('date');
    }
  } : {});
  var Component = getCalendarBlock(mode, type);
  return /*#__PURE__*/React.createElement("div", _extends({}, otherProps, {
    className: cnCalendar(null, [className]),
    ref: ref,
    "data-t-id": "DatePicker-Calendar"
  }), /*#__PURE__*/React.createElement(ModeToggle, {
    className: cnCalendar('toggler'),
    date: currentVisibleDate,
    onChange: setMode,
    value: mode
  }), /*#__PURE__*/React.createElement(AnimatePresence, {
    mode: "wait"
  }, /*#__PURE__*/React.createElement(motion.div, {
    animate: {
      y: 0,
      opacity: 1
    },
    exit: {
      y: -10,
      opacity: 0.3
    },
    initial: {
      y: 10,
      opacity: 0.3
    },
    key: mode,
    transition: {
      duration: 0.2
    }
  }, /*#__PURE__*/React.createElement(Div, {
    className: cnCalendar('divider'),
    motion: true,
    shouldRender: mode === 'year' || type !== 'date'
  }), /*#__PURE__*/React.createElement(Component, blockProps), /*#__PURE__*/React.createElement("div", {
    className: cnCalendar('controls')
  }, additionalControls, /*#__PURE__*/React.createElement(Button, {
    "aria-label": "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435",
    className: cnCalendar('clear'),
    disabled: isValueEmpty(value),
    onClick: onClear,
    size: isMobile ? 'l' : 'm',
    view: "secondary-on-secondary"
  }, "\u0441\u0431\u0440\u043E\u0441\u0438\u0442\u044C"), /*#__PURE__*/React.createElement(Button, _extends({}, completeButtonProps || {}, {
    "aria-label": "\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F",
    className: cnCalendar('submit'),
    onClick: onComplete,
    size: isMobile ? 'l' : 'm'
  }), "\u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C")))));
};
export var Calendar = /*#__PURE__*/forwardRef(CalendarRender);