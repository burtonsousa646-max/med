export {};
//# sourceMappingURL=setupTestingLibrary.d.ts.map