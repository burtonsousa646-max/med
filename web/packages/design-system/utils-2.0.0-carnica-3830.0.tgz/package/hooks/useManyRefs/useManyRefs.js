import { createRef, useMemo } from 'react';
export var useManyRefs = function useManyRefs(elements, params) {
  var _ref = params !== null && params !== void 0 ? params : {},
    getItemId = _ref.getItemId,
    updateDeps = _ref.updateDeps;
  return useMemo(function () {
    if (typeof elements === 'number') {
      return Array.from({
        length: elements
      }).map(function () {
        return /*#__PURE__*/createRef();
      });
    }
    var obj = {};
    elements.forEach(function (item) {
      if (typeof item === 'string') {
        var _ref2;
        obj[(_ref2 = getItemId === null || getItemId === void 0 ? void 0 : getItemId(item)) !== null && _ref2 !== void 0 ? _ref2 : item] = /*#__PURE__*/createRef();
      } else {
        var _ref3;
        obj[(_ref3 = getItemId === null || getItemId === void 0 ? void 0 : getItemId(item)) !== null && _ref3 !== void 0 ? _ref3 : ''] = /*#__PURE__*/createRef();
      }
    });
    return obj;
  }, [elements, updateDeps]);
};