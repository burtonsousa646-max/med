import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["direction"];
import { IconArrowsLeft, IconArrowsRight } from '@carnica/graphics';
import React, { forwardRef } from 'react';
import { Button } from "../../Button";
export var BannerControl = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var _ref$direction = _ref.direction,
    direction = _ref$direction === void 0 ? 'next' : _ref$direction,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(Button, _extends({}, otherProps, {
    "aria-label": direction === 'next' ? 'Следующий слайд' : 'Предыдущий слайд',
    iconLeft: direction === 'prev' ? IconArrowsLeft : IconArrowsRight,
    onlyIcon: true,
    ref: ref,
    size: "l",
    view: "secondary",
    "data-t-id": "BannerEmbla-BannerControl"
  }));
});