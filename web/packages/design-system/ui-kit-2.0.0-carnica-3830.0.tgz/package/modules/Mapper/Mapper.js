import React from 'react';
import { withRenderFlag } from '@beef/react';
// eslint-disable-next-line @typescript-eslint/comma-dangle
var MapperRender = function MapperRender(_ref) {
  var items = _ref.items,
    children = _ref.children;
  if (!items) {
    return null;
  }
  return /*#__PURE__*/React.createElement(React.Fragment, null, items.map(function (item, index) {
    return children(item, index);
  }));
};
export var Mapper = withRenderFlag(MapperRender);