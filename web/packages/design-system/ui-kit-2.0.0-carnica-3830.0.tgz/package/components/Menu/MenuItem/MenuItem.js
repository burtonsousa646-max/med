import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["icon", "label", "description", "className", "disabled", "invert", "tagName", "state"];
import React from 'react';
import { cnBem, forwardRefWithTag } from '@carnica/utils';
import { Text } from "../../Text";
import styles from "./styles.module.css";
import { getIconColor, getTextColor } from "./utils";
var cnMenuItem = cnBem('menu--item', styles);
export var MenuItem = forwardRefWithTag(function (props, ref) {
  var Icon = props.icon,
    label = props.label,
    description = props.description,
    className = props.className,
    disabled = props.disabled,
    invert = props.invert,
    _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'button' : _props$tagName,
    _props$state = props.state,
    state = _props$state === void 0 ? 'default' : _props$state,
    otherProps = _objectWithoutProperties(props, _excluded);
  var Tag = tagName;
  var isAccentFlag = !(disabled || state === 'faded');
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cnMenuItem({
      disabled: disabled
    }, [className]),
    role: "menuitem"
  }, otherProps, tagName === 'button' ? {
    disabled: disabled
  } : {}, {
    ref: ref,
    "data-t-id": "Menu-MenuItem"
  }), Icon && /*#__PURE__*/React.createElement(Icon, {
    color: getIconColor(isAccentFlag, invert),
    iconClassName: cnMenuItem('icon', {
      state: state
    }),
    size: "m"
  }), label && /*#__PURE__*/React.createElement(Text, {
    align: "left",
    className: cnMenuItem('label', {
      withIcon: !!Icon,
      state: state
    }),
    color: getTextColor('label', isAccentFlag, invert),
    variant: "body-medium"
  }, label), description && /*#__PURE__*/React.createElement(Text, {
    align: "left",
    className: cnMenuItem('description', {
      state: state
    }),
    color: getTextColor('description', isAccentFlag, invert),
    variant: "body-small"
  }, description));
});