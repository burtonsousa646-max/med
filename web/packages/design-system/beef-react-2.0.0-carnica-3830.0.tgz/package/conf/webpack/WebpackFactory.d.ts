export = ReactWebpackBuilder;
declare const ReactWebpackBuilder_base: typeof import("@beef/conf/webpack/WebpackFactory");
declare class ReactWebpackBuilder extends ReactWebpackBuilder_base {
    get plugins(): {
        MiniCssExtractPlugin: typeof MiniCssExtractPlugin;
        CssMinimizerPlugin: typeof CssMinimizerPlugin;
        HtmlWebpackPlugin: typeof HtmlWebpackPlugin;
        ReactRefreshWebpackPlugin: typeof ReactRefreshWebpackPlugin;
        FriendlyErrorOverlayPlugin: typeof FriendlyErrorOverlayPlugin;
        ForkTsCheckerWebpackPlugin: typeof ForkTsCheckerWebpackPlugin;
        CopyWebpackPlugin: typeof import("copy-webpack-plugin");
        BeefCacheBuildDependencyPlugin: typeof import("@beef/conf/webpack-26").BeefCacheBuildDependencyPlugin;
        CircularDependencyPlugin: typeof import("circular-dependency-plugin");
        WebpackManifestPlugin: typeof import("webpack-manifest-plugin").WebpackManifestPlugin;
        BeefManifestPlugin: typeof import("@beef/conf/webpack-26").BeefManifestPlugin;
        EnvironmentPlugin: typeof import("webpack").EnvironmentPlugin;
        TerserPlugin: typeof import("terser-webpack-plugin");
        DefinePlugin: typeof import("webpack").DefinePlugin;
    };
    get rawLoaders(): {
        expose: string;
        css: string;
        pcss: string;
        style: string;
        svgr: string;
        miniCssExtractLoader: string;
        pug: string;
        babel: string;
    };
    get rules(): {
        pcss: RegExp;
        css: RegExp;
        img: RegExp;
        font: RegExp;
        svg: RegExp;
        pug: RegExp;
        docs: RegExp;
        code: RegExp;
    };
    get loaders(): {
        expose: (exposes: any) => {
            loader: string;
            options: {
                exposes: any;
            };
        };
        pcss: {
            loader: string;
        };
        css: {
            loader: string;
            options: {
                importLoaders: number;
                modules: {
                    localIdentName: string;
                    getLocalIdent: (context: any, localIdentName: any, localName?: string, options?: {}) => any;
                };
            };
        };
        rawCss: {
            loader: string;
        };
        svg: {
            loader: string;
            options: {
                svgo: boolean;
                svgoConfig: {
                    plugins: (string | {
                        name: string;
                        params: {
                            overrides: {
                                removeViewBox: boolean;
                                removeUselessDefs: boolean;
                                cleanupIds: {
                                    minify: boolean;
                                    remove: boolean;
                                };
                                collapseGroups: boolean;
                            };
                        };
                    })[];
                };
            };
            type: string;
            issuer: RegExp;
        };
        url: {
            loader: any;
            options: {
                limit: number;
                name: string;
            };
            type: string;
        };
        cssExtract: {
            loader: string;
            options: {
                emit: boolean;
            };
        } | undefined;
        style: {
            loader: string;
        } | undefined;
        pug: {
            loader: string;
        };
        resourceUrl: {
            resourceQuery: RegExp;
            type: string;
        };
        babel: {
            loader: string;
            options: {
                cacheDirectory: boolean;
                rootMode: string;
            };
            exclude: RegExp;
        };
        asset: {
            type: string;
        };
    };
    get config(): {
        module: {
            rules: any[];
        };
        plugins: any[];
        optimization: {
            minimizer: any[];
            minimize: any;
        };
        devServer: {
            client: {
                overlay: boolean;
                reconnect: number;
                progress: boolean;
            };
            hot?: boolean | undefined;
            port?: string | number | undefined;
            headers?: {
                'Access-Control-Allow-Origin': string;
            } | undefined;
        };
        mode: string;
        snapshot: {
            managedPaths: RegExp[];
        };
        watchOptions: {
            ignored: RegExp;
            followSymlinks: boolean;
        };
        output: {
            filename: string;
            publicPath: string;
            path: string;
            hotUpdateMainFilename: string;
            hotUpdateChunkFilename: string;
            assetModuleFilename: string;
            clean: boolean;
            devtoolModuleFilenameTemplate: (info: any) => any;
        };
        resolve: {
            extensions: string[];
            symlinks: boolean;
        };
        devtool: string;
        stats: {
            chunks: boolean;
            colors: boolean;
            children: boolean;
        };
    };
    getHtmlOptions: (name: any) => any;
    injectHMREntry: (entry: any) => any[];
}
import MiniCssExtractPlugin = require("mini-css-extract-plugin");
import CssMinimizerPlugin = require("css-minimizer-webpack-plugin");
import HtmlWebpackPlugin = require("html-webpack-plugin");
import ReactRefreshWebpackPlugin = require("@pmmmwh/react-refresh-webpack-plugin");
import FriendlyErrorOverlayPlugin = require("./FriendlyErrorOverlayWebpackPlugin");
import ForkTsCheckerWebpackPlugin = require("fork-ts-checker-webpack-plugin/lib/plugin");
//# sourceMappingURL=WebpackFactory.d.ts.map