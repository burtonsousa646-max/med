import { BaseObserver } from './baseObserverMock';
interface IntersectionObserverEntry {
    isIntersecting: boolean;
    target: Element;
}
type IntersectionCallback = (entries: IntersectionObserverEntry[], observer: MockIntersectionObserver) => void;
interface IntersectionObserverEntry {
    isIntersecting: boolean;
    target: Element;
}
export declare class MockIntersectionObserver extends BaseObserver<IntersectionCallback> {
    observe(target: Element): void;
    unobserve(): void;
    disconnect(): void;
}
export {};
//# sourceMappingURL=mockIntersectionObserver.d.ts.map