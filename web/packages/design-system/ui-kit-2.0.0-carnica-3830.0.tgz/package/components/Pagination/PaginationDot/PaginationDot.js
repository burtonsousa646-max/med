import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["active", "paused", "onComplete", "duration"],
  _excluded2 = ["className", "active", "direction", "paused", "autoplay", "onComplete", "duration"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useEffect } from 'react';
import { cnBem } from '@carnica/utils';
import { animate, motion, useMotionValue, useTransform } from 'framer-motion';
import styles from "../styles.module.css";
var cnPaginationDot = cnBem('pagination', styles);
var AnimatedPaginationDot = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var active = _ref.active,
    paused = _ref.paused,
    onComplete = _ref.onComplete,
    _ref$duration = _ref.duration,
    duration = _ref$duration === void 0 ? 6000 : _ref$duration,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var progress = useMotionValue(0);
  var scale = useTransform(progress, [0, 1], [0, 1]);
  useEffect(function () {
    if (!active) {
      /* eslint-disable-next-line @typescript-eslint/no-floating-promises */
      animate(progress, 0, {
        duration: 0.2,
        ease: 'easeIn'
      });
      return function () {};
    }
    progress.set(0);
    var controls = animate(progress, 1, {
      duration: duration / 1000,
      ease: 'easeOut',
      onComplete: onComplete
    });
    return function () {
      controls.stop();
    };
  }, [active, duration]);
  useEffect(function () {
    var _progress$animation2;
    if (!active) return;
    if (paused) {
      var _progress$animation;
      (_progress$animation = progress.animation) === null || _progress$animation === void 0 || _progress$animation.pause();
      return;
    }
    (_progress$animation2 = progress.animation) === null || _progress$animation2 === void 0 || _progress$animation2.play();
  }, [paused, active]);
  return /*#__PURE__*/React.createElement(motion.button, _extends({}, otherProps, {
    ref: ref,
    style: _objectSpread(_objectSpread({}, otherProps.style), {}, _defineProperty({}, '--pagination-progress-scale', scale))
  }));
});
export var PaginationDot = /*#__PURE__*/forwardRef(function (_ref2, ref) {
  var className = _ref2.className,
    active = _ref2.active,
    _ref2$direction = _ref2.direction,
    direction = _ref2$direction === void 0 ? 'row' : _ref2$direction,
    paused = _ref2.paused,
    autoplay = _ref2.autoplay,
    onComplete = _ref2.onComplete,
    duration = _ref2.duration,
    otherProps = _objectWithoutProperties(_ref2, _excluded2);
  var defaultProps = _objectSpread(_objectSpread({}, otherProps), {}, {
    'aria-current': active ? 'page' : undefined,
    className: cnPaginationDot('dot', {
      active: active,
      direction: direction,
      autoplay: autoplay
    }, [className]),
    type: 'button'
  });
  if (autoplay) {
    return /*#__PURE__*/React.createElement(AnimatedPaginationDot, _extends({}, defaultProps, {
      active: active,
      duration: duration,
      onComplete: onComplete,
      paused: paused,
      "data-t-id": "Pagination-PaginationDot"
    }));
  }
  return /*#__PURE__*/React.createElement("button", _extends({}, defaultProps, {
    ref: ref,
    type: "button"
  }));
});