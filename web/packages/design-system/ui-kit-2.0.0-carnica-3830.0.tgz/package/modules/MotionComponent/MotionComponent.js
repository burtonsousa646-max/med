import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["tagName", "motion", "children", "shouldRender"];
import { forwardRefWithMotionTag } from '@carnica/utils';
import React from 'react';
import { motion as motionComponents } from 'framer-motion';
export var MotionComponent = forwardRefWithMotionTag(function (props, ref) {
  var _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'div' : _props$tagName,
    motion = props.motion,
    children = props.children,
    shouldRender = props.shouldRender,
    otherProps = _objectWithoutProperties(props, _excluded);
  var Tag = tagName;
  if (motion) {
    var Component = typeof tagName === 'string' ? motionComponents[tagName] : motionComponents(tagName);
    return /*#__PURE__*/React.createElement(Component, _extends({}, otherProps, {
      ref: ref,
      "data-t-id": "modules-MotionComponent"
    }), children);
  }
  return /*#__PURE__*/React.createElement(Tag, _extends({}, otherProps, {
    ref: ref
  }), children);
});