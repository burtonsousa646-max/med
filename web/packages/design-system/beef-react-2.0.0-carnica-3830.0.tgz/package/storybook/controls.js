import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
export var getPreparedArgs = function getPreparedArgs(_ref) {
  var _ref$control = _ref.control,
    control = _ref$control === void 0 ? 'text' : _ref$control,
    defaultValue = _ref.defaultValue,
    _ref$name = _ref.name,
    name = _ref$name === void 0 ? 'variant' : _ref$name,
    extraOptions = _ref.extraOptions;
  return {
    argTypes: _defineProperty({}, name, _objectSpread({
      control: control
    }, extraOptions)),
    args: _defineProperty({}, name, defaultValue),
    // Данное свойство заведено чисто для дальнейшего преобразования в типы
    _type: defaultValue
  };
};
export var select = function select(name, options, defaultValue, extraOptions) {
  return getPreparedArgs({
    name: name,
    defaultValue: defaultValue,
    control: 'select',
    extraOptions: _objectSpread({
      options: _toConsumableArray(options)
    }, extraOptions)
  });
};
export var multiSelect = function multiSelect(name, options, defaultValue, extraOptions) {
  return getPreparedArgs({
    name: name,
    defaultValue: defaultValue,
    control: 'multi-select',
    extraOptions: _objectSpread({
      options: options
    }, extraOptions)
  });
};
export var radio = function radio(name, options, defaultValue, extraOptions) {
  return getPreparedArgs({
    name: name,
    defaultValue: defaultValue,
    control: 'radio',
    extraOptions: _objectSpread({
      options: options
    }, extraOptions)
  });
};
export var inlineRadio = function inlineRadio(name, options, defaultValue, extraOptions) {
  return getPreparedArgs({
    name: name,
    defaultValue: defaultValue,
    control: 'inline-radio',
    extraOptions: _objectSpread({
      options: options
    }, extraOptions)
  });
};
export var check = function check(name, options, defaultValue, extraOptions) {
  return getPreparedArgs({
    name: name,
    defaultValue: defaultValue,
    control: 'check',
    extraOptions: _objectSpread({
      options: options
    }, extraOptions)
  });
};
export var inlineCheck = function inlineCheck(name, options, defaultValue, extraOptions) {
  return getPreparedArgs({
    name: name,
    defaultValue: defaultValue,
    control: 'inline-check',
    extraOptions: _objectSpread({
      options: options
    }, extraOptions)
  });
};
export var object = function object(name, defaultValue, extraOptions) {
  return getPreparedArgs({
    control: 'object',
    defaultValue: defaultValue,
    name: name,
    extraOptions: extraOptions
  });
};
export var boolean = function boolean(name, defaultValue, extraOptions) {
  return getPreparedArgs({
    control: 'boolean',
    defaultValue: defaultValue,
    name: name,
    extraOptions: extraOptions
  });
};
export var number = function number(name, defaultValue, extraOptions) {
  return getPreparedArgs({
    control: 'number',
    defaultValue: defaultValue,
    name: name,
    extraOptions: extraOptions
  });
};
export var range = function range(name, defaultValue, extraOptions) {
  return getPreparedArgs({
    control: 'range',
    defaultValue: defaultValue,
    name: name,
    extraOptions: extraOptions
  });
};
export var text = function text(name, defaultValue, extraOptions) {
  return getPreparedArgs({
    control: 'text',
    defaultValue: defaultValue,
    name: name,
    extraOptions: extraOptions
  });
};
export var date = function date(name, defaultValue, extraOptions) {
  return getPreparedArgs({
    control: 'date',
    defaultValue: defaultValue.toISOString(),
    name: name,
    extraOptions: extraOptions
  });
};
export var color = function color(name, defaultValue, extraOptions) {
  return getPreparedArgs({
    control: 'color',
    defaultValue: defaultValue,
    name: name,
    extraOptions: extraOptions
  });
};