import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
// based on http://stackoverflow.com/a/9039885/177710

var iOS_PLATFORM_LIST = ['iPad Simulator', 'iPhone Simulator', 'iPod Simulator', 'iPad', 'iPhone', 'iPod'];
var iosRegExp = new RegExp(iOS_PLATFORM_LIST.join('|'), 'gi');
var _getMobileOS = function _getMobileOS(navigatorInterface, documentInterface) {
  var _navigatorInterface$u;
  // Проверка на Android
  if (/android/i.test(navigatorInterface.userAgent)) {
    return 'android';
  }

  // Используем navigator.userAgentData, если доступен, иначе navigator.platform
  var platform = (navigatorInterface === null || navigatorInterface === void 0 || (_navigatorInterface$u = navigatorInterface.userAgentData) === null || _navigatorInterface$u === void 0 ? void 0 : _navigatorInterface$u.platform) || (navigatorInterface === null || navigatorInterface === void 0 ? void 0 : navigatorInterface.platform);
  if (iOS_PLATFORM_LIST.includes(platform || '') || navigatorInterface.userAgent.includes('Mac') && 'ontouchend' in documentInterface) {
    return 'ios';
  }
  return null;
};

/*
 * Для SSR значение userAgent передаётся с бэкенда.
 */
export var getMobileOS = function getMobileOS() {
  var _userAgent$match;
  var userAgent = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  if (typeof window !== 'undefined') {
    // Клиентский рендеринг
    return _getMobileOS(window.navigator, window.document);
  }

  // SSR: если window не доступен, используем переданный userAgent
  var mockNavigator = {
    userAgent: userAgent,
    platform: '',
    userAgentData: {
      // Небольшой костыль, чтобы при SSR корректно сработала проверка для iOS
      platform: ((_userAgent$match = userAgent.match(iosRegExp)) === null || _userAgent$match === void 0 ? void 0 : _userAgent$match[0]) || ''
    }
  };
  return userAgent ? _getMobileOS(mockNavigator, {}) : null;
};
var parseVersion = function parseVersion(v) {
  if (!v) {
    return null;
  }
  var splited = v.split('.');
  var _splited$map = splited.map(function (el) {
      return Number.isNaN(parseInt(el, 10)) ? undefined : parseInt(el, 10);
    }),
    _splited$map2 = _slicedToArray(_splited$map, 3),
    major = _splited$map2[0],
    minor = _splited$map2[1],
    patch = _splited$map2[2];
  return {
    major: major,
    minor: minor,
    patch: patch
  };
};
export var getBrowserInfo = function getBrowserInfo(agent) {
  if (typeof window === 'undefined' && !agent) return {
    browser: 'unknown',
    version: null
  };
  var ua = agent || navigator.userAgent;
  var browserName;
  var version;
  if (ua.includes('Chrome') && !ua.includes('Edg') && !ua.includes('OPR')) {
    // Chrome (включая Edge на Chromium и Opera)
    browserName = 'Chrome';
    var match = ua.match(/Chrome\/(\d+)/);
    version = match ? match[1] : undefined;
  } else if (ua.includes('Edg')) {
    // Edge (Chromium)
    browserName = 'Edge';
    var _match = ua.match(/Edg\/(\d+)/);
    version = _match ? _match[1] : undefined;
  } else if (ua.includes('Firefox')) {
    // Firefox
    browserName = 'Firefox';
    var _match2 = ua.match(/Firefox\/(\d+)/);
    version = _match2 ? _match2[1] : undefined;
  } else if (ua.includes('Safari') && !ua.includes('Chrome') && !ua.includes('Edg')) {
    // Safari (включая iOS)
    browserName = 'Safari';
    var _match3 = ua.match(/Version\/(\d+(?:\.\d+)*)/);
    version = _match3 ? _match3[1] : undefined;
  } else if (ua.includes('OPR')) {
    // Opera
    browserName = 'Opera';
    var _match4 = ua.match(/OPR\/(\d+)/);
    version = _match4 ? _match4[1] : undefined;
  }
  return {
    browser: browserName,
    version: parseVersion(version)
  };
};
export var getIOSVersion = function getIOSVersion(ua) {
  var os = getMobileOS(ua);
  var userAgent = ua || navigator.userAgent;
  var match = userAgent.match(/OS (\d+)_(\d+)_?(\d+)?/);
  if (os !== 'ios' || !match) {
    return null;
  }
  var major = parseInt(match[1], 10);
  var minor = parseInt(match[2], 10);
  var patch = parseInt(match[3] || '0', 10);
  var _getBrowserInfo = getBrowserInfo(userAgent),
    version = _getBrowserInfo.version,
    browser = _getBrowserInfo.browser;

  // Отдельно для сафари так как там версию ос можно задетектить только через браузер
  return {
    major: browser === 'Safari' ? (version === null || version === void 0 ? void 0 : version.major) || major : major,
    minor: minor,
    patch: patch
  };
};