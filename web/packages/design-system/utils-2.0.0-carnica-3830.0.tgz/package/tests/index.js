import _asyncToGenerator from "@babel/runtime/helpers/asyncToGenerator";
import _regeneratorRuntime from "@babel/runtime/regenerator";
import { act, screen } from '@testing-library/react';
import { toHaveNoViolations } from 'jest-axe';
expect.extend(toHaveNoViolations);
export var getRender = function getRender(testId) {
  return screen.getByTestId(testId);
};
export var testRender = function testRender(render) {
  it('должен рендериться без ошибок', /*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
    var renderedNode, _t;
    return _regeneratorRuntime.wrap(function (_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          if (!(typeof render === 'function')) {
            _context.next = 2;
            break;
          }
          _context.next = 1;
          return render();
        case 1:
          _t = _context.sent;
          _context.next = 3;
          break;
        case 2:
          _t = render;
        case 3:
          renderedNode = _t;
          expect(function () {
            return renderedNode;
          }).not.toThrow();
        case 4:
        case "end":
          return _context.stop();
      }
    }, _callee);
  })));
};
export var executeTestCases = function executeTestCases(testId, render, beforeComponentTest) {
  return function (func) {
    describe("\u041A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442 ".concat(testId), function () {
      beforeComponentTest === null || beforeComponentTest === void 0 || beforeComponentTest();
      if (render) {
        testRender(render);
      }
      func();
    });
  };
};
export var delay = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
    var time,
      _args3 = arguments;
    return _regeneratorRuntime.wrap(function (_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          time = _args3.length > 0 && _args3[0] !== undefined ? _args3[0] : 400;
          return _context3.abrupt("return", act(/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
            return _regeneratorRuntime.wrap(function (_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  return _context2.abrupt("return", new Promise(function (r) {
                    setTimeout(r, time);
                  }));
                case 1:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          }))));
        case 1:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return function delay() {
    return _ref2.apply(this, arguments);
  };
}();
export var getRandomValue = function getRandomValue() {
  var count = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 8;
  return Array.from({
    length: count
  }, function () {
    return Math.floor(Math.random() * 9);
  }).join('');
};
export var NAMING_TEST_MAP = {
  a11y: 'проверка a11y',
  behavior: 'проверка работы компонента',
  props: 'проверка props',
  snapshot: 'snapshot тесты'
};