export function withForwardedRef(WrappedComponent: any): any;
//# sourceMappingURL=withForwardedRef.d.ts.map