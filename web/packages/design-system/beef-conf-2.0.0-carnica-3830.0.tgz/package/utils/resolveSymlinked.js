const path = require('path');
const fs = require('fs');
const {
  createRequire
} = require('module');
const jsonfile = require('jsonfile');
const {
  configRootResolverSync
} = require('./configResolvers');

/**
 * В случае, если модуль по sourcePath залинкован
 *   возвращает sourcePath без symlink-resolution'а
 */
const resolveSymlinkedModuleDir = (sourcePath, cwd = process.cwd()) => {
  // Частый кейс - если путь и так в проекте - то все ок
  const pkgPath = configRootResolverSync('package.json', sourcePath);
  if (sourcePath.indexOf(cwd) === 0) return pkgPath;
  const pkgName = jsonfile.readFileSync(path.join(pkgPath, 'package.json')).name;
  if (!pkgName) return pkgPath;
  const checkPaths = createRequire(`${cwd}/package.json`).resolve.paths(pkgName);
  let resolvedModuleDir;
  const found = checkPaths.some(modulePath => {
    resolvedModuleDir = path.join(modulePath, pkgName);

    // found symlink and it leads to sourcePath
    return fs.existsSync(resolvedModuleDir) && fs.realpathSync(resolvedModuleDir) === pkgPath;
  });
  return found ? resolvedModuleDir : pkgPath;
};
const createRequireLinked = sourcePath => createRequire(path.join(resolveSymlinkedModuleDir(sourcePath), 'package.json'));
module.exports = {
  resolveSymlinkedModuleDir,
  createRequireLinked
};