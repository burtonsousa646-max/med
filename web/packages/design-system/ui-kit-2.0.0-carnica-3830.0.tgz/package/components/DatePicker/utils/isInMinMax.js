import { isWithinInterval } from 'date-fns-new';
var isMinMax = function isMinMax(date, minDate, maxDate) {
  var minDateTime = minDate === null || minDate === void 0 ? void 0 : minDate.getTime();
  var maxDateTime = maxDate === null || maxDate === void 0 ? void 0 : maxDate.getTime();
  if (minDate && maxDate && minDateTime && maxDateTime) {
    return minDateTime < maxDateTime ? isWithinInterval(date, {
      start: minDate,
      end: maxDate
    }) : false;
  }
  var dateTime = date.getTime();
  if (minDateTime && !maxDateTime) {
    return minDateTime <= dateTime;
  }
  if (!minDateTime && maxDateTime) {
    return maxDateTime >= dateTime;
  }
  return true;
};
export var isInMinMaxDate = function isInMinMaxDate(date, minDate, maxDate, startOf, endOf) {
  if (!minDate && !maxDate) {
    return true;
  }
  return isMinMax(date, startOf && minDate && startOf(minDate) || minDate, endOf && maxDate && endOf(maxDate) || maxDate);
};