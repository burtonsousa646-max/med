import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["direction", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnStepper = cnBem('skeleton-stepper', styles);
export var Stepper = function Stepper(_ref) {
  var _ref$direction = _ref.direction,
    direction = _ref$direction === void 0 ? 'vertical' : _ref$direction,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    className: cnStepper(null, [className]),
    height: direction === 'vertical' ? 100 : 44,
    width: direction === 'horizontal' ? 100 : 44
  }, props, {
    "data-t-id": "components-Stepper"
  }));
};