import { extendConfig } from './extend-config';
export declare const baseConfig: ReturnType<typeof extendConfig>;
//# sourceMappingURL=base-config.d.ts.map