import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["lineHeight", "size", "variant", "weight", "color", "align", "transform", "truncate", "tagName", "className", "rows", "style"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import React from 'react';
import { withInnerHTML } from "../../hocs/withInnerHTML";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { composeCSSVariables } from "./utils";
var cnText = cnBem('text', styles);
var TextRender = forwardRefWithMotionTag(function (props, ref) {
  var lineHeight = props.lineHeight,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    variantProp = props.variant,
    _props$weight = props.weight,
    weight = _props$weight === void 0 ? 'regular' : _props$weight,
    _props$color = props.color,
    color = _props$color === void 0 ? 'primary' : _props$color,
    align = props.align,
    transform = props.transform,
    truncate = props.truncate,
    _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'p' : _props$tagName,
    className = props.className,
    rows = props.rows,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _composeCSSVariables = composeCSSVariables({
      lineHeight: lineHeight,
      size: size,
      variant: variantProp,
      weight: weight,
      color: color,
      align: align,
      transform: transform
    }),
    variant = _composeCSSVariables.variant,
    generatedStyles = _composeCSSVariables.generatedStyles;
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnText({
      variant: variant,
      truncate: truncate
    }, [className]),
    ref: ref,
    style: _objectSpread(_objectSpread(_objectSpread({}, style), generatedStyles), truncate ? _defineProperty({}, '--text-rows', rows || 1) : {}),
    tagName: tagName,
    "data-t-id": "components-Text"
  }));
});
export var Text = withInnerHTML(TextRender);