import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["state", "icon", "onAnimationComplete"];
import React from 'react';
import { motion } from 'framer-motion';
import { iconByStateMap } from "./utils";
export var StatusViewIndicatorDynamicIcon = function StatusViewIndicatorDynamicIcon(_ref) {
  var _ref$state = _ref.state,
    state = _ref$state === void 0 ? 'progress' : _ref$state,
    _ref$icon = _ref.icon,
    icon = _ref$icon === void 0 ? iconByStateMap[state] : _ref$icon,
    onAnimationComplete = _ref.onAnimationComplete,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  if (state === 'success') {
    return /*#__PURE__*/React.createElement("svg", _extends({
      height: 60,
      width: 60,
      xmlns: "http://www.w3.org/2000/svg"
    }, otherProps, {
      "data-t-id": "StatusView-StatusViewAnimateBlock"
    }), /*#__PURE__*/React.createElement(motion.path, {
      animate: {
        pathLength: 1,
        opacity: 1
      },
      d: "M14.5 37L23.5 44L44.5 17",
      fill: "transparent",
      initial: {
        pathLength: 0,
        opacity: 0
      },
      onAnimationComplete: onAnimationComplete,
      stroke: "var(--icon-color-white)",
      strokeLinecap: "round",
      strokeWidth: 4.3,
      transition: {
        pathLength: {
          delay: 0.83,
          duration: 0.93,
          ease: 'easeOut'
        },
        opacity: {
          delay: 0.83
        }
      }
    }));
  }
  var Icon = state === 'error' ? iconByStateMap.error : icon;
  return /*#__PURE__*/React.createElement(Icon, _extends({}, otherProps, {
    animate: {
      opacity: 1
    },
    color: state === 'error' ? 'tertiary' : 'black',
    initial: {
      opacity: 0
    },
    motion: true,
    onAnimationComplete: onAnimationComplete,
    size: 60,
    transition: {
      delay: 0.78,
      duration: 0.33,
      ease: 'easeOut'
    }
  }));
};