export interface HookKeys {
    contentKey: string;
    isReady: boolean;
}
export declare const useKeyBasedEffect: (callback: () => () => void, { contentKey, isReady }: Partial<HookKeys>, options?: {}) => void;
//# sourceMappingURL=useKeyBasedEffect.d.ts.map