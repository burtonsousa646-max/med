export var logoSizeMap = {
  xl: 64,
  l: 56,
  m: 44,
  s: 32,
  xs: 24
};
export var avatarSizeMap = {
  xl: 64,
  l: 56,
  m: 44,
  s: 32,
  xs: 24
};
export var iconSizeMap = {
  xl: 32,
  l: 24,
  m: 24,
  s: 16,
  xs: 16
};
export var accentIconSizeMap = {
  xl: 24,
  l: 24,
  m: 16,
  s: 16,
  xs: 16
};
export var textSizeMap = {
  xl: 'body-accent-medium',
  l: 'body-accent-medium',
  m: 'body-accent-small',
  s: 'caption-accent-medium',
  xs: 'caption-accent-medium'
};
export var badgeSizeMap = {
  xl: 's',
  l: 's',
  m: 's',
  s: 'xs',
  xs: 'xs'
};