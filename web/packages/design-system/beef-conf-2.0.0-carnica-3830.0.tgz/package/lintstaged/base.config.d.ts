declare function _exports(fix?: boolean): {
    '!({package,tsconfig}.json)*.{js,jsx,ts,tsx,json}': string;
    '*.{ts,tsx}': string;
    '*.md': string;
    '*.pcss': string;
};
export = _exports;
//# sourceMappingURL=base.config.d.ts.map