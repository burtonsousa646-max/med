import type { IconComponentNames, IconComponentNamesIcon } from '../../types/iconNames';
import type { IconComponent, LogoComponent } from '../../types/IconComponent';
type Component<COLORED extends boolean> = COLORED extends true ? IconComponent : LogoComponent;
export declare const getIconByName: <NAME extends IconComponentNames>(name: NAME) => Component<NAME extends IconComponentNamesIcon ? true : false>;
export {};
//# sourceMappingURL=getIconByName.d.ts.map