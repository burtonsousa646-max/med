import React from 'react';
export declare const GenericLink: (props: React.ComponentProps<"a">) => React.JSX.Element;
//# sourceMappingURL=GenericLink.d.ts.map