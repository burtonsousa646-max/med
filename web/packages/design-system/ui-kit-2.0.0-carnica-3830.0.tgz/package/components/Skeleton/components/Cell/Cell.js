import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["reverse", "round", "color", "invert", "view", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
import { Avatar } from "../Avatar";
var cnCell = cnBem('skeleton-cell', styles);
export var Cell = function Cell(_ref) {
  var reverse = _ref.reverse,
    round = _ref.round,
    color = _ref.color,
    invert = _ref.invert,
    _ref$view = _ref.view,
    view = _ref$view === void 0 ? 'default' : _ref$view,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnCell({
      view: view,
      invert: invert,
      round: round
    }, [className])
  }, props, {
    "data-t-id": "components-Cell"
  }), /*#__PURE__*/React.createElement(Avatar, {
    color: color,
    invert: invert,
    size: "m"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnCell('wrapper', {
      reverse: reverse
    })
  }, /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 24,
    invert: invert,
    width: "100%"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 16,
    invert: invert,
    width: 160
  })));
};