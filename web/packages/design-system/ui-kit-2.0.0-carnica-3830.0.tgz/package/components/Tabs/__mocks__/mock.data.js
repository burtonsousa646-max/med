export var items = [{
  label: 'я первый Tab',
  key: '1'
}, {
  label: 'я второй Tab',
  key: '2'
}, {
  badge: true,
  label: 'я третий Tab',
  key: '3'
}];