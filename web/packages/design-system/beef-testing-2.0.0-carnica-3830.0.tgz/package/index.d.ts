import { SharedOptions } from 'old-msw';
import { convertRoutesToMswHandlers } from './converter';
import { MockResizeObserver } from './__mocks__/mockResizeObserver';
import { MockIntersectionObserver } from './__mocks__/mockIntersectionObserver';
import { mockLottie } from './__mocks__/mockLottie';
export { convertRoutesToMswHandlers };
type MockServerConfig = {
    options?: SharedOptions;
    overridesPath?: string;
    routesPath?: string;
};
interface IMockServer {
    close(): void;
    listen(): void;
    override(routesPath: string): void;
    reset(): void;
}
export declare class MockServer implements IMockServer {
    private readonly server;
    private readonly options?;
    private readonly overridesPath;
    constructor({ routesPath, overridesPath, options, }?: MockServerConfig);
    private composeOverridesPath;
    listen(): void;
    close(): void;
    reset(): void;
    override(...overridePaths: string[]): void;
}
export declare const server: MockServer;
export { MockResizeObserver };
export { MockIntersectionObserver };
export { mockLottie };
//# sourceMappingURL=index.d.ts.map