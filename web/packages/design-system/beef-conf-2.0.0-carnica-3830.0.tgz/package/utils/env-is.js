const isLocalhost = () => (process.env.RUN_ENV || '').indexOf('localhost') === 0;
module.exports = {
  isLocalhost
};