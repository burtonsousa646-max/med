export declare const getMobileOS: (userAgent?: string) => "android" | "ios" | null;
export declare const getBrowserInfo: (agent?: string) => {
    browser: string | undefined;
    version: {
        major: number | undefined;
        minor: number | undefined;
        patch: number | undefined;
    } | null;
};
export declare const getIOSVersion: (ua?: string) => {
    major: number;
    minor: number;
    patch: number;
} | null;
//# sourceMappingURL=detect.d.ts.map