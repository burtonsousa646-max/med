export declare const bemPreset: {
    b: string;
    e: string;
    m: string;
};
//# sourceMappingURL=preset.d.ts.map