import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["portalClassName", "portalProps", "portalRef", "overlayClassName", "isOpen"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { AnimatePresence, motion } from 'framer-motion';
import { useBlockScroll, useIsMobileDimension, useLowPerformanceDevice } from '@carnica/utils/hooks';
import { ThemedPortal } from "../../modules/ThemedPortal";
import styles from "./styles.module.css";
import { contentAnimationMobileSettings, contentAnimationSettings, overlayAnimationSettings } from "./utils";
import { LoadingWindowContent } from "./LoadingWindowContent";
var cnLoadingWindow = cnBem('loading-window', styles);
export var LoadingWindow = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var portalClassName = _ref.portalClassName,
    portalProps = _ref.portalProps,
    portalRef = _ref.portalRef,
    overlayClassName = _ref.overlayClassName,
    isOpen = _ref.isOpen,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  useBlockScroll(isOpen);
  var isMobile = useIsMobileDimension();
  var isLowPerformance = useLowPerformanceDevice();
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait",
    "data-t-id": "components-LoadingWindow"
  }, isOpen && /*#__PURE__*/React.createElement(ThemedPortal, _extends({}, portalProps, {
    "aria-atomic": true,
    "aria-label": "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430. \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u043F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435.",
    "aria-live": "assertive",
    "aria-modal": true,
    className: cnLoadingWindow(null, [portalClassName]),
    motion: true,
    ref: portalRef,
    role: "dialog"
  }), /*#__PURE__*/React.createElement(motion.div, _extends({}, overlayAnimationSettings, {
    "aria-hidden": true,
    className: cnLoadingWindow('overlay', {
      lowPerformance: isLowPerformance
    }, [overlayClassName])
  })), /*#__PURE__*/React.createElement(LoadingWindowContent, _extends({}, isMobile ? contentAnimationMobileSettings : contentAnimationSettings, otherProps, {
    ref: ref,
    "data-t-id": "components-LoadingWindow"
  }))));
});