import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "accent", "size", "tagName", "children", "view", "disabled", "isCurrentDate", "rootProps"];
import React from 'react';
import { cnBem, forwardRefWithTag } from '@carnica/utils';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnCell = cnBem('cell', styles);
export var Cell = forwardRefWithTag(function (props, ref) {
  var className = props.className,
    accent = props.accent,
    _props$size = props.size,
    size = _props$size === void 0 ? 's' : _props$size,
    _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'button' : _props$tagName,
    children = props.children,
    _props$view = props.view,
    view = _props$view === void 0 ? 'default' : _props$view,
    disabled = props.disabled,
    isCurrentDate = props.isCurrentDate,
    rootProps = props.rootProps,
    otherProps = _objectWithoutProperties(props, _excluded);
  var Tag = tagName;
  var params = tagName === 'button' ? {
    disabled: disabled,
    type: 'button'
  } : {};
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-type": "cell",
    role: "gridcell"
  }, rootProps, {
    className: cnCell('root', [rootProps === null || rootProps === void 0 ? void 0 : rootProps.className]),
    "data-t-id": "DatePicker-Cell"
  }), /*#__PURE__*/React.createElement(Tag, _extends({}, otherProps, params, {
    className: cnCell({
      size: size,
      view: view,
      accent: accent,
      notInteractive: tagName !== 'button'
    }, [className]),
    ref: ref
  }), /*#__PURE__*/React.createElement(Text, {
    className: cnCell('label', {
      isCurrentDate: isCurrentDate
    }),
    color: "primary-fake-invert",
    variant: size === 's' ? 'body-small' : 'body-large',
    "data-t-id": "DatePicker-Cell"
  }, children)));
});