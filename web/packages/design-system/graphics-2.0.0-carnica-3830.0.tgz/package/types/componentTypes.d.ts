export type { BaseIconComponent, BaseIconProps } from '../components/BaseIcon/types';
//# sourceMappingURL=componentTypes.d.ts.map