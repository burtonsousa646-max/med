export declare const useMutableRef: <T>(value: T) => import("react").RefObject<T>;
//# sourceMappingURL=useMutableRef.d.ts.map