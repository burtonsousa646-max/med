import { useEffect, useRef } from 'react';
import { useIsDesktopDimension } from '@carnica/utils/hooks';
var getIsIOS = function getIsIOS() {
  var _window;
  return /iP(ad|od|hone)/i.test((_window = window) === null || _window === void 0 || (_window = _window.navigator) === null || _window === void 0 ? void 0 : _window.userAgent);
};
export var useBlockIOSNavigation = function useBlockIOSNavigation(inputRef) {
  var elementsRef = useRef([]);
  var isIOS = getIsIOS();
  var isDesktop = useIsDesktopDimension();
  var setFlags = function setFlags(flag) {
    var _elementsRef$current;
    (_elementsRef$current = elementsRef.current) === null || _elementsRef$current === void 0 || _elementsRef$current.forEach(function (el) {
      el.disabled = flag;
    });
  };
  var blockAll = function blockAll() {
    if (isIOS && !isDesktop) {
      elementsRef.current = [];
      var elements = document.querySelectorAll('input,select,textarea');
      for (var i = 0; i < elements.length; i += 1) {
        var element = elements.item(i);
        if (!element.isEqualNode(inputRef.current) && !element.disabled) {
          elementsRef.current.push(element);
        }
      }
      setFlags(true);
    }
  };
  var onFocus = function onFocus() {
    blockAll();
  };
  var onBlur = function onBlur() {
    setFlags(false);
  };
  useEffect(function () {
    blockAll();
    return function () {
      return setFlags(false);
    };
  }, [isIOS]);
  return {
    onFocus: onFocus,
    onBlur: onBlur
  };
};