import { UseKeys } from './types';
export declare const useKeys: UseKeys;
//# sourceMappingURL=useKeys.d.ts.map