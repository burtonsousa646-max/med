import { UseDeprecationWarningParams } from './types';
export declare const useDeprecationWarning: (deprecatedProps: UseDeprecationWarningParams) => void;
//# sourceMappingURL=useDeprecationWarning.d.ts.map