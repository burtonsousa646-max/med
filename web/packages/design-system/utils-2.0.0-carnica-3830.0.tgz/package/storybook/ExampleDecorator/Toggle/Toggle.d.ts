import React from 'react';
export type TogglerPropItems<T> = Array<{
    icon?: string;
    label?: string;
    value: T;
}>;
export declare const Toggler: <T extends string>({ items, value, onChange, }: {
    items: TogglerPropItems<T>;
    onChange: (val: T) => void;
    value: T;
}) => React.JSX.Element;
//# sourceMappingURL=Toggle.d.ts.map