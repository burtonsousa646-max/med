import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["tagName", "icon", "badge", "disabled", "invert", "href", "state", "priority", "className", "onClick", "style"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithTag } from '@carnica/utils';
import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import { useFlag } from '@carnica/utils/hooks';
import { MotionComponent } from "../../../modules/MotionComponent";
import { Badge } from "../../Badge/V3";
import styles from "./styles.module.css";
import { decomposeBadge, getIconColors } from "./utils";
var cnButtonGroupItem = cnBem('button-group-item', styles);
export var ButtonGroupItem = forwardRefWithTag(function (props, ref) {
  var _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'button' : _props$tagName,
    Icon = props.icon,
    badge = props.badge,
    disabled = props.disabled,
    invert = props.invert,
    href = props.href,
    state = props.state,
    priority = props.priority,
    className = props.className,
    onClick = props.onClick,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isPressed = _useFlag2[0],
    setIsPressed = _useFlag2[1];
  var timerRef = useRef(undefined);
  var handleClick = useCallback(function (e) {
    if (disabled) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    clearTimeout(timerRef.current);
    onClick === null || onClick === void 0 || onClick(e);
    setIsPressed.on();
    timerRef.current = setTimeout(setIsPressed.off, 310);
  }, [disabled, onClick]);
  var badgeProps = useMemo(function () {
    return decomposeBadge(badge);
  }, [badge]);
  useEffect(function () {
    return function () {
      clearTimeout(timerRef.current);
    };
  }, []);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnButtonGroupItem({
      disabled: disabled
    }, [className]),
    "data-pressed": isPressed,
    onClick: handleClick,
    ref: ref,
    style: _objectSpread(_objectSpread({}, style), getIconColors({
      priority: priority,
      invert: invert,
      state: state
    })),
    tagName: tagName
  }, tagName === 'button' ? {
    type: 'button',
    disabled: disabled
  } : {
    href: href
  }, {
    "data-t-id": "ButtonGroup-ButtonGroupItem"
  }), /*#__PURE__*/React.createElement(Icon, {
    className: cnButtonGroupItem('icon'),
    customColor: "currentColor",
    size: "m",
    "data-t-id": "ButtonGroup-ButtonGroupItem"
  }), badgeProps && /*#__PURE__*/React.createElement(Badge, _extends({
    className: cnButtonGroupItem('badge')
  }, badgeProps)));
});