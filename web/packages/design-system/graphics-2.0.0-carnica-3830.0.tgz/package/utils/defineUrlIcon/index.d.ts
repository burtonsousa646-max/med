export * from './defineUrlIcon';
//# sourceMappingURL=index.d.ts.map