import React from 'react';
import type { ExampleDecoratorProps } from './types';
export declare const ExampleDecorator: React.FC<ExampleDecoratorProps>;
//# sourceMappingURL=ExampleDecorator.d.ts.map