export var getLocalStorageValue = function getLocalStorageValue(key) {
  try {
    return localStorage.getItem(key);
  } catch (err) {
    console.error(err);
  }
  return null;
};
export var setLocalStorageValue = function setLocalStorageValue(key, data) {
  try {
    localStorage.setItem(key, data);
    return true;
  } catch (err) {
    console.error(err);
  }
  return false;
};