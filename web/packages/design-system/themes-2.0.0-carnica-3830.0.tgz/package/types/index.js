export var lineHeight = ['3xs', '2xs', 'xs', 's', 'm', 'l', 'xl', '2xl', '3xl', '4xl', '5xl'];
export var fontSize = ['2xs', 'xs', 's', 'm', 'l', 'xl', '2xl'];
// TODO: В случае изменения набора шрифтов в Beeline Sans поправить
export var fontWeight = ['regular', 'medium', 'bold', 'black'];
export var spaces = ['xs', 's', 'm', 'l', 'xl', '2xl', '2xs', '3xl', '3xs', '4xl', '5xl', '6xl', 'negative-400', 'negative-300', 'negative-250', 'negative-200', 'negative-150', 'negative-100', '0', '50', '100', '150', '200', '250', '300', '400', '450', '500', '600', '800', '1000', '1200', '1600', '2000'];
export var radius = ['50', '100', '200', '300', '400', '600', '800', '1000', 'infinite', 'circle'];
export var size = ['200', '300', '400', '500', '600', '800', '1000', '1100', '1200', '1400', '1600', '2400'];
export var border = ['25', '50'];