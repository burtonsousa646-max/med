import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
/**
 * Выбирает необходимое склонение существительного в замисимости от количества единиц
 * @param {array} nounArray массив из 3х возможных склонений слова (напр. ['устройство', 'устройства', 'устройств'])
 * @param {number} number количество единиц
 * @returns {string} необходимое склонение
 */
export var determineDeclension = function determineDeclension(nounArray, number) {
  var num = Math.floor(number);
  var cases = [2, 0, 1, 1, 1, 2];
  var index = num % 100 > 4 && num % 100 < 20 ? 2 : cases[num % 10 < 5 ? num % 10 : 5];
  return nounArray[index];
};

/**
 * Форматирует строку в представление номера телефона
 * @param {string} phone номер телефона
 * @returns {string} отформатированное значение
 */
export var formatPhone = function formatPhone() {
  var phone = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  return phone.replace(/^(\d{3})(\d{3})(\d{2})(\d{2})/, '+7 $1 $2-$3-$4');
};

/**
 * Форматирует число или число в строковом формате в строку с валютой
 * @param {number | string | undefined} value значение
 * @returns {string} отформатированное значение
 */
export var getLocalCurrencyStr = function getLocalCurrencyStr(value) {
  var isNumber = typeof value === 'number' && (value || value === 0);
  var isNumberString = typeof value === 'string' && value.trim() && !Number.isNaN(Number(value));
  if (!(isNumber || isNumberString)) {
    return '';
  }
  var num = typeof value === 'string' ? Number(value) : value;
  var _num$toString$split = num.toString().split('.'),
    _num$toString$split2 = _slicedToArray(_num$toString$split, 2),
    decimal = _num$toString$split2[1];
  var withCurrency = "".concat(num).concat(decimal && decimal.length === 1 ? 0 : '', " \u20BD");
  var separator = ' ';
  return withCurrency.replace(/(\d{1,3}(?=(?:\d{3})+(?!\d)))/g, "$1".concat(separator)).replace('.', ',');
};
export var templateParser = function templateParser(str, vars) {
  if (!str) return '';
  if (!vars) return str;
  return str.replace(/{{(\w+)}}/gi, function (full, match) {
    return vars[match];
  });
};

// [один, два, пять]
export var dictionary = {
  additional: ['дополнительный', 'дополнительных', 'дополнительных'],
  additionalDevices: ['доп. устройство', 'доп. устройства', 'доп. устройств'],
  app: ['приложение', 'приложения', 'приложений'],
  channels: ['канал', 'канала', 'каналов'],
  days: ['день', 'дня', 'дней'],
  daysGenitive: ['дня', 'дней', 'дней'],
  gbGenetive: ['гигабайт', 'гигабайта', 'гигабайт'],
  goods: ['товар', 'товара', 'товаров'],
  minGenetive: ['минуту', 'минуты', 'минут'],
  minutes: ['минута', 'минуты', 'минут'],
  month: ['месяц', 'месяца', 'месяцев'],
  monthGenetive: ['месяца', 'месяцев', 'месяцев'],
  number: ['номер', 'номера', 'номеров'],
  numbers: ['номер', 'номера', 'номеров'],
  numbersCount: ['номером', 'номерами', 'номерами'],
  numbersGenitive: ['номера', 'номеров', 'номеров'],
  office: ['офис', 'офиса', 'офисов'],
  packages: ['пакет', 'пакета', 'пакетов'],
  peopleGenetive: ['человека', 'человек', 'человек'],
  secGenetive: ['секунду', 'секунды', 'секунд'],
  seconds: ['секунда', 'секунды', 'секунд'],
  hours: ['час', 'часа', 'часов'],
  service: ['услуга', 'услуги', 'услуг'],
  tariff: ['тариф', 'тарифа', 'тарифов'],
  weeks: ['неделя', 'недели', 'недель']
};
export function translate(word, number) {
  return determineDeclension(dictionary[word], number);
}