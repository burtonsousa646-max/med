import type { AnimatedIconComponent } from './types';
export declare const AnimatedIcon: AnimatedIconComponent;
//# sourceMappingURL=AnimatedIcon.d.ts.map