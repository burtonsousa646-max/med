import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["buttons", "className", "convertButton"],
  _excluded2 = ["attributes", "icon", "label", "ref"];
import { cnBem } from '@carnica/utils';
import React, { useMemo } from 'react';
import { IconInfoOutline } from '@carnica/graphics';
import { withRenderCondition } from '@beef/react';
import { Button } from "../../Button";
import styles from "./styles.module.css";
var cnErrorEmptyStateButtons = cnBem('error-empty-state-buttons', styles);
var ErrorEmptyStateButtonsRender = function ErrorEmptyStateButtonsRender(_ref) {
  var buttons = _ref.buttons,
    className = _ref.className,
    convertButton = _ref.convertButton,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var items = useMemo(function () {
    return convertButton ? buttons === null || buttons === void 0 ? void 0 : buttons.map(convertButton) : buttons;
  }, [convertButton, buttons]);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnErrorEmptyStateButtons(null, [className])
  }, otherProps, {
    "data-t-id": "ErrorEmptyState-ErrorEmptyStateButtons"
  }), items === null || items === void 0 ? void 0 : items.map(function (_ref2, i) {
    var attributes = _ref2.attributes,
      _ref2$icon = _ref2.icon,
      icon = _ref2$icon === void 0 ? IconInfoOutline : _ref2$icon,
      label = _ref2.label,
      ref = _ref2.ref,
      params = _objectWithoutProperties(_ref2, _excluded2);
    return /*#__PURE__*/React.createElement(Button, _extends({}, attributes, params, {
      iconLeft: icon,
      key: cnErrorEmptyStateButtons('item', {
        i: i
      }),
      mode: "grid",
      ref: ref,
      size: "l",
      view: i === 0 ? 'primary' : 'secondary-on-primary'
    }), label);
  }));
};
export var ErrorEmptyStateButtons = withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref3) {
    var buttons = _ref3.buttons;
    return !!(buttons !== null && buttons !== void 0 && buttons.length);
  }
})(ErrorEmptyStateButtonsRender);