import { cnBem } from '@carnica/utils';
import lightTheme from "../styles/color/light-palette.module.css";
import darkTheme from "../styles/color/dark-palette.module.css";
import lightThemeV2 from "../styles/colorV2/light-palette.module.css";
import darkThemeV2 from "../styles/colorV2/dark-palette.module.css";
var lightThemeMap = {
  v1: lightTheme,
  v2: lightThemeV2
};
var darkThemeMap = {
  v1: darkTheme,
  v2: darkThemeV2
};
var getCn = function getCn(theme) {
  var version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'v1';
  var map = theme === 'dark' ? darkThemeMap : lightThemeMap;
  return cnBem("theme-".concat(theme), map[version]);
};
export var cnTheme = function cnTheme(theme, version) {
  return getCn(theme, version)();
};