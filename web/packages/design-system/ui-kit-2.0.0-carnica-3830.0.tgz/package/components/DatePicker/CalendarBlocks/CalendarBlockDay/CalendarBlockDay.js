import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["date", "label"],
  _excluded2 = ["currentVisibleDate", "range", "setCurrentVisibleDate", "value", "onChange", "isComposed", "minDate", "maxDate", "disableDates", "locale", "isAnimationFinished"];
import React, { useMemo } from 'react';
import { cnBem } from '@carnica/utils';
import { usePrevious } from '@beef/react';
import { eachDayOfInterval, endOfWeek, format, formatDate, setMonth, startOfWeek } from 'date-fns-new';
import { AnimatePresence, motion } from 'framer-motion';
import { useCalendarGridKeyboardHandler } from "../../hooks/useCalendarGridKeyboardHandler";
import { Grid } from "../../Grid";
import { Cell } from "../../Cell";
import { MonthSelector } from "../../MonthSelector";
import { useDaysList } from "../../hooks/useDaysList";
import { getMonthList } from "../../utils/date";
import styles from "./styles.module.css";
import { variants } from "./utils";
var cnCalendarBlockDay = cnBem('day-block', styles);
var GridRender = function GridRender(_ref) {
  var currentVisibleDate = _ref.currentVisibleDate,
    setCurrentVisibleDate = _ref.setCurrentVisibleDate,
    range = _ref.range,
    value = _ref.value,
    onChange = _ref.onChange,
    maxDate = _ref.maxDate,
    minDate = _ref.minDate,
    disableDates = _ref.disableDates,
    isComposed = _ref.isComposed,
    isAnimationFinished = _ref.isAnimationFinished;
  var days = useDaysList({
    currentVisibleDate: currentVisibleDate,
    range: range,
    value: value,
    onChange: onChange,
    minDate: minDate,
    maxDate: maxDate,
    disableDates: disableDates
  });
  var _useCalendarGridKeybo = useCalendarGridKeyboardHandler({
      items: days,
      currentVisibleDate: currentVisibleDate,
      setCurrentVisibleDate: setCurrentVisibleDate,
      isComposed: isComposed,
      value: value,
      type: 'date',
      disableDates: disableDates,
      maxDate: maxDate,
      minDate: minDate,
      isAnimationFinished: isAnimationFinished
    }),
    refs = _useCalendarGridKeybo.refs,
    onKeyDownByIndex = _useCalendarGridKeybo.onKeyDownByIndex;
  return /*#__PURE__*/React.createElement(Grid, {
    className: cnCalendarBlockDay('days'),
    "data-t-id": "CalendarBlocks-CalendarBlockDay"
  }, days.map(function (item, i) {
    var date = item.date,
      label = item.label,
      params = _objectWithoutProperties(item, _excluded);
    return /*#__PURE__*/React.createElement(Cell, _extends({
      key: date.toDateString()
    }, params, {
      "data-t-date": formatDate(date, 'yyyy-MM-dd'),
      onKeyDown: onKeyDownByIndex(i, item),
      ref: refs[i]
    }), label);
  }));
};
export var CalendarBlockDay = function CalendarBlockDay(props) {
  var currentVisibleDate = props.currentVisibleDate,
    range = props.range,
    setCurrentVisibleDate = props.setCurrentVisibleDate,
    value = props.value,
    onChange = props.onChange,
    isComposed = props.isComposed,
    minDate = props.minDate,
    maxDate = props.maxDate,
    disableDates = props.disableDates,
    locale = props.locale,
    isAnimationFinished = props.isAnimationFinished,
    otherProps = _objectWithoutProperties(props, _excluded2);
  var previousMonth = usePrevious(currentVisibleDate.getMonth()) || currentVisibleDate.getMonth();
  var diff = currentVisibleDate.getMonth() - previousMonth;
  var weekDays = useMemo(function () {
    return eachDayOfInterval({
      start: startOfWeek(currentVisibleDate, {
        weekStartsOn: 1
      }),
      end: endOfWeek(currentVisibleDate, {
        weekStartsOn: 1
      })
    }).map(function (day) {
      return format(day, 'EEEEEE', {
        locale: locale
      });
    });
  }, [locale]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(MonthSelector, {
    items: getMonthList(currentVisibleDate),
    locale: locale,
    onChange: function onChange(month) {
      return setCurrentVisibleDate === null || setCurrentVisibleDate === void 0 ? void 0 : setCurrentVisibleDate(setMonth(currentVisibleDate, month.getMonth()));
    },
    value: currentVisibleDate
  }), /*#__PURE__*/React.createElement(motion.div, _extends({}, otherProps, {
    className: cnCalendarBlockDay(),
    layoutRoot: true
  }), /*#__PURE__*/React.createElement(Grid, {
    "aria-hidden": true,
    className: cnCalendarBlockDay('weeks')
  }, weekDays.map(function (el) {
    return /*#__PURE__*/React.createElement(Cell, {
      disabled: true,
      key: el,
      tagName: "div"
    }, el);
  })), /*#__PURE__*/React.createElement(motion.div, {
    "aria-hidden": true,
    className: cnCalendarBlockDay('divider'),
    role: "presentation"
  }), /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: diff,
    initial: false
  }, /*#__PURE__*/React.createElement(motion.div, {
    animate: "center",
    className: cnCalendarBlockDay('container'),
    custom: diff,
    exit: "exit",
    initial: "enter",
    key: currentVisibleDate.getMonth(),
    transition: {
      x: {
        type: 'spring',
        stiffness: 300,
        damping: 30
      },
      opacity: {
        duration: 0.2
      }
    },
    variants: variants
  }, /*#__PURE__*/React.createElement(GridRender, {
    currentVisibleDate: currentVisibleDate,
    disableDates: disableDates,
    isAnimationFinished: isAnimationFinished,
    isComposed: isComposed,
    maxDate: maxDate,
    minDate: minDate,
    onChange: onChange,
    range: range,
    setCurrentVisibleDate: setCurrentVisibleDate,
    value: value
  })))));
};