import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["show", "children", "disabled"],
  _excluded2 = ["disabled", "placeholder", "rightSide", "value"];
import React, { forwardRef } from 'react';
import { useFlag } from '@carnica/utils/hooks';
import { cnBem } from '@carnica/utils';
import { AnimatedIcon, IconEyeCloseFilled, IconEyeOpenFilled } from '@carnica/graphics';
import { Input } from "../../Input";
import styles from "./styles.module.css";
var cnPasswordInput = cnBem('password-input', styles);
var RightSide = function RightSide(_ref) {
  var show = _ref.show,
    children = _ref.children,
    disabled = _ref.disabled,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(React.Fragment, null, children, !disabled && /*#__PURE__*/React.createElement(AnimatedIcon, _extends({}, props, {
    activeIndex: show ? 1 : 0,
    className: cnPasswordInput('button'),
    color: "tertiary",
    icons: [IconEyeCloseFilled, IconEyeOpenFilled],
    tagName: "button",
    type: "button",
    "data-t-id": "AdvancedInputs-PasswordInput"
  })));
};
export var PasswordInput = /*#__PURE__*/forwardRef(function (props, ref) {
  var disabled = props.disabled,
    _props$placeholder = props.placeholder,
    placeholder = _props$placeholder === void 0 ? 'знаете только вы' : _props$placeholder,
    rightSide = props.rightSide,
    value = props.value,
    otherProps = _objectWithoutProperties(props, _excluded2);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isPasswordVisible = _useFlag2[0],
    setIsPasswordVisible = _useFlag2[1];
  return /*#__PURE__*/React.createElement(Input, _extends({}, otherProps, {
    disabled: disabled,
    placeholder: placeholder,
    ref: ref,
    rightSide: /*#__PURE__*/React.createElement(RightSide, {
      disabled: disabled,
      onClick: setIsPasswordVisible.toggle,
      show: isPasswordVisible
    }, rightSide),
    type: isPasswordVisible ? 'text' : 'password',
    value: value
  }));
});