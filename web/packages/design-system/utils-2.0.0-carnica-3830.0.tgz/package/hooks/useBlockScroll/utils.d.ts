export declare const isBodyOverflowing: () => boolean;
export declare const getContainer: (node?: HTMLElement | React.RefObject<HTMLElement>) => HTMLElement;
export declare const getSelector: (id: string, node?: HTMLElement) => string;
//# sourceMappingURL=utils.d.ts.map