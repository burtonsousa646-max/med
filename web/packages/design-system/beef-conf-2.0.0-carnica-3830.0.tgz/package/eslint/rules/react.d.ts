export let rules: {
    'react/destructuring-assignment': number;
    'react/function-component-definition': (number | {
        namedComponents: string;
        unnamedComponents: string;
    })[];
    'react/jsx-no-target-blank': number;
    'react/jsx-props-no-spreading': number;
    'react/no-array-index-key': number;
    'react/no-multi-comp': number;
    'react/prop-types': {}[];
    'react/forbid-prop-types': number;
    'react/require-default-props': number;
    'react/sort-comp': (number | {
        order: string[];
    })[];
    'react/state-in-constructor': number;
    'react-hooks/exhaustive-deps': number;
};
//# sourceMappingURL=react.d.ts.map