import React, { ComponentType } from 'react';
export type HocifyOptions<HocProps, InputProps, CompProps> = {
    enhanceOpts?: (opts: InputProps, props: CompProps) => HocProps;
    enhanceProps?: (props: CompProps, opts: InputProps) => CompProps;
};
export declare const hocify: <HocProps, InputProps, RestictedProps extends Record<string, any>>(ContainerComponent: ComponentType<HocProps>, { enhanceOpts, enhanceProps, }?: HocifyOptions<HocProps, InputProps, RestictedProps>) => (opts: InputProps) => <Props extends RestictedProps>(WrappedComponent: React.ComponentType<Props>) => React.FC<Props>;
export declare const hocifyManually: <RestrictedProps extends Record<string, any>>(fn: (WrappedComponent: ComponentType<RestrictedProps>) => (props: any) => any) => <Props extends RestrictedProps>(WrappedComponent: ComponentType<Props>) => React.FC<Props>;
//# sourceMappingURL=hocs.d.ts.map