import _defineProperty from "@babel/runtime/helpers/defineProperty";
import React from 'react';
import { cnBem } from "../../../bem";
import styles from "./styles.module.css";
var cnToggler = cnBem('toggle', styles);
export var Toggler = function Toggler(_ref) {
  var items = _ref.items,
    value = _ref.value,
    onChange = _ref.onChange;
  var activeIndex = items.findIndex(function (el) {
    return el.value === value;
  });
  return /*#__PURE__*/React.createElement("div", {
    className: cnToggler(),
    style: _defineProperty({}, '--toggler-active-index', activeIndex),
    "data-t-id": "ExampleDecorator-Toggle"
  }, items.map(function (item, i) {
    return /*#__PURE__*/React.createElement("button", {
      className: cnToggler('control', {
        active: i === activeIndex
      }),
      key: item.value,
      onClick: function onClick() {
        return onChange(item.value);
      },
      type: "button"
    }, item.icon ? /*#__PURE__*/React.createElement("span", {
      className: cnToggler('icon'),
      style: _defineProperty({}, '--icon-url', "url(".concat(item.icon, ")"))
    }) : /*#__PURE__*/React.createElement("span", {
      className: cnToggler('label')
    }, item.label));
  }));
};