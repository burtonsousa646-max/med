export var getMixinsList = function getMixinsList(entityName, mix) {
  var list = [];
  var mixins = Array.isArray(mix) ? mix : [mix];
  mixins.forEach(function (value) {
    if (value && typeof value === 'string') {
      value.split(' ').forEach(function (val) {
        if (val !== entityName) {
          list.push(val);
        }
      });
    }
  });
  return list;
};