/**
 * Lazy compilation strikes with reading call of undefined at options.factory
 * Issue cannot be fixed, even by forking
 */
module.exports = ({
  error,
  stackFrames
}) => {
  return error.message === "Cannot read properties of undefined (reading 'call')" && stackFrames?.[0]?.functionName === 'options.factory' && stackFrames?.[0]?._originalFileName?.endsWith?.('webpack/runtime/publicPath');
};