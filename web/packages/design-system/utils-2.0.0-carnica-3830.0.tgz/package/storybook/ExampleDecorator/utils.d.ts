import type { ThemeProviderBaseThemes } from './ThemeProvider/types';
import type { TogglerPropItems } from './Toggle';
import type { ExampleDecoratorPropThemeVersion } from './types';
export declare const themeItems: TogglerPropItems<ThemeProviderBaseThemes>;
export declare const versionItems: TogglerPropItems<ExampleDecoratorPropThemeVersion>;
//# sourceMappingURL=utils.d.ts.map