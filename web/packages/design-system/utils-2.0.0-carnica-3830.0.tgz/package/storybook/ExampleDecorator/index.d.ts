export * from './ExampleDecorator';
//# sourceMappingURL=index.d.ts.map