import React from 'react';
export declare const useBlockIOSNavigation: (inputRef: React.MutableRefObject<HTMLInputElement | null>) => {
    onFocus: () => void;
    onBlur: () => void;
};
//# sourceMappingURL=useBlockIOSNavigation.d.ts.map