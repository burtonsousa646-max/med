import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["loader", "options"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { filterLoaders } from "../webpack/helpers";
export var oneOfLoaders = function oneOfLoaders() {
  for (var _len = arguments.length, loaders = new Array(_len), _key = 0; _key < _len; _key++) {
    loaders[_key] = arguments[_key];
  }
  return {
    oneOf: filterLoaders(loaders).map(function (_ref) {
      var loader = _ref.loader,
        options = _ref.options,
        params = _objectWithoutProperties(_ref, _excluded);
      return _objectSpread(_objectSpread({}, loader ? {
        use: [{
          loader: loader,
          options: options
        }]
      } : {}), params);
    })
  };
};
export var stringifyRule = function stringifyRule(rule) {
  // eslint-disable @typescript-eslint/no-base-to-string
  var str = rule === null || rule === void 0 ? void 0 : rule.toString();
  if (!str || str === '[object Object]') {
    throw new Error("\u0421\u0435\u0440\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u043D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u0430. \u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E RegExp, \u0441\u0442\u0440\u043E\u043A\u0438 \u0438 \u0438\u0445 \u043C\u0430\u0441\u0441\u0438\u0432\u044B, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ".concat(JSON.stringify(rule)));
  }
  return str;
};