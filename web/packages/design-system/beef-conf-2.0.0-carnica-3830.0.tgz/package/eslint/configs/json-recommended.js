// config preset for json files
module.exports = {
  extends: ['plugin:jsonc/base', 'plugin:jsonc/recommended-with-json', 'plugin:jsonc/prettier'],
  parser: 'jsonc-eslint-parser',
  rules: {
    'jsonc/sort-keys': ['error', 'asc', {
      allowLineSeparatedGroups: false,
      caseSensitive: true,
      minKeys: 2,
      natural: true
    }],
    'no-irregular-whitespace': 'warn'
  }
};