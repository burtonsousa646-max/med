import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "value", "position", "className", "menu", "onItemClick", "onMenuClick", "onMenuButtonClick", "itemGetters", "menuGetters", "convertItem", "convertMenu", "invert", "menuAttributes", "closeMenuOnScroll", "buttonScrollThrough"];
import React, { forwardRef, useLayoutEffect } from 'react';
import { cnBem } from '@carnica/utils';
import { useFlag } from '@carnica/utils/hooks';
import { compose, getIOSVersion } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { dataConverter } from "./utils";
import { TabBarNav } from "./TabBarNav";
import { TabBarMenu } from "./TabBarMenu";
var cnTabBar = cnBem('tabbar', styles);
var TabBarRender = function TabBarRender(props, ref) {
  var _props$items = props.items,
    items = _props$items === void 0 ? [] : _props$items,
    value = props.value,
    _props$position = props.position,
    position = _props$position === void 0 ? 'default' : _props$position,
    className = props.className,
    menu = props.menu,
    onItemClick = props.onItemClick,
    onMenuClick = props.onMenuClick,
    onMenuButtonClick = props.onMenuButtonClick,
    itemGetters = props.itemGetters,
    menuGetters = props.menuGetters,
    convertItem = props.convertItem,
    convertMenu = props.convertMenu,
    invert = props.invert,
    menuAttributes = props.menuAttributes,
    closeMenuOnScroll = props.closeMenuOnScroll,
    buttonScrollThrough = props.buttonScrollThrough,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    withIos26Overlay = _useFlag2[0],
    setWithIos26Overlay = _useFlag2[1];
  useLayoutEffect(function () {
    var _getIOSVersion;
    return setWithIos26Overlay.set(((_getIOSVersion = getIOSVersion()) === null || _getIOSVersion === void 0 ? void 0 : _getIOSVersion.major) === 26);
  }, []);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnTabBar({
      position: position,
      hasOverlay: withIos26Overlay,
      invert: invert
    }, [className]),
    ref: ref,
    "data-t-id": "components-TabBar"
  }), /*#__PURE__*/React.createElement(TabBarMenu, _extends({}, menuAttributes || {}, {
    className: cnTabBar('button'),
    closeMenuOnScroll: closeMenuOnScroll,
    convertMenu: convertMenu,
    getters: menuGetters,
    invert: invert,
    items: menu,
    onMenuButtonClick: onMenuButtonClick,
    onMenuClick: onMenuClick,
    position: position,
    "data-t-id": "components-TabBar"
  })), /*#__PURE__*/React.createElement(TabBarNav, {
    buttonScrollThrough: buttonScrollThrough,
    className: cnTabBar('wrapper', {
      position: position
    }),
    convertItem: convertItem,
    getters: itemGetters,
    invert: invert,
    items: items,
    onItemClick: onItemClick,
    position: position,
    value: value
  }));
};
export var TabBar = compose(withDataConverter(dataConverter), forwardRef)(TabBarRender);