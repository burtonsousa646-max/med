import React from 'react';
export type UseManyRefsElements = number | object[] | string[];
export type UseManyRefsPropGetItemId<ESTIMATE extends UseManyRefsElements> = ESTIMATE extends object[] ? (item: ESTIMATE[number]) => string : ESTIMATE extends string[] ? (item: ESTIMATE[number]) => string : (item: number) => string;
export type UseManyRefsResult<ELEMENT, ESTIMATE extends UseManyRefsElements> = ESTIMATE extends string[] ? Record<ESTIMATE[number], React.RefObject<ELEMENT | null>> : ESTIMATE extends object[] ? Record<string, React.RefObject<ELEMENT | null>> : Array<React.RefObject<ELEMENT | null>>;
export type UseManyRefsParams<ESTIMATE extends UseManyRefsElements> = {
    updateDeps?: unknown[];
} & (ESTIMATE extends number ? {
    getItemId?: never;
} : {
    getItemId?: UseManyRefsPropGetItemId<ESTIMATE>;
});
//# sourceMappingURL=types.d.ts.map