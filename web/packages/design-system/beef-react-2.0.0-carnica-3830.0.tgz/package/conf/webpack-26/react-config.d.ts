import { extendConfig } from '@beef/conf/webpack-26';
export declare const reactConfig: ReturnType<typeof extendConfig>;
//# sourceMappingURL=react-config.d.ts.map