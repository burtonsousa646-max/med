import React from 'react';
import { TagTypeAttributes, TagTypes } from './TagType';
export type PropsWithHTMLAttributes<Props, HTMLElement> = Props & Omit<React.HTMLAttributes<HTMLElement>, 'css' | keyof Props>;
export type PropsWithHTMLAttributesAndRef<Props, HTMLElement> = PropsWithHTMLAttributes<React.PropsWithoutRef<Props>, HTMLElement> & React.RefAttributes<HTMLElement>;
type PropsForTagElement<Tag extends React.ElementType | TagTypes> = Tag extends TagTypes ? TagTypeAttributes<Tag> : Omit<React.ComponentProps<Tag>, keyof React.HTMLAttributes<HTMLElement>> & React.HTMLAttributes<HTMLElement>;
export type PropsWithJsxAttributes<Props, Tag extends TagTypes = 'div'> = Omit<Props & Omit<TagTypeAttributes<Tag>, keyof Props>, 'css'>;
type TagComponent<Tag extends React.ElementType> = React.ComponentProps<Tag> extends React.HTMLAttributes<HTMLElement> ? Tag : never;
type TagName<Tag extends React.ElementType | TagTypes> = Tag extends TagTypes ? Tag : TagComponent<Tag>;
export type PropsWithTagAttributes<Props, AllowedTags extends TagTypes, Tag extends AllowedTags | React.ElementType> = Props & {
    tagName?: TagName<Tag>;
} & Omit<PropsForTagElement<Tag>, keyof Props>;
export type ComponentWithTag<Props, AllowedTags extends TagTypes, DefaultTag extends AllowedTags> = <Tag extends AllowedTags | React.ElementType = DefaultTag>(props: PropsWithTagAttributes<Props, AllowedTags, Tag> & React.RefAttributes<Element>) => React.ReactElement | null;
export {};
//# sourceMappingURL=PropsWithAttributes.d.ts.map