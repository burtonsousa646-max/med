import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import { LogoAkbars, LogoAlfabank, LogoArvand, LogoBspb, LogoDomrfbank, LogoEnergobank, LogoEnergotransbank, LogoFinambank, LogoGazprombank, LogoHomecredit, LogoHumo, LogoMinbank, LogoMkb, LogoModulbank, LogoNationalStandardBank, LogoOpen, LogoOzonbank, LogoPochtabank, LogoPrimsotsbank, LogoRaiffeisen, LogoRencredit, LogoRosbank, LogoRosselkhozbank, LogoRsb, LogoSberbank, LogoSdco, LogoSovcombank, LogoTinkoff, LogoTkbbank, LogoTochkabank, LogoUnicreditbank, LogoUralsib, LogoVtb, LogoWbBank, LogoWebmoney, defineUrlIcon } from '@carnica/graphics';
export var items = [{
  key: 'sber',
  avatar: {
    logo: LogoSberbank
  },
  title: 'Сбербанк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'raif',
  avatar: {
    logo: LogoRaiffeisen
  },
  title: 'Райфайзен',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'alfa',
  avatar: {
    logo: LogoAlfabank
  },
  title: 'Альфа-банк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'tink',
  avatar: {
    logo: LogoTinkoff
  },
  title: 'Тинькоф',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'vtb',
  avatar: {
    logo: LogoVtb
  },
  title: 'ВТБ',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'pochta',
  avatar: {
    logo: LogoPochtabank
  },
  title: 'Почта-банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'tochka',
  avatar: {
    logo: LogoTochkabank
  },
  title: 'Точка-банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'gaz',
  avatar: {
    logo: LogoGazprombank
  },
  title: 'Газпромбанк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'open',
  avatar: {
    logo: LogoOpen
  },
  title: 'Открытие',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'home',
  avatar: {
    logo: LogoHomecredit
  },
  title: 'Хоумбанк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'modul',
  avatar: {
    logo: LogoModulbank
  },
  title: 'Модуль-банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'rsb',
  avatar: {
    logo: LogoRsb
  },
  title: 'РСБ',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'sovcom',
  avatar: {
    logo: LogoSovcombank
  },
  title: 'Совкомбанк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'tk',
  avatar: {
    logo: LogoTkbbank
  },
  title: 'ТК банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'energotrans',
  avatar: {
    logo: LogoEnergotransbank
  },
  title: 'Энерготрансбанк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'bspb',
  avatar: {
    logo: LogoBspb
  },
  title: 'Банк Санкт-Петербурга',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'finam',
  avatar: {
    logo: LogoFinambank
  },
  title: 'Финам банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'min',
  avatar: {
    logo: LogoMinbank
  },
  title: 'Московский индустриальный банк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'humo',
  avatar: {
    logo: LogoHumo
  },
  title: 'Хумо',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'arvand',
  avatar: {
    logo: LogoArvand
  },
  title: 'Арванд',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'national',
  avatar: {
    logo: LogoNationalStandardBank
  },
  title: 'Национал-стандарт банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'primsots',
  avatar: {
    logo: LogoPrimsotsbank
  },
  title: 'Примсоц банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'sdco',
  avatar: {
    logo: LogoSdco
  },
  title: 'СДЦО',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'ros',
  avatar: {
    logo: LogoRosbank
  },
  title: 'Росбанк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'energo',
  avatar: {
    logo: LogoEnergobank
  },
  title: 'Энергобанк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'webmoney',
  avatar: {
    logo: LogoWebmoney
  },
  title: 'Вебмани',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'youmoney',
  avatar: {
    logo: LogoWebmoney
  },
  title: 'Ю-мани',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'ozon',
  avatar: {
    logo: LogoOzonbank
  },
  title: 'Озон-банк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'wb',
  avatar: {
    logo: LogoWbBank
  },
  title: 'ВБ-банк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'rshb',
  avatar: {
    logo: LogoRosselkhozbank
  },
  title: 'Россельхозбанк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'uralsib',
  avatar: {
    logo: LogoUralsib
  },
  title: 'Уралсиб',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'mkb',
  avatar: {
    logo: LogoMkb
  },
  title: 'МКБ',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'dom',
  avatar: {
    logo: LogoDomrfbank
  },
  title: 'Дом РФ банк',
  subTitle: 'предпочтительный банк',
  groupKey: 1
}, {
  key: 'unicredit',
  avatar: {
    logo: LogoUnicreditbank
  },
  title: 'Юникредит банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'akbars',
  avatar: {
    logo: LogoAkbars
  },
  title: 'Акбарс-банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}, {
  key: 'rencredit',
  avatar: {
    logo: LogoRencredit
  },
  title: 'Ренкредит банк',
  subTitle: 'предпочтительный банк',
  groupKey: 2
}];
export var groups = [{
  label: 'популярные',
  key: 1
}, {
  label: 'все',
  key: 'all'
}];
var countries = ['Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'AntiguaAndBarbuda', 'Argentina', 'Armenia', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan', 'Bolivia', 'BosniaAndHerzegovina', 'Botswana', 'Brazil', 'Brunei', 'Bulgaria', 'BurkinaFaso', 'Burundi', 'CaboVerde', 'Cambodia', 'Cameroon', 'Canada', 'CentralAfricanRepublic', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros', 'CongoDemocratic', 'CongoRepublic', 'CostaRica', 'CoteDlvoire', 'Croatia', 'Cuba', 'Cyprus', 'CzechRepublic', 'Denmark', 'Dijbouti', 'Dominica', 'DominicanRepublic', 'Ecuador', 'Egypt', 'ElSalvador', 'EquatorialGuinea', 'Eritrea', 'Estonia', 'Eswatini', 'Ethiopia', 'Fiji', 'Finland', 'France', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Greece', 'Grenada', 'Guatemala', 'GuineaBissau', 'Guinea', 'Guyana', 'Haiti', 'Honduras', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali', 'Malta', 'MarshallIslands', 'Mauritania', 'Mauritius', 'Mexico', 'Micronesia', 'Moldova', 'Monaco', 'Mongolia', 'Montenegro', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'NewZealand', 'Nicaragua', 'Niger', 'Nigeria', 'NorthKorea', 'NorthMacedonia', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Palestine', 'Panama', 'PapuaNewGuinea', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 'Rwanda', 'SaintKittsAndNevis', 'SaintLucia', 'SaintVincentAndTheGrenadines', 'Samoa', 'SanMarino', 'SaoTomeAndPrincipe', 'SaudiArabia', 'Senegal', 'Serbia', 'Seychelles', 'SierraLeone', 'Singapore', 'Slovakia', 'Slovenia', 'SolomonIslands', 'Somalia', 'SouthAfrica', 'SouthKorea', 'SouthSudan', 'Spain', 'SriLanka', 'Sudan', 'Suriname', 'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'TimorLeste', 'Togo', 'Tonga', 'TrinidadAndTobago', 'Tunisia', 'Turkey', 'Turkmenistan', 'Uganda', 'Ukraine', 'UnitedArabEmirates', 'UnitedKingdom', 'UnitedStatesOfAmerica', 'Uruguay', 'Uzbekistan', 'Vatican', 'Venezuela', 'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe'];
var letters = countries.reduce(function (acc, country) {
  var letter = country.charAt(0);
  if (acc.indexOf(letter) !== -1) {
    return acc;
  }
  return [].concat(_toConsumableArray(acc), [letter]);
}, []);
export var countryGroups = [{
  label: 'все',
  key: 'all'
}].concat(_toConsumableArray(letters.map(function (letter, i) {
  return {
    label: "\u0441\u0442\u0440\u0430\u043D\u044B \u043D\u0430 \u0431\u0443\u043A\u0432\u0443 ".concat(letter),
    key: i
  };
})));
export var countriesList = countries.map(function (name) {
  return {
    title: name,
    subTitle: "\u0441\u0442\u0440\u0430\u043D\u0430 \u043D\u0430 \u0431\u0443\u043A\u0432\u0443 ".concat(name[0]),
    key: name,
    avatar: {
      logo: defineUrlIcon({
        url: "https://static.beeline.ru/upload/images/carnica/flags/Flag".concat(name, "Rounded.svg"),
        multiColor: false
      })
    },
    groupKey: letters.indexOf(name.charAt(0))
  };
});