export function filter(obj: any, fn: any): {};
export function getTsCheckEslintConfigPath(): string;
export const isFixMode: boolean;
export function resolvePlugin(pluginPath: any): any;
//# sourceMappingURL=utils.d.ts.map