export { reactConfig } from './react-config';
export { reactToolkit } from './react-toolkit';
export type { BuildEnv, CssMinimizerPluginCssNano, CssMinimizerPluginEsbuild } from './types';
export { extendConfig, extendPlugin, extendToolkit, useConfig, usePlugin, useRule, } from '@beef/conf/webpack-26';
//# sourceMappingURL=index.d.ts.map