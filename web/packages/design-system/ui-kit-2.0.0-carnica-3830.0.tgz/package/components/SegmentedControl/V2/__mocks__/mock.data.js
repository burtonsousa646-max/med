import { IconTrashOutline } from '@carnica/graphics';
export var items = [{
  label: 'text',
  key: 1
}, {
  label: 'disabled',
  disabled: true,
  key: 2
}, {
  label: 'icon',
  icon: IconTrashOutline,
  key: 3,
  badge: '-20%'
}];
export var simpleItems = Array.from({
  length: 5
}).map(function (_, i) {
  return {
    label: "item ".concat(i + 1),
    key: i
  };
});