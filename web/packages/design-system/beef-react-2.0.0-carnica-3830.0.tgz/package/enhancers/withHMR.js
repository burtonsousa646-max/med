/**
 * @deprecated no longer required, fast-refresh is configuration-free
 * Will probably be removed in future versions
 */
export var withHMR = function withHMR() {
  return function (WrappedComponent) {
    return WrappedComponent;
  };
};