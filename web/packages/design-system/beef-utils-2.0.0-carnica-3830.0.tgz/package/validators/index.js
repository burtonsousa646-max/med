/** FIXME: move to final forms */

var URL_PATTERN = new RegExp('^(https?:\\/\\/)?' +
// protocol
'((([a-zа-яё\\d]([a-zа-яё\\d-]*[a-zа-яё\\d])*)\\.)+[a-zа-яё]{2,}|' +
// domain name
'((\\d{1,3}\\.){3}\\d{1,3}))' +
// OR ip (v4) address
'(\\:\\d+)?(\\/[-a-zа-яё\\d%_.~+]*)*' +
// port and path
'(\\?[;&a-zа-яё\\d%_.~+=-]*)?' +
// query string
'(\\#[-a-zа-яё\\d_]*)?$', 'i'); // fragment locator

/**
 * Function used to inject validators into form controlled by redux-forms
 * @param getValidators {function} - a function returning dict of field to validators
 * @returns {function(values)} - takes values and returns large object with errors for every separate validator
 *
 * Iterate fields that have validators and each validator individually
 * gather field errors in a large object and return it
 */
export var composeFormValidator = function composeFormValidator(getValidators) {
  return function (values) {
    values = values || {};
    var validators = getValidators();
    return Object.keys(validators).reduce(function (errors, name) {
      var fieldValidatorsList = validators[name] || [];
      if (typeof fieldValidatorsList === 'function') {
        fieldValidatorsList = [fieldValidatorsList];
      }
      fieldValidatorsList.some(function (fieldValidator) {
        var fieldError = fieldValidator(values[name], values);
        if (fieldError) {
          errors[name] = fieldError;
          return true;
        }
        return false;
      });
      return errors;
    }, {});
  };
};
export var composeRequiredValidator = function composeRequiredValidator(message) {
  return function (value) {
    return value && (
    // value should not be empty
    typeof value !== 'string' ||
    // also it should either be not string
    value.replace(/^\s*(.*?)\s*$/, '$1').length) // or not just spaces
    ? undefined : message;
  };
};
export var composePhoneValidator = function composePhoneValidator(message) {
  return function (value) {
    return /** validator does not make field required */!/^9[0-9]{9}$/.test(value) ? message : undefined;
  };
};
export var composeEmailValidator = function composeEmailValidator(message) {
  return function (value) {
    /** validator does not make field required */
    if (!value || value.length === 0) return undefined;
    return /^([A-Za-z0-9_-]+\.)*[A-Za-z0-9_-]+@[A-Za-z0-9_-]+(\.[A-Za-z0-9_-]+)*\.[a-z]{2,6}$/.test(value) ? undefined : message || '';
  };
};
export var composeCheckedValidator = function composeCheckedValidator(message) {
  return function (value) {
    return !value ? message : undefined;
  };
};
export var composeNameValidator = function composeNameValidator(message) {
  return function (value) {
    if (value.length < 1) return message;
    if (value.replace(/ /g, '').length === 0) return message;
    return /^(?![- ])[A-Za-zёЁА-Яа-я -]{0,60}$/.test(value) ? undefined : message;
  };
};
export var composeSlugValidator = function composeSlugValidator(message) {
  return function (value) {
    /** validator does not make field required */
    if (!value || value.length === 0) return undefined;
    if (value.replace(/[^a-zA-Zа-яА-ЯёЁ]/g, '').length === 0) return message;
    return undefined;
  };
};
export var composeNumberValidator = function composeNumberValidator(message, _ref) {
  var _ref$min = _ref.min,
    min = _ref$min === void 0 ? null : _ref$min,
    _ref$max = _ref.max,
    max = _ref$max === void 0 ? null : _ref$max;
  return function (value) {
    /** validator does not make field required */
    if (!value) return undefined;
    if (min !== null && value < min || max !== null && value > max) return message;
    return undefined;
  };
};
export var composeLengthValidator = function composeLengthValidator(message, _ref2) {
  var _ref2$min = _ref2.min,
    min = _ref2$min === void 0 ? null : _ref2$min,
    _ref2$max = _ref2.max,
    max = _ref2$max === void 0 ? null : _ref2$max;
  return function (value) {
    /** validator does not make field required */
    if (!value) return undefined;
    if (min !== null && value.length < min || max !== null && value.length > max) return message;
    return undefined;
  };
};
export var composeUrlValidator = function composeUrlValidator(message) {
  return function (value) {
    /** validator does not make field required */
    if (!value || value.length === 0) return undefined;
    if (!URL_PATTERN.test(value)) return message;
    return undefined;
  };
};
export var composeDateValidator = function composeDateValidator(message, _ref3) {
  var _ref3$min = _ref3.min,
    min = _ref3$min === void 0 ? null : _ref3$min,
    _ref3$max = _ref3.max,
    max = _ref3$max === void 0 ? null : _ref3$max;
  return function (value) {
    /** validator does not make field required */
    if (!value || typeof value === 'string' && value.length === 0) return undefined;
    if (min !== null && new Date(value).getTime() < min.getTime() || max !== null && new Date(value).getTime() > max.getTime()) return message;
    return undefined;
  };
};

/**
 * given key: value object with errors,
 * concatenates all the errors into single string, separated by dot and space
 */
export var mergeErrorObject = function mergeErrorObject(errors) {
  var ignoreFields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  return Object.keys(errors).filter(function (key) {
    return ignoreFields.indexOf(key) === -1;
  }).map(function (key) {
    return errors[key].replace(/\.$/, '');
  }).join('. ');
};