/* eslint-disable no-console */
const path = require('path');
const rimraf = require('rimraf');

/**
 * Функция, которая рекурсивно удаляет файлы и директории,
 * которые соответствуют списку паттернов (deleteList),
 * внутри другой директории (startPath)
 *
 * @param {String} startPath
 * @param {String[]} deleteList
 */
function deleteItems(startPath, deleteList) {
  try {
    return Promise.all(deleteList.map(async pattern => {
      const _path = path.resolve(startPath, pattern).replaceAll('\\', '/');
      return new Promise(res => {
        rimraf(_path, {
          glob: true
        }, res);
      }).then((...args) => console.log(`Successfully removed ${_path}`, ...args));
    }));
  } catch (e) {
    console.error('Could not delete items', e);
    return Promise.resolve(null);
  }
}
module.exports = {
  deleteItems
};