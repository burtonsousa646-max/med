const {
  rules: airbnbTsRules
} = require('eslint-config-airbnb-typescript/lib/shared');
const {
  rules: recommendedTsRules
} = require('@typescript-eslint/eslint-plugin').configs.recommended;
const {
  rules: recommendedTypeCheckedRules
} = require('@typescript-eslint/eslint-plugin').configs['recommended-type-checked'];
const {
  rules: disableTypeCheckedRules
} = require('@typescript-eslint/eslint-plugin').configs['disable-type-checked'];
const settings = require('./configs/settings');
const {
  rules: customTsRules
} = require('./rules/typescript');
const {
  filter
} = require('./utils');
const {
  resolveProjectReferences
} = require('../utils');
const isTypeCheckedRule = (_, rule) => !!disableTypeCheckedRules[rule];
module.exports = {
  ...settings,
  parser: require.resolve('@typescript-eslint/parser'),
  parserOptions: {
    project: resolveProjectReferences(),
    EXPERIMENTAL_useProjectService: true
  },
  /**
   * NOTE: Собираем правила по конфигам, чтобы можно было из них отфильтровать
   *   требующие запущенный project service
   */
  rules: filter({
    ...recommendedTsRules,
    ...recommendedTypeCheckedRules,
    ...airbnbTsRules,
    ...customTsRules
  }, isTypeCheckedRule)
};