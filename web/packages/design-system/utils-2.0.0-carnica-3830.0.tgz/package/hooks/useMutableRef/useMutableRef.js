import { useRef } from 'react';
export var useMutableRef = function useMutableRef(value) {
  var ref = useRef(value);
  ref.current = value;
  return ref;
};