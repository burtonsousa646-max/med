const fs = require('fs');
const path = require('path');
const {
  isModuleAvailable
} = require('@beef/conf/utils');
const readDirSchemaSync = rootDir => fs.existsSync(rootDir) ? fs.readdirSync(rootDir).map(fileName => ({
  filePath: path.join(rootDir, fileName),
  name: path.parse(fileName).name
})).reduce((accum, {
  name,
  filePath
}) => ({
  ...accum,
  [name]: {
    name,
    filePath
  }
}), {}) : {};

/**
 * Returns Record<name, path> for pug/html templates taken either from project views or server base views
 * @param fn {(options: { name: string, filePath: string }) => any}
 */
const mapViewFiles = fn => {
  // what's the use of views if there is no server
  if (!isModuleAvailable('@beef/server')) return [];
  const serverPath = path.dirname(require.resolve('@beef/server'));
  return Object.values({
    ...readDirSchemaSync(path.join(serverPath, './views')),
    ...readDirSchemaSync(path.join(serverPath, './src/views')),
    ...readDirSchemaSync(path.join(process.cwd(), './server/views'))
  }).map(fn);
};
const {
  provideSmartGetLocalIdent,
  replaceNonCSSCharacters
} = require('./getLocalIdent');
module.exports = {
  mapViewFiles,
  replaceNonCSSCharacters,
  provideSmartGetLocalIdent,
  errorFilters: {
    silentFilter: require.resolve('./FriendlyErrorOverlayWebpackPlugin/filters/silent-filter.js'),
    lazyCompilationFilter: require.resolve('./FriendlyErrorOverlayWebpackPlugin/filters/lazy-compilation-filter.js')
  }
};