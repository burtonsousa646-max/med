export { baseConfig } from './base-config';
export { BeefCacheBuildDependencyPlugin, BeefManifestPlugin, baseToolkit } from './base-toolkit';
export { type Configuration, extendConfig } from './extend-config';
export { extendPlugin } from './extend-plugin';
export { extendToolkit } from './extend-toolkit';
export type { MergeBuilders, MergeObjectValues, MergeValue } from './extend-toolkit';
export type { BuildEnv, Loader, Plugin, PluginArgs, TerserPluginTyped, TerserWebpackPlugin, WebpackBuilderUtils, } from './types';
export { useConfig } from './useConfig';
export { usePlugin } from './usePlugin';
export { useRule } from './useRule';
export { oneOfLoaders } from './utilities';
//# sourceMappingURL=index.d.ts.map