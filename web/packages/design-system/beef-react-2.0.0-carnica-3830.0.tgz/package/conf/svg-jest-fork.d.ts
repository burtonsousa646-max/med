declare function processSvg(contents: any, filename: any): any;
export { processSvg as process };
//# sourceMappingURL=svg-jest-fork.d.ts.map