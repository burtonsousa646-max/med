export * from './useTimer';
export { TimerType } from './types';
//# sourceMappingURL=index.d.ts.map