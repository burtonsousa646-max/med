import _defineProperty from "@babel/runtime/helpers/defineProperty";
import { useCallback } from 'react';
var getResultPosition = function getResultPosition(container, item, direction, resultAlign) {
  var itemPosition = direction === 'horizontal' ? item.offsetLeft : item.offsetTop;
  var itemSize = direction === 'horizontal' ? item.offsetWidth : item.offsetHeight;
  var containerSize = direction === 'horizontal' ? container.offsetWidth : container.offsetHeight;
  if (resultAlign === 'start') {
    return itemPosition;
  }
  if (resultAlign === 'center') {
    return itemPosition - (containerSize - itemSize) / 2;
  }
  return itemPosition - containerSize + itemSize;
};
export var useScrollToItem = function useScrollToItem(_ref) {
  var containeRef = _ref.containeRef,
    itemRefs = _ref.itemRefs,
    _ref$direction = _ref.direction,
    direction = _ref$direction === void 0 ? 'horizontal' : _ref$direction,
    _ref$resultAlign = _ref.resultAlign,
    resultAlign = _ref$resultAlign === void 0 ? 'center' : _ref$resultAlign;
  return useCallback(function (index) {
    var _itemRefs$index;
    var item = (_itemRefs$index = itemRefs[index]) === null || _itemRefs$index === void 0 ? void 0 : _itemRefs$index.current;
    if (!item || !containeRef.current) {
      return;
    }
    containeRef.current.scrollTo(_defineProperty(_defineProperty({}, direction === 'horizontal' ? 'left' : 'top', getResultPosition(containeRef.current, item, direction, resultAlign)), "behavior", 'smooth'));
  }, [direction, resultAlign]);
};