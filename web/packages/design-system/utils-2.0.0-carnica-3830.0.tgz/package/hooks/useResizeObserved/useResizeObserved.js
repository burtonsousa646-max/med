import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useEffect, useRef, useState } from 'react';
import { isEqual } from 'lodash';
import { useMutableRef } from "../useMutableRef";
export var useResizeObserved = function useResizeObserved(refs, mapper, deps) {
  var _useState = useState(function () {
      return refs.map(function (ref) {
        return mapper(ref.current);
      });
    }),
    _useState2 = _slicedToArray(_useState, 2),
    dimensions = _useState2[0],
    setDimensions = _useState2[1];
  var dimensionsRef = useMutableRef(dimensions);
  var mapperRef = useMutableRef(mapper);
  var resizingDelayTimer = useRef(undefined);
  useEffect(function () {
    var resizeObserver = new ResizeObserver(function () {
      clearTimeout(resizingDelayTimer.current);
      resizingDelayTimer.current = setTimeout(function () {
        var newValue = refs.map(function (ref) {
          return mapperRef.current(ref.current);
        });
        if (!isEqual(newValue, dimensionsRef.current)) {
          setDimensions(refs.map(function (ref) {
            return mapperRef.current(ref.current);
          }));
        }
      }, 100);
    });
    refs.forEach(function (ref) {
      if (ref.current) {
        resizeObserver.observe(ref.current);
      }
    });
    return function () {
      clearTimeout(resizingDelayTimer.current);
      resizeObserver.disconnect();
    };
  }, [refs.length, deps]);
  return dimensions;
};