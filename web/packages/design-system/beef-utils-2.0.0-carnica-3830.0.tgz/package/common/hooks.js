import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useEffect, useRef, useState } from 'react';

/** checks if element is in viewport
 * returns boolean
 */
export var useOnScreen = function useOnScreen(ref) {
  var _useState = useState(false),
    _useState2 = _slicedToArray(_useState, 2),
    isIntersecting = _useState2[0],
    setIntersecting = _useState2[1];
  var observer = null;
  if (typeof window !== 'undefined' && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(function (_ref) {
      var _ref2 = _slicedToArray(_ref, 1),
        entry = _ref2[0];
      return setIntersecting(entry.isIntersecting);
    });
  }
  useEffect(function () {
    if (ref !== null && ref !== void 0 && ref.current && observer) {
      observer.observe(ref.current);
    }
    // Remove the observer as soon as the component is unmounted
    return function () {
      if (observer) {
        observer.disconnect();
      }
    };
  }, []);
  return isIntersecting;
};
var useOnScreenWithCallback = function useOnScreenWithCallback(ref, callback, dep) {
  useEffect(function () {
    var observerRefValue = null;
    var observer = new IntersectionObserver(function (_ref3) {
      var _ref4 = _slicedToArray(_ref3, 1),
        entry = _ref4[0];
      if (entry.isIntersecting && ref.current) {
        callback();
        if (!(dep !== null && dep !== void 0 && dep.length)) {
          observer.unobserve(ref.current);
        }
      }
    });
    if (ref !== null && ref !== void 0 && ref.current) {
      observer.observe(ref.current);
      observerRefValue = ref.current;
    }
    return function () {
      if (dep !== null && dep !== void 0 && dep.length) {
        observer.disconnect();
      }
      if (observerRefValue && !dep.length) {
        observer.unobserve(observerRefValue);
      }
    };
  }, [dep]);
};
export var useOnScreenEffect = function useOnScreenEffect(callback) {
  var dependencies = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  var ref = useRef(null);
  useOnScreenWithCallback(ref, callback, dependencies);
  return ref;
};