import React from 'react';
export type ThemeType = 'dark' | 'light';
export type ExampleDecoratorPropThemeVersion = 'v1' | 'v2';
export type ExampleDecoratorProps = Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> & {
    background?: 'primary' | 'secondary' | 'tertiary';
    children: ((theme: 'dark' | 'light', version: ExampleDecoratorPropThemeVersion) => React.ReactNode) | React.ReactNode;
    className?: string;
    direction?: 'column' | 'row';
    themeVersion?: ExampleDecoratorPropThemeVersion;
    withoutControls?: boolean;
};
//# sourceMappingURL=types.d.ts.map