import { useState } from 'react';
var globalIdCounter = 0;
var generateUniqueId = function generateUniqueId() {
  return "react-18-fallback-".concat(globalIdCounter + 1);
};
export var useId = function useId() {
  return useState(function () {
    return generateUniqueId();
  })[0];
};