export let plugins: string[];
export namespace env {
    let browser: boolean;
    let jest: boolean;
    let node: boolean;
    let es2020: boolean;
}
export let settings: {
    'import/cache': {
        lifetime: string;
    };
    'import/extensions': string[];
    'import/resolver': {
        'babel-module': {
            babelOptions: {
                rootMode: string;
            };
        };
        node: {};
        exports: {};
    };
};
export let ignorePatterns: string[];
//# sourceMappingURL=settings.d.ts.map