import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "items", "convertItem", "counterSettings", "badgeClassName", "size", "disabled", "visibleCount", "wrap"],
  _excluded2 = ["attributes"],
  _excluded3 = ["className"];
import React, { forwardRef, useMemo } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { Avatar } from "../../Avatar/V5";
import { avatarSizeMap } from "../../Avatar/V5/utils";
import styles from "./styles.module.css";
import { AvatarGroupCore } from "../core";
import { useVisibleItems } from "../hooks/useVisibleItems";
var cnAvatarGroup = cnBem('avatar-group-v5', styles);
var defaultConvertItem = function defaultConvertItem(item) {
  return item;
};
var AvatarGroupRender = function AvatarGroupRender(props, ref) {
  var className = props.className,
    itemsProp = props.items,
    _props$convertItem = props.convertItem,
    convertItem = _props$convertItem === void 0 ? defaultConvertItem : _props$convertItem,
    counterSettings = props.counterSettings,
    badgeClassName = props.badgeClassName,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    disabled = props.disabled,
    visibleCount = props.visibleCount,
    wrap = props.wrap,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useVisibleItems = useVisibleItems((itemsProp === null || itemsProp === void 0 ? void 0 : itemsProp.length) || 0, avatarSizeMap[size], wrap && typeof visibleCount !== 'number' ? undefined : visibleCount),
    parentRef = _useVisibleItems.parentRef,
    hiddenCount = _useVisibleItems.hiddenCount,
    visibleItems = _useVisibleItems.visibleItems;
  var items = useMemo(function () {
    return (itemsProp === null || itemsProp === void 0 ? void 0 : itemsProp.map(convertItem).slice(0, visibleItems)) || [];
  }, [itemsProp, convertItem, visibleItems]);
  return /*#__PURE__*/React.createElement(AvatarGroupCore, _extends({}, otherProps, {
    className: cnAvatarGroup(null, [className]),
    ref: combineRefs([ref, parentRef]),
    size: size,
    wrap: wrap,
    "data-t-id": "AvatarGroup-V5"
  }), items.map(function (_ref, i) {
    var _item$disabled;
    var attributes = _ref.attributes,
      item = _objectWithoutProperties(_ref, _excluded2);
    var _ref2 = attributes || {},
      itemClassName = _ref2.className,
      itemProps = _objectWithoutProperties(_ref2, _excluded3);
    return /*#__PURE__*/React.createElement(Avatar, _extends({}, itemProps, item, {
      badgeClassName: cnAvatarGroup('badge', [badgeClassName]),
      className: cnAvatarGroup('item', [itemClassName]),
      disabled: (_item$disabled = item.disabled) !== null && _item$disabled !== void 0 ? _item$disabled : disabled,
      key: cnAvatarGroup('item', {
        i: i
      }),
      size: size
    }));
  }), hiddenCount > 0 && /*#__PURE__*/React.createElement(Avatar, _extends({}, counterSettings, {
    className: cnAvatarGroup('item', [counterSettings === null || counterSettings === void 0 ? void 0 : counterSettings.className]),
    disabled: disabled || (counterSettings === null || counterSettings === void 0 ? void 0 : counterSettings.disabled),
    label: "+".concat(hiddenCount),
    size: size
  })));
};
export var AvatarGroup = /*#__PURE__*/forwardRef(AvatarGroupRender);