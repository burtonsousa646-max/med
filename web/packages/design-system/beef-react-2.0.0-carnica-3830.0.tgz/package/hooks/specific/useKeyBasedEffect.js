import React from 'react';
import { useLegitEffect } from "./useLegitEffect";
/**
 * Complicated binding for useEffect:
 * 1. runs effect once onMount or after isReady is true
 * 2. runs effect when contentKey changes and isReady turns true
 * 2. runs afterEffect once onUnmount or after isReady is set to false
 * 2. runs afterEffect before contentKey changes
 */
export var useKeyBasedEffect = function useKeyBasedEffect(callback, _ref) {
  var _ref$contentKey = _ref.contentKey,
    contentKey = _ref$contentKey === void 0 ? 'singleKey' : _ref$contentKey,
    _ref$isReady = _ref.isReady,
    isReady = _ref$isReady === void 0 ? true : _ref$isReady;
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var attachedKey = React.useRef(null);
  useLegitEffect(function () {
    /** delay execution if content is not ready */
    if (!isReady || attachedKey.current === contentKey) return undefined;
    attachedKey.current = contentKey;
    return callback();
  }, [contentKey, isReady], options);
};