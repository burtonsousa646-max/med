export function getTestRegex(): any;
export function getCoverageDirectory(): string;
export function getJunitOutputName(): string;
//# sourceMappingURL=configUtils.d.ts.map