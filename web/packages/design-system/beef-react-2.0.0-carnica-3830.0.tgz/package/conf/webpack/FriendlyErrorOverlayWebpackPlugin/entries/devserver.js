/* global __resourceQuery */

import SockJS from 'sockjs-client';
// eslint-disable-next-line import/extensions
import formatWebpackMessages from 'react-dev-utils/formatWebpackMessages.js';
import { dismissBuildError, reportBuildError } from '../react-error-overlay/index.cjs';
let sockOptions = {};
if (typeof __resourceQuery === 'string' && __resourceQuery) {
  const queryParams = new URLSearchParams(__resourceQuery);
  sockOptions = Object.fromEntries(queryParams.entries());
}
const connection = sockOptions.sockPath === '/ws' && typeof WebSocket !== 'undefined' ? new WebSocket(`${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${sockOptions.sockHost || window.location.hostname}:${sockOptions.sockPort || window.location.port}${sockOptions.sockPath || '/ws'}`) : new SockJS(`${window.location.protocol}//${sockOptions.sockHost || window.location.hostname}:${sockOptions.sockPort || window.location.port}${sockOptions.sockPath || '/sockjs-node'}`);
connection.onmessage = function onmessage(e) {
  const {
    type,
    data
  } = JSON.parse(e.data);
  let formatted;
  switch (type) {
    case 'ok':
      dismissBuildError();
      break;
    case 'errors':
      formatted = formatWebpackMessages({
        errors: data,
        warnings: []
      });
      reportBuildError(formatted.errors[0]);
      break;
    default:
    // Do nothing.
  }
};