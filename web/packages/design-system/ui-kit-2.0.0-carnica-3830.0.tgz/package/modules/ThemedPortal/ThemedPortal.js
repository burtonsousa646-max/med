import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "theme", "container", "className", "shouldRender"];
import React, { useMemo } from 'react';
import ReactDOM from 'react-dom';
import { withClientRendering } from '@beef/react/enhancers';
import { ATTRIBUTE_PORTAL_VALUE, cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import { ThemeProvider, useThemeContext } from "../ThemeProvider";
import { getAdditionalClassName } from "./utils";
var cnThemedPortal = cnBem('portal');
var ThemedPortalRender = forwardRefWithMotionTag(function (props, ref) {
  var _window;
  var children = props.children,
    theme = props.theme,
    _props$container = props.container,
    containerProp = _props$container === void 0 ? (_window = window) === null || _window === void 0 || (_window = _window.document) === null || _window === void 0 ? void 0 : _window.body : _props$container,
    classNameProp = props.className,
    shouldRender = props.shouldRender,
    otherProps = _objectWithoutProperties(props, _excluded);
  var themeContext = useThemeContext();
  var container = 'current' in containerProp ? containerProp.current : containerProp;
  var className = useMemo(function () {
    return cnThemedPortal(null, [getAdditionalClassName(theme, themeContext), classNameProp]);
  }, [classNameProp, themeContext, theme]);
  if (!container) {
    return null;
  }
  return /*#__PURE__*/ReactDOM.createPortal(/*#__PURE__*/React.createElement(ThemeProvider, _extends({
    className: className,
    "data-portal": ATTRIBUTE_PORTAL_VALUE,
    initialTheme: theme
  }, otherProps, {
    ref: ref,
    "data-t-id": "modules-ThemedPortal"
  }), children), container);
});
export var ThemedPortal = withClientRendering(ThemedPortalRender);