import { IconInfoFilled } from '@carnica/graphics';
export var items = [{
  key: 1,
  icon: IconInfoFilled,
  label: 'купить сим-карту',
  description: 'пластиковую или е-сим с гибким тарифом'
}, {
  key: 2,
  icon: IconInfoFilled,
  label: 'подключить интернет',
  description: 'на скорости до 600 мбит/с'
}, {
  key: 3,
  icon: IconInfoFilled,
  label: 'все сразу',
  description: 'мобильная связь, интернет и тв',
  disabled: true
}];