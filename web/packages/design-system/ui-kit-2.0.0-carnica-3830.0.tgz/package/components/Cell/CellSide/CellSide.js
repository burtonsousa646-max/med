import React from 'react';
import { isIconComponent, isSideText } from "../utils";
import { CellSideText } from "./CellSideText";
var getIconColor = function getIconColor(_ref) {
  var position = _ref.position,
    disabled = _ref.disabled;
  if (disabled) {
    return 'disabled';
  }
  return position === 'left' ? 'primary' : 'secondary';
};
export var CellSide = function CellSide(_ref2) {
  var side = _ref2.side,
    _ref2$position = _ref2.position,
    position = _ref2$position === void 0 ? 'left' : _ref2$position,
    _ref2$disabled = _ref2.disabled,
    disabled = _ref2$disabled === void 0 ? false : _ref2$disabled;
  if (isIconComponent(side)) {
    var Icon = side;
    return /*#__PURE__*/React.createElement(Icon, {
      color: getIconColor({
        disabled: disabled,
        position: position
      }),
      "data-t-id": "Cell-CellSide"
    });
  }
  if (typeof side === 'function') {
    return side(disabled);
  }
  if (isSideText(side)) {
    var title = side.title,
      subTitle = side.subTitle,
      subTitleIcon = side.subTitleIcon,
      titleIcon = side.titleIcon,
      _side$titleVariant = side.titleVariant,
      titleVariant = _side$titleVariant === void 0 ? 'body-small' : _side$titleVariant;
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CellSideText, {
      disabled: disabled,
      icon: titleIcon,
      type: "title",
      variant: titleVariant
    }, title), /*#__PURE__*/React.createElement(CellSideText, {
      disabled: disabled,
      icon: subTitleIcon,
      type: "subtitle"
    }, subTitle));
  }
  return side;
};