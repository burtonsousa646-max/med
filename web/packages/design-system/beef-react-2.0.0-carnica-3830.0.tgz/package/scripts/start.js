/**
 * Если webpack возвращает массив конфигов, то пытаемся подобрать клиент через name,
 *   если не выходит - берем первый из списка
 */
var extractClientConfig = function extractClientConfig(configs) {
  if (!Array.isArray(configs)) return configs;
  return configs.find(function (c) {
    return c.name === 'client';
  }) || configs[0];
};

/**
 * NOTE: Running webpack from another package via cli doesn't work, so server-side WDS is a must have
 */
var _require = require('@beef/conf/modules'),
  webpackCompiler = _require.webpack;
var WebpackDevServer = require('webpack-dev-server');
var config = require("../conf").resolveWebpackConfig();
var clientConfig = extractClientConfig(config);
var compiler = webpackCompiler(config);
var server = new WebpackDevServer(clientConfig.devServer, compiler);
server.startCallback(function () {
  console.log("Serving webpack content on http://localhost:".concat(clientConfig.devServer.port));
});