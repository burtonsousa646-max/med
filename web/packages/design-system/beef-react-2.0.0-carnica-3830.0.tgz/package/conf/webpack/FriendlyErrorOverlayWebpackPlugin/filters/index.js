const toImport = path => `require('${path.replaceAll('\\', '\\\\')}')`;

/**
 * @param errorFilters {string[]}
 * @returns string
 */
const setErrorFiltersInlineTemplate = errorFilters => `
  window.__REACT_ERROR_OVERLAY_GLOBAL_HOOK__ ||= {};
  window.__REACT_ERROR_OVERLAY_GLOBAL_HOOK__.runtimeErrorFilters = [
    ${errorFilters.map(toImport).join(',')}
  ];
`;

/**
 * Если хотя бы один фильтр возвращает true - игнорируем ошибку
 */
const runtimeErrorFilter = err => window.__REACT_ERROR_OVERLAY_GLOBAL_HOOK__.runtimeErrorFilters.some(fn => fn(err));
module.exports = {
  setErrorFiltersInlineTemplate,
  runtimeErrorFilter
};