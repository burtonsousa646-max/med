import React from 'react';
type EffectCallback = () => (() => void) | void;
export declare const useIosEffect: (effect: EffectCallback, deps?: React.DependencyList) => void;
export {};
//# sourceMappingURL=index.d.ts.map