import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["closeOptions", "ignoredClickOutsideRefs", "onClose", "className", "children", "style"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useEffect, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { motion } from 'framer-motion';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { ClickOutsideWrapper } from "../../ClickOutsideWrapper";
import { Button } from "../../../components/Button";
import styles from "../styles.module.css";
import { useSheetScroll } from "../hooks/useSheetScroll";
var cnBottomSheetWindow = cnBem('bottom-sheet', styles);
var varinats = {
  hidden: {
    poinerEvents: 'none',
    y: '100vh',
    opacity: 0
  },
  visible: {
    y: 0,
    opacity: 1,
    poinerEvents: 'all'
  }
};
export var BottomSheetWindow = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var closeOptions = _ref.closeOptions,
    ignoredClickOutsideRefs = _ref.ignoredClickOutsideRefs,
    onClose = _ref.onClose,
    className = _ref.className,
    children = _ref.children,
    style = _ref.style,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _useSheetScroll = useSheetScroll(),
    scrollRef = _useSheetScroll.scrollRef,
    topOffset = _useSheetScroll.topOffset,
    radius = _useSheetScroll.radius;
  var buttonRef = useRef(null);
  useEffect(function () {
    var _buttonRef$current;
    (_buttonRef$current = buttonRef.current) === null || _buttonRef$current === void 0 || _buttonRef$current.focus();
  }, []);
  return /*#__PURE__*/React.createElement(ClickOutsideWrapper, {
    ignoreClicksInsideRefs: [].concat(_toConsumableArray(ignoredClickOutsideRefs), [scrollRef]),
    onClickOutside: closeOptions.overlay ? onClose : undefined,
    "data-t-id": "BottomSheet-BottomSheetWindow"
  }, /*#__PURE__*/React.createElement(motion.div, _extends({}, otherProps, {
    animate: "visible",
    className: cnBottomSheetWindow('container', [className]),
    exit: "hidden",
    initial: "hidden",
    ref: combineRefs([ref, scrollRef]),
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty(_defineProperty({}, '--bottom-sheet-offset', "".concat(topOffset, "px")), '--bottom-sheet-radius', "".concat(radius, "px"))),
    transition: {
      transform: {
        duration: 0.3
      },
      opacity: {
        duration: 0.3
      }
    },
    variants: varinats
  }), closeOptions.button && onClose && /*#__PURE__*/React.createElement("div", {
    className: cnBottomSheetWindow('sticky-wrapper')
  }, /*#__PURE__*/React.createElement(Button, {
    "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043C\u043E\u0434\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u043A\u043D\u043E",
    className: cnBottomSheetWindow('close'),
    iconLeft: IconCloseRoundStroked,
    onClick: onClose,
    onlyIcon: true,
    ref: buttonRef,
    size: "m",
    type: "button",
    view: "secondary-on-primary"
  })), children));
});