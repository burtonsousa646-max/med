import { useCallback, useEffect, useRef } from 'react';
import { useMutableRef } from "../useMutableRef";
export var useDragScroll = function useDragScroll(scrollableRef, direction) {
  var isActive = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  var mouseDownRef = useRef(false);
  var startRef = useRef({
    left: 0,
    top: 0
  });
  var scrollRef = useRef({
    left: 0,
    top: 0
  });
  var directionRef = useMutableRef(direction || 'horizontal');
  var setTimerRef = useRef(null);
  var setScrollFlag = useCallback(function (flag) {
    mouseDownRef.current = flag;
    var setDataValue = function setDataValue() {
      if (scrollableRef.current) {
        scrollableRef.current.dataset.dragScroll = String(flag);
      }
    };
    if (setTimerRef.current) {
      clearTimeout(setTimerRef.current);
    }
    if (flag) {
      setTimerRef.current = setTimeout(setDataValue, 200);
    } else {
      setDataValue();
    }
  }, []);
  var startDragging = useCallback(function (event) {
    var e = event;
    e.preventDefault();
    setScrollFlag(true);
    if (scrollableRef.current) {
      scrollRef.current = {
        top: scrollableRef.current.scrollTop,
        left: scrollableRef.current.scrollLeft
      };
      startRef.current = {
        top: e.pageY - scrollableRef.current.offsetTop,
        left: e.pageX - scrollableRef.current.offsetLeft
      };
    }
  }, []);
  var stopDragging = function stopDragging() {
    setScrollFlag(false);
  };
  var move = useCallback(function (event) {
    var e = event;
    e.preventDefault();
    if (!mouseDownRef.current || !scrollableRef.current) {
      return;
    }
    var orientation = directionRef.current;
    var pagePosition = orientation === 'horizontal' ? e.pageX : e.pageY;
    var offset = orientation === 'horizontal' ? scrollableRef.current.offsetLeft : scrollableRef.current.offsetTop;
    var position = pagePosition - offset;
    var scrollPosition = position - (orientation === 'horizontal' ? startRef.current.left : startRef.current.top);
    if (directionRef.current === 'horizontal') {
      scrollableRef.current.scrollLeft = scrollRef.current.left - scrollPosition;
      return;
    }
    scrollableRef.current.scrollTop = scrollRef.current.top - scrollPosition;
  }, []);
  var updateListeners = function updateListeners(type) {
    var element = scrollableRef.current;
    if (element) {
      var action = type === 'add' ? 'addEventListener' : 'removeEventListener';
      element[action]('mousemove', move, false);
      element[action]('mousedown', startDragging, false);
      element[action]('mouseup', stopDragging, false);
      element[action]('mouseleave', stopDragging, false);
    }
  };
  useEffect(function () {
    if (isActive) {
      updateListeners('add');
    }
    return function () {
      return updateListeners('remove');
    };
  }, [isActive]);
};