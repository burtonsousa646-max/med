export default [{
  name: 'Brand',
  colors: [{
    name: '--color-brand-primary',
    value: 'rgba(255, 200, 0, 1)'
  }, {
    name: '--color-brand-secondary',
    value: 'rgba(255, 213, 70, 1)'
  }, {
    name: '--color-brand-tertiary',
    value: 'rgba(244, 184, 7, 1)'
  }]
}, {
  name: 'Success',
  colors: [{
    name: '--color-success-primary',
    value: 'rgba(0, 165, 94, 1)'
  }, {
    name: '--color-success-secondary',
    value: 'rgba(0, 192, 109, 1)'
  }, {
    name: '--color-success-tertiary',
    value: 'rgba(0, 143, 81, 1)'
  }]
}, {
  name: 'Error',
  colors: [{
    name: '--color-error-primary',
    value: 'rgba(248, 74, 0, 1)'
  }, {
    name: '--color-error-secondary',
    value: 'rgba(255, 101, 36, 1)'
  }, {
    name: '--color-error-tertiary',
    value: 'rgba(184, 55, 0, 1)'
  }]
}, {
  name: 'Text',
  colors: [{
    name: '--color-text-primary',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-text-secondary',
    value: 'rgba(200, 206, 217, 1)'
  }, {
    name: '--color-text-tertiary',
    value: 'rgba(110, 120, 138, 1)'
  }, {
    name: '--color-text-primary-invert',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-text-secondary-invert',
    value: 'rgba(110, 120, 138, 1)'
  }, {
    name: '--color-text-tertiary-invert',
    value: 'rgba(152, 160, 176, 1)'
  }, {
    name: '--color-text-success',
    value: 'rgba(0, 192, 109, 1)'
  }, {
    name: '--color-text-error',
    value: 'rgba(248, 74, 0, 1)'
  }, {
    name: '--color-text-link',
    value: 'rgba(46, 148, 250, 1)'
  }]
}, {
  name: 'Icon',
  colors: [{
    name: '--color-icon-primary',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-icon-secondary',
    value: 'rgba(200, 206, 217, 1)'
  }, {
    name: '--color-icon-tertiary',
    value: 'rgba(152, 160, 176, 1)'
  }, {
    name: '--color-icon-disabled',
    value: 'rgba(110, 120, 138, 1)'
  }, {
    name: '--color-icon-disabled-invert',
    value: 'rgba(175, 183, 196, 1)'
  }, {
    name: '--color-icon-primary-invert',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-icon-secondary-invert',
    value: 'rgba(110, 120, 138, 1)'
  }, {
    name: '--color-icon-tertiary-invert',
    value: 'rgba(152, 160, 176, 1)'
  }, {
    name: '--color-icon-success',
    value: 'rgba(0, 192, 109, 1)'
  }, {
    name: '--color-icon-error',
    value: 'rgba(248, 74, 0, 1)'
  }, {
    name: '--color-icon-link',
    value: 'rgba(46, 148, 250, 1)'
  }]
}, {
  name: 'Accent',
  colors: [{
    name: '--color-accent-01',
    value: 'rgba(0, 192, 109, 1)'
  }, {
    name: '--color-accent-02',
    value: 'rgba(0, 184, 162, 1)'
  }, {
    name: '--color-accent-03',
    value: 'rgba(46, 148, 250, 1)'
  }, {
    name: '--color-accent-04',
    value: 'rgba(133, 97, 236, 1)'
  }, {
    name: '--color-accent-05',
    value: 'rgba(231, 64, 154, 1)'
  }, {
    name: '--color-accent-06',
    value: 'rgba(245, 71, 71, 1)'
  }, {
    name: '--color-accent-07',
    value: 'rgba(248, 74, 0, 1)'
  }, {
    name: '--color-accent-08',
    value: 'rgba(255, 200, 0, 1)'
  }]
}, {
  name: 'Surface',
  colors: [{
    name: '--color-surface-01',
    value: 'rgba(0, 74, 42, 1)'
  }, {
    name: '--color-surface-02',
    value: 'rgba(0, 71, 63, 1)'
  }, {
    name: '--color-surface-03',
    value: 'rgba(3, 56, 109, 1)'
  }, {
    name: '--color-surface-04',
    value: 'rgba(55, 31, 122, 1)'
  }, {
    name: '--color-surface-05',
    value: 'rgba(109, 13, 65, 1)'
  }, {
    name: '--color-surface-06',
    value: 'rgba(121, 21, 21, 1)'
  }, {
    name: '--color-surface-07',
    value: 'rgba(102, 30, 0, 1)'
  }, {
    name: '--color-surface-08',
    value: 'rgba(122, 58, 0, 1)'
  }]
}, {
  name: 'Background',
  colors: [{
    name: '--color-background-primary',
    value: 'rgba(25, 28, 34, 1)'
  }, {
    name: '--color-background-secondary',
    value: 'rgba(34, 39, 49, 1)'
  }, {
    name: '--color-background-tertiary',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-background-overlay',
    value: 'rgba(0, 0, 0, 0.8)'
  }, {
    name: '--color-background-error',
    value: 'rgba(77, 23, 0, 1)'
  }, {
    name: '--color-background-primary-invert',
    value: 'rgba(240, 243, 245, 1)'
  }, {
    name: '--color-background-secondary-invert',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-background-tertiary-invert',
    value: 'rgba(226, 230, 237, 1)'
  }, {
    name: '--color-background-overlay-invert',
    value: 'rgba(25, 28, 34, 0.7)'
  }]
}, {
  name: 'Border',
  colors: [{
    name: '--color-border-primary',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-border-secondary',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-border-error',
    value: 'rgba(248, 74, 0, 1)'
  }, {
    name: '--color-border-primary-invert',
    value: 'rgba(25, 28, 34, 1)'
  }, {
    name: '--color-border-secondary-invert',
    value: 'rgba(200, 206, 217, 1)'
  }]
}, {
  name: 'Constant',
  colors: [{
    name: '--color-constant-01',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-constant-02',
    value: 'rgba(255, 255, 255, 1)'
  }]
}];