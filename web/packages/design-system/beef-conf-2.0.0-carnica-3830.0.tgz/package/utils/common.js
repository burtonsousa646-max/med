const {
  execSync
} = require('child_process');
const getRegistry = () => new URL(execSync('yarn config get registry').toString().trim());
const getWorkspacesInfo = () => {
  try {
    return Object.entries(JSON.parse(execSync(`yarn workspaces info`).toString()));
  } catch (e) {
    console.error(e);
    return undefined;
  }
};
module.exports = {
  getRegistry,
  getWorkspacesInfo
};