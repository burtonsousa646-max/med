const path = require('path');
const {
  scopeRegExpStr
} = require('@beef/conf/registry');
const {
  getCoverageDirectory,
  getJunitOutputName,
  getTestRegex
} = require('./jest');
module.exports = (cwd, {
  setupFilesAfterEnv = [],
  ...customOptions
} = {}) => ({
  collectCoverageFrom: ['!**/node_modules/**'],
  coverageDirectory: getCoverageDirectory(),
  coveragePathIgnorePatterns: ['/node_modules/', 'stories', '__stories__', '__tests__', 'icons'],
  coverageReporters: ['html', 'json-summary', 'cobertura'],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node', 'mjs'],
  /**
   * Default resolver of jest@27 can't handle package.json exports field
   *   this is a temporary crutch until we update to jest@28 or use custom resolver
   *   basically we try to parse initial import first, then fallback to src dir
   */
  moduleNameMapper: {
    '^@carnica/([^\\/]+)/(.*)$': ['@carnica/$1/$2', '@carnica/$1/src/$2'],
    '^@beef/([^\\/]+)/(.*)$': ['@beef/$1/$2', '@beef/$1/src/$2'],
    'swiper/react': 'swiper/swiper-react.mjs',
    'swiper/core': 'swiper/swiper.mjs',
    'swiper/css': 'swiper/swiper.css',
    'swiper/bundle': 'swiper/swiper-bundle.mjs',
    'swiper/types': 'swiper/types/index.d.ts',
    '^swiper/css/([^\\/]+)/(.*)$': 'swiper/modules/$1.css'
  },
  reporters: ['default', ['jest-junit', {
    outputDirectory: process.env.WORKDIR ? `${process.env.CI_PROJECT_DIR}/junit-reports` : '.',
    outputName: getJunitOutputName()
  }]],
  rootDir: path.resolve(cwd, 'src'),
  setupFilesAfterEnv: [require.resolve('@beef/testing/setupTestingLibrary'), require.resolve('@beef/testing/setupFetch'), ...setupFilesAfterEnv],
  testEnvironment: require.resolve('jest-environment-jsdom'),
  testPathIgnorePatterns: ['/node_modules/'],
  testRegex: getTestRegex(),
  transform: {
    '\\.(css|pcss|less|scss|sass|png|jpg|ttf|woff|woff2)$': 'jest-transform-stub',
    '\\.(js|ts|jsx|tsx|mjs)$': [require.resolve('babel-jest'), {
      rootMode: 'upward-optional'
    }],
    // TODO: crutch, fix error with 'svg-jest' parser
    //  + fix error when trying to import an SVG file with inline ?url - example: './warning.svg?url'
    '\\.svg$': require.resolve('./svg-jest-fork.js')
  },
  transformIgnorePatterns: [`/node_modules/(?!(debounce|throttleit|swiper|axios|date-fns-new|react-jsx-parser|${scopeRegExpStr})/|.*\\.css)`],
  ...customOptions
});