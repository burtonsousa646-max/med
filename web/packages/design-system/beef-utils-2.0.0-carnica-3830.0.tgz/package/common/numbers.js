export var roundToPrecision = function roundToPrecision(value) {
  var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
  return +(value + Number.EPSILON).toFixed(precision);
};
export var fractionToPrecision = function fractionToPrecision(value, fraction) {
  return "".concat(Math.round(10 / (fraction * value))).length - 1;
};

/**
 * Округляет таким образом, что указанная фракция не теряется в округлении
 * Примеры:
 * - округление до фракцией 0.1 для 5.5 = 5.5,
 * - округление до фракции 0.1 для 55.5 = 55
 * @param value {number} - значение для округления
 * @param fraction {number} - фракция, по которой нужно делать округление
 */
export var roundToFraction = function roundToFraction(value) {
  var fraction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0.02;
  return roundToPrecision(value, fractionToPrecision(value, fraction));
};