import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["label", "caption", "disabled", "error", "wrapperProps", "withLengthCounter", "maxLength", "forwardedRef", "wrapperRef", "value", "className", "withMobileOffset", "width", "readOnly", "id"];
import React, { forwardRef, useMemo } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { ControlWrapper } from "../ControlWrapper";
import styles from "./styles.module.css";
import { TextAreaCore } from "./TextAreaCore";
import { TextAreaCaption } from "./TextAreaCaption";
import { getErrorContent } from "./utils";
var cnTextArea = cnBem('textarea', styles);
export var TextArea = /*#__PURE__*/forwardRef(function (props, ref) {
  var label = props.label,
    caption = props.caption,
    disabled = props.disabled,
    error = props.error,
    _props$wrapperProps = props.wrapperProps,
    wrapperProps = _props$wrapperProps === void 0 ? {} : _props$wrapperProps,
    withLengthCounter = props.withLengthCounter,
    maxLength = props.maxLength,
    forwardedRef = props.forwardedRef,
    wrapperRef = props.wrapperRef,
    value = props.value,
    className = props.className,
    withMobileOffset = props.withMobileOffset,
    _props$width = props.width,
    width = _props$width === void 0 ? 'default' : _props$width,
    readOnly = props.readOnly,
    id = props.id,
    otherProps = _objectWithoutProperties(props, _excluded);
  var errorText = getErrorContent({
    maxLength: maxLength,
    value: value,
    withLengthCounter: withLengthCounter,
    error: error
  });
  var captionRender = useMemo(function () {
    return /*#__PURE__*/React.createElement(TextAreaCaption, {
      caption: caption,
      maxLength: maxLength,
      shouldRender: !readOnly,
      value: value,
      withLengthCounter: withLengthCounter,
      "data-t-id": "components-TextArea"
    });
  }, [caption, maxLength, readOnly, value, withLengthCounter]);
  return /*#__PURE__*/React.createElement(ControlWrapper, _extends({}, wrapperProps, {
    caption: captionRender,
    captionProps: {
      id: id ? "".concat(id, "-caption") : undefined
    },
    className: cnTextArea({
      width: width
    }, [wrapperProps.className]),
    disabled: disabled,
    error: errorText,
    label: label,
    labelProps: {
      htmlFor: id
    },
    readOnly: readOnly,
    ref: wrapperRef,
    width: width,
    withMobileOffset: withMobileOffset
  }), /*#__PURE__*/React.createElement(TextAreaCore, _extends({
    "aria-describedby": id ? "".concat(id, "-caption") : undefined,
    "aria-label": label ? undefined : 'Поле ввода текста',
    disabled: disabled,
    error: errorText,
    id: id,
    maxLength: maxLength,
    readOnly: readOnly,
    ref: combineRefs([ref, forwardedRef]),
    value: value
  }, otherProps, {
    "data-t-id": "components-TextArea"
  })));
});