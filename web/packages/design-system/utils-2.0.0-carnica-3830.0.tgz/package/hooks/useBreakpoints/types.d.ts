export declare enum DIMENSION_TYPE {
    MOBILE = "mobile",
    TABLET = "tablet",
    DESKTOP = "desktop"
}
export type BreakpointsMap<POINTS extends string> = Record<POINTS, number>;
export type BreakpointsResult<POINTS extends string> = [POINTS | null, Record<POINTS, boolean>];
//# sourceMappingURL=types.d.ts.map