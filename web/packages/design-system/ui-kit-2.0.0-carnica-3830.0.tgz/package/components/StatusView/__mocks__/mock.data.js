import { IconBellOutline, IconDocFillFilled, IconGiftFilled, IconImportFilled, IconMarkOutline, IconRefresh } from '@carnica/graphics';
export var buttons = [{
  label: 'повторить платёж',
  icon: IconRefresh
}, {
  label: 'включить уведомления',
  icon: IconBellOutline
}, {
  label: 'найти офис на карте',
  icon: IconMarkOutline
}];
export var actions = [{
  icon: IconDocFillFilled,
  onClick: function onClick() {
    return alert('send');
  },
  tagName: 'button',
  label: 'отправить чек на почту'
}, {
  icon: IconImportFilled,
  onClick: function onClick() {
    return alert('save');
  },
  tagName: 'button',
  label: 'сохранить чек'
}, {
  icon: IconGiftFilled,
  onClick: function onClick() {
    return alert('gift');
  },
  tagName: 'button',
  label: 'получить подарок'
}];