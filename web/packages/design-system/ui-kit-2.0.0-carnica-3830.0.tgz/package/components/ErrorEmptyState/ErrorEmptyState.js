import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["title", "subTitle", "icon", "buttons", "convertButton", "children", "className", "titleVariant"];
import React, { forwardRef } from 'react';
import { IconDangerFilled } from '@carnica/graphics';
import { cnBem } from '@carnica/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import { Text } from "../Text";
import styles from "./styles.module.css";
import { ErrorEmptyStateButtons } from "./ErrorEmptyStateButtons";
var cnErrorEmptyState = cnBem('error-empty-state', styles);
var ErrorEmptyStateRender = function ErrorEmptyStateRender(props, ref) {
  var title = props.title,
    subTitle = props.subTitle,
    _props$icon = props.icon,
    Icon = _props$icon === void 0 ? IconDangerFilled : _props$icon,
    buttons = props.buttons,
    convertButton = props.convertButton,
    children = props.children,
    className = props.className,
    _props$titleVariant = props.titleVariant,
    titleVariant = _props$titleVariant === void 0 ? 'headline-small' : _props$titleVariant,
    otherProps = _objectWithoutProperties(props, _excluded);
  var hasChild = React.Children.count(children) > 0;
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    "aria-atomic": true,
    className: cnErrorEmptyState({
      hasChild: hasChild,
      hasSubTitle: !!subTitle
    }, [className]),
    ref: ref,
    role: "status",
    tagName: "section",
    "data-t-id": "components-ErrorEmptyState"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnErrorEmptyState('wrapper'),
    "data-t-id": "components-ErrorEmptyState"
  }, /*#__PURE__*/React.createElement("div", {
    className: cnErrorEmptyState('indicator')
  }, /*#__PURE__*/React.createElement(Icon, {
    color: "tertiary",
    size: 60
  })), title && /*#__PURE__*/React.createElement(Text, {
    align: "center",
    className: cnErrorEmptyState('title', {
      bigger: titleVariant === 'headline-small'
    }),
    color: "primary",
    variant: titleVariant
  }, title), subTitle && /*#__PURE__*/React.createElement(Text, {
    align: "center",
    className: cnErrorEmptyState('subtitle'),
    color: "secondary",
    variant: "body-small"
  }, subTitle), children && /*#__PURE__*/React.createElement("div", {
    className: cnErrorEmptyState('content')
  }, children)), /*#__PURE__*/React.createElement(ErrorEmptyStateButtons, {
    buttons: buttons,
    className: cnErrorEmptyState('buttons'),
    convertButton: convertButton
  }));
};
export var ErrorEmptyState = /*#__PURE__*/forwardRef(ErrorEmptyStateRender);