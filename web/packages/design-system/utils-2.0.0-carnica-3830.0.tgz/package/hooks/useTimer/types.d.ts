export declare enum TimerType {
    DECREMENTAL = 0,
    INCREMENTAL = 1
}
export type UseTimerParams = {
    endTime: null | number;
    interval: number;
    onInterval?: (time: number) => void;
    onTimeOver?: () => void;
    startTime: number;
    timerType: TimerType;
};
//# sourceMappingURL=types.d.ts.map