export declare const deprecationWarning: (prop: string, message?: string) => void;
//# sourceMappingURL=deprecationWarning.d.ts.map