export function deleteItems(startPath: string, deleteList: string[]): Promise<void[]> | Promise<null>;
//# sourceMappingURL=deleteItems.d.ts.map