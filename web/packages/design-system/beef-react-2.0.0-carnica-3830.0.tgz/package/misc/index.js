/* eslint-disable react/forbid-prop-types */
import PropTypes from 'prop-types';
var PropTypesNewRef = PropTypes.shape({
  current: PropTypes.any
});
export var CustomPropTypes = {
  component: PropTypes.elementType,
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  newRef: PropTypesNewRef,
  ref: PropTypes.oneOfType([PropTypes.func, PropTypesNewRef]),
  options: PropTypes.arrayOf(PropTypes.shape({
    label: PropTypes.string,
    value: PropTypes.any
  })),
  oneOfValues: function oneOfValues(obj) {
    return PropTypes.oneOf(Object.values(obj));
  }
};