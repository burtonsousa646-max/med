import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["title", "className", "subTitle", "progress", "mode", "ready", "onClose"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { motion } from 'framer-motion';
import styles from "./styles.module.css";
import { useLoadingAnimation } from "../hooks/useLoadingAnimation";
import { LoadingWindowContentText } from "./LoadingWindowContentText";
import { useLoadingText } from "../hooks/useLoadingText";
var cnLoadingWindowContent = cnBem('loading-window-content', styles);
export var LoadingWindowContent = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var _ref$title = _ref.title,
    title = _ref$title === void 0 ? 'подключаем, займёт полминуты' : _ref$title,
    className = _ref.className,
    _ref$subTitle = _ref.subTitle,
    subTitle = _ref$subTitle === void 0 ? 'пришлём смс, как закончим' : _ref$subTitle,
    progress = _ref.progress,
    _ref$mode = _ref.mode,
    mode = _ref$mode === void 0 ? 'flag' : _ref$mode,
    ready = _ref.ready,
    onClose = _ref.onClose,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _useLoadingAnimation = useLoadingAnimation({
      mode: mode,
      progress: progress,
      ready: ready,
      onClose: onClose
    }),
    value = _useLoadingAnimation.value,
    indicatorRef = _useLoadingAnimation.indicatorRef,
    titleRef = _useLoadingAnimation.titleRef,
    subTitleRef = _useLoadingAnimation.subTitleRef,
    counterRef = _useLoadingAnimation.counterRef;
  var text = useLoadingText({
    title: title,
    subTitle: subTitle,
    value: value
  });
  return /*#__PURE__*/React.createElement(motion.div, _extends({}, otherProps, {
    className: cnLoadingWindowContent(null, [className]),
    ref: ref
  }), /*#__PURE__*/React.createElement("div", {
    className: cnLoadingWindowContent('content'),
    "data-t-id": "LoadingWindow-LoadingWindowContent"
  }, /*#__PURE__*/React.createElement(LoadingWindowContentText, {
    ref: titleRef,
    type: "title"
  }, text.title), /*#__PURE__*/React.createElement(LoadingWindowContentText, {
    ref: subTitleRef,
    type: "subTitle"
  }, text.subTitle)), /*#__PURE__*/React.createElement(motion.p, {
    className: cnLoadingWindowContent('counter'),
    ref: counterRef
  }, /*#__PURE__*/React.createElement(motion.span, null, value), "%"), /*#__PURE__*/React.createElement(motion.div, {
    "aria-hidden": true,
    className: cnLoadingWindowContent('indicator'),
    ref: indicatorRef,
    role: "progressbar"
  }));
});