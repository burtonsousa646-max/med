import React from 'react';
export declare const useResizeObserved: <ELEMENT extends HTMLElement | SVGGraphicsElement, RETURN_TYPE>(refs: Array<React.RefObject<ELEMENT | null>>, mapper: (el: ELEMENT | null) => RETURN_TYPE, deps?: unknown[]) => RETURN_TYPE[];
//# sourceMappingURL=useResizeObserved.d.ts.map