import React from 'react';
export declare const QR: React.ForwardRefExoticComponent<{
    backgroundColor?: string | undefined;
    children?: undefined;
    color?: string | undefined;
    cutout?: boolean | undefined;
    cutoutElement?: React.ReactNode;
    errorCorrectionLevel?: import("./types").QRPropErrorCorrectionLevel | undefined;
    rounding?: number | undefined;
    size?: number | undefined;
    url: string;
    viewPortSize?: number | undefined;
} & Omit<React.HTMLAttributes<SVGSVGElement>, "css" | "color" | "children" | "backgroundColor" | "cutout" | "cutoutElement" | "errorCorrectionLevel" | "rounding" | "size" | "url" | "viewPortSize"> & React.RefAttributes<SVGSVGElement>>;
//# sourceMappingURL=QR.d.ts.map