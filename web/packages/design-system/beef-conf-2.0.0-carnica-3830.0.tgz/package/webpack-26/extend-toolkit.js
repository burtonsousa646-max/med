import { deepmerge } from "./helpers";
export function extendToolkit(base, factory) {
  return deepmerge(base, factory(base), function (a, b, path) {
    return path.length > 1 ? b : undefined;
  });
}