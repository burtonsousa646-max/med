import _extends from "@babel/runtime/helpers/extends";
import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["animate", "onClose", "closeOptions", "isOpen", "size", "ignoredClickOutsideRefs", "children", "className", "containerRef"];
import { cnBem, combineRefs, forwardRefWithMotion } from '@carnica/utils';
import React, { useEffect, useRef } from 'react';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { motion } from 'framer-motion';
import { Button } from "../../Button";
import { ClickOutsideWrapper } from "../../../modules/ClickOutsideWrapper";
import styles from "./styles.module.css";
import { useContentScroll } from "../hooks/useContentScroll";
var cnModalContent = cnBem('modal-content', styles);
var varinats = {
  hidden: {
    poinerEvents: 'none',
    transform: 'translate(0, 20px)',
    opacity: 0
  },
  visible: {
    transform: 'translate(0)',
    opacity: 1,
    poinerEvents: 'all'
  }
};
export var ModalContent = forwardRefWithMotion(function (props, ref) {
  var animate = props.animate,
    onClose = props.onClose,
    closeOptions = props.closeOptions,
    isOpen = props.isOpen,
    _props$size = props.size,
    size = _props$size === void 0 ? 'l' : _props$size,
    _props$ignoredClickOu = props.ignoredClickOutsideRefs,
    ignoredClickOutsideRefs = _props$ignoredClickOu === void 0 ? [] : _props$ignoredClickOu,
    children = props.children,
    className = props.className,
    containerRef = props.containerRef,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useContentScroll = useContentScroll(containerRef),
    contentRef = _useContentScroll.contentRef,
    buttonOffset = _useContentScroll.buttonOffset;
  var buttonRef = useRef(null);
  useEffect(function () {
    if (isOpen) {
      var _buttonRef$current;
      (_buttonRef$current = buttonRef.current) === null || _buttonRef$current === void 0 || _buttonRef$current.focus();
    }
  }, [isOpen]);
  return /*#__PURE__*/React.createElement(motion.div, _extends({}, otherProps, {
    animate: "visible",
    className: cnModalContent({
      size: size,
      withCloseButton: !!onClose
    }, [className]),
    exit: "hidden",
    initial: "hidden",
    ref: combineRefs([contentRef, ref]),
    transition: {
      transform: {
        duration: 0.3
      },
      opacity: {
        duration: 0.3
      }
    },
    variants: varinats
  }), onClose && closeOptions.button && /*#__PURE__*/React.createElement(Button, {
    "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043C\u043E\u0434\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u043A\u043D\u043E",
    className: cnModalContent('close'),
    iconLeft: IconCloseRoundStroked,
    onClick: onClose,
    onlyIcon: true,
    ref: buttonRef,
    size: "m",
    style: _defineProperty({}, '--modal-button-offset', "".concat(buttonOffset, "px")),
    type: "button",
    view: "secondary-on-primary",
    "data-t-id": "Modal-ModalContent"
  }), /*#__PURE__*/React.createElement(ClickOutsideWrapper, {
    ignoreClicksInsideRefs: [].concat(_toConsumableArray(ignoredClickOutsideRefs), [contentRef]),
    onClickOutside: closeOptions.overlay ? onClose : undefined
  }, children));
});