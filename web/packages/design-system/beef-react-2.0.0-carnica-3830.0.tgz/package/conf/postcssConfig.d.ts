declare function _exports(opts: any): {
    plugins: {
        [x: string]: any;
    };
};
export = _exports;
//# sourceMappingURL=postcssConfig.d.ts.map