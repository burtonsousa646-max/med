import { IMask } from 'react-imask';
import { IconTimeOutline } from '@carnica/graphics';
import React from 'react';
import { compose } from '@beef/utils';
import { defineProps } from '@beef/react';
import { withMaskedInput } from "../../../hocs/withMaskedInput";
import { Input } from "../../Input";
export var timeMask = {
  mask: 'hh{:}mm',
  blocks: {
    mm: {
      mask: IMask.MaskedRange,
      from: 0,
      to: 59
    },
    hh: {
      mask: IMask.MaskedRange,
      from: 0,
      to: 23
    }
  },
  lazy: true,
  autofix: true
};
export var TimeInput = compose(defineProps({}, {
  placeholder: 'чч:мм',
  rightSide: /*#__PURE__*/React.createElement(IconTimeOutline, {
    color: "tertiary",
    "data-t-id": "AdvancedInputs-TimeInput"
  })
}), withMaskedInput(timeMask))(Input);