import { TResolutions } from './types';
export declare const getWindowWidth: () => number;
export declare const getCurrentResolution: (resolutions: TResolutions) => number;
//# sourceMappingURL=helpers.d.ts.map