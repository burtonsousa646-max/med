import { TimerType, UseTimerParams } from './types';
export declare const initialConfig: UseTimerParams;
export declare const getTimeIsOver: (timerType: TimerType, time: number, endTime: null | number) => boolean;
//# sourceMappingURL=helper.d.ts.map