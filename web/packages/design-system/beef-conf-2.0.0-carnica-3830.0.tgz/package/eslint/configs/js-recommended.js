const {
  isFixMode,
  resolvePlugin
} = require('../utils');
module.exports = {
  parser: require.resolve('@babel/eslint-parser'),
  extends: [/** sonarJs */
  'plugin:sonarjs/recommended', /** perfectionist */
  'plugin:perfectionist/recommended-natural', 'plugin:import/recommended', 'airbnb', 'airbnb/hooks', /** prettier plugins */
  'prettier', 'plugin:prettier/recommended', '../rules/common', '../rules/imports', '../rules/react', '../rules/accessibility', '../rules/broken', '../rules/sonar', '../rules/perfectionist', isFixMode ? '../rules/autofix-broken' : null].filter(Boolean).map(resolvePlugin)
};