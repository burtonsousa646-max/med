import { PRIVATE_BUILDER_API } from "./builder.internals";
import { deepmerge } from "./helpers";

/**
 * Производит рекурсивное слияние базового конфига с полученным в результате вызова
 *
 * Плагины и правила объединяет в единый массив, учитывая особенности работы плагинов и правил:
 * - usePlugin & useRule - добавляет элемент в конец списка
 * - usePlugin.replace & useRule.replace - ставит новый элемент вместо старого
 * - usePlugin.exclude & useRule.replace - удаляет старый элемент плагин из списка
 *
 * Для всех прочих значение (в том числе массивов) берет новое значение
 */

export var extendConfig = function extendConfig(config, extendFn) {
  return function (env) {
    return PRIVATE_BUILDER_API.build(function () {
      return deepmerge(typeof config === 'function' ? config(env) : config, extendFn(env), function (a, b, path) {
        switch (path.join('.')) {
          case 'plugins':
          case 'optimization.minimizer':
            return PRIVATE_BUILDER_API.buildPlugins(a, b);
          case 'module.rules':
            return PRIVATE_BUILDER_API.buildRules(a, b);
          default:
            return PRIVATE_BUILDER_API.buildConfig(a, b);
        }
      });
    });
  };
};