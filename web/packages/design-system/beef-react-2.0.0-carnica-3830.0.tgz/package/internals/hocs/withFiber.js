import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { FiberAccess } from "../components/FiberAccess";
export function withFiber() {
  return function (WrappedComponent) {
    return function (props) {
      return /*#__PURE__*/React.createElement(FiberAccess, {
        "data-t-id": "internals-hocs"
      }, function (fiber) {
        return /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, props, {
          fiber: fiber
        }));
      });
    };
  };
}