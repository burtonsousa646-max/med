export declare const getNodeScrollBarSize: (target: HTMLElement) => {
    width: number;
    height: number;
};
//# sourceMappingURL=getScrollbarSize.d.ts.map