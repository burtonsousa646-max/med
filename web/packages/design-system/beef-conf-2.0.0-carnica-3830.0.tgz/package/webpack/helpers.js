const filterRules = (rules, excludeRules) => {
  if (!Array.isArray(rules)) rules = [rules];
  return rules.filter(rule => excludeRules.map(String).indexOf(rule.toString()) === -1);
};
const filterLoaders = loaders => {
  /** allow shorthand for loaders */
  if (!Array.isArray(loaders)) loaders = [loaders];
  return loaders.filter(Boolean);
};

/**
 * Joins all 3rd params of loaderRules in a single object
 * with overrideParams merged on top of it
 */
const combineRuleParams = (loaderRules, overrideParams = {}) => loaderRules.reduce((accum, {
  loader,
  options,
  ...params
}) => ({
  ...params,
  ...accum
}), overrideParams);
module.exports = {
  filterRules,
  filterLoaders,
  combineRuleParams
};