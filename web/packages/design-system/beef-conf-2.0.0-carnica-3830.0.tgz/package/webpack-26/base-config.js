/* eslint-disable class-methods-use-this, react-hooks/rules-of-hooks */
import path from 'path';
import { extendConfig } from "./extend-config";
import { usePlugin } from "./usePlugin";
import { useRule } from "./useRule";
import { useConfig } from "./useConfig";
import { baseToolkit } from "./base-toolkit";
var plugins = baseToolkit.plugins,
  loaders = baseToolkit.loaders,
  rules = baseToolkit.rules,
  options = baseToolkit.options;
export var baseConfig = extendConfig({}, function (_ref) {
  var isProduction = _ref.isProduction,
    isServer = _ref.isServer,
    isHMR = _ref.isHMR;
  return {
    mode: isProduction ? 'production' : 'development',
    // NOTE: snapshot.managedPaths & watchOptions.ignored нужны для того,
    //   чтобы изменения в linked-пакетах триггер или HMR
    snapshot: {
      managedPaths: [options.monorepoExcludes]
    },
    watchOptions: {
      ignored: options.monorepoExcludes,
      followSymlinks: true
    },
    output: {
      filename: "".concat(options.filePattern(isProduction), ".js"),
      publicPath: '/',
      path: path.resolve(options.cwd, './build'),
      hotUpdateMainFilename: 'static/[runtime].[fullhash].hot-update.json',
      hotUpdateChunkFilename: 'static/[id].[fullhash].hot-update.js',
      assetModuleFilename: 'static/assets/[name].[hash][ext][query]',
      devtoolModuleFilenameTemplate: function devtoolModuleFilenameTemplate(info) {
        return isHMR ? path.resolve(info.absoluteResourcePath).replace(/\\/g, '/') : info;
      }
    },
    resolve: {
      extensions: ['.js', '.jsx', '.ts', '.tsx'],
      symlinks: false
    },
    module: {
      rules: [useRule(rules.code, loaders.babel)]
    },
    plugins: [usePlugin(plugins.WebpackManifestPlugin, {}), usePlugin(plugins.CircularDependencyPlugin.warnOnError), usePlugin(plugins.EnvironmentPlugin, {
      NODE_ENV: isProduction ? 'production' : 'development'
      // RUN_ENV: process.env.RUN_ENV || '',
      // VERSION: options.version || '',
    }), usePlugin(plugins.DefinePlugin, {
      'typeof window': JSON.stringify(isServer ? 'undefined' : 'object')
    })],
    optimization: {
      minimize: isProduction,
      minimizer: [usePlugin(plugins.TerserPlugin.eraseComments, isProduction)]
    },
    devtool: isProduction ? 'source-map' : 'cheap-module-source-map',
    stats: {
      chunks: false,
      colors: true,
      children: false
    },
    devServer: useConfig({
      hot: true,
      port: process.env.WEBPACK_PORT || 8081,
      headers: {
        'Access-Control-Allow-Origin': '*'
      }
    }, isHMR)
  };
});