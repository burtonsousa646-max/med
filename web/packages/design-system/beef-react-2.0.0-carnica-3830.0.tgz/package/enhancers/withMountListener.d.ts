export function withMountListener(WrappedComponent: any): {
    ({ onMount, onUnmount, ...props }: {
        [x: string]: any;
        onMount: any;
        onUnmount: any;
    }): React.JSX.Element;
    propTypes: any;
};
import React from 'react';
//# sourceMappingURL=withMountListener.d.ts.map