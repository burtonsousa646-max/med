import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "children", "invert", "color", "size"];
import { cnBem } from '@carnica/utils';
import React from 'react';
import styles from "./styles.module.css";
import { Avatar } from "../Avatar";
import { SkeletonBrick } from "../../Skeleton";
var cnSkeleton = cnBem('skeleton-cell-grid', styles);
export var CellGrid = function CellGrid(_ref) {
  var className = _ref.className,
    children = _ref.children,
    invert = _ref.invert,
    color = _ref.color,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnSkeleton({
      size: size
    }, [className])
  }, otherProps, {
    "data-t-id": "components-CellGrid"
  }), /*#__PURE__*/React.createElement(Avatar, {
    color: color,
    invert: invert,
    size: size === 'm' ? 'l' : 'xl'
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: size === 'm' ? 12 : 16,
    invert: invert,
    width: 80
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: size === 'm' ? 12 : 16,
    invert: invert,
    width: 52
  }));
};