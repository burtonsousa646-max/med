import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
var _excluded = ["content", "offset", "badgeClassName"],
  _excluded2 = ["label", "className", "badge", "icon", "inputProps", "invert"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { Text } from "../../Text";
import { Badge } from "../../Badge/V3";
import { getColor } from "./utils";
import styles from "./styles.module.css";
import { SegmentedControlCoreItem } from "../core";
var cnSegmentedControlItem = cnBem('segmented-control-item-v2', styles);
var convertBadgeProps = function convertBadgeProps(badge) {
  if (!badge) {
    return {};
  }
  if (typeof badge === 'string') {
    return {
      children: badge,
      color: 'brand',
      className: cnSegmentedControlItem('badge'),
      style: _defineProperty(_defineProperty({}, '--segemented-control-item-badge-top', 'var(--space-200)'), '--segemented-control-item-badge-right', 'var(--space-negative-100)')
    };
  }
  var content = badge.content,
    _badge$offset = badge.offset,
    offset = _badge$offset === void 0 ? {
      vertical: 8,
      horizontal: -4
    } : _badge$offset,
    badgeClassName = badge.badgeClassName,
    params = _objectWithoutProperties(badge, _excluded);
  var _ref = typeof offset === 'number' ? {
      vertical: offset,
      horizontal: offset
    } : offset,
    _ref$vertical = _ref.vertical,
    vertical = _ref$vertical === void 0 ? 8 : _ref$vertical,
    _ref$horizontal = _ref.horizontal,
    horizontal = _ref$horizontal === void 0 ? -4 : _ref$horizontal;
  return _objectSpread(_objectSpread({}, params), {}, {
    className: cnSegmentedControlItem('badge', [badgeClassName]),
    children: content,
    style: _defineProperty(_defineProperty({}, '--segemented-control-item-badge-top', "".concat(vertical, "px")), '--segemented-control-item-badge-right', "".concat(horizontal, "px"))
  });
};
export var SegmentedControlItem = /*#__PURE__*/forwardRef(function (_ref2, ref) {
  var label = _ref2.label,
    className = _ref2.className,
    badge = _ref2.badge,
    Icon = _ref2.icon,
    inputProps = _ref2.inputProps,
    invert = _ref2.invert,
    otherProps = _objectWithoutProperties(_ref2, _excluded2);
  return /*#__PURE__*/React.createElement(SegmentedControlCoreItem, _extends({}, otherProps, {
    className: cnSegmentedControlItem(null, [className]),
    inputClassName: cnSegmentedControlItem('input'),
    inputProps: inputProps,
    invert: invert,
    ref: ref,
    "data-t-id": "SegmentedControl-V2"
  }), Icon && /*#__PURE__*/React.createElement(Icon, {
    className: cnSegmentedControlItem('icon'),
    color: getColor(inputProps.disabled, inputProps.checked, invert),
    size: 24
  }), !Icon && /*#__PURE__*/React.createElement(Text, {
    className: cnSegmentedControlItem('label'),
    color: getColor(inputProps.disabled, inputProps.checked, invert),
    size: "xs"
  }, label), badge && /*#__PURE__*/React.createElement(Badge, convertBadgeProps(badge)));
});