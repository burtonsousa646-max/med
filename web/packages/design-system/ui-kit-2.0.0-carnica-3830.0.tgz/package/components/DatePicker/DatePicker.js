import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["value", "range", "onChange", "onClear", "minDate", "maxDate", "id", "disabled", "onKeyDown", "onClick", "disableDates", "calendarProps", "locale", "className", "calendarRef", "type", "wrapperProps"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useEffect, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { useFlag, useIsMobileDimension } from '@carnica/utils/hooks';
import styles from "./styles.module.css";
import { Input } from "./Input";
import { Calendar } from "./Calendar";
import { CalendarWrapper } from "./CalendarWrapper";
import { CloseButton } from "./CloseButton";
var cnDatePicker = cnBem('date-picker', styles);
var getValidDate = function getValidDate(a, b) {
  if (!a || !b) {
    return [a, b];
  }
  return b < a ? [b, a] : [a, b];
};
var getCalendarId = function getCalendarId(id, calendarId) {
  if (calendarId) {
    return calendarId;
  }
  return id ? "".concat(id, "-calendar") : undefined;
};
var DatePickerRender = function DatePickerRender(props, ref) {
  var value = props.value,
    range = props.range,
    onChange = props.onChange,
    onClear = props.onClear,
    minDateProp = props.minDate,
    maxDateProp = props.maxDate,
    id = props.id,
    disabled = props.disabled,
    onKeyDown = props.onKeyDown,
    onClick = props.onClick,
    disableDates = props.disableDates,
    calendarProps = props.calendarProps,
    locale = props.locale,
    className = props.className,
    calendarRef = props.calendarRef,
    _props$type = props.type,
    type = _props$type === void 0 ? 'date' : _props$type,
    wrapperProps = props.wrapperProps,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isCalendarOpen = _useFlag2[0],
    setIsCalendarOpen = _useFlag2[1];
  var _useFlag3 = useFlag(),
    _useFlag4 = _slicedToArray(_useFlag3, 2),
    isAnimationFinished = _useFlag4[0],
    setIsAnimationFinished = _useFlag4[1];
  var _getValidDate = getValidDate(minDateProp, maxDateProp),
    _getValidDate2 = _slicedToArray(_getValidDate, 2),
    minDate = _getValidDate2[0],
    maxDate = _getValidDate2[1];
  var inputRef = useRef(null);
  var handleClick = function handleClick() {
    if (!disabled) {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      onClick === null || onClick === void 0 || onClick.apply(void 0, args);
      setIsCalendarOpen.on();
    }
  };
  var calendarId = getCalendarId(id, calendarProps === null || calendarProps === void 0 ? void 0 : calendarProps.id);
  var isMobile = useIsMobileDimension();
  var closeCalendar = function closeCalendar() {
    setIsCalendarOpen.off();
    setTimeout(function () {
      var _inputRef$current;
      return (_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 ? void 0 : _inputRef$current.focus();
    });
  };
  var onCalendarChange = function onCalendarChange() {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    onChange === null || onChange === void 0 || onChange.apply(void 0, args);
    closeCalendar();
  };
  var handleKeyDown = function handleKeyDown(e) {
    onKeyDown === null || onKeyDown === void 0 || onKeyDown(e);
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setIsCalendarOpen.on();
    }
  };
  var onWrapperClick = function onWrapperClick(e) {
    if (!disabled) {
      var _wrapperProps$onClick;
      wrapperProps === null || wrapperProps === void 0 || (_wrapperProps$onClick = wrapperProps.onClick) === null || _wrapperProps$onClick === void 0 || _wrapperProps$onClick.call(wrapperProps, e);
      setIsCalendarOpen.on();
    }
  };
  useEffect(function () {
    if (disabled) {
      setIsCalendarOpen.off();
    }
  }, [disabled]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Input, _extends({}, otherProps, {
    "aria-controls": calendarId,
    className: cnDatePicker(null, [className]),
    disableDates: disableDates,
    disabled: disabled,
    id: id,
    isCalendarOpen: isCalendarOpen,
    maxDate: maxDate,
    minDate: minDate,
    onChange: onChange,
    onClear: onClear,
    onClick: handleClick,
    onKeyDown: handleKeyDown,
    range: range,
    ref: combineRefs([inputRef, ref]),
    type: type,
    value: value,
    wrapperProps: _objectSpread(_objectSpread({}, wrapperProps || {}), {}, {
      onClick: onWrapperClick
    }),
    "data-t-id": "components-DatePicker"
  })), /*#__PURE__*/React.createElement(CalendarWrapper, {
    anchorRef: inputRef,
    className: cnDatePicker('wrapper'),
    isComposed: true,
    isOpen: isCalendarOpen,
    onAnimationComplete: function onAnimationComplete(difinition) {
      return setIsAnimationFinished.set(difinition === 'visible');
    },
    onClose: closeCalendar
  }, /*#__PURE__*/React.createElement(Calendar, _extends({}, calendarProps || {}, {
    className: cnDatePicker('calendar', [calendarProps === null || calendarProps === void 0 ? void 0 : calendarProps.className]),
    disableDates: disableDates,
    id: calendarId,
    isAnimationFinished: isAnimationFinished,
    isComposed: true,
    locale: locale,
    maxDate: maxDate,
    minDate: minDate,
    onChange: onCalendarChange,
    onClear: onClear,
    range: range,
    ref: calendarRef,
    type: type,
    value: value,
    "data-t-id": "components-DatePicker"
  })), isMobile && /*#__PURE__*/React.createElement(CloseButton, {
    onClick: setIsCalendarOpen.off
  })));
};
export var DatePicker = /*#__PURE__*/forwardRef(DatePickerRender);