const fs = require('fs');
const path = require('path');
module.exports = (cwd = process.cwd()) => {
  const webpackConfigPath = path.resolve(cwd, './webpack.config.js');
  if (!fs.existsSync(webpackConfigPath)) {
    throw new Error('Unable to find webpack.config.js');
  }

  // eslint-disable-next-line import/no-dynamic-require
  return require(webpackConfigPath);
};