import { ClassNameList, NoStrictEntityMods } from './types';
export declare const getClassName: (prefix: string, styles?: Record<string, string>, elemOrMods?: NoStrictEntityMods | null | string, elemModsOrBlockMix?: ClassNameList | NoStrictEntityMods | null, elemMix?: ClassNameList) => string;
//# sourceMappingURL=getClassName.d.ts.map