import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "className", "mode", "slideClass", "slidePrevClass", "renderNode", "containerContent", "emblaRef", "withControls", "emblaApi", "loop", "id", "controlsResponseArea", "onNavigationClick", "prevSlideIndex"];
import React, { forwardRef, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import styles from "./styles.module.css";
import { BannerControl } from "./BannerControl";
import { useAccessibility, useBannerControls } from "./hooks";
var cnBanner = cnBem('banner-embla-core', styles);
var defaultRender = function defaultRender(node) {
  return node;
};
export var BannerCore = /*#__PURE__*/forwardRef(function (props, ref) {
  var children = props.children,
    className = props.className,
    mode = props.mode,
    slideClass = props.slideClass,
    slidePrevClass = props.slidePrevClass,
    _props$renderNode = props.renderNode,
    renderNode = _props$renderNode === void 0 ? defaultRender : _props$renderNode,
    containerContent = props.containerContent,
    emblaRef = props.emblaRef,
    withControls = props.withControls,
    emblaApi = props.emblaApi,
    _props$loop = props.loop,
    loop = _props$loop === void 0 ? true : _props$loop,
    id = props.id,
    controlsResponseArea = props.controlsResponseArea,
    onNavigationClick = props.onNavigationClick,
    prevSlideIndex = props.prevSlideIndex,
    otherProps = _objectWithoutProperties(props, _excluded);
  var rootRef = useRef(null);
  var nodes = React.Children.toArray(children);
  var _useBannerControls = useBannerControls({
      withControls: withControls,
      rootRef: rootRef,
      emblaApi: emblaApi,
      loop: loop,
      controlsResponseArea: controlsResponseArea,
      onNavigationClick: onNavigationClick
    }),
    showNextControl = _useBannerControls.showNextControl,
    showPrevControl = _useBannerControls.showPrevControl,
    onButtonClick = _useBannerControls.onButtonClick;
  useAccessibility(emblaApi);
  var slidesId = id ? "".concat(id, "-slides") : undefined;
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnBanner(null, [className, 'embla']),
    id: id,
    ref: combineRefs([rootRef, ref])
  }, otherProps, {
    "data-t-id": "components-BannerEmbla"
  }), containerContent, withControls && ['prev', 'next'].map(function (side) {
    return /*#__PURE__*/React.createElement(BannerControl, {
      "aria-controls": slidesId,
      className: cnBanner('control', {
        side: side,
        visible: side === 'prev' ? showPrevControl : showNextControl
      }),
      direction: side,
      key: side,
      onClick: onButtonClick(side)
    });
  }), /*#__PURE__*/React.createElement("div", {
    "aria-live": "off",
    className: cnBanner('viewport'),
    id: slidesId,
    ref: emblaRef
  }, /*#__PURE__*/React.createElement("div", {
    className: cnBanner('container')
  }, nodes.map(function (node, i) {
    return /*#__PURE__*/React.createElement("div", {
      className: cnBanner('slide', {
        mode: mode,
        i: i
      }, [slideClass, i === prevSlideIndex ? slidePrevClass : undefined]),
      key: cnBanner('slide', {
        i: i
      })
    }, renderNode(node, i));
  }))), /*#__PURE__*/React.createElement("div", {
    className: cnBanner('live-region')
  }));
});