declare function _exports(cwd: any): (api: any) => {
    babelrcRoots: any[];
    ignore: RegExp[];
    overrides: ({
        exclude: any[];
        presets: (false | any[])[];
    } | {
        exclude: RegExp[];
        presets: (false | any[])[];
        plugins: (false | any[])[];
        ignore: any[];
    })[];
};
export = _exports;
//# sourceMappingURL=babelConfigRoot.d.ts.map