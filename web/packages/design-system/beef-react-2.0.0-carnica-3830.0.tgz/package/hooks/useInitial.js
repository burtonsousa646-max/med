import { useMemo } from 'react';

/** Хук мемоизирует изначальное значение при монтировании */
export var useInitial = function useInitial(value) {
  return useMemo(function () {
    return value;
  }, []);
};