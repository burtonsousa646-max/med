import React from 'react';
import { useForceUpdate } from "./useForceUpdate";

/**
 * Работает как обычный setState, но в случае изменения dependencies, берет значение из initialState
 */
export var useDerivedState = function useDerivedState(initialState, dependencies) {
  var forceUpdate = useForceUpdate();
  var stateRef = React.useRef(initialState);
  var setState = function setState(newState) {
    stateRef.current = newState;
    forceUpdate();
  };
  React.useMemo(function () {
    stateRef.current = initialState;
  }, dependencies); // eslint-disable-line react-hooks/exhaustive-deps

  return [stateRef.current, setState];
};