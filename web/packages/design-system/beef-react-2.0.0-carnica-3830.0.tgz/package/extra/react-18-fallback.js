import React from 'react';
import { useId } from "./useId";
React.useInsertionEffect = typeof (React === null || React === void 0 ? void 0 : React.useInsertionEffect) === 'function' ? React.useInsertionEffect : React.useLayoutEffect;
React.useId = typeof (React === null || React === void 0 ? void 0 : React.useId) === 'function' ? React.useId : useId;
if (typeof window === 'undefined') {
  globalThis.performance = {
    now: function now() {
      return 0;
    }
  };
}