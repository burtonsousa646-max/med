import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["url", "iconClassName", "mode"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { MotionComponent } from "../MotionComponent";
import styles from "./styles.module.css";
import { dataConverter } from "./utils";
var cnIcon = cnBem('icon', styles);
var IconRender = function IconRender(_ref, ref) {
  var url = _ref.url,
    iconClassName = _ref.iconClassName,
    mode = _ref.mode,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    ref: ref,
    "data-t-id": "components-Icon"
  }), /*#__PURE__*/React.createElement("span", {
    className: cnIcon('image', {
      mode: mode
    }, [iconClassName]),
    style: _defineProperty({}, '--icon-url', "url(".concat(url, ")")),
    "data-t-id": "components-Icon"
  }));
};
export var Icon = compose(withDataConverter(dataConverter), forwardRef)(IconRender);