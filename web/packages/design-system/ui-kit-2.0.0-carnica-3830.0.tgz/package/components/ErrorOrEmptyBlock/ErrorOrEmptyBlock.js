import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["title", "subTitle", "icon", "className", "children", "invert", "tagName"];
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import React from 'react';
import { IconCloseRoundStroked, IconCompasFilled } from '@carnica/graphics';
import { Text } from "../Text";
import { Button } from "../Button";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnErrorOrEmptyBlock = cnBem('error-or-empty-block', styles);
export var ErrorOrEmptyBlock = forwardRefWithMotionTag(function (props, ref) {
  var _props$title = props.title,
    title = _props$title === void 0 ? 'тут пока пусто' : _props$title,
    _props$subTitle = props.subTitle,
    subTitle = _props$subTitle === void 0 ? 'выберите что-то другое' : _props$subTitle,
    _props$icon = props.icon,
    Icon = _props$icon === void 0 ? IconCompasFilled : _props$icon,
    className = props.className,
    children = props.children,
    invert = props.invert,
    _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'section' : _props$tagName,
    otherProps = _objectWithoutProperties(props, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    "aria-atomic": true,
    className: cnErrorOrEmptyBlock({
      invert: invert
    }, [className]),
    ref: ref,
    role: "status",
    tagName: tagName,
    "data-t-id": "components-ErrorOrEmptyBlock"
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": true,
    className: cnErrorOrEmptyBlock('iconContainer'),
    role: "presentation",
    "data-t-id": "components-ErrorOrEmptyBlock"
  }, /*#__PURE__*/React.createElement(Icon, {
    color: invert ? 'primary-fake-invert' : 'primary',
    size: "m"
  }), /*#__PURE__*/React.createElement(IconCloseRoundStroked, {
    className: cnErrorOrEmptyBlock('close'),
    color: "tertiary",
    size: 20
  })), /*#__PURE__*/React.createElement(Text, {
    align: "center",
    className: cnErrorOrEmptyBlock('title'),
    color: invert ? 'primary-fake-invert' : 'primary',
    variant: "body-medium"
  }, title), /*#__PURE__*/React.createElement(Text, {
    align: "center",
    className: cnErrorOrEmptyBlock('subTitle', {
      withGap: children !== null
    }),
    color: invert ? 'secondary-fake-invert' : 'secondary',
    variant: "body-small"
  }, subTitle), typeof children === 'undefined' ? /*#__PURE__*/React.createElement(Button, {
    onClick: function onClick() {
      return window.location.reload();
    },
    view: invert ? 'secondary-on-primary' : 'tertiary'
  }, "\u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C") : children);
});