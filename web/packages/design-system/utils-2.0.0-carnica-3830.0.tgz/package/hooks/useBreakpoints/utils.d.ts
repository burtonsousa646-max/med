import { BreakpointsMap, BreakpointsResult } from './types';
export declare const mapping: <POINTS extends string>(width: number, map: BreakpointsMap<POINTS>) => BreakpointsResult<POINTS>;
export declare const isPointsEqual: <POINTS extends string>(a: BreakpointsResult<POINTS>, b: BreakpointsResult<POINTS>) => boolean;
//# sourceMappingURL=utils.d.ts.map