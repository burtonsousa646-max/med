export type Route = {
    Component?: string;
    delay?: number;
    getSlug?: (req: {
        query: Record<string, string>;
    }) => string;
    handler?: () => void;
    method?: string;
    status?: number;
    type?: 'htm' | 'json' | 'model' | 'redirect';
    url?: string;
};
export type SafeRoute = Omit<Route, 'getSlug' | 'url'> & Required<Pick<Route, 'getSlug' | 'url'>>;
export type HandlerType = Pick<SafeRoute, 'delay' | 'getSlug' | 'handler' | 'status' | 'type'>;
export type Directory = {
    dirPath: string;
    routes: Route[];
};
//# sourceMappingURL=types.d.ts.map