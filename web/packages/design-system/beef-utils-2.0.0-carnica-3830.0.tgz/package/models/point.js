import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
export var Point = /*#__PURE__*/function () {
  function Point(clientX, clientY) {
    _classCallCheck(this, Point);
    this.clientX = clientX;
    this.clientY = clientY;
  }
  return _createClass(Point, [{
    key: "diff",
    value: function diff(origin) {
      return {
        dx: this.clientX - origin.clientX,
        dy: this.clientY - origin.clientY
      };
    }
  }], [{
    key: "fromEvent",
    value: function fromEvent(event) {
      return new Point(event.clientX, event.clientY);
    }
  }]);
}();