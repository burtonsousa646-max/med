import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "initialTheme", "baseName", "className", "themeStyles"];
import React, { createContext, useContext, useMemo, useState } from 'react';
import { withDataConverter } from '@beef/react';
import { cnBem } from "../../../bem";
import { dataConverter, getThemeStyles } from "./utils";
import defaultStyles from "./themeV1.module.css";
var themeContext = /*#__PURE__*/createContext(['light', function () {}, {
  baseName: 'theme',
  initialTheme: 'light',
  themeStyles: {}
}]);
var ThemeProviderRender = function ThemeProviderRender(props) {
  var children = props.children,
    initialTheme = props.initialTheme,
    _props$baseName = props.baseName,
    baseName = _props$baseName === void 0 ? 'theme' : _props$baseName,
    classNameProp = props.className,
    themeStyles = props.themeStyles,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useState = useState(initialTheme),
    _useState2 = _slicedToArray(_useState, 2),
    theme = _useState2[0],
    setTheme = _useState2[1];
  var styles = useMemo(function () {
    if (!themeStyles) {
      return defaultStyles;
    }
    return getThemeStyles(themeStyles, theme);
  }, [theme, themeStyles]);
  var className = cnBem(baseName, styles)({
    theme: theme
  }, [classNameProp]);
  var value = useMemo(function () {
    return [theme, function (val) {
      return setTheme(val);
    }, {
      initialTheme: initialTheme,
      themeStyles: themeStyles || {},
      baseName: baseName
    }];
  }, [theme, initialTheme, themeStyles, baseName]);
  return /*#__PURE__*/React.createElement(themeContext.Provider, {
    value: value
  }, /*#__PURE__*/React.createElement("div", _extends({
    className: className
  }, otherProps, {
    "data-t-id": "ExampleDecorator-ThemeProvider"
  }), typeof children === 'function' ? children(theme) : children));
};
export var useThemeContext = function useThemeContext() {
  return useContext(themeContext);
};
export var ThemeProvider = withDataConverter(dataConverter)(ThemeProviderRender);