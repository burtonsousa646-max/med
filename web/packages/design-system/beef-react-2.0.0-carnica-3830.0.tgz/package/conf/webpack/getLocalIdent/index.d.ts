export function provideSmartGetLocalIdent({ maxAttempts, hashLength }?: {
    maxAttempts?: number | undefined;
    hashLength?: number | undefined;
}): (context: any, localIdentName: any, localName?: string, options?: {}) => any;
export function replaceNonCSSCharacters(input?: string): string;
//# sourceMappingURL=index.d.ts.map