type TimeParts = {
    hours: number;
    minutes: number;
    ms: number;
    seconds: number;
};
export declare const getTimePartsMs: (timeMs: number) => TimeParts;
type DateParts = {
    days: number;
    hours: number;
    months: number;
    years: number;
};
export declare const getDatePastParts: (dateStartStr: string, dateEndStr?: string) => DateParts | null;
export {};
//# sourceMappingURL=date.d.ts.map