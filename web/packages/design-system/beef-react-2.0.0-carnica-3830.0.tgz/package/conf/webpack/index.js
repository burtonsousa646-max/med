const WebpackFactory = require('./WebpackFactory');
module.exports = {
  webpack: new WebpackFactory(),
  WebpackFactory
};