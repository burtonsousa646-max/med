export type Ctor<T = any, A extends any[] = any[]> = new (...args: A) => T;
export declare const isCtor: (cls: Record<string, any>) => cls is Ctor;
//# sourceMappingURL=common.d.ts.map