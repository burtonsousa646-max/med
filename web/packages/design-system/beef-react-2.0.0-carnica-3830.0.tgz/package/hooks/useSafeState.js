import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import React from 'react';
import { useCheckMounted } from "./useCheckMounted";

/**
 * Absolutely same API as useState, except it does not fire on unmounted components
 */
export function useSafeState(initialState) {
  var _React$useState = React.useState(initialState),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    state = _React$useState2[0],
    setState = _React$useState2[1];
  var checkIsMounted = useCheckMounted();
  var safeSetState = function safeSetState(val) {
    if (checkIsMounted()) {
      setState(val);
    }
  };
  return [state, safeSetState];
}