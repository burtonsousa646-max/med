declare const _exports: {
    parser: string;
    parserOptions: {
        project: any[];
        EXPERIMENTAL_useProjectService: boolean;
    };
    rules: {};
    plugins: string[];
    env: {
        browser: boolean;
        jest: boolean;
        node: boolean;
        es2020: boolean;
    };
    settings: {
        'import/cache': {
            lifetime: string;
        };
        'import/extensions': string[];
        'import/resolver': {
            'babel-module': {
                babelOptions: {
                    rootMode: string;
                };
            };
            node: {};
            exports: {};
        };
    };
    ignorePatterns: string[];
};
export = _exports;
//# sourceMappingURL=slow-ts.config.d.ts.map