import React, { createContext } from 'react';
export var AnimatedIconContext = /*#__PURE__*/createContext(0);
export var AnimatedIconProvider = function AnimatedIconProvider(props) {
  return /*#__PURE__*/React.createElement(AnimatedIconContext.Provider, {
    value: props.activeIndex || 0
  }, props.children);
};