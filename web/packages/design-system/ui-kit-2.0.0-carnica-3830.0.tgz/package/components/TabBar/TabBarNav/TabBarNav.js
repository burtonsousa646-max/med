import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "value", "position", "getters", "convertItem", "invert", "onItemClick", "buttonScrollThrough", "style"],
  _excluded2 = ["key", "attributes", "label"];
import React, { forwardRef, useCallback, useMemo, useRef, useState } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { useConvertedItems } from "../../../hooks/useConvertedItems";
import styles from "./styles.module.css";
import { TabBarItem } from "../TabBarItem";
import { useTabBar } from "../hooks/useTabBar";
import { TabBarNavWrapper } from "./TabBarNavWrapper";
import { useNavigationScroll } from "../hooks/useNavigationScroll";
import { useHiddenElementsCount } from "../hooks/useHiddenElementsCount";
import { useScrollBlur } from "../hooks/useScrollBlur";
import { useNavKeyboardHandler } from "../hooks/useNavKeyboardHandler";
import { convertItemToDefault, itemKeys } from "./utils";
var cnTabBarNav = cnBem('tabbar-nav', styles);
var TabBarNavRender = function TabBarNavRender(props, ref) {
  var itemsProp = props.items,
    value = props.value,
    position = props.position,
    getters = props.getters,
    convertItem = props.convertItem,
    invert = props.invert,
    onItemClick = props.onItemClick,
    _props$buttonScrollTh = props.buttonScrollThrough,
    buttonScrollThrough = _props$buttonScrollTh === void 0 ? 'end' : _props$buttonScrollTh,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useState = useState(-1),
    _useState2 = _slicedToArray(_useState, 2),
    hoveredIndex = _useState2[0],
    setHoveredIndex = _useState2[1];
  var wrapperRef = useRef(null);
  var items = useConvertedItems({
    items: itemsProp || [],
    getters: getters,
    convertItem: convertItem,
    keys: itemKeys,
    withOriginal: true
  });
  var convertedValue = useMemo(function () {
    return value ? convertItemToDefault(getters, convertItem)(value) : undefined;
  }, [value]);
  var _useNavKeyboardHandle = useNavKeyboardHandler(items),
    tabRefs = _useNavKeyboardHandle.tabRefs,
    onKeyDownByItem = _useNavKeyboardHandle.onKeyDownByItem;
  var _useTabBar = useTabBar({
      items: items,
      value: convertedValue,
      tabRefs: tabRefs
    }),
    pointer = _useTabBar.pointer,
    tabWidths = _useTabBar.tabWidths,
    activeIndex = _useTabBar.activeIndex;
  var indexHandler = useCallback(function (index) {
    return function () {
      var item = items[index];
      // Затемняем прочие табы если таб на который навелись не активный и доступный для выбора
      setHoveredIndex(item && !item.converted.disabled && activeIndex !== index ? index : -1);
    };
  }, []);
  var handleItemClick = useCallback(function (item) {
    return function (e) {
      var _item$converted$onCli, _item$converted;
      onItemClick === null || onItemClick === void 0 || onItemClick(item.original, e);
      (_item$converted$onCli = (_item$converted = item.converted).onClick) === null || _item$converted$onCli === void 0 || _item$converted$onCli.call(_item$converted, e);
    };
  }, [onItemClick]);
  var hiddenCount = useHiddenElementsCount({
    wrapperRef: wrapperRef,
    tabWidths: tabWidths
  });
  var _useScrollBlur = useScrollBlur({
      position: position,
      wrapperRef: wrapperRef,
      tabWidths: tabWidths,
      offset: {
        left: position === 'fixed' ? 6 : 4
      }
    }),
    setBlurOffset = _useScrollBlur.setBlurOffset,
    blurAreaRefs = _useScrollBlur.blurAreaRefs;
  var onScrollButtonClick = useNavigationScroll({
    wrapperRef: wrapperRef,
    buttonScrollThrough: buttonScrollThrough,
    tabWidths: tabWidths,
    position: position,
    setBlurOffset: setBlurOffset,
    activeIndex: activeIndex
  });
  return /*#__PURE__*/React.createElement(TabBarNavWrapper, _extends({
    blurAreaRefs: blurAreaRefs,
    hiddenCount: hiddenCount,
    invert: invert,
    onScrollButtonClick: onScrollButtonClick,
    onUlMouseLeave: indexHandler(-1),
    position: position,
    ref: ref,
    role: "navigation",
    wrapperRef: wrapperRef
  }, otherProps, {
    "data-t-id": "TabBar-TabBarNav"
  }), /*#__PURE__*/React.createElement("li", {
    "aria-hidden": true,
    className: cnTabBarNav('pointer', {
      visible: !!pointer.width,
      invert: invert
    }),
    style: _defineProperty(_defineProperty({}, '--tabbar-pointer-width', "".concat(pointer.width, "px")), '--tabbar-pointer-offset', "".concat(pointer.offset, "px")),
    "data-t-id": "TabBar-TabBarNav"
  }), items.map(function (item, i) {
    var _item$converted2 = item.converted,
      key = _item$converted2.key,
      attributes = _item$converted2.attributes,
      label = _item$converted2.label,
      converted = _objectWithoutProperties(_item$converted2, _excluded2);
    return /*#__PURE__*/React.createElement("li", {
      className: cnTabBarNav('item'),
      key: key,
      onMouseEnter: indexHandler(i)
    }, /*#__PURE__*/React.createElement(TabBarItem, _extends({
      accent: hoveredIndex !== -1 ? activeIndex === i || hoveredIndex === i : true,
      "aria-current": activeIndex === i,
      invert: invert,
      size: position === 'fixed' ? 's' : 'm'
    }, attributes, converted, {
      onClick: handleItemClick(item),
      onKeyDown: onKeyDownByItem(item),
      ref: combineRefs([converted.ref, tabRefs[i]])
    }), label));
  }));
};
export var TabBarNav = /*#__PURE__*/forwardRef(TabBarNavRender);