export let rules: {
    'jsx-a11y/click-events-have-key-events': number;
    'jsx-a11y/mouse-events-have-key-events': number;
    'jsx-a11y/anchor-is-valid': number;
    'jsx-a11y/label-has-associated-control': (string | {
        required: {
            some: string[];
        };
    })[];
    'jsx-a11y/label-has-for': number;
    'jsx-a11y/media-has-caption': number;
    'jsx-a11y/no-static-element-interactions': number;
};
//# sourceMappingURL=accessibility.d.ts.map