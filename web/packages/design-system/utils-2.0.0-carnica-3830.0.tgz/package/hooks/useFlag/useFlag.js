import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useMemo, useState } from 'react';
export var useFlag = function useFlag() {
  var initial = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
  var _useState = useState(initial),
    _useState2 = _slicedToArray(_useState, 2),
    state = _useState2[0],
    setState = _useState2[1];
  var setters = useMemo(function () {
    return {
      on: function on() {
        return setState(true);
      },
      off: function off() {
        return setState(false);
      },
      toggle: function toggle() {
        return setState(function (flag) {
          return !flag;
        });
      },
      set: setState
    };
  }, []);
  return [state, setters];
};