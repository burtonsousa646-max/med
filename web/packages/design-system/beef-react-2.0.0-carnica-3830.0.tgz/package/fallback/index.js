import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import React, { useState } from 'react';
var globalIdCounter = 0;
var generateUniqueId = function generateUniqueId(prefix) {
  globalIdCounter += 1;
  return "".concat(prefix, "-").concat(globalIdCounter);
};
export var useId = function useId() {
  var _useState = useState(function () {
      return generateUniqueId('use-id');
    }),
    _useState2 = _slicedToArray(_useState, 1),
    id = _useState2[0];
  return id;
};
React.useId = typeof (React === null || React === void 0 ? void 0 : React.useId) === 'function' ? React.useId : useId;
React.useInsertionEffect = typeof (React === null || React === void 0 ? void 0 : React.useInsertionEffect) === 'function' ? React.useInsertionEffect : React.useLayoutEffect;