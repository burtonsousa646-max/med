export * from './useDeprecationWarning';
//# sourceMappingURL=index.d.ts.map