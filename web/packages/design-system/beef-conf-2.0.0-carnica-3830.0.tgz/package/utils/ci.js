const {
  execSync
} = require('child_process');
const {
  CI,
  CI_REPO_URL,
  CI_COMMIT_SHA,
  CI_COMMIT_BRANCH,
  CI_COMMIT_TITLE,
  CI_PUBLISH_BRANCH,
  ADAPTIVE_REPO_URL,
  ELK_REPO_URL,
  CI_MERGE_REQUEST_TARGET_BRANCH_NAME,
  CI_MERGE_REQUEST_SOURCE_BRANCH_SHA,
  CI_MERGE_REQUEST_SOURCE_BRANCH_NAME,
  BEEF_PUBLISH,
  BEEF_UPGRADE_SCOPE
} = process.env;
const CI_VARIABLES = {
  CI,
  CI_COMMIT_SHA,
  CI_COMMIT_BRANCH,
  CI_COMMIT_TITLE,
  CI_REPO_URL,
  CI_PUBLISH_BRANCH,
  ADAPTIVE_REPO_URL,
  ELK_REPO_URL,
  CI_MERGE_REQUEST_TARGET_BRANCH_NAME,
  CI_MERGE_REQUEST_SOURCE_BRANCH_SHA,
  CI_MERGE_REQUEST_SOURCE_BRANCH_NAME,
  BEEF_PUBLISH,
  BEEF_UPGRADE_SCOPE
};
const isCI = CI_VARIABLES.CI;
const gitInitCI = repository => execSync(['git config --global user.email "ci@pipeline.ru"', 'git config --global user.name "CI Pipeline"', 'git config --global http.sslVerify false', `git remote set-url origin ${repository}`, 'git fetch origin --quiet'].join(' && '));
module.exports = {
  gitInitCI,
  CI_VARIABLES,
  isCI
};