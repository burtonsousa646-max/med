export declare const usePrevious: <T>(value: T) => T | null;
//# sourceMappingURL=usePrevious.d.ts.map