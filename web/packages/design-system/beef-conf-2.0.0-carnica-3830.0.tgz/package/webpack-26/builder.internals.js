import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _typeof from "@babel/runtime/helpers/typeof";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { stringifyRule } from "./utilities";
var builderStack = [];
var builderState;

/**
 * TODO: возможно будет полезно считать число замен и примененных замен, чтобы выводить ошибку
 */
var configReplaceSymbol = Symbol('Replaced by useConfig.replace');

/**
 * Приватный API билдера. Не предназначен для использования в продуктовом коде.
 *
 * Содержит логику работы builder`а конфигов
 */
export var PRIVATE_BUILDER_API = {
  build: function build(fn) {
    // if (builderState.isBuilding) throw new Error('mergeConfig не могут быть вложены друг в друга');
    builderState = {
      plugins: {
        excluded: {},
        replaced: new WeakMap()
      },
      rules: {
        excluded: {},
        replaced: {}
      },
      errors: {}
    };
    builderStack.push(builderState);
    var result = fn();
    builderState = builderStack.pop();
    return result;
  },
  assertBuilding: function assertBuilding(name) {
    if (builderState) return;
    throw new Error("".concat(name, " \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0432\u044B\u0437\u0432\u0430\u043D \u0437\u0430 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u043C\u0438 mergeConfig'\u0430"));
  },
  /** configs */

  replaceConfig: function replaceConfig(arg) {
    return _objectSpread(_objectSpread({}, arg), {}, _defineProperty({}, configReplaceSymbol, true));
  },
  buildConfig: function buildConfig(initial, replaceConfig) {
    if (replaceConfig[configReplaceSymbol]) {
      return replaceConfig;
    }
    return undefined;
  },
  /** rules */

  replaceRule: function replaceRule(rule, replacementRule) {
    builderState.rules.replaced[rule.toString()] = replacementRule;
  },
  excludeRule: function excludeRule(rule) {
    var excludeSymbol = Symbol("Exclude placeholder for rule ".concat(rule.toString()));
    builderState.rules.excluded[excludeSymbol] = rule;
    return excludeSymbol;
  },
  /** plugins */

  replacePlugin: function replacePlugin(PluginCls, replacementPlugin) {
    builderState.plugins.replaced.set(PluginCls, replacementPlugin);
    return replacementPlugin;
  },
  excludePlugin: function excludePlugin(PluginCls) {
    var excludeSymbol = Symbol("Exclude placeholder for ".concat(PluginCls.constructor.name));
    builderState.plugins.excluded[excludeSymbol] = PluginCls;
    return excludeSymbol;
  },
  buildRules: function buildRules() {
    var originalRules = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    var extendRules = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    return extendRules.reduce(function (rules, rule) {
      if (!rule || rule === '...') return rules;
      // Символ, подставляется директивой useRule.exclude
      if (_typeof(rule) === 'symbol') {
        var excluded = builderState.rules.excluded[rule];
        return rules.filter(function (item) {
          return item && item !== '...' && stringifyRule(item.test) !== excluded.toString();
        });
      }
      // Меняем выбранное правило на передаваемое
      if (rule.test && builderState.rules.replaced[stringifyRule(rule.test)]) {
        var replaceRule = builderState.rules.replaced[stringifyRule(rule.test)];
        var replaceRuleIndex = rules.findIndex(function (item) {
          return (item && item !== '...' && item.test && stringifyRule(item.test)) === (rule && rule.test && stringifyRule(rule.test));
        });
        extendRules = extendRules.filter(function (item) {
          return item !== replaceRule;
        });
        rules.splice(replaceRuleIndex, 1, replaceRule);
        return rules;
      }
      // Добавляем правило в конец списка
      return [].concat(_toConsumableArray(rules), [rule]);
    }, originalRules);
  },
  buildPlugins: function buildPlugins(originalPlugins, extendPlugins) {
    return extendPlugins.reduce(function (plugins, plugin) {
      if (!plugin) return plugins;
      // Символ, подставляется директивой usePlugin.exclude
      if (_typeof(plugin) === 'symbol') return plugins.filter(function (item) {
        return item.constructor !== builderState.plugins.excluded[plugin];
      });
      // Меняем существующий плагин на новый
      if (builderState.plugins.replaced.has(plugin.constructor)) {
        // return plugins.splice(plugins.indexOf(replacePlugin), 1, plugin);
        var index = plugins.findIndex(function (p) {
          return p.constructor === plugin.constructor;
        });
        if (index !== -1) {
          plugins.splice(index, 1, plugin);
          return plugins;
        }
      }
      // Добавляем правило в конец списка
      return [].concat(_toConsumableArray(plugins), [plugin]);
    }, originalPlugins.filter(Boolean));
  }
};