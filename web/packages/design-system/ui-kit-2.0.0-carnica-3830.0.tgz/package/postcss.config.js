module.exports = require('@beef/react/conf').postcssConfig;
