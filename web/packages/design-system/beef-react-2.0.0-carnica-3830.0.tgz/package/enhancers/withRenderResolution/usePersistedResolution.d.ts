import { TResolutions } from './types';
export declare const usePersistedResolution: (lastKnownResolution: number, resolutions: TResolutions) => null | number;
//# sourceMappingURL=usePersistedResolution.d.ts.map