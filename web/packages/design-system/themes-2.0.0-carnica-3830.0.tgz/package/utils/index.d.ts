type ThemeType = 'dark' | 'light';
type ThemeVersion = 'v1' | 'v2';
export declare const cnTheme: (theme?: ThemeType, version?: ThemeVersion) => string;
export {};
//# sourceMappingURL=index.d.ts.map