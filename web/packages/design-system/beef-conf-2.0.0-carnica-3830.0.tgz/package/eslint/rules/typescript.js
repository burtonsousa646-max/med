module.exports = {
  rules: {
    // disable return type validation, typescript does that just fine
    '@typescript-eslint/explicit-function-return-type': 0,
    // Allow unused array destructuring to have leading underscore,
    // Conflicts with prettier
    '@typescript-eslint/indent': 0,
    // Used with destructuredArrayIgnorePattern: '^_' in `[@typescript-eslint/]no-unused-vars` rule
    '@typescript-eslint/naming-convention': [0, {
      format: ['camelCase'],
      leadingUnderscore: 'allow',
      modifiers: ['unused'],
      selector: 'variable'
    }],
    // Sometimes you know that interfaces are not the same, but don't know what fields can be added
    '@typescript-eslint/no-empty-interface': ['error', {
      allowSingleExtends: true
    }],
    // ts-nazi rule, takes ages to play with non-any types
    '@typescript-eslint/no-explicit-any': 0,
    // Can't even pass async function into a promise, with this entirely on
    '@typescript-eslint/no-misused-promises': [2, {
      checksVoidReturn: false
    }],
    // ts-nazi rule, another extension of no-explicit-any, in terms of passing an argument
    '@typescript-eslint/no-unsafe-argument': 0,
    // ts-nazi rule, extension of no-explicit-any
    '@typescript-eslint/no-unsafe-assignment': 0,
    // ts-nazi rule, breaks on dom, e.g., can't even call methods of dom elements
    '@typescript-eslint/no-unsafe-call': 0,
    // ts-nazi rule, it can be js-safe, but not ts-safe
    '@typescript-eslint/no-unsafe-member-access': 0,
    // ts-nazi rule, just. Too. Complicated
    '@typescript-eslint/no-unsafe-return': 0,
    // When destructuring arrays, there must be a way to ignore variables
    // Example: [used, _unused, alsoUsed]
    '@typescript-eslint/no-unused-vars': [2, {
      destructuredArrayIgnorePattern: '^_',
      ignoreRestSiblings: true
    }],
    // similar to js rule, mostly should be okay to use before define
    '@typescript-eslint/no-use-before-define': 0,
    // disable prop-types check in tsx files
    'react/prop-types': 0
  }
};