import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "anchorRef", "className", "onClickOutside"];
import { AnimatePresence } from 'framer-motion';
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { Popover } from "../../../modules/Popover";
import styles from "./styles.module.css";
var cnSelectList = cnBem('select-list', styles);
var variants = {
  hidden: {
    poinerEvents: 'none',
    y: 12,
    opacity: 0
  },
  visible: {
    y: 0,
    opacity: 1,
    poinerEvents: 'all'
  }
};
export var SelectListWrapper = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var isOpen = _ref.isOpen,
    anchorRef = _ref.anchorRef,
    className = _ref.className,
    onClickOutside = _ref.onClickOutside,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait",
    onExitComplete: function onExitComplete() {
      return null;
    },
    "data-t-id": "Select-SelectList"
  }, isOpen && /*#__PURE__*/React.createElement(Popover, _extends({}, otherProps, {
    anchorRef: anchorRef,
    animate: "visible",
    className: cnSelectList(null, [className]),
    direction: "downStartLeft",
    equalAnchorWidth: true,
    exit: "hidden",
    initial: "hidden",
    motion: true,
    offsetVertical: 8,
    onClickOutside: onClickOutside,
    possibleDirections: ['downStartLeft', 'upStartLeft'],
    ref: ref,
    reposition: true,
    role: "listbox",
    transition: {
      transform: {
        duration: 0.3
      },
      opacity: {
        duration: 0.3
      }
    },
    variants: variants
  })));
});