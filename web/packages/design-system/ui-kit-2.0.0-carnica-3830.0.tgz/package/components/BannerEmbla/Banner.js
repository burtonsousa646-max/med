import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "progressBarClassName", "duration", "autoPlay", "loop", "children", "emblaOptions", "infinite", "invertBar", "swiperOptions", "withControls", "onEmblaInit", "onChangeSlide", "onMouseLeave", "onMouseEnter", "onNavigationClick", "onActiveIndexChange", "mode", "controlsResponseArea", "shouldRender", "slideClassName", "slidePrevClass"];
import React, { forwardRef, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { withRenderCondition } from '@beef/react';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { ProgressBar } from "../ProgressBar";
import styles from "./styles.module.css";
import { BannerCore } from "./BannerCore";
import { useEmblaCarousel, useProgressBar, useVirtualSlides } from "./hooks";
var cnBanner = cnBem('banner-embla', styles);
var BannerRender = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    progressBarClassName = props.progressBarClassName,
    _props$duration = props.duration,
    duration = _props$duration === void 0 ? 2500 : _props$duration,
    _props$autoPlay = props.autoPlay,
    autoPlay = _props$autoPlay === void 0 ? true : _props$autoPlay,
    _props$loop = props.loop,
    loop = _props$loop === void 0 ? true : _props$loop,
    children = props.children,
    emblaOptions = props.emblaOptions,
    infinite = props.infinite,
    invertBar = props.invertBar,
    swiperOptions = props.swiperOptions,
    withControls = props.withControls,
    onEmblaInit = props.onEmblaInit,
    onChangeSlide = props.onChangeSlide,
    onMouseLeave = props.onMouseLeave,
    onMouseEnter = props.onMouseEnter,
    onNavigationClick = props.onNavigationClick,
    onActiveIndexChange = props.onActiveIndexChange,
    mode = props.mode,
    controlsResponseArea = props.controlsResponseArea,
    shouldRender = props.shouldRender,
    slideClassName = props.slideClassName,
    slidePrevClass = props.slidePrevClass,
    otherProps = _objectWithoutProperties(props, _excluded);
  useDeprecationWarning({
    infinite: {
      value: infinite,
      newPropKey: 'loop={true}'
    }
  });
  var containerRef = useRef(null);
  var nodes = useVirtualSlides({
    children: children,
    loop: loop,
    mode: mode
  });
  var slides = React.Children.count(children);
  var _useEmblaCarousel = useEmblaCarousel({
      mode: mode,
      autoPlay: autoPlay,
      loop: loop,
      onChangeSlide: onChangeSlide,
      slides: slides,
      onEmblaInit: onEmblaInit,
      emblaOptions: emblaOptions,
      withControls: withControls,
      originalSlidesCount: slides,
      onActiveIndexChange: onActiveIndexChange
    }),
    emblaRef = _useEmblaCarousel.emblaRef,
    emblaApi = _useEmblaCarousel.emblaApi,
    activeSlide = _useEmblaCarousel.activeSlide,
    isPlay = _useEmblaCarousel.isPlay,
    changeSlide = _useEmblaCarousel.changeSlide,
    prevSlideIndex = _useEmblaCarousel.prevSlideIndex;
  var progressBarProps = useProgressBar({
    autoPlay: autoPlay,
    duration: duration,
    loop: loop,
    isActive: isPlay,
    activeSlide: activeSlide,
    slides: slides,
    changeSlide: changeSlide,
    onSlideChange: emblaApi === null || emblaApi === void 0 ? void 0 : emblaApi.goToNext
  });
  return /*#__PURE__*/React.createElement(BannerCore, _extends({}, otherProps, {
    className: cnBanner({
      mode: mode
    }, [className]),
    containerContent: slides > 1 ? /*#__PURE__*/React.createElement(ProgressBar, _extends({
      className: cnBanner('progress', {
        hidden: mode === 'default' ? false : !isPlay
      }, [progressBarClassName]),
      invert: invertBar,
      style: _defineProperty({}, '--banner-slides', nodes.length)
    }, progressBarProps)) : null,
    controlsResponseArea: controlsResponseArea,
    emblaApi: emblaApi,
    emblaRef: emblaRef,
    loop: loop,
    onNavigationClick: onNavigationClick,
    prevSlideIndex: prevSlideIndex,
    ref: combineRefs([ref, containerRef]),
    slideClass: cnBanner('slide', {
      mode: mode
    }, [slideClassName || (swiperOptions === null || swiperOptions === void 0 ? void 0 : swiperOptions.slideClass)]),
    slidePrevClass: slidePrevClass,
    withControls: withControls && slides > 1,
    "data-t-id": "components-BannerEmbla"
  }), nodes);
});
export var Banner = withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref2) {
    var children = _ref2.children;
    return !!React.Children.count(children);
  }
})(BannerRender);