export var themeItems = [{
  icon: 'https://static.beeline.ru/upload/images/carnica/icons/IconSunFilled.svg',
  value: 'light'
}, {
  icon: 'https://static.beeline.ru/upload/images/carnica/icons/IconMoonFilled.svg',
  value: 'dark'
}];
export var versionItems = [{
  label: 'v1',
  value: 'v1'
}, {
  label: 'v2',
  value: 'v2'
}];