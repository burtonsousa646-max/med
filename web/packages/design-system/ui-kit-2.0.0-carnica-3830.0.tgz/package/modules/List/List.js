import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "groups", "renderItem", "convertGroup", "convertItem", "itemGetters", "groupGetters", "onItemClick", "className", "motion", "invert"],
  _excluded2 = ["onClick", "attributes", "groupKey"];
import React, { forwardRef, useCallback } from 'react';
import { cnBem } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { useConvertedItems } from "../../hooks/useConvertedItems";
import styles from "./styles.module.css";
import { useList } from "./hooks/useList";
import { dataConverter, groupKeys, itemKeys } from "./utils";
import { ListItem } from "./ListItem";
import { ListGroup } from "./ListGroup";
import { MotionComponent } from "../MotionComponent";
import { useListKeyboardHandler } from "./hooks/useListKeyboardHandler";
var cnList = cnBem('list', styles);
var ListRender = function ListRender(props, ref) {
  var itemsProp = props.items,
    groupsProp = props.groups,
    renderItem = props.renderItem,
    convertGroup = props.convertGroup,
    convertItem = props.convertItem,
    itemGetters = props.itemGetters,
    groupGetters = props.groupGetters,
    onItemClick = props.onItemClick,
    className = props.className,
    motion = props.motion,
    invert = props.invert,
    otherProps = _objectWithoutProperties(props, _excluded);
  var items = useConvertedItems({
    items: itemsProp || [],
    keys: itemKeys,
    getters: itemGetters,
    convertItem: convertItem,
    withOriginal: true
  });
  var groups = useConvertedItems({
    items: groupsProp || [],
    keys: groupKeys,
    getters: groupGetters,
    convertItem: convertGroup,
    prefix: 'group'
  });
  var listItems = useList({
    items: items,
    groups: groups
  });
  var _useListKeyboardHandl = useListKeyboardHandler(items),
    onKeyDownByIndex = _useListKeyboardHandl.onKeyDownByIndex,
    optionRefs = _useListKeyboardHandl.optionRefs;
  var renderItemDefault = function renderItemDefault(item) {
    var onClick = item.onClick,
      attributes = item.attributes,
      groupKey = item.groupKey,
      params = _objectWithoutProperties(item, _excluded2);
    var handleClick = function handleClick(e) {
      var _item$onClick;
      (_item$onClick = item.onClick) === null || _item$onClick === void 0 || _item$onClick.call(item, e);
      onItemClick === null || onItemClick === void 0 || onItemClick(item, e);
    };
    return /*#__PURE__*/React.createElement(ListItem, _extends({}, attributes, params, {
      invert: invert,
      onClick: handleClick,
      ref: item.ref,
      "data-t-id": "modules-List"
    }));
  };
  var renderListItem = useCallback(function (item) {
    return renderItem ? renderItem(item.original) : renderItemDefault(item.converted);
  }, [renderItem, onItemClick]);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({
    role: "listbox"
  }, otherProps, {
    className: cnList(null, [className]),
    motion: motion,
    ref: ref,
    tagName: "ul"
  }), listItems.map(function (item) {
    return /*#__PURE__*/React.createElement(MotionComponent, _extends({
      key: "".concat(item.type, "-").concat(item.type === 'item' ? item.converted.key : item.element.key),
      onKeyDown: item.type === 'item' ? onKeyDownByIndex(item.index) : undefined,
      ref: item.type === 'item' ? optionRefs[item.index] : undefined,
      role: "presentation",
      tagName: "li"
    }, motion ? {
      motion: true,
      layout: true
    } : {}), item.type === 'item' ? renderListItem(item) : /*#__PURE__*/React.createElement(ListGroup, {
      className: cnList('group'),
      role: "presentation",
      tabIndex: -1
    }, item.element.label));
  }));
};
export var List = compose(withDataConverter(dataConverter), forwardRef)(ListRender);