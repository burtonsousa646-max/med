export var ATTRIBUTE_PORTAL = 'portal';
export var ATTRIBUTE_PORTAL_VALUE = 'portal';
export var ATTRIBUTE_SEARCH_MODAL = 'searchmodal';