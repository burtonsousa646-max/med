import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "onClose", "isComposed", "anchorRef", "style", "children", "className"];
import React, { forwardRef } from 'react';
import { AnimatePresence } from 'framer-motion';
import { cnBem } from '@carnica/utils';
import { useFlag, useIsMobileDimension } from '@carnica/utils/hooks';
import { FocusTrap } from 'focus-trap-react';
import { BottomSheet } from "../../../modules/BottomSheet";
import { Popover } from "../../../modules/Popover";
import styles from "./styles.module.css";
var varinats = {
  hidden: {
    poinerEvents: 'none',
    y: 'var(--space-300)',
    opacity: 0
  },
  visible: {
    y: 0,
    opacity: 1,
    poinerEvents: 'all'
  }
};
var cnCalendarWrapper = cnBem('wrapper', styles);
export var CalendarWrapper = /*#__PURE__*/forwardRef(function (props, ref) {
  var isOpen = props.isOpen,
    onClose = props.onClose,
    isComposed = props.isComposed,
    anchorRef = props.anchorRef,
    style = props.style,
    children = props.children,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isAnimationComplete = _useFlag2[0],
    setIsAnimationComplete = _useFlag2[1];
  var handleKeyDown = function handleKeyDown(e) {
    var _otherProps$onKeyDown;
    (_otherProps$onKeyDown = otherProps.onKeyDown) === null || _otherProps$onKeyDown === void 0 || _otherProps$onKeyDown.call(otherProps, e);
    if (e.code === 'Escape') {
      onClose === null || onClose === void 0 || onClose();
    }
  };
  if (isMobile) {
    return /*#__PURE__*/React.createElement(BottomSheet, _extends({}, otherProps, {
      "aria-label": "\u0412\u044B\u0431\u043E\u0440 \u0434\u0430\u0442\u044B",
      "aria-live": "polite",
      className: cnCalendarWrapper(null, [className]),
      closeOptions: {
        overlay: true
      },
      isOpen: isOpen,
      onClose: onClose,
      ref: ref,
      "data-t-id": "DatePicker-CalendarWrapper"
    }), children);
  }
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait",
    onExitComplete: function onExitComplete() {
      return null;
    }
  }, isOpen && /*#__PURE__*/React.createElement(FocusTrap, {
    active: isAnimationComplete,
    focusTrapOptions: {
      fallbackFocus: function fallbackFocus() {
        var _document;
        return (_document = document) === null || _document === void 0 ? void 0 : _document.body;
      },
      delayInitialFocus: true,
      allowOutsideClick: true,
      preventScroll: true,
      returnFocusOnDeactivate: false
    }
  }, /*#__PURE__*/React.createElement(Popover, _extends({}, otherProps, {
    anchorRef: anchorRef,
    animate: "visible",
    "aria-modal": true,
    className: cnCalendarWrapper(null, [className]),
    direction: "downStartLeft",
    exit: "hidden",
    initial: "hidden",
    motion: true,
    offsetVertical: 18,
    onAnimationComplete: function onAnimationComplete(difinition) {
      var _otherProps$onAnimati;
      setIsAnimationComplete.set(difinition === 'visible');
      (_otherProps$onAnimati = otherProps.onAnimationComplete) === null || _otherProps$onAnimati === void 0 || _otherProps$onAnimati.call(otherProps, difinition);
    },
    onClickOutside: onClose,
    onKeyDown: handleKeyDown,
    possibleDirections: ['downStartLeft', 'upStartLeft'],
    role: "dialog",
    transition: {
      transform: {
        duration: 0.3
      },
      opacity: {
        duration: 0.3
      }
    },
    variants: varinats,
    "data-t-id": "DatePicker-CalendarWrapper"
  }), children)));
});