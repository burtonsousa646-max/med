import { useEffect, useRef } from 'react';
export var useDidUpdateEffect = function useDidUpdateEffect(callback, deps) {
  var isMountingRef = useRef(false);
  useEffect(function () {
    if (isMountingRef.current) {
      callback();
    } else {
      isMountingRef.current = true;
    }
  }, deps);
};