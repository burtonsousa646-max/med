import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["onMount", "onUnmount"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React from 'react';
import PropTypes from 'prop-types';

/**
 * На текущий момент поддерживает только mount,
 * можно добавить еще onMountChange({ type })
 */
export function withMountListener(WrappedComponent) {
  var MountListener = function MountListener(_ref) {
    var onMount = _ref.onMount,
      onUnmount = _ref.onUnmount,
      props = _objectWithoutProperties(_ref, _excluded);
    React.useEffect(function () {
      onMount === null || onMount === void 0 || onMount();
    }, [onMount]);
    // onUnmount сохраняется в момент монтирования
    // нужен useWillUnmount, который сохраняет callback в ref и вызывает последнюю версию этого callback'а.
    React.useEffect(function () {
      return function () {
        onUnmount === null || onUnmount === void 0 || onUnmount();
      };
    }, []);
    return /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, props, {
      "data-t-id": "src-enhancers"
    }));
  };
  MountListener.propTypes = process.env.NODE_ENV !== "production" ? _objectSpread(_objectSpread({}, WrappedComponent.propTypes), {}, {
    onMount: PropTypes.func,
    onUnMount: PropTypes.func
  }) : {};
  return MountListener;
}