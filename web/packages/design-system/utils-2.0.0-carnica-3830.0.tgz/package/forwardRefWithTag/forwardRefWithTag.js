import React from 'react';
export function forwardRefWithTag(render) {
  return /*#__PURE__*/React.forwardRef(render);
}