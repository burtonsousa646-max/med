import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "title", "subTitle", "size", "align", "reverse", "titleTagName"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withRenderCondition } from '@beef/react';
import { Text } from "../Text";
import { MotionComponent } from "../../modules/MotionComponent";
import { subTitleSizeMap, titleSizeMap, titleTagMap } from "./utils";
import styles from "./styles.module.css";
var cnTitle = cnBem('title', styles);
var TitleRender = function TitleRender(_ref, ref) {
  var className = _ref.className,
    title = _ref.title,
    subTitle = _ref.subTitle,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    _ref$align = _ref.align,
    align = _ref$align === void 0 ? 'center' : _ref$align,
    _ref$reverse = _ref.reverse,
    reverse = _ref$reverse === void 0 ? false : _ref$reverse,
    titleTagName = _ref.titleTagName,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnTitle({
      size: size,
      reverse: reverse
    }, [className]),
    ref: ref,
    "data-t-id": "components-Title"
  }), title && /*#__PURE__*/React.createElement(Text, {
    align: align,
    className: cnTitle('title'),
    color: "primary",
    tagName: titleTagName || titleTagMap[size],
    variant: titleSizeMap[size]
  }, title), subTitle && /*#__PURE__*/React.createElement(Text, {
    align: align,
    className: cnTitle('subtitle'),
    color: "secondary",
    tagName: "p",
    variant: subTitleSizeMap[size]
  }, subTitle));
};
export var Title = compose(withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref2) {
    var title = _ref2.title,
      subTitle = _ref2.subTitle;
    return !!title || !!subTitle;
  }
}), forwardRef)(TitleRender);