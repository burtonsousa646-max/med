import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "range", "value", "onChange", "onFocus", "onBlur", "minDate", "maxDate", "disableDates", "onClear"],
  _excluded2 = ["className", "range", "value", "onChange", "onFocus", "onBlur", "minDate", "maxDate", "disableDates", "onClear"];
import React, { forwardRef } from 'react';
import { format } from 'date-fns-new';
import { DateRangeInput, DateInput as SingleDateInput } from "../../../AdvancedInputs";
import { dateFormat, useRangeInput, useSingleInput } from "../../hooks/usePickerInput";
import { isNotRangeParams, isRangeParams } from "./utils";
var SingleInput = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    range = props.range,
    value = props.value,
    onChange = props.onChange,
    _onFocus = props.onFocus,
    _onBlur = props.onBlur,
    minDate = props.minDate,
    maxDate = props.maxDate,
    disableDates = props.disableDates,
    _onClear = props.onClear,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useSingleInput = useSingleInput({
      range: range,
      value: value,
      disableDates: disableDates,
      onChange: onChange,
      minDate: minDate,
      maxDate: maxDate
    }),
    maskOptions = _useSingleInput.maskOptions,
    handleChange = _useSingleInput.onChange;
  return /*#__PURE__*/React.createElement(SingleDateInput, _extends({}, otherProps, {
    maskOptions: maskOptions,
    onBlur: function onBlur(_, e) {
      return _onBlur === null || _onBlur === void 0 ? void 0 : _onBlur(value || null, e);
    },
    onChange: handleChange,
    onClear: function onClear(_, e) {
      return _onClear === null || _onClear === void 0 ? void 0 : _onClear(null, e);
    },
    onFocus: function onFocus(_, e) {
      return _onFocus === null || _onFocus === void 0 ? void 0 : _onFocus(value || null, e);
    },
    ref: ref,
    unmask: false,
    value: value ? format(value, dateFormat) : '',
    "data-t-id": "Input-DateInput"
  }));
});
var RangeInput = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    range = props.range,
    value = props.value,
    onChange = props.onChange,
    _onFocus2 = props.onFocus,
    _onBlur2 = props.onBlur,
    minDate = props.minDate,
    maxDate = props.maxDate,
    disableDates = props.disableDates,
    _onClear2 = props.onClear,
    otherProps = _objectWithoutProperties(props, _excluded2);
  var _useRangeInput = useRangeInput({
      range: range,
      value: value,
      disableDates: disableDates,
      onChange: onChange,
      minDate: minDate,
      maxDate: maxDate
    }),
    maskOptions = _useRangeInput.maskOptions,
    handleChange = _useRangeInput.onChange,
    stringValue = _useRangeInput.stringValue;
  return /*#__PURE__*/React.createElement(DateRangeInput, _extends({}, otherProps, {
    maskOptions: maskOptions,
    onBlur: function onBlur(_, e) {
      return _onBlur2 === null || _onBlur2 === void 0 ? void 0 : _onBlur2(value || [null, null], e);
    },
    onChange: handleChange,
    onClear: function onClear(_, e) {
      return _onClear2 === null || _onClear2 === void 0 ? void 0 : _onClear2([null, null], e);
    },
    onFocus: function onFocus(_, e) {
      return _onFocus2 === null || _onFocus2 === void 0 ? void 0 : _onFocus2(value || [null, null], e);
    },
    ref: ref,
    unmask: false,
    value: stringValue
  }));
});
export var DateInput = /*#__PURE__*/forwardRef(function (props, ref) {
  if (isRangeParams(props)) {
    return /*#__PURE__*/React.createElement(RangeInput, _extends({}, props, {
      ref: ref
    }));
  }
  if (isNotRangeParams(props)) {
    return /*#__PURE__*/React.createElement(SingleInput, _extends({}, props, {
      ref: ref
    }));
  }
  return null;
});