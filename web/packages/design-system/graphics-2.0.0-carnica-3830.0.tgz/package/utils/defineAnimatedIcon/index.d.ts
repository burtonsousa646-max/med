export * from './defineAnimatedIcon';
//# sourceMappingURL=index.d.ts.map