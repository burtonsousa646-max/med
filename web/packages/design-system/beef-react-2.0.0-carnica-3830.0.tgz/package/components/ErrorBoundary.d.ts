import React from 'react';
import type { ReactProps } from '../types';
interface FallbackRenderProps {
    error: Error;
}
type FallbackRender = (renderProps: FallbackRenderProps) => React.ReactElement;
interface State {
    error: Error | null;
    hasError: boolean;
}
export interface ErrorBoundaryProps extends ReactProps {
    fallback?: FallbackRender | React.ReactElement | null;
    onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
}
export declare class ErrorBoundary extends React.Component<ErrorBoundaryProps, State> {
    state: {
        hasError: boolean;
        error: null;
    };
    static getDerivedStateFromError(error: Error): State;
    componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void;
    render(): React.ReactNode;
}
export {};
//# sourceMappingURL=ErrorBoundary.d.ts.map