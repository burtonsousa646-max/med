import React, { ComponentType, FC } from 'react';
type ShouldRenderFn = (params: any) => boolean;
type Params = {
    fallback?: React.ReactNode | null;
    shouldRenderFn?: ShouldRenderFn;
};
type WithRenderFlag<Added = {
    shouldRender?: boolean;
}> = <C extends ComponentType<any>>(component: C) => FC<React.ComponentProps<C> & Added>;
export declare const withRenderCondition: ({ shouldRenderFn, fallback }?: Params) => WithRenderFlag<{ [key in never]: never; }>;
export declare const withRenderFlag: WithRenderFlag;
export {};
//# sourceMappingURL=withRenderFlag.d.ts.map