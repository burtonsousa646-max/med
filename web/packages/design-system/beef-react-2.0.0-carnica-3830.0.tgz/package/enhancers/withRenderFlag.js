import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["shouldRender"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { allowParamOmit } from "./allowParamOmit";
var defaultShouldRenderFn = function defaultShouldRenderFn(props) {
  return props.shouldRender;
};
export var withRenderCondition = function withRenderCondition() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
    _ref$shouldRenderFn = _ref.shouldRenderFn,
    shouldRenderFn = _ref$shouldRenderFn === void 0 ? defaultShouldRenderFn : _ref$shouldRenderFn,
    _ref$fallback = _ref.fallback,
    fallback = _ref$fallback === void 0 ? null : _ref$fallback;
  return function (Component) {
    var ConditionalRenderer = /*#__PURE__*/forwardRef(function (_ref2, ref) {
      var shouldRender = _ref2.shouldRender,
        props = _objectWithoutProperties(_ref2, _excluded);
      return shouldRenderFn(_objectSpread(_objectSpread({}, props), {}, {
        shouldRender: shouldRender
      })) ? /*#__PURE__*/React.createElement(Component, _extends({}, props, {
        ref: ref,
        "data-t-id": "src-enhancers"
      })) : fallback;
    });
    if (process.env.NODE_ENV !== 'production') {
      var ComponentName = Component.displayName || Component.name || 'Component';
      ConditionalRenderer.displayName = "withRenderFlag(".concat(ComponentName, ")");
    }
    return ConditionalRenderer;
  };
};

/**
 * В идеале надо заменить на withRenderCondition()
 * Сейчас для обратной совместимости оставили allowParamOmit
 *
 * Известные ограничения: если оборачивается generic-функция, то типы теряются, к сожалению это ограничение самого typescript'а :(
 */
export var withRenderFlag = allowParamOmit(withRenderCondition);