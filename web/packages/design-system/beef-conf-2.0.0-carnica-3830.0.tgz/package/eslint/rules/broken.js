module.exports = {
  rules: {
    // FIXME: BROKEN in eslint-plugin-react@7.29.4, uncomment once 7.29.5 releases with:
    //   https://github.com/jsx-eslint/eslint-plugin-react/commit/4876d549158df538520026170df3b8c933fa3603
    'react/no-unused-state': 0,
    // FIXME: Rule is broken in @beef/*, due to common dependencies pulling from @beef/react, redux etc.
    //   in short it is about react, react-dom, classnames, prop-types, redux, ...
    'import/no-extraneous-dependencies': 0
  }
};