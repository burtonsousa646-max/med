export var badgePropColor = ['brand', 'dark', 'error', 'accent'];
export var badgePropType = ['dot', 'text', 'icon'];
export var badgePropSize = ['s', 'l'];