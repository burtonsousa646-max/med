// <a href="mailto:$1?cc=$2,$3,$4&bcc=$5&subject=SUBJECT-TEXT&body=BODY-TEXT">Email Us</a>

export var getMailtoHref = function getMailtoHref(_ref) {
  var to = _ref.to,
    cc = _ref.cc,
    bcc = _ref.bcc,
    subject = _ref.subject,
    body = _ref.body;
  var params = [];
  if (cc) params.push("cc=".concat(cc.join(',')));
  if (bcc) params.push("bcc=".concat(bcc.join(',')));
  if (subject) params.push("subject=".concat(subject));
  if (body) params.push("body=".concat(body));
  var paramsStr = params.join('&');
  return "mailto:".concat(to).concat(paramsStr && '?').concat(paramsStr);
};