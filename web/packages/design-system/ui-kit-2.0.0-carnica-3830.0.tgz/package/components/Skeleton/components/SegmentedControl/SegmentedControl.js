import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnSegmentedControl = cnBem('skeleton-segmented-control', styles);
export var SegmentedControl = function SegmentedControl(_ref) {
  var className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    className: cnSegmentedControl(null, [className]),
    height: 44,
    width: 200
  }, props, {
    "data-t-id": "components-SegmentedControl"
  }));
};