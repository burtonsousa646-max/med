import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["icon", "size", "view", "color", "stroke"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { withDataConverter } from '@beef/react';
import { Badge } from "./Badge";
import { BadgeWrapperCore } from "../core";
var dataConverter = function dataConverter(_ref) {
  var icon = _ref.icon,
    size = _ref.size,
    view = _ref.view,
    color = _ref.color,
    stroke = _ref.stroke,
    props = _objectWithoutProperties(_ref, _excluded);
  return _objectSpread(_objectSpread({}, props), {}, {
    component: Badge,
    componentProps: {
      icon: icon,
      size: size,
      view: view,
      color: color,
      stroke: stroke
    }
  });
};
export var BadgeWrapper = withDataConverter(dataConverter)(BadgeWrapperCore);