import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import React from 'react';
import { Point } from '@beef/utils/models';
import { useEventListener } from "../useEventListener";
/**
 * Basic hook to support mouse-based dnd on top of node, provides `delta` and `toggle` events
 */
export var useNodeDrag = function useNodeDrag(_ref) {
  var onDragDelta = _ref.onDragDelta,
    onDragToggle = _ref.onDragToggle;
  var _React$useState = React.useState(false),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    isDragged = _React$useState2[0],
    setDragged = _React$useState2[1];
  var handleDraggedToggle = React.useCallback(function (flag) {
    setDragged(flag);
    if (onDragToggle) onDragToggle(flag);
  }, [onDragToggle]);
  var _React$useState3 = React.useState(undefined),
    _React$useState4 = _slicedToArray(_React$useState3, 2),
    initialPoint = _React$useState4[0],
    setInitialPoint = _React$useState4[1];
  var handleMouseMove = React.useCallback(function (event) {
    onDragDelta(Point.fromEvent(event).diff(initialPoint));
  }, [initialPoint, onDragDelta]);
  var handleMouseUp = React.useCallback(function () {
    handleDraggedToggle(false);
  }, [handleDraggedToggle]);
  var handleMouseDown = React.useCallback(function (event) {
    setInitialPoint(Point.fromEvent(event));
    // e.preventDefault();
    handleDraggedToggle(true);
  }, [handleDraggedToggle, setInitialPoint]);
  var domNodeRef = React.useRef(null);
  useEventListener('mousedown', handleMouseDown, domNodeRef);
  useEventListener('mousemove', handleMouseMove, isDragged ? document : null);
  useEventListener('mouseup', handleMouseUp, isDragged ? document : null);
  return domNodeRef;
};