import { IconLockFilled } from '@carnica/graphics';
export var items = [{
  label: 'Сходненская улица',
  description: 'Москва',
  leftSide: IconLockFilled,
  key: 1
}, {
  label: 'Сходненская улица',
  description: 'деревня Путилково, городской округ Красногорск, Московская область',
  key: 2
}, {
  label: 'Сходненская улица',
  description: 'деревня Чёрная Грязь, городской округ Химки, Московская область',
  key: 3
}, {
  label: ' Сходненская улица',
  description: 'Брянск',
  leftSide: IconLockFilled,
  disabled: true,
  key: 4
}, {
  label: ' Сходненская улица',
  description: 'деревня Чёрная Грязь, городской округ Химки, Московская область',
  key: 5
}, {
  label: ' Сходненская улица',
  description: 'Брянск',
  key: 6
}];