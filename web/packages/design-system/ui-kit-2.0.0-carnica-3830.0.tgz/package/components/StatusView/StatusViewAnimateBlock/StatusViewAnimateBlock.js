import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["wrapperRef", "state", "loading", "loadingOptions", "className", "icon", "onAnimationFinished", "anchorRef"];
import React, { forwardRef, useEffect, useState } from 'react';
import { cnBem } from '@carnica/utils';
import { AnimatePresence, motion } from 'framer-motion';
import { useFlag, useIsMobileDimension } from '@carnica/utils/hooks';
import { LoadingWindow } from "../../LoadingWindow";
import { ThemedPortal } from "../../../modules/ThemedPortal";
import styles from "./styles.module.css";
import { useLoadingAnimation } from "../hooks/useLoadingAnimation";
import { StatusViewIndicatorDynamicIcon } from "./StatusViewIndicatorDynamicIcon";
var cnStatusViewAnimateBlock = cnBem('status-view-animate-block', styles);
export var StatusViewAnimateBlock = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var wrapperRef = _ref.wrapperRef,
    _ref$state = _ref.state,
    state = _ref$state === void 0 ? 'progress' : _ref$state,
    loadingProp = _ref.loading,
    loadingOptions = _ref.loadingOptions,
    className = _ref.className,
    icon = _ref.icon,
    onAnimationFinished = _ref.onAnimationFinished,
    anchorRef = _ref.anchorRef,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isIconVisible = _useFlag2[0],
    setIsIconVisible = _useFlag2[1];
  var _useFlag3 = useFlag(),
    _useFlag4 = _slicedToArray(_useFlag3, 2),
    isAnimationStarted = _useFlag4[0],
    setIsAnimationStarted = _useFlag4[1];
  var _useState = useState(loadingProp),
    _useState2 = _slicedToArray(_useState, 2),
    loading = _useState2[0],
    setLoading = _useState2[1];
  var isMobile = useIsMobileDimension();
  var _useLoadingAnimation = useLoadingAnimation({
      wrapperRef: wrapperRef,
      loading: loading,
      anchorRef: anchorRef,
      state: state
    }),
    loaderRef = _useLoadingAnimation.loaderRef,
    circleRef = _useLoadingAnimation.circleRef,
    resetStyles = _useLoadingAnimation.resetStyles,
    containerRef = _useLoadingAnimation.containerRef,
    animateIndicator = _useLoadingAnimation.animateIndicator,
    isLoaderVisible = _useLoadingAnimation.isLoaderVisible,
    isInModal = _useLoadingAnimation.isInModal;
  var onFinish = function onFinish() {
    onAnimationFinished === null || onAnimationFinished === void 0 || onAnimationFinished();
    // Выносим в отдельную макрозадачу, чтоб логика завязанная на onAnimationFinished успела отработать
    setTimeout(function () {
      setIsAnimationStarted.off();
      resetStyles();
    });
  };
  var handleClose = function handleClose() {
    setIsAnimationStarted.on();
    setTimeout(setIsIconVisible.on, state === 'success' ? 660 : 810);
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    animateIndicator();
  };
  useEffect(function () {
    setLoading(function (prev) {
      if (!loadingProp && !isAnimationStarted && prev) {
        // eslint-disable-next-line @typescript-eslint/no-floating-promises
        handleClose();
      }
      return loadingProp;
    });
    setIsIconVisible.set(!loadingProp);
  }, [loadingProp]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(LoadingWindow, _extends({
    mode: "mock"
  }, loadingOptions, {
    className: cnStatusViewAnimateBlock('loader', [loadingOptions === null || loadingOptions === void 0 ? void 0 : loadingOptions.className]),
    exit: {
      opacity: 1,
      y: 0,
      transition: {
        ease: 'easeOut',
        delay: 0.5,
        duration: 0.65
      }
    },
    isOpen: isLoaderVisible,
    onClose: handleClose,
    overlayClassName: cnStatusViewAnimateBlock('overlay', {
      hidden: isInModal && !isMobile
    }),
    ref: loaderRef,
    "data-t-id": "StatusView-StatusViewAnimateBlock"
  })), /*#__PURE__*/React.createElement(ThemedPortal, _extends({}, otherProps, {
    className: cnStatusViewAnimateBlock({
      state: state
    }, [className]),
    ref: ref,
    role: "presentation"
  }), /*#__PURE__*/React.createElement(motion.div, {
    className: cnStatusViewAnimateBlock('container'),
    ref: containerRef
  }, /*#__PURE__*/React.createElement(motion.div, {
    className: cnStatusViewAnimateBlock('indicator'),
    ref: circleRef
  }), /*#__PURE__*/React.createElement(AnimatePresence, {
    mode: "sync"
  }, isIconVisible && /*#__PURE__*/React.createElement(StatusViewIndicatorDynamicIcon, {
    className: cnStatusViewAnimateBlock('icon'),
    icon: icon,
    onAnimationComplete: onFinish,
    state: state
  })))));
});