import { useEffect, useRef } from 'react';
export var useKeys = function useKeys(keyHandlers, element) {
  var eventType = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'keyup';
  var keyHandlersRef = useRef({});
  useEffect(function () {
    keyHandlersRef.current = keyHandlers;
  }, [keyHandlers]);
  useEffect(function () {
    var subscribe = function subscribe(e) {
      var current = keyHandlersRef.current;
      var event = e;
      var handler = current[event.code] || current[event.key];
      handler === null || handler === void 0 || handler(event);
    };
    var node = !element || element instanceof Document ? document : element === null || element === void 0 ? void 0 : element.current;
    node === null || node === void 0 || node.addEventListener(eventType, subscribe);
    return function () {
      node === null || node === void 0 || node.removeEventListener(eventType, subscribe);
    };
  }, [eventType, element]);
};