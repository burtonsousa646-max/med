import { WebpackFactory } from "./webpack";
import { errorFilters } from "./webpack/utils";
import { webpack } from "./webpack";
import { resolveWebpackConfig } from "@beef/conf";
export declare let postcssConfig: (opts: any) => {
    plugins: {
        [x: string]: any;
    };
};
export declare let storybookConfig: (...args: any[]) => any;
export declare let jestConfig: (cwd: any, { setupFilesAfterEnv, ...customOptions }?: {
    setupFilesAfterEnv?: never[] | undefined;
}) => {
    collectCoverageFrom: string[];
    coverageDirectory: string;
    coveragePathIgnorePatterns: string[];
    coverageReporters: string[];
    moduleFileExtensions: string[];
    moduleNameMapper: {
        '^@carnica/([^\\/]+)/(.*)$': string[];
        '^@beef/([^\\/]+)/(.*)$': string[];
        'swiper/react': string;
        'swiper/core': string;
        'swiper/css': string;
        'swiper/bundle': string;
        'swiper/types': string;
        '^swiper/css/([^\\/]+)/(.*)$': string;
    };
    reporters: (string | (string | {
        outputDirectory: string;
        outputName: string;
    })[])[];
    rootDir: string;
    setupFilesAfterEnv: any[];
    testEnvironment: string;
    testPathIgnorePatterns: string[];
    testRegex: any;
    transform: {
        '\\.(css|pcss|less|scss|sass|png|jpg|ttf|woff|woff2)$': string;
        '\\.(js|ts|jsx|tsx|mjs)$': (string | {
            rootMode: string;
        })[];
        '\\.svg$': string;
    };
    transformIgnorePatterns: string[];
};
export { WebpackFactory, errorFilters, webpack, resolveWebpackConfig };
//# sourceMappingURL=index.d.ts.map