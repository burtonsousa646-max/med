export const allowedLeadingCharacters: "abcdefghijklmnopqrstuvwqyzABCDEFGHIJKLMNOPQRSTUVWQYZ";
export function permuteArray(inputArray: any): any;
//# sourceMappingURL=helpers.d.ts.map