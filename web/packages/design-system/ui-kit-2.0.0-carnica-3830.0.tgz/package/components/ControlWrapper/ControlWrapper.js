import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "label", "caption", "withMobileOffset", "captionSize", "children", "invert", "disabled", "error", "width", "onCaptionClick", "captionDisabled", "labelProps", "captionProps", "readOnly"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { Text } from "../Text";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnControlWrapper = cnBem('control-wrapper', styles);
var getColor = function getColor(type, disabled, invert, isError) {
  if (isError && !disabled) {
    return "var(--control-wrapper-".concat(type, "-color-error)");
  }
  return "var(--control-wrapper-".concat(type, "-color-").concat(invert ? 'invert' : 'default').concat(disabled ? '-disabled' : '', ")");
};
var ControlWrapperRender = function ControlWrapperRender(props, ref) {
  var className = props.className,
    label = props.label,
    caption = props.caption,
    _props$withMobileOffs = props.withMobileOffset,
    withMobileOffset = _props$withMobileOffs === void 0 ? true : _props$withMobileOffs,
    _props$captionSize = props.captionSize,
    captionSize = _props$captionSize === void 0 ? 'small' : _props$captionSize,
    children = props.children,
    invert = props.invert,
    disabled = props.disabled,
    error = props.error,
    _props$width = props.width,
    width = _props$width === void 0 ? 'full' : _props$width,
    onCaptionClick = props.onCaptionClick,
    captionDisabled = props.captionDisabled,
    labelProps = props.labelProps,
    captionProps = props.captionProps,
    readOnly = props.readOnly,
    otherProps = _objectWithoutProperties(props, _excluded);
  var showLabel = readOnly ? !!label : !!(label || typeof error === 'string' && error);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnControlWrapper({
      width: width,
      withMobileOffset: withMobileOffset,
      readOnly: readOnly
    }, [className]),
    ref: ref,
    "data-t-id": "components-ControlWrapper"
  }), showLabel && /*#__PURE__*/React.createElement(Text, _extends({}, labelProps, {
    "aria-errormessage": typeof error === 'string' ? error : undefined,
    className: cnControlWrapper('label'),
    color: "primary",
    style: _defineProperty({}, '--control-wrapper-label-color', getColor('label', disabled, invert, readOnly ? false : !!error)),
    tagName: "label",
    variant: readOnly ? 'body-small' : 'caption-accent-medium'
  }), typeof error === 'string' ? error : label), children, caption && /*#__PURE__*/React.createElement(Text, _extends({}, captionProps, {
    className: cnControlWrapper('caption', {
      size: captionSize
    }),
    color: "primary",
    style: _defineProperty({}, '--control-wrapper-caption-color', getColor(captionSize === 'big' ? 'button' : 'caption', disabled, invert)),
    tagName: onCaptionClick ? 'button' : 'div',
    variant: captionSize === 'big' ? 'body-accent-small' : 'caption-accent-medium'
  }, onCaptionClick ? {
    type: 'button',
    disabled: captionDisabled || disabled,
    onClick: onCaptionClick
  } : {}), caption));
};
export var ControlWrapper = /*#__PURE__*/forwardRef(ControlWrapperRender);