import { IconInfoFilled, LogoBeelineColor } from '@carnica/graphics';
export var items = [{
  image: 'https://static.beeline.ru/upload/images/carnica/logos/LogoBeelineColor.svg'
}, {
  icon: IconInfoFilled
}, {
  logo: LogoBeelineColor
}, {
  name: 'Alehandro'
}, {
  name: 'Beto',
  customColors: {
    bg: '#d7ebfe',
    content: '#1086f9'
  }
}, {
  name: 'Cirilla',
  customColors: {
    bg: '#cbf6e3',
    content: '#00a55e'
  }
}, {
  name: 'Dumb',
  customColors: {
    bg: '#fbdbec',
    content: '#e52e90'
  }
}, {
  name: 'Evan',
  customColors: {
    bg: '#ffd8c7',
    content: '#f84a00'
  }
}];