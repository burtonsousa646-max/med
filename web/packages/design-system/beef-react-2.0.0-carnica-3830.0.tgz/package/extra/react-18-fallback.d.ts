export {};
//# sourceMappingURL=react-18-fallback.d.ts.map