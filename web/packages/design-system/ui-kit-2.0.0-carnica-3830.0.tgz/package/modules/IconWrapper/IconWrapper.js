import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["disabled", "color", "icon", "className"];
import React, { useEffect, useRef, useState } from 'react';
import { cnBem, combineRefs, forwardRefWithTag } from '@carnica/utils';
import styles from "./styles.module.css";
var cnIconWrapper = cnBem('icon-wrapper', styles);
export var IconWrapper = forwardRefWithTag(function (props, ref) {
  var disabled = props.disabled,
    _props$color = props.color,
    color = _props$color === void 0 ? 'primary' : _props$color,
    Icon = props.icon,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useState = useState(true),
    _useState2 = _slicedToArray(_useState, 2),
    isIcon = _useState2[0],
    setIsIcon = _useState2[1];
  var iconRef = useRef(null);
  useEffect(function () {
    var _iconRef$current;
    setIsIcon(!!((_iconRef$current = iconRef.current) !== null && _iconRef$current !== void 0 && _iconRef$current.style.getPropertyValue('--icon-color')));
  }, [iconRef.current, color, Icon]);
  return /*#__PURE__*/React.createElement(Icon, _extends({}, otherProps, isIcon ? {
    color: disabled ? 'disabled' : color
  } : {}, {
    className: cnIconWrapper({
      disabled: !isIcon && disabled
    }, [className]),
    ref: combineRefs([ref, iconRef]),
    "data-t-id": "modules-IconWrapper"
  }));
});