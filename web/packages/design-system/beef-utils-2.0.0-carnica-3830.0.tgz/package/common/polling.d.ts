type PollingConfig = {
    initialTimeout?: number;
    interval?: number;
    timeout?: number;
};
type RequestFnResult = {
    data?: any;
    isError: boolean;
    isSuccess: boolean;
    status?: number;
};
type NextFnResult = {
    isDone: boolean;
    isFailed: boolean;
};
type RequestFn = (...args: any[]) => Promise<RequestFnResult>;
type NextFn = (v: RequestFnResult) => NextFnResult;
export declare const polling: (requestFn: RequestFn, nextFn: NextFn, { timeout, interval, initialTimeout }: PollingConfig) => ((...args: any[]) => Promise<Error | RequestFnResult>);
export {};
//# sourceMappingURL=polling.d.ts.map