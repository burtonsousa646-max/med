import { ClassNameList, NoStrictEntityMods } from './types';
export declare const getClassList: (b: string, e?: string, modificators?: NoStrictEntityMods | null, mix?: ClassNameList) => string[];
//# sourceMappingURL=getClassList.d.ts.map