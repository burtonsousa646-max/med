import { baseServerUrl } from "../utils/constant";
import { defineUrlIcon } from "../utils/defineUrlIcon";
export var FlagAfghanistanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAfghanistanCircle.svg"),
  multiColor: false
});
export var FlagAfghanistanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAfghanistanRounded.svg"),
  multiColor: false
});
export var FlagAlbaniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAlbaniaCircle.svg"),
  multiColor: false
});
export var FlagAlbaniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAlbaniaRounded.svg"),
  multiColor: false
});
export var FlagAlgeriaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAlgeriaCircle.svg"),
  multiColor: false
});
export var FlagAlgeriaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAlgeriaRounded.svg"),
  multiColor: false
});
export var FlagAndorraCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAndorraCircle.svg"),
  multiColor: false
});
export var FlagAndorraRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAndorraRounded.svg"),
  multiColor: false
});
export var FlagAngolaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAngolaCircle.svg"),
  multiColor: false
});
export var FlagAngolaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAngolaRounded.svg"),
  multiColor: false
});
export var FlagAntiguaAndBarbudaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAntiguaAndBarbudaCircle.svg"),
  multiColor: false
});
export var FlagAntiguaAndBarbudaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAntiguaAndBarbudaRounded.svg"),
  multiColor: false
});
export var FlagArgentinaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagArgentinaCircle.svg"),
  multiColor: false
});
export var FlagArgentinaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagArgentinaRounded.svg"),
  multiColor: false
});
export var FlagArmeniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagArmeniaCircle.svg"),
  multiColor: false
});
export var FlagArmeniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagArmeniaRounded.svg"),
  multiColor: false
});
export var FlagAustraliaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAustraliaCircle.svg"),
  multiColor: false
});
export var FlagAustraliaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAustraliaRounded.svg"),
  multiColor: false
});
export var FlagAustriaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAustriaCircle.svg"),
  multiColor: false
});
export var FlagAustriaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAustriaRounded.svg"),
  multiColor: false
});
export var FlagAzerbaijanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAzerbaijanCircle.svg"),
  multiColor: false
});
export var FlagAzerbaijanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagAzerbaijanRounded.svg"),
  multiColor: false
});
export var FlagBahamasCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBahamasCircle.svg"),
  multiColor: false
});
export var FlagBahamasRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBahamasRounded.svg"),
  multiColor: false
});
export var FlagBahrainCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBahrainCircle.svg"),
  multiColor: false
});
export var FlagBahrainRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBahrainRounded.svg"),
  multiColor: false
});
export var FlagBangladeshCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBangladeshCircle.svg"),
  multiColor: false
});
export var FlagBangladeshRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBangladeshRounded.svg"),
  multiColor: false
});
export var FlagBarbadosCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBarbadosCircle.svg"),
  multiColor: false
});
export var FlagBarbadosRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBarbadosRounded.svg"),
  multiColor: false
});
export var FlagBelarusCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBelarusCircle.svg"),
  multiColor: false
});
export var FlagBelarusRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBelarusRounded.svg"),
  multiColor: false
});
export var FlagBelgiumCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBelgiumCircle.svg"),
  multiColor: false
});
export var FlagBelgiumRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBelgiumRounded.svg"),
  multiColor: false
});
export var FlagBelizeCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBelizeCircle.svg"),
  multiColor: false
});
export var FlagBelizeRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBelizeRounded.svg"),
  multiColor: false
});
export var FlagBeninCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBeninCircle.svg"),
  multiColor: false
});
export var FlagBeninRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBeninRounded.svg"),
  multiColor: false
});
export var FlagBhutanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBhutanCircle.svg"),
  multiColor: false
});
export var FlagBhutanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBhutanRounded.svg"),
  multiColor: false
});
export var FlagBoliviaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBoliviaCircle.svg"),
  multiColor: false
});
export var FlagBoliviaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBoliviaRounded.svg"),
  multiColor: false
});
export var FlagBosniaAndHerzegovinaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBosniaAndHerzegovinaCircle.svg"),
  multiColor: false
});
export var FlagBosniaAndHerzegovinaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBosniaAndHerzegovinaRounded.svg"),
  multiColor: false
});
export var FlagBotswanaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBotswanaCircle.svg"),
  multiColor: false
});
export var FlagBotswanaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBotswanaRounded.svg"),
  multiColor: false
});
export var FlagBrazilCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBrazilCircle.svg"),
  multiColor: false
});
export var FlagBrazilRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBrazilRounded.svg"),
  multiColor: false
});
export var FlagBruneiCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBruneiCircle.svg"),
  multiColor: false
});
export var FlagBruneiRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBruneiRounded.svg"),
  multiColor: false
});
export var FlagBulgariaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBulgariaCircle.svg"),
  multiColor: false
});
export var FlagBulgariaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBulgariaRounded.svg"),
  multiColor: false
});
export var FlagBurkinaFasoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBurkinaFasoCircle.svg"),
  multiColor: false
});
export var FlagBurkinaFasoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBurkinaFasoRounded.svg"),
  multiColor: false
});
export var FlagBurundiCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBurundiCircle.svg"),
  multiColor: false
});
export var FlagBurundiRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagBurundiRounded.svg"),
  multiColor: false
});
export var FlagCaboVerdeCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCaboVerdeCircle.svg"),
  multiColor: false
});
export var FlagCaboVerdeRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCaboVerdeRounded.svg"),
  multiColor: false
});
export var FlagCambodiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCambodiaCircle.svg"),
  multiColor: false
});
export var FlagCambodiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCambodiaRounded.svg"),
  multiColor: false
});
export var FlagCameroonCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCameroonCircle.svg"),
  multiColor: false
});
export var FlagCameroonRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCameroonRounded.svg"),
  multiColor: false
});
export var FlagCanadaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCanadaCircle.svg"),
  multiColor: false
});
export var FlagCanadaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCanadaRounded.svg"),
  multiColor: false
});
export var FlagCentralAfricanRepublicCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCentralAfricanRepublicCircle.svg"),
  multiColor: false
});
export var FlagCentralAfricanRepublicRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCentralAfricanRepublicRounded.svg"),
  multiColor: false
});
export var FlagChadCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagChadCircle.svg"),
  multiColor: false
});
export var FlagChadRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagChadRounded.svg"),
  multiColor: false
});
export var FlagChileCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagChileCircle.svg"),
  multiColor: false
});
export var FlagChileRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagChileRounded.svg"),
  multiColor: false
});
export var FlagChinaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagChinaCircle.svg"),
  multiColor: false
});
export var FlagChinaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagChinaRounded.svg"),
  multiColor: false
});
export var FlagColombiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagColombiaCircle.svg"),
  multiColor: false
});
export var FlagColombiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagColombiaRounded.svg"),
  multiColor: false
});
export var FlagComorosCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagComorosCircle.svg"),
  multiColor: false
});
export var FlagComorosRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagComorosRounded.svg"),
  multiColor: false
});
export var FlagCongoDemocraticCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCongoDemocraticCircle.svg"),
  multiColor: false
});
export var FlagCongoDemocraticRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCongoDemocraticRounded.svg"),
  multiColor: false
});
export var FlagCongoRepublicCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCongoRepublicCircle.svg"),
  multiColor: false
});
export var FlagCongoRepublicRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCongoRepublicRounded.svg"),
  multiColor: false
});
export var FlagCostaRicaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCostaRicaCircle.svg"),
  multiColor: false
});
export var FlagCostaRicaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCostaRicaRounded.svg"),
  multiColor: false
});
export var FlagCoteDlvoireCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCoteDlvoireCircle.svg"),
  multiColor: false
});
export var FlagCoteDlvoireRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCoteDlvoireRounded.svg"),
  multiColor: false
});
export var FlagCroatiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCroatiaCircle.svg"),
  multiColor: false
});
export var FlagCroatiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCroatiaRounded.svg"),
  multiColor: false
});
export var FlagCubaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCubaCircle.svg"),
  multiColor: false
});
export var FlagCubaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCubaRounded.svg"),
  multiColor: false
});
export var FlagCyprusCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCyprusCircle.svg"),
  multiColor: false
});
export var FlagCyprusRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCyprusRounded.svg"),
  multiColor: false
});
export var FlagCzechRepublicCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCzechRepublicCircle.svg"),
  multiColor: false
});
export var FlagCzechRepublicRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagCzechRepublicRounded.svg"),
  multiColor: false
});
export var FlagDenmarkCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDenmarkCircle.svg"),
  multiColor: false
});
export var FlagDenmarkRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDenmarkRounded.svg"),
  multiColor: false
});
export var FlagDijboutiCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDijboutiCircle.svg"),
  multiColor: false
});
export var FlagDijboutiRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDijboutiRounded.svg"),
  multiColor: false
});
export var FlagDominicaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDominicaCircle.svg"),
  multiColor: false
});
export var FlagDominicaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDominicaRounded.svg"),
  multiColor: false
});
export var FlagDominicanRepublicCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDominicanRepublicCircle.svg"),
  multiColor: false
});
export var FlagDominicanRepublicRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagDominicanRepublicRounded.svg"),
  multiColor: false
});
export var FlagEcuadorCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEcuadorCircle.svg"),
  multiColor: false
});
export var FlagEcuadorRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEcuadorRounded.svg"),
  multiColor: false
});
export var FlagEgyptCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEgyptCircle.svg"),
  multiColor: false
});
export var FlagEgyptRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEgyptRounded.svg"),
  multiColor: false
});
export var FlagElSalvadorCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagElSalvadorCircle.svg"),
  multiColor: false
});
export var FlagElSalvadorRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagElSalvadorRounded.svg"),
  multiColor: false
});
export var FlagEquatorialGuineaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEquatorialGuineaCircle.svg"),
  multiColor: false
});
export var FlagEquatorialGuineaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEquatorialGuineaRounded.svg"),
  multiColor: false
});
export var FlagEritreaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEritreaCircle.svg"),
  multiColor: false
});
export var FlagEritreaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEritreaRounded.svg"),
  multiColor: false
});
export var FlagEstoniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEstoniaCircle.svg"),
  multiColor: false
});
export var FlagEstoniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEstoniaRounded.svg"),
  multiColor: false
});
export var FlagEswatiniCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEswatiniCircle.svg"),
  multiColor: false
});
export var FlagEswatiniRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEswatiniRounded.svg"),
  multiColor: false
});
export var FlagEthiopiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEthiopiaCircle.svg"),
  multiColor: false
});
export var FlagEthiopiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagEthiopiaRounded.svg"),
  multiColor: false
});
export var FlagFijiCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagFijiCircle.svg"),
  multiColor: false
});
export var FlagFijiRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagFijiRounded.svg"),
  multiColor: false
});
export var FlagFinlandCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagFinlandCircle.svg"),
  multiColor: false
});
export var FlagFinlandRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagFinlandRounded.svg"),
  multiColor: false
});
export var FlagFranceCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagFranceCircle.svg"),
  multiColor: false
});
export var FlagFranceRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagFranceRounded.svg"),
  multiColor: false
});
export var FlagGabonCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGabonCircle.svg"),
  multiColor: false
});
export var FlagGabonRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGabonRounded.svg"),
  multiColor: false
});
export var FlagGambiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGambiaCircle.svg"),
  multiColor: false
});
export var FlagGambiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGambiaRounded.svg"),
  multiColor: false
});
export var FlagGeorgiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGeorgiaCircle.svg"),
  multiColor: false
});
export var FlagGeorgiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGeorgiaRounded.svg"),
  multiColor: false
});
export var FlagGermanyCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGermanyCircle.svg"),
  multiColor: false
});
export var FlagGermanyRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGermanyRounded.svg"),
  multiColor: false
});
export var FlagGhanaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGhanaCircle.svg"),
  multiColor: false
});
export var FlagGhanaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGhanaRounded.svg"),
  multiColor: false
});
export var FlagGreeceCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGreeceCircle.svg"),
  multiColor: false
});
export var FlagGreeceRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGreeceRounded.svg"),
  multiColor: false
});
export var FlagGrenadaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGrenadaCircle.svg"),
  multiColor: false
});
export var FlagGrenadaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGrenadaRounded.svg"),
  multiColor: false
});
export var FlagGuatemalaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuatemalaCircle.svg"),
  multiColor: false
});
export var FlagGuatemalaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuatemalaRounded.svg"),
  multiColor: false
});
export var FlagGuineaBissauCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuineaBissauCircle.svg"),
  multiColor: false
});
export var FlagGuineaBissauRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuineaBissauRounded.svg"),
  multiColor: false
});
export var FlagGuineaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuineaCircle.svg"),
  multiColor: false
});
export var FlagGuineaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuineaRounded.svg"),
  multiColor: false
});
export var FlagGuyanaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuyanaCircle.svg"),
  multiColor: false
});
export var FlagGuyanaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagGuyanaRounded.svg"),
  multiColor: false
});
export var FlagHaitiCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagHaitiCircle.svg"),
  multiColor: false
});
export var FlagHaitiRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagHaitiRounded.svg"),
  multiColor: false
});
export var FlagHondurasCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagHondurasCircle.svg"),
  multiColor: false
});
export var FlagHondurasRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagHondurasRounded.svg"),
  multiColor: false
});
export var FlagHungaryCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagHungaryCircle.svg"),
  multiColor: false
});
export var FlagHungaryRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagHungaryRounded.svg"),
  multiColor: false
});
export var FlagIcelandCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIcelandCircle.svg"),
  multiColor: false
});
export var FlagIcelandRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIcelandRounded.svg"),
  multiColor: false
});
export var FlagIndiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIndiaCircle.svg"),
  multiColor: false
});
export var FlagIndiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIndiaRounded.svg"),
  multiColor: false
});
export var FlagIndonesiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIndonesiaCircle.svg"),
  multiColor: false
});
export var FlagIndonesiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIndonesiaRounded.svg"),
  multiColor: false
});
export var FlagIranCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIranCircle.svg"),
  multiColor: false
});
export var FlagIranRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIranRounded.svg"),
  multiColor: false
});
export var FlagIraqCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIraqCircle.svg"),
  multiColor: false
});
export var FlagIraqRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIraqRounded.svg"),
  multiColor: false
});
export var FlagIrelandCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIrelandCircle.svg"),
  multiColor: false
});
export var FlagIrelandRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIrelandRounded.svg"),
  multiColor: false
});
export var FlagIsraelCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIsraelCircle.svg"),
  multiColor: false
});
export var FlagIsraelRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagIsraelRounded.svg"),
  multiColor: false
});
export var FlagItalyCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagItalyCircle.svg"),
  multiColor: false
});
export var FlagItalyRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagItalyRounded.svg"),
  multiColor: false
});
export var FlagJamaicaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagJamaicaCircle.svg"),
  multiColor: false
});
export var FlagJamaicaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagJamaicaRounded.svg"),
  multiColor: false
});
export var FlagJapanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagJapanCircle.svg"),
  multiColor: false
});
export var FlagJapanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagJapanRounded.svg"),
  multiColor: false
});
export var FlagJordanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagJordanCircle.svg"),
  multiColor: false
});
export var FlagJordanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagJordanRounded.svg"),
  multiColor: false
});
export var FlagKazakhstanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKazakhstanCircle.svg"),
  multiColor: false
});
export var FlagKazakhstanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKazakhstanRounded.svg"),
  multiColor: false
});
export var FlagKenyaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKenyaCircle.svg"),
  multiColor: false
});
export var FlagKenyaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKenyaRounded.svg"),
  multiColor: false
});
export var FlagKiribatiCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKiribatiCircle.svg"),
  multiColor: false
});
export var FlagKiribatiRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKiribatiRounded.svg"),
  multiColor: false
});
export var FlagKuwaitCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKuwaitCircle.svg"),
  multiColor: false
});
export var FlagKuwaitRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKuwaitRounded.svg"),
  multiColor: false
});
export var FlagKyrgyzstanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKyrgyzstanCircle.svg"),
  multiColor: false
});
export var FlagKyrgyzstanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagKyrgyzstanRounded.svg"),
  multiColor: false
});
export var FlagLaosCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLaosCircle.svg"),
  multiColor: false
});
export var FlagLaosRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLaosRounded.svg"),
  multiColor: false
});
export var FlagLatviaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLatviaCircle.svg"),
  multiColor: false
});
export var FlagLatviaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLatviaRounded.svg"),
  multiColor: false
});
export var FlagLebanonCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLebanonCircle.svg"),
  multiColor: false
});
export var FlagLebanonRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLebanonRounded.svg"),
  multiColor: false
});
export var FlagLesothoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLesothoCircle.svg"),
  multiColor: false
});
export var FlagLesothoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLesothoRounded.svg"),
  multiColor: false
});
export var FlagLiberiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLiberiaCircle.svg"),
  multiColor: false
});
export var FlagLiberiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLiberiaRounded.svg"),
  multiColor: false
});
export var FlagLibyaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLibyaCircle.svg"),
  multiColor: false
});
export var FlagLibyaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLibyaRounded.svg"),
  multiColor: false
});
export var FlagLiechtensteinCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLiechtensteinCircle.svg"),
  multiColor: false
});
export var FlagLiechtensteinRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLiechtensteinRounded.svg"),
  multiColor: false
});
export var FlagLithuaniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLithuaniaCircle.svg"),
  multiColor: false
});
export var FlagLithuaniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLithuaniaRounded.svg"),
  multiColor: false
});
export var FlagLuxembourgCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLuxembourgCircle.svg"),
  multiColor: false
});
export var FlagLuxembourgRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagLuxembourgRounded.svg"),
  multiColor: false
});
export var FlagMadagascarCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMadagascarCircle.svg"),
  multiColor: false
});
export var FlagMadagascarRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMadagascarRounded.svg"),
  multiColor: false
});
export var FlagMalawiCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMalawiCircle.svg"),
  multiColor: false
});
export var FlagMalawiRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMalawiRounded.svg"),
  multiColor: false
});
export var FlagMalaysiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMalaysiaCircle.svg"),
  multiColor: false
});
export var FlagMalaysiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMalaysiaRounded.svg"),
  multiColor: false
});
export var FlagMaldivesCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMaldivesCircle.svg"),
  multiColor: false
});
export var FlagMaldivesRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMaldivesRounded.svg"),
  multiColor: false
});
export var FlagMaliCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMaliCircle.svg"),
  multiColor: false
});
export var FlagMaliRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMaliRounded.svg"),
  multiColor: false
});
export var FlagMaltaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMaltaCircle.svg"),
  multiColor: false
});
export var FlagMaltaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMaltaRounded.svg"),
  multiColor: false
});
export var FlagMarshallIslandsCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMarshallIslandsCircle.svg"),
  multiColor: false
});
export var FlagMarshallIslandsRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMarshallIslandsRounded.svg"),
  multiColor: false
});
export var FlagMauritaniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMauritaniaCircle.svg"),
  multiColor: false
});
export var FlagMauritaniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMauritaniaRounded.svg"),
  multiColor: false
});
export var FlagMauritiusCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMauritiusCircle.svg"),
  multiColor: false
});
export var FlagMauritiusRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMauritiusRounded.svg"),
  multiColor: false
});
export var FlagMexicoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMexicoCircle.svg"),
  multiColor: false
});
export var FlagMexicoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMexicoRounded.svg"),
  multiColor: false
});
export var FlagMicronesiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMicronesiaCircle.svg"),
  multiColor: false
});
export var FlagMicronesiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMicronesiaRounded.svg"),
  multiColor: false
});
export var FlagMoldovaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMoldovaCircle.svg"),
  multiColor: false
});
export var FlagMoldovaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMoldovaRounded.svg"),
  multiColor: false
});
export var FlagMonacoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMonacoCircle.svg"),
  multiColor: false
});
export var FlagMonacoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMonacoRounded.svg"),
  multiColor: false
});
export var FlagMongoliaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMongoliaCircle.svg"),
  multiColor: false
});
export var FlagMongoliaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMongoliaRounded.svg"),
  multiColor: false
});
export var FlagMontenegroCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMontenegroCircle.svg"),
  multiColor: false
});
export var FlagMontenegroRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMontenegroRounded.svg"),
  multiColor: false
});
export var FlagMoroccoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMoroccoCircle.svg"),
  multiColor: false
});
export var FlagMoroccoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMoroccoRounded.svg"),
  multiColor: false
});
export var FlagMozambiqueCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMozambiqueCircle.svg"),
  multiColor: false
});
export var FlagMozambiqueRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMozambiqueRounded.svg"),
  multiColor: false
});
export var FlagMyanmarCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMyanmarCircle.svg"),
  multiColor: false
});
export var FlagMyanmarRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagMyanmarRounded.svg"),
  multiColor: false
});
export var FlagNamibiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNamibiaCircle.svg"),
  multiColor: false
});
export var FlagNamibiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNamibiaRounded.svg"),
  multiColor: false
});
export var FlagNauruCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNauruCircle.svg"),
  multiColor: false
});
export var FlagNauruRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNauruRounded.svg"),
  multiColor: false
});
export var FlagNepalCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNepalCircle.svg"),
  multiColor: false
});
export var FlagNepalRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNepalRounded.svg"),
  multiColor: false
});
export var FlagNetherlandsCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNetherlandsCircle.svg"),
  multiColor: false
});
export var FlagNetherlandsRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNetherlandsRounded.svg"),
  multiColor: false
});
export var FlagNewZealandCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNewZealandCircle.svg"),
  multiColor: false
});
export var FlagNewZealandRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNewZealandRounded.svg"),
  multiColor: false
});
export var FlagNicaraguaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNicaraguaCircle.svg"),
  multiColor: false
});
export var FlagNicaraguaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNicaraguaRounded.svg"),
  multiColor: false
});
export var FlagNigerCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNigerCircle.svg"),
  multiColor: false
});
export var FlagNigerRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNigerRounded.svg"),
  multiColor: false
});
export var FlagNigeriaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNigeriaCircle.svg"),
  multiColor: false
});
export var FlagNigeriaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNigeriaRounded.svg"),
  multiColor: false
});
export var FlagNorthKoreaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNorthKoreaCircle.svg"),
  multiColor: false
});
export var FlagNorthKoreaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNorthKoreaRounded.svg"),
  multiColor: false
});
export var FlagNorthMacedoniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNorthMacedoniaCircle.svg"),
  multiColor: false
});
export var FlagNorthMacedoniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNorthMacedoniaRounded.svg"),
  multiColor: false
});
export var FlagNorwayCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNorwayCircle.svg"),
  multiColor: false
});
export var FlagNorwayRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagNorwayRounded.svg"),
  multiColor: false
});
export var FlagOmanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagOmanCircle.svg"),
  multiColor: false
});
export var FlagOmanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagOmanRounded.svg"),
  multiColor: false
});
export var FlagPakistanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPakistanCircle.svg"),
  multiColor: false
});
export var FlagPakistanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPakistanRounded.svg"),
  multiColor: false
});
export var FlagPalauCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPalauCircle.svg"),
  multiColor: false
});
export var FlagPalauRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPalauRounded.svg"),
  multiColor: false
});
export var FlagPalestineCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPalestineCircle.svg"),
  multiColor: false
});
export var FlagPalestineRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPalestineRounded.svg"),
  multiColor: false
});
export var FlagPanamaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPanamaCircle.svg"),
  multiColor: false
});
export var FlagPanamaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPanamaRounded.svg"),
  multiColor: false
});
export var FlagPapuaNewGuineaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPapuaNewGuineaCircle.svg"),
  multiColor: false
});
export var FlagPapuaNewGuineaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPapuaNewGuineaRounded.svg"),
  multiColor: false
});
export var FlagParaguayCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagParaguayCircle.svg"),
  multiColor: false
});
export var FlagParaguayRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagParaguayRounded.svg"),
  multiColor: false
});
export var FlagPeruCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPeruCircle.svg"),
  multiColor: false
});
export var FlagPeruRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPeruRounded.svg"),
  multiColor: false
});
export var FlagPhilippinesCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPhilippinesCircle.svg"),
  multiColor: false
});
export var FlagPhilippinesRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPhilippinesRounded.svg"),
  multiColor: false
});
export var FlagPolandCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPolandCircle.svg"),
  multiColor: false
});
export var FlagPolandRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPolandRounded.svg"),
  multiColor: false
});
export var FlagPortugalCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPortugalCircle.svg"),
  multiColor: false
});
export var FlagPortugalRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagPortugalRounded.svg"),
  multiColor: false
});
export var FlagQatarCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagQatarCircle.svg"),
  multiColor: false
});
export var FlagQatarRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagQatarRounded.svg"),
  multiColor: false
});
export var FlagRomaniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagRomaniaCircle.svg"),
  multiColor: false
});
export var FlagRomaniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagRomaniaRounded.svg"),
  multiColor: false
});
export var FlagRussiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagRussiaCircle.svg"),
  multiColor: false
});
export var FlagRussiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagRussiaRounded.svg"),
  multiColor: false
});
export var FlagRwandaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagRwandaCircle.svg"),
  multiColor: false
});
export var FlagRwandaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagRwandaRounded.svg"),
  multiColor: false
});
export var FlagSaintKittsAndNevisCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaintKittsAndNevisCircle.svg"),
  multiColor: false
});
export var FlagSaintKittsAndNevisRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaintKittsAndNevisRounded.svg"),
  multiColor: false
});
export var FlagSaintLuciaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaintLuciaCircle.svg"),
  multiColor: false
});
export var FlagSaintLuciaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaintLuciaRounded.svg"),
  multiColor: false
});
export var FlagSaintVincentAndTheGrenadinesCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaintVincentAndTheGrenadinesCircle.svg"),
  multiColor: false
});
export var FlagSaintVincentAndTheGrenadinesRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaintVincentAndTheGrenadinesRounded.svg"),
  multiColor: false
});
export var FlagSamoaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSamoaCircle.svg"),
  multiColor: false
});
export var FlagSamoaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSamoaRounded.svg"),
  multiColor: false
});
export var FlagSanMarinoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSanMarinoCircle.svg"),
  multiColor: false
});
export var FlagSanMarinoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSanMarinoRounded.svg"),
  multiColor: false
});
export var FlagSaoTomeAndPrincipeCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaoTomeAndPrincipeCircle.svg"),
  multiColor: false
});
export var FlagSaoTomeAndPrincipeRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaoTomeAndPrincipeRounded.svg"),
  multiColor: false
});
export var FlagSaudiArabiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaudiArabiaCircle.svg"),
  multiColor: false
});
export var FlagSaudiArabiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSaudiArabiaRounded.svg"),
  multiColor: false
});
export var FlagSenegalCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSenegalCircle.svg"),
  multiColor: false
});
export var FlagSenegalRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSenegalRounded.svg"),
  multiColor: false
});
export var FlagSerbiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSerbiaCircle.svg"),
  multiColor: false
});
export var FlagSerbiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSerbiaRounded.svg"),
  multiColor: false
});
export var FlagSeychellesCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSeychellesCircle.svg"),
  multiColor: false
});
export var FlagSeychellesRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSeychellesRounded.svg"),
  multiColor: false
});
export var FlagSierraLeoneCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSierraLeoneCircle.svg"),
  multiColor: false
});
export var FlagSierraLeoneRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSierraLeoneRounded.svg"),
  multiColor: false
});
export var FlagSingaporeCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSingaporeCircle.svg"),
  multiColor: false
});
export var FlagSingaporeRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSingaporeRounded.svg"),
  multiColor: false
});
export var FlagSlovakiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSlovakiaCircle.svg"),
  multiColor: false
});
export var FlagSlovakiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSlovakiaRounded.svg"),
  multiColor: false
});
export var FlagSloveniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSloveniaCircle.svg"),
  multiColor: false
});
export var FlagSloveniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSloveniaRounded.svg"),
  multiColor: false
});
export var FlagSolomonIslandsCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSolomonIslandsCircle.svg"),
  multiColor: false
});
export var FlagSolomonIslandsRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSolomonIslandsRounded.svg"),
  multiColor: false
});
export var FlagSomaliaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSomaliaCircle.svg"),
  multiColor: false
});
export var FlagSomaliaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSomaliaRounded.svg"),
  multiColor: false
});
export var FlagSouthAfricaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSouthAfricaCircle.svg"),
  multiColor: false
});
export var FlagSouthAfricaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSouthAfricaRounded.svg"),
  multiColor: false
});
export var FlagSouthKoreaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSouthKoreaCircle.svg"),
  multiColor: false
});
export var FlagSouthKoreaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSouthKoreaRounded.svg"),
  multiColor: false
});
export var FlagSouthSudanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSouthSudanCircle.svg"),
  multiColor: false
});
export var FlagSouthSudanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSouthSudanRounded.svg"),
  multiColor: false
});
export var FlagSpainCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSpainCircle.svg"),
  multiColor: false
});
export var FlagSpainRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSpainRounded.svg"),
  multiColor: false
});
export var FlagSriLankaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSriLankaCircle.svg"),
  multiColor: false
});
export var FlagSriLankaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSriLankaRounded.svg"),
  multiColor: false
});
export var FlagSudanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSudanCircle.svg"),
  multiColor: false
});
export var FlagSudanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSudanRounded.svg"),
  multiColor: false
});
export var FlagSurinameCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSurinameCircle.svg"),
  multiColor: false
});
export var FlagSurinameRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSurinameRounded.svg"),
  multiColor: false
});
export var FlagSwedenCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSwedenCircle.svg"),
  multiColor: false
});
export var FlagSwedenRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSwedenRounded.svg"),
  multiColor: false
});
export var FlagSwitzerlandCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSwitzerlandCircle.svg"),
  multiColor: false
});
export var FlagSwitzerlandRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSwitzerlandRounded.svg"),
  multiColor: false
});
export var FlagSyriaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSyriaCircle.svg"),
  multiColor: false
});
export var FlagSyriaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagSyriaRounded.svg"),
  multiColor: false
});
export var FlagTaiwanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTaiwanCircle.svg"),
  multiColor: false
});
export var FlagTaiwanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTaiwanRounded.svg"),
  multiColor: false
});
export var FlagTajikistanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTajikistanCircle.svg"),
  multiColor: false
});
export var FlagTajikistanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTajikistanRounded.svg"),
  multiColor: false
});
export var FlagTanzaniaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTanzaniaCircle.svg"),
  multiColor: false
});
export var FlagTanzaniaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTanzaniaRounded.svg"),
  multiColor: false
});
export var FlagThailandCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagThailandCircle.svg"),
  multiColor: false
});
export var FlagThailandRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagThailandRounded.svg"),
  multiColor: false
});
export var FlagTimorLesteCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTimorLesteCircle.svg"),
  multiColor: false
});
export var FlagTimorLesteRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTimorLesteRounded.svg"),
  multiColor: false
});
export var FlagTogoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTogoCircle.svg"),
  multiColor: false
});
export var FlagTogoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTogoRounded.svg"),
  multiColor: false
});
export var FlagTongaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTongaCircle.svg"),
  multiColor: false
});
export var FlagTongaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTongaRounded.svg"),
  multiColor: false
});
export var FlagTrinidadAndTobagoCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTrinidadAndTobagoCircle.svg"),
  multiColor: false
});
export var FlagTrinidadAndTobagoRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTrinidadAndTobagoRounded.svg"),
  multiColor: false
});
export var FlagTunisiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTunisiaCircle.svg"),
  multiColor: false
});
export var FlagTunisiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTunisiaRounded.svg"),
  multiColor: false
});
export var FlagTurkeyCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTurkeyCircle.svg"),
  multiColor: false
});
export var FlagTurkeyRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTurkeyRounded.svg"),
  multiColor: false
});
export var FlagTurkmenistanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTurkmenistanCircle.svg"),
  multiColor: false
});
export var FlagTurkmenistanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagTurkmenistanRounded.svg"),
  multiColor: false
});
export var FlagUgandaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUgandaCircle.svg"),
  multiColor: false
});
export var FlagUgandaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUgandaRounded.svg"),
  multiColor: false
});
export var FlagUkraineCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUkraineCircle.svg"),
  multiColor: false
});
export var FlagUkraineRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUkraineRounded.svg"),
  multiColor: false
});
export var FlagUnitedArabEmiratesCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUnitedArabEmiratesCircle.svg"),
  multiColor: false
});
export var FlagUnitedArabEmiratesRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUnitedArabEmiratesRounded.svg"),
  multiColor: false
});
export var FlagUnitedKingdomCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUnitedKingdomCircle.svg"),
  multiColor: false
});
export var FlagUnitedKingdomRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUnitedKingdomRounded.svg"),
  multiColor: false
});
export var FlagUnitedStatesOfAmericaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUnitedStatesOfAmericaCircle.svg"),
  multiColor: false
});
export var FlagUnitedStatesOfAmericaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUnitedStatesOfAmericaRounded.svg"),
  multiColor: false
});
export var FlagUruguayCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUruguayCircle.svg"),
  multiColor: false
});
export var FlagUruguayRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUruguayRounded.svg"),
  multiColor: false
});
export var FlagUzbekistanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUzbekistanCircle.svg"),
  multiColor: false
});
export var FlagUzbekistanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagUzbekistanRounded.svg"),
  multiColor: false
});
export var FlagVaticanCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagVaticanCircle.svg"),
  multiColor: false
});
export var FlagVaticanRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagVaticanRounded.svg"),
  multiColor: false
});
export var FlagVenezuelaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagVenezuelaCircle.svg"),
  multiColor: false
});
export var FlagVenezuelaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagVenezuelaRounded.svg"),
  multiColor: false
});
export var FlagVietnamCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagVietnamCircle.svg"),
  multiColor: false
});
export var FlagVietnamRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagVietnamRounded.svg"),
  multiColor: false
});
export var FlagYemenCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagYemenCircle.svg"),
  multiColor: false
});
export var FlagYemenRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagYemenRounded.svg"),
  multiColor: false
});
export var FlagZambiaCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagZambiaCircle.svg"),
  multiColor: false
});
export var FlagZambiaRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagZambiaRounded.svg"),
  multiColor: false
});
export var FlagZimbabweCircle = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagZimbabweCircle.svg"),
  multiColor: false
});
export var FlagZimbabweRounded = defineUrlIcon({
  url: "".concat(baseServerUrl, "/flags/FlagZimbabweRounded.svg"),
  multiColor: false
});