import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnInput = cnBem('skeleton-input', styles);
export var Input = function Input(_ref) {
  var invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnInput(null, [className])
  }, props, {
    "data-t-id": "components-Input"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 16,
    invert: invert,
    width: 100
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 28,
    invert: invert,
    width: "100%"
  }));
};