import { IMask } from 'react-imask';
import { compose } from '@beef/utils';
import { defineProps } from '@beef/react';
import { Input } from "../../Input";
import { withMaskedInput } from "../../../hocs/withMaskedInput";
export var monthMask = {
  mask: 'MM/yy',
  blocks: {
    MM: {
      mask: IMask.MaskedRange,
      from: 1,
      to: 12
    },
    yy: {
      mask: IMask.MaskedRange,
      from: 0,
      to: 99
    }
  },
  lazy: true,
  autofix: true
};
export var MonthInput = compose(defineProps({}, {
  placeholder: 'мм/гг'
}), withMaskedInput(monthMask))(Input);