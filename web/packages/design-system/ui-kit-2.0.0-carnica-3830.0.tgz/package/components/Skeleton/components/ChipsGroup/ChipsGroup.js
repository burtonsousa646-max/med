import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["wrap", "length", "invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import styles from "./styles.module.css";
import { Chips } from "../Chips";
var cnChipsGroup = cnBem('skeleton-chips-group', styles);
export var ChipsGroup = function ChipsGroup(_ref) {
  var _ref$wrap = _ref.wrap,
    wrap = _ref$wrap === void 0 ? true : _ref$wrap,
    _ref$length = _ref.length,
    length = _ref$length === void 0 ? 10 : _ref$length,
    invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnChipsGroup({
      wrap: wrap
    }, [className])
  }, props, {
    "data-t-id": "components-ChipsGroup"
  }), Array.from({
    length: length
  }).map(function (_, i) {
    return /*#__PURE__*/React.createElement(Chips, {
      color: color,
      invert: invert,
      key: cnChipsGroup('item', {
        i: i
      })
    });
  }));
};