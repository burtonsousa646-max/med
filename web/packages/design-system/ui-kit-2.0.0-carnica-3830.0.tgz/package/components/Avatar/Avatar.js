import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["size", "name", "logo", "color", "badge", "image", "bgColor", "icon", "type", "invert", "badgeClassName", "className"];
import { cnBem } from '@carnica/utils';
import React, { forwardRef } from 'react';
import { withDataConverter } from '@beef/react';
import { compose } from '@beef/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import { Badge } from "../Badge";
import { dataConverter, useWarning } from "./utils";
import { AvatarContent } from "./AvatarContent";
import styles from "./styles.module.css";
export var cnAvatar = cnBem('avatar', styles);
var AvatarRender = function AvatarRender(_ref, ref) {
  var _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    name = _ref.name,
    logo = _ref.logo,
    color = _ref.color,
    badge = _ref.badge,
    image = _ref.image,
    bgColor = _ref.bgColor,
    icon = _ref.icon,
    type = _ref.type,
    invert = _ref.invert,
    badgeClassName = _ref.badgeClassName,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  useWarning({
    bgColor: bgColor,
    color: color,
    invert: invert
  });
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnAvatar({
      size: size,
      color: color,
      bgColor: bgColor,
      disabled: otherProps.disabled,
      type: type
    }, [className]),
    ref: ref,
    "data-t-id": "components-Avatar"
  }), /*#__PURE__*/React.createElement(AvatarContent, {
    disabled: otherProps.disabled,
    icon: icon,
    image: image,
    logo: logo,
    name: name,
    size: size,
    "data-t-id": "components-Avatar"
  }), badge && /*#__PURE__*/React.createElement("div", {
    className: cnAvatar('badgeContainer', [badgeClassName])
  }, /*#__PURE__*/React.createElement(Badge, _extends({
    className: cnAvatar('badge')
  }, badge))));
};
export var Avatar = compose(withDataConverter(dataConverter), forwardRef)(AvatarRender);