import { IMask } from 'react-imask';
import { IconCalendarOutline } from '@carnica/graphics';
import React from 'react';
import { compose } from '@beef/utils';
import { defineProps } from '@beef/react';
import { Input } from "../../Input";
import { withMaskedInput } from "../../../hocs/withMaskedInput";
export var dateRangeMask = {
  mask: 'dd.MM.yyyy - dd.MM.yyyy',
  blocks: {
    yyyy: {
      mask: IMask.MaskedRange,
      from: 1,
      to: 9999
    },
    MM: {
      mask: IMask.MaskedRange,
      from: 1,
      to: 12
    },
    dd: {
      mask: IMask.MaskedRange,
      from: 1,
      to: 31
    }
  },
  lazy: true,
  autofix: true
};
export var DateRangeInput = compose(defineProps({}, {
  placeholder: 'выберите в календарике',
  rightSide: /*#__PURE__*/React.createElement(IconCalendarOutline, {
    color: "tertiary",
    "data-t-id": "AdvancedInputs-DateRangeInput"
  })
}), withMaskedInput(dateRangeMask))(Input);