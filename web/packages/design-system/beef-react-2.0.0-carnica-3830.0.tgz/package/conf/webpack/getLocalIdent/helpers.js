const allowedLeadingCharacters = 'abcdefghijklmnopqrstuvwqyzABCDEFGHIJKLMNOPQRSTUVWQYZ';

// Main function to initiate the permutation process
function permuteArray(inputArray) {
  // Recursive function to create permutations
  function permuteHelper(currentPermutation, remainingElements) {
    if (remainingElements.length === 0) {
      return [currentPermutation];
    }
    return createPermutations(currentPermutation, remainingElements, 0);
  }

  // Function to recursively iterate over the array and create permutations
  function createPermutations(currentPermutation, remainingElements, index) {
    if (index >= remainingElements.length) {
      return [];
    }

    // Creating a new array of remaining elements excluding the current element
    const newRemaining = remainingElements.slice(0, index).concat(remainingElements.slice(index + 1));

    // Recursively call permuteHelper for the new permutation and remaining elements
    const permutationsWithCurrent = permuteHelper(currentPermutation.concat(remainingElements[index]), newRemaining);

    // Recursively call createPermutations for the next index
    const permutationsWithoutCurrent = createPermutations(currentPermutation, remainingElements, index + 1);

    // Concatenate the results of both recursive calls
    return permutationsWithCurrent.concat(permutationsWithoutCurrent);
  }
  return permuteHelper([], inputArray);
}
module.exports = {
  allowedLeadingCharacters,
  permuteArray
};