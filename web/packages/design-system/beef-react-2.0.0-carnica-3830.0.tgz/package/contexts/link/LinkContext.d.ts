import React from 'react';
export type LinkComponentType = React.ComponentType<React.ComponentProps<'a'>>;
export declare const LinkContext: React.Context<"a" | LinkComponentType>;
export declare const useLink: () => "a" | LinkComponentType;
//# sourceMappingURL=LinkContext.d.ts.map