import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["invert", "erid", "advertisingDescription", "onClose", "className", "children", "title", "logo"];
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import React from 'react';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { BannerCardErid } from "./BannerCardErid";
import { BannerCardContent } from "./BannerCardContent";
var cnBannerCard = cnBem('banner-card', styles);
export var BannerCard = forwardRefWithMotionTag(function (props, ref) {
  var invert = props.invert,
    erid = props.erid,
    advertisingDescription = props.advertisingDescription,
    onClose = props.onClose,
    className = props.className,
    children = props.children,
    title = props.title,
    logo = props.logo,
    otherProps = _objectWithoutProperties(props, _excluded);
  useDeprecationWarning({
    erid: {
      value: erid,
      newPropKey: 'advertisingDescription'
    }
  });
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({
    "aria-atomic": true
  }, otherProps, {
    className: cnBannerCard({
      invert: invert
    }, [className]),
    ref: ref,
    "data-t-id": "components-BannerCard"
  }), onClose && /*#__PURE__*/React.createElement(IconCloseRoundStroked, {
    "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0431\u0430\u043D\u043D\u0435\u0440",
    className: cnBannerCard('button'),
    color: invert ? 'white' : 'black',
    onClick: onClose,
    tagName: "button",
    type: "button"
  }), /*#__PURE__*/React.createElement(BannerCardContent, {
    className: cnBannerCard('content'),
    invert: invert,
    logo: logo,
    title: title
  }), children, (advertisingDescription || erid) && /*#__PURE__*/React.createElement(BannerCardErid, {
    className: cnBannerCard('erid'),
    invert: invert,
    isTooltip: !!advertisingDescription
  }, advertisingDescription || erid));
});