import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _extends from "@babel/runtime/helpers/extends";
var _excluded = ["withBasicStyles", "className"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { Button } from "../../Button";
import styles from "../styles.module.css";
var cnDatePicker = cnBem('date-picker', styles);
var ButtonIcon = function ButtonIcon(props) {
  return /*#__PURE__*/React.createElement(IconCloseRoundStroked, _extends({}, props, {
    customColor: "var(--date-picker-close-button-icon-color)",
    "data-t-id": "DatePicker-CloseButton"
  }));
};
export var CloseButton = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var _ref$withBasicStyles = _ref.withBasicStyles,
    withBasicStyles = _ref$withBasicStyles === void 0 ? true : _ref$withBasicStyles,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(Button, _extends({
    "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C",
    className: cnDatePicker('button', {
      withBasicStyles: withBasicStyles
    }, [className]),
    iconLeft: ButtonIcon,
    onlyIcon: true,
    size: "m",
    view: "tertiary"
  }, props, {
    ref: ref
  }));
});