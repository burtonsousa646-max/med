import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import { glob } from 'glob';
import path from 'path';
export var encodeUrl = function encodeUrl(url) {
  return url.replace(/\/$/, '');
};
export var typeToExtension = function typeToExtension(type) {
  return type === 'htm' ? 'htm' : 'json';
};
export var sanitizeUrl = function sanitizeUrl(url) {
  var _ref;
  return (_ref = (url === null || url === void 0 ? void 0 : url.split('?')[0]) || url) === null || _ref === void 0 ? void 0 : _ref.replace(/^.*\/\/[^/]+/, '');
};
export var convertSearchParamsToObject = function convertSearchParamsToObject(searchParams) {
  return (
    // eslint-disable-next-line no-sequences,no-return-assign
    _toConsumableArray(searchParams).reduce(function (a, _ref2) {
      var _ref3 = _slicedToArray(_ref2, 2),
        k = _ref3[0],
        v = _ref3[1];
      return a[k] = v, a;
    }, {})
  );
};
export var findFiles = function findFiles(dirPath, fileName) {
  return glob.sync(path.resolve(process.cwd(), "".concat(dirPath, "/**/").concat(fileName)));
};