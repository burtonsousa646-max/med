import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["caption", "error", "label", "wrapperProps", "wrapperRef", "disabled", "invert", "forwardedRef", "readOnly", "withMobileOffset", "id", "status"];
import React, { forwardRef } from 'react';
import { combineRefs } from '@carnica/utils';
import { ControlWrapper } from "../ControlWrapper";
import { InputCore } from "./InputCore";
export var Input = /*#__PURE__*/forwardRef(function (props, ref) {
  var caption = props.caption,
    error = props.error,
    label = props.label,
    _props$wrapperProps = props.wrapperProps,
    wrapperProps = _props$wrapperProps === void 0 ? {} : _props$wrapperProps,
    wrapperRef = props.wrapperRef,
    disabled = props.disabled,
    invert = props.invert,
    forwardedRef = props.forwardedRef,
    readOnly = props.readOnly,
    withMobileOffset = props.withMobileOffset,
    id = props.id,
    _props$status = props.status,
    status = _props$status === void 0 ? 'default' : _props$status,
    otherProps = _objectWithoutProperties(props, _excluded);
  return /*#__PURE__*/React.createElement(ControlWrapper, _extends({}, wrapperProps, {
    caption: caption,
    captionProps: {
      id: id ? "".concat(id, "-caption") : undefined
    },
    disabled: disabled,
    error: error || status === 'error',
    invert: invert,
    label: label,
    labelProps: {
      htmlFor: id
    },
    readOnly: readOnly,
    ref: wrapperRef,
    withMobileOffset: withMobileOffset,
    "data-t-id": "components-Input"
  }), /*#__PURE__*/React.createElement(InputCore, _extends({
    "aria-describedby": id ? "".concat(id, "-caption") : undefined,
    "aria-label": label ? undefined : 'Поле ввода'
  }, otherProps, {
    disabled: disabled,
    hidePlaceholderOnFocus: !!label,
    id: id,
    invert: invert,
    readOnly: readOnly,
    ref: combineRefs([ref, forwardedRef]),
    status: error || status === 'error' ? 'error' : 'default',
    "data-t-id": "components-Input"
  })));
});