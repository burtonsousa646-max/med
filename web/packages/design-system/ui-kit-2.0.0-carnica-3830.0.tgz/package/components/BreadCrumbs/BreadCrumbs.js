import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "getters", "onItemClick", "convertItem", "invert", "className"],
  _excluded2 = ["attributes"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { IconChevronRight } from '@carnica/graphics';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { MotionComponent } from "../../modules/MotionComponent";
import { useConvertedItems } from "../../hooks/useConvertedItems";
import styles from "./styles.module.css";
import { dataConverter, itemKeys } from "./utils";
import { BreadCrumbsItem } from "./BreadCrumbsItem";
var cnBreadCrumbs = cnBem('breadcrumbs', styles);
var BreadCrumbsRender = function BreadCrumbsRender(props, ref) {
  var itemsProp = props.items,
    getters = props.getters,
    onItemClick = props.onItemClick,
    convertItem = props.convertItem,
    invert = props.invert,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var items = useConvertedItems({
    items: itemsProp || [],
    keys: itemKeys,
    getters: getters,
    convertItem: convertItem
  });
  var handleClick = function handleClick(item) {
    return function (e) {
      var _item$onClick;
      onItemClick === null || onItemClick === void 0 || onItemClick(item, e);
      (_item$onClick = item.onClick) === null || _item$onClick === void 0 || _item$onClick.call(item, e);
    };
  };
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnBreadCrumbs(null, [className]),
    itemScope: true,
    itemType: "https://schema.org/BreadcrumbList",
    ref: ref,
    tagName: "ul",
    "data-t-id": "components-BreadCrumbs"
  }), items === null || items === void 0 ? void 0 : items.map(function (_ref, i) {
    var attributes = _ref.attributes,
      item = _objectWithoutProperties(_ref, _excluded2);
    var isLastItem = i === items.length - 1;
    var isAnchorElement = (item.tagName || 'a') === 'a';
    return /*#__PURE__*/React.createElement("li", {
      className: cnBreadCrumbs('item-wrapper'),
      itemProp: "itemListElement",
      itemScope: true,
      itemType: "https://schema.org/ListItem",
      key: cnBreadCrumbs('item', {
        i: i
      })
    }, /*#__PURE__*/React.createElement(BreadCrumbsItem, _extends({}, attributes, item, {
      "aria-current": isLastItem && isAnchorElement ? 'page' : undefined,
      className: cnBreadCrumbs('item', [attributes === null || attributes === void 0 ? void 0 : attributes.className]),
      invert: invert,
      itemProp: isAnchorElement ? 'item' : 'name',
      onClick: handleClick(item),
      ref: item.ref
    })), /*#__PURE__*/React.createElement("meta", {
      content: String(i + 1),
      itemProp: "position"
    }), !isLastItem && /*#__PURE__*/React.createElement(IconChevronRight, {
      customColor: "var(--bread-crumbs-divider-icon-color-".concat(invert ? 'invert' : 'default', ")"),
      size: "xs"
    }));
  }));
};
export var BreadCrumbs = compose(withDataConverter(dataConverter), forwardRef)(BreadCrumbsRender);