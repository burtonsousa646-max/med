export { Point } from './point';
//# sourceMappingURL=index.d.ts.map