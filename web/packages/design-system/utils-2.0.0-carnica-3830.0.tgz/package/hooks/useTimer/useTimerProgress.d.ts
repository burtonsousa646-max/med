import React from 'react';
import { UseTimerParams } from './types';
export declare const useTimerProgress: ({ timerType, interval, startTime, endTime, onTimeOver, onInterval, }: UseTimerParams) => {
    cancelInterval: VoidFunction;
    createInterval: VoidFunction;
    intervalRef: React.RefObject<number | undefined>;
    time: React.RefObject<number>;
    shouldResetTimeRef: React.RefObject<boolean>;
    isRunning: boolean;
    resetTime: (newTime?: number) => void;
};
//# sourceMappingURL=useTimerProgress.d.ts.map