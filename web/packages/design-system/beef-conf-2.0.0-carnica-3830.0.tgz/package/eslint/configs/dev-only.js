const {
  resolvePlugin,
  isFixMode
} = require('../utils');

// config preset for tests, storybook etc
module.exports = {
  extends: ['../rules/dev-only', isFixMode ? '../rules/autofix-broken' : null].filter(Boolean).map(resolvePlugin),
  rules: {}
};