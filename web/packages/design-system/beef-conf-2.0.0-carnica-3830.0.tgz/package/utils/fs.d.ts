export function rewriteJsonFile(filepath: any, contentChanger?: (fileContent: any) => Promise<any>): Promise<void>;
export function getWorkspacePackageJsonPaths(): Promise<string[]>;
//# sourceMappingURL=fs.d.ts.map