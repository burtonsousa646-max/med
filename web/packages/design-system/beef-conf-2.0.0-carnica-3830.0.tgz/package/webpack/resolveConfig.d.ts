declare function _exports(cwd?: string): any;
export = _exports;
//# sourceMappingURL=resolveConfig.d.ts.map