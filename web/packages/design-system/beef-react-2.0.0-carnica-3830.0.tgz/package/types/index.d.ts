import React, { JSX, PropsWithChildren } from 'react';
export type TWithZonesReturnType<PKey extends string, PProps> = React.FC<PropsWithChildren<Omit<PProps, 'zones'>>> & Record<PKey, React.FC<PropsWithChildren<unknown>>>;
export type TWithZonesLayoutType<PKey extends string, PProps> = React.FC<{
    zones: Record<PKey, React.ReactNode>;
} & PProps>;
export interface ReactProps extends JSX.IntrinsicAttributes {
    children?: Array<React.ReactNode> | React.ReactNode;
}
export interface DangerAndChildren {
    children: React.ReactNode;
    dangerouslySetInnerHTML: {
        __html: string;
    } | undefined;
}
//# sourceMappingURL=index.d.ts.map