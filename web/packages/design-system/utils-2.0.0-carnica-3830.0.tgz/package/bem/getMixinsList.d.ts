import { ClassNameList } from './types';
export declare const getMixinsList: (entityName: string, mix: ClassNameList) => string[];
//# sourceMappingURL=getMixinsList.d.ts.map