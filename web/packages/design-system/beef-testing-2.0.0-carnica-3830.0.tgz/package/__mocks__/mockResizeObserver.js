import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime/helpers/getPrototypeOf";
import _inherits from "@babel/runtime/helpers/inherits";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
// Mock для ResizeObserver, наследующийся от базового класса
import { BaseObserver } from "./baseObserverMock";
export var MockResizeObserver = /*#__PURE__*/function (_BaseObserver) {
  function MockResizeObserver() {
    _classCallCheck(this, MockResizeObserver);
    return _callSuper(this, MockResizeObserver, arguments);
  }
  _inherits(MockResizeObserver, _BaseObserver);
  return _createClass(MockResizeObserver, [{
    key: "observe",
    value: function observe() {}
  }, {
    key: "unobserve",
    value: function unobserve() {}
  }, {
    key: "disconnect",
    value: function disconnect() {}
  }]);
}(BaseObserver);
// Пример использования
// globalThis.ResizeObserver = MockResizeObserver