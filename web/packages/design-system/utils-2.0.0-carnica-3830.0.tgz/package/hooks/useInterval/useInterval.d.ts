import { UseInterval } from './types';
export declare const useInterval: UseInterval;
//# sourceMappingURL=useInterval.d.ts.map