export * from './QR';
export type { QRPropErrorCorrectionLevel, QRProps } from './types';
//# sourceMappingURL=index.d.ts.map