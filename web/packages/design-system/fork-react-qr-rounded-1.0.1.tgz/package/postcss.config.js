const { postcssConfig } = require('@beef/react/conf');

module.exports = (opts) => ({
  ...postcssConfig(opts),
  plugins: {
    ...postcssConfig(opts).plugins,
    [require.resolve('postcss-simple-vars')]: [],
  },
});
