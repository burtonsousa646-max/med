import type { ComponentWithMotionTag, MotionTags } from '@carnica/utils/types';
export declare const iconPropColor: readonly ["primary", "primary-invert", "primary-fake-invert", "secondary", "secondary-invert", "secondary-fake-invert", "tertiary", "tertiary-invert", "tertiary-fake-invert", "disabled", "disabled-invert", "disabled-fake-invert", "brand-primary", "brand-secondary", "brand-tertiary", "success-primary", "success-secondary", "success-tertiary", "error-primary", "error-secondary", "error-tertiary", "link-primary", "link-secondary", "link-tertiary", "success", "error", "link", "black", "white"];
export type IconPropColor = (typeof iconPropColor)[number];
export declare const iconPropSize: readonly ["xs", "s", "m", "l"];
export type IconPropSize = (typeof iconPropSize)[number];
type DefaultIconProps = {
    iconClassName?: string;
    size?: IconPropSize | number;
};
export type IconComponent = ComponentWithMotionTag<{
    color?: IconPropColor;
    customColor?: string;
} & DefaultIconProps, MotionTags, 'span'>;
export type LogoComponent = ComponentWithMotionTag<DefaultIconProps, MotionTags, 'span'>;
export {};
//# sourceMappingURL=IconComponent.d.ts.map