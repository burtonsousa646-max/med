import { IconInfoFilled, LogoBeelineColor } from '@carnica/graphics';
export var items = [{
  image: 'https://static.beeline.ru/upload/images/carnica/logos/LogoBeelineColor.svg',
  view: 'image'
}, {
  icon: IconInfoFilled,
  view: 'icon'
}, {
  icon: IconInfoFilled,
  view: 'accent-icon'
}, {
  logo: LogoBeelineColor,
  view: 'logo'
}, {
  label: 'Alehandro',
  view: 'text'
}, {
  label: 'Beto',
  view: 'text',
  color: 'brand'
}, {
  label: 'Cirilla',
  view: 'text',
  color: 'invert'
}];