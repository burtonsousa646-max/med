import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { isPlainObject } from "./checks";
import { reduce } from "./objects";
// import { replaceQuotes } from './stringFormat';

export var NullComponent = function NullComponent() {
  return null;
};
export var NullContainer = function NullContainer(_ref) {
  var children = _ref.children;
  return children;
};

/**
 * Обертка для хука, чтобы он выполнялся только на клиенте, на сервере превращается в тыкву
 */
export var clientOnlyHook = function clientOnlyHook(hook) {
  if (typeof window === 'undefined') return function () {
    return undefined;
  };
  return hook;
};
export var spreadDangerousChildren = function spreadDangerousChildren(children) {
  return {
    children: typeof children !== 'string' ? children : null,
    dangerouslySetInnerHTML: typeof children === 'string' ? {
      __html: children
    } : undefined
  };
};

/**
 * Input: isAvailableFlag
 * Output: availableFlag
 */
var statusToClass = function statusToClass(status) {
  return status.indexOf('is') === 0 ? status.substring(2, 3).toLowerCase() + status.substring(3) : status;
};

/**
 * Remove `is` and convert next letter to lowerCase
 */
export var cxBool = function cxBool(classes) {
  return reduce(classes, function (result, value, key) {
    return _objectSpread(_objectSpread({}, result), {}, _defineProperty({}, statusToClass(key), value));
  }, {});
};
export function proxyHandler(originalHandler, extraHandler) {
  return function () {
    if (typeof originalHandler === 'function') originalHandler.apply(void 0, arguments);
    extraHandler.apply(void 0, arguments);
  };
}

/** TODO: heal too much pain typing */
export var getNodeDisplayName = function getNodeDisplayName(node) {
  if (isPlainObject(node) && node.type !== 'string') {
    return node.type.displayName;
  }
  return null;
};

/** Функция, позволяющая делать key из любых данных */
// TODO: Rewrite to rely on WebCrypto API (with Jest support)
export function generateReactKey(input) {
  try {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore TODO: temporary ts error
    var _input = isPlainObject(input) ? Object.values(input).join('') : input;

    // Делаем строку из input
    var jsonString = JSON.stringify(_input);

    // Делаем base64 строку из получившейся строки
    var encodedString = btoa(encodeURIComponent(jsonString));
    var foldedString = _toConsumableArray(encodedString).reduce(function (acc, char, idx, arr) {
      if (acc.length < 10) {
        // Если четный, оставляем значение как есть
        if (idx % 2 === 0) {
          return "".concat(acc).concat(char);
        }

        // Если нечетный, то берем значение с конца
        var oddChar = arr[arr.length - 1 - Math.floor(idx / 2)];
        return "".concat(acc).concat(oddChar);
      }
      return acc;
    }, '');
    return foldedString.substring(0, 10);
  } catch (e) {
    console.error(e);
    return '';
  }
}