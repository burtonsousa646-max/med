export * from './useInterval';
//# sourceMappingURL=index.d.ts.map