export declare const useCheckMounted: () => () => boolean;
//# sourceMappingURL=useCheckMounted.d.ts.map