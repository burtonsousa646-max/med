export declare function useRequestPolling<T>(fn: () => Promise<T>, { interval }?: {
    interval?: number | undefined;
}): void;
//# sourceMappingURL=useRequestPolling.d.ts.map