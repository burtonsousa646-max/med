export let rules: {
    '@typescript-eslint/explicit-function-return-type': number;
    '@typescript-eslint/indent': number;
    '@typescript-eslint/naming-convention': (number | {
        format: string[];
        leadingUnderscore: string;
        modifiers: string[];
        selector: string;
    })[];
    '@typescript-eslint/no-empty-interface': (string | {
        allowSingleExtends: boolean;
    })[];
    '@typescript-eslint/no-explicit-any': number;
    '@typescript-eslint/no-misused-promises': (number | {
        checksVoidReturn: boolean;
    })[];
    '@typescript-eslint/no-unsafe-argument': number;
    '@typescript-eslint/no-unsafe-assignment': number;
    '@typescript-eslint/no-unsafe-call': number;
    '@typescript-eslint/no-unsafe-member-access': number;
    '@typescript-eslint/no-unsafe-return': number;
    '@typescript-eslint/no-unused-vars': (number | {
        destructuredArrayIgnorePattern: string;
        ignoreRestSiblings: boolean;
    })[];
    '@typescript-eslint/no-use-before-define': number;
    'react/prop-types': number;
};
//# sourceMappingURL=typescript.d.ts.map