export { GenericLink } from './GenericLink';
export { LinkContext, useLink } from './LinkContext';
export type { LinkComponentType } from './LinkContext';
//# sourceMappingURL=index.d.ts.map