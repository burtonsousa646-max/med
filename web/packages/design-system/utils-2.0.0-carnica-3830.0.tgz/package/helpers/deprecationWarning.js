export var deprecationWarning = function deprecationWarning(prop, message) {
  if (process.env.NODE_ENV !== 'production') {
    // eslint-disable-next-line no-console
    console.warn("[DEPRECATED]: Prop \"".concat(prop, "\" is deprecated. ").concat(message));
  }
};