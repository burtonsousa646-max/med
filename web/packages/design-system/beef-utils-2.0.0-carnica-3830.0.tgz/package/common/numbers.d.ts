export declare const roundToPrecision: (value: number, precision?: number) => number;
export declare const fractionToPrecision: (value: number, fraction: number) => number;
export declare const roundToFraction: (value: number, fraction?: number) => number;
//# sourceMappingURL=numbers.d.ts.map