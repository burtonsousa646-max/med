import { BasePluginOptions, DefinedDefaultMinimizerAndOptions, MinimizerOptions } from 'terser-webpack-plugin';
import { MinifyOptions } from 'terser';
import { Ctor } from './common';
export type BuildEnv = {
    [key: `is${string}`]: boolean | undefined;
    isHMR?: boolean;
    isProduction?: boolean;
    isServer?: boolean;
};
type RawLoader = string;
export type Loader = any;
export type Plugin = Record<PropertyKey, any>;
type ZeroParam<P> = [] extends P ? (P extends [] ? true : false) : false;
type ReqParam<P> = [any] extends P ? (P extends [any] ? true : false) : false;
export type PluginArgs<C extends Plugin> = C extends Ctor<any, infer A> ? ZeroParam<A> extends true ? [] | [undefined, boolean] : ReqParam<A> extends true ? [A[0], boolean?] : [A[0]?, boolean?] : [boolean?];
export type WebpackBuilderUtils = {
    [key: PropertyKey]: any;
    _loaders: Record<string, RawLoader>;
    loaders: Record<string, Loader>;
    plugins: Record<string, Plugin>;
    rules: Record<string, RegExp | string>;
};
export type TerserPluginTyped = new (options: BasePluginOptions & DefinedDefaultMinimizerAndOptions<MinimizerOptions<MinifyOptions>>) => any;
export type { default as TerserWebpackPlugin } from 'terser-webpack-plugin';
//# sourceMappingURL=types.d.ts.map