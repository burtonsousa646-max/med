import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["loading", "isOpen", "className", "children"];
import React, { createContext, forwardRef, useContext, useEffect, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { useFlag } from '@carnica/utils/hooks';
import { Modal } from "../../Modal";
import styles from "./styles.module.css";
var AnimateModalContext = /*#__PURE__*/createContext({
  current: null
});
var cnStatusViewAnimateModal = cnBem('status-view-animate-modal', styles);
export var StatusViewAnimateModal = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var loading = _ref.loading,
    isOpen = _ref.isOpen,
    className = _ref.className,
    children = _ref.children,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _useFlag = useFlag(loading),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    hidden = _useFlag2[0],
    setHidden = _useFlag2[1];
  var modalRef = useRef(null);
  useEffect(function () {
    if (isOpen) {
      setHidden.set(!!loading);
      if (loading) {
        setTimeout(setHidden.off, 3000);
      }
    }
  }, [loading, isOpen]);
  return /*#__PURE__*/React.createElement(Modal, _extends({}, otherProps, {
    className: cnStatusViewAnimateModal({
      hidden: hidden
    }, [className]),
    isOpen: isOpen,
    ref: combineRefs([ref, modalRef]),
    "data-t-id": "StatusView-StatusViewAnimateModal"
  }), /*#__PURE__*/React.createElement(AnimateModalContext.Provider, {
    value: modalRef
  }, children));
});
export var useAnimateModalContext = function useAnimateModalContext() {
  return useContext(AnimateModalContext);
};