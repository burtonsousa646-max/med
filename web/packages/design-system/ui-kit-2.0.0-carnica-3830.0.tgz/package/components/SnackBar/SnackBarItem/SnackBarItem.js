import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "mode", "view", "position", "title", "subTitle", "autoCloseTime", "truncate", "style", "onClose", "onMouseEnter", "onMouseLeave"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { motion } from 'framer-motion';
import { Text } from "../../Text";
import styles from "./styles.module.css";
import { iconColorMap, subTitleColorMap, subTitleOpacityMap, textColorMap } from "../utils";
import { useSnackBarItem } from "../hooks/useSnackBarItem";
var cnSnackBarItem = cnBem('snackbar-item', styles);
var nameByView = {
  info: 'уведомление',
  error: 'сообщение об ошибке',
  success: 'уведомление',
  warning: 'предупреждение'
};
export var SnackBarItem = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    _props$mode = props.mode,
    mode = _props$mode === void 0 ? 'autoclose' : _props$mode,
    _props$view = props.view,
    view = _props$view === void 0 ? 'info' : _props$view,
    position = props.position,
    title = props.title,
    subTitle = props.subTitle,
    autoCloseTime = props.autoCloseTime,
    truncate = props.truncate,
    style = props.style,
    onClose = props.onClose,
    onMouseEnter = props.onMouseEnter,
    onMouseLeave = props.onMouseLeave,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useSnackBarItem = useSnackBarItem({
      mode: mode,
      autoCloseTime: autoCloseTime,
      onClose: onClose,
      view: view
    }),
    pause = _useSnackBarItem.pause,
    play = _useSnackBarItem.play;
  var handleMouseEnter = function handleMouseEnter(e) {
    onMouseEnter === null || onMouseEnter === void 0 || onMouseEnter(e);
    pause();
  };
  var handleMouseLeave = function handleMouseLeave(e) {
    onMouseLeave === null || onMouseLeave === void 0 || onMouseLeave(e);
    play();
  };
  return /*#__PURE__*/React.createElement(motion.div, _extends({
    "aria-atomic": true,
    "aria-live": "assertive",
    className: cnSnackBarItem({
      view: view,
      withButton: mode === 'button'
    }, [className]),
    onMouseEnter: handleMouseEnter,
    onMouseLeave: handleMouseLeave,
    ref: ref,
    role: "alert",
    style: _objectSpread(_defineProperty({}, '--snackbar-item-sub-opacity', subTitleOpacityMap[view]), style)
  }, otherProps), /*#__PURE__*/React.createElement("div", {
    className: cnSnackBarItem('wrapper'),
    "data-t-id": "SnackBar-SnackBarItem"
  }, title && /*#__PURE__*/React.createElement(Text, {
    align: "center",
    className: cnSnackBarItem('title'),
    color: textColorMap[view],
    truncate: truncate,
    variant: "body-small"
  }, title), subTitle && /*#__PURE__*/React.createElement(Text, {
    align: "center",
    className: cnSnackBarItem('subtitle'),
    color: subTitleColorMap[view],
    truncate: truncate,
    variant: "body-small"
  }, subTitle)), mode === 'button' && /*#__PURE__*/React.createElement(IconCloseRoundStroked, {
    "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C ".concat(nameByView[view]),
    className: cnSnackBarItem('button'),
    color: iconColorMap[view],
    onClick: onClose,
    size: "m",
    tagName: "button",
    type: "button"
  }));
});