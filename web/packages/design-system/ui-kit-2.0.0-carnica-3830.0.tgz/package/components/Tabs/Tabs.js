import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["convertItem", "getters", "onChange", "items", "className", "size", "activeTab"],
  _excluded2 = ["attributes", "label"];
import React, { forwardRef, useMemo } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter, withRenderCondition } from '@beef/react';
import { MotionComponent } from "../../modules/MotionComponent";
import { useConvertedItems } from "../../hooks/useConvertedItems";
import { convertItemToDefault, dataConverter, itemKeys } from "./utils";
import { TabsItem } from "./TabsItem";
import styles from "./styles.module.css";
import { useTabsKeyboardHandler } from "./hooks/useTabsKeyboardHandler";
var cnTabs = cnBem('tabs', styles);
var TabsRender = function TabsRender(props, ref) {
  var convertItem = props.convertItem,
    getters = props.getters,
    onChange = props.onChange,
    itemsProp = props.items,
    className = props.className,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    activeTabProp = props.activeTab,
    otherProps = _objectWithoutProperties(props, _excluded);
  var items = useConvertedItems({
    items: itemsProp || [],
    getters: getters,
    keys: itemKeys,
    convertItem: convertItem,
    withOriginal: true
  });
  var _useTabsKeyboardHandl = useTabsKeyboardHandler(items),
    itemRefs = _useTabsKeyboardHandl.itemRefs,
    onKeyDownByItem = _useTabsKeyboardHandl.onKeyDownByItem;
  var activeTab = useMemo(function () {
    return activeTabProp ? convertItemToDefault(getters, convertItem)(activeTabProp) : items[0].converted;
  }, [activeTabProp]);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnTabs({
      size: size
    }, [className]),
    ref: ref,
    tagName: "ul",
    "data-t-id": "components-Tabs"
  }), items.map(function (item, i) {
    var _item$converted = item.converted,
      attributes = _item$converted.attributes,
      label = _item$converted.label,
      converted = _objectWithoutProperties(_item$converted, _excluded2);
    return /*#__PURE__*/React.createElement(TabsItem, _extends({}, converted, {
      active: activeTab.key === converted.key,
      onClick: function onClick(e) {
        return onChange(item.original, e);
      }
    }, attributes, {
      onKeyDown: onKeyDownByItem(item),
      ref: combineRefs([itemRefs[i], converted.ref]),
      size: size
    }), label);
  }));
};
export var Tabs = compose(withDataConverter(dataConverter), withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref) {
    var items = _ref.items;
    return Boolean(items.length);
  }
}), forwardRef)(TabsRender);