import { useClickOutside } from '@carnica/utils/hooks';
export var ClickOutsideWrapper = function ClickOutsideWrapper(_ref) {
  var onClickOutside = _ref.onClickOutside,
    _ref$children = _ref.children,
    children = _ref$children === void 0 ? null : _ref$children,
    ignoreClicksInsideRefs = _ref.ignoreClicksInsideRefs;
  useClickOutside({
    isActive: !!onClickOutside,
    ignoreClicksInsideRefs: ignoreClicksInsideRefs || [],
    onClick: onClickOutside
  });
  return children;
};