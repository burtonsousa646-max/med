import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { startOfDay } from 'date-fns-new';
import { isEqalDate, isInInterval } from "./date";
var normalizeValue = function normalizeValue(value) {
  var _value = _slicedToArray(value, 2),
    start = _value[0],
    end = _value[1];
  return [start ? startOfDay(start) : start, end ? startOfDay(end) : end];
};
export var getNewRangeValidValue = function getNewRangeValidValue(date, value, minDate, maxDate) {
  var disableDates = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : [];
  var _value2 = _slicedToArray(value, 2),
    startDate = _value2[0],
    endDate = _value2[1];
  if (!isInInterval(date, minDate, maxDate)) {
    return normalizeValue(value);
  }
  if (startDate && !isInInterval(startDate, minDate, maxDate) || endDate && !isInInterval(endDate, minDate, maxDate)) {
    return normalizeValue([date, null]);
  }
  if (disableDates.length) {
    var includes = disableDates.find(function (el) {
      return Array.isArray(el) ? isInInterval(date, el[0], el[1]) : isEqalDate(el, date);
    });
    if (includes) {
      return normalizeValue(value);
    }
  }
  if (startDate && isEqalDate(startDate, date)) {
    return normalizeValue([endDate, null]);
  }
  if (endDate && isEqalDate(endDate, date)) {
    return normalizeValue([startDate, null]);
  }
  if (startDate && !endDate) {
    var range = startDate > date ? [date, startDate] : [startDate, date];
    var hasIncludes = !!disableDates.find(function (el) {
      return Array.isArray(el) ? isInInterval(el[0], range[0], range[1]) || isInInterval(el[1], range[0], range[1]) : isInInterval(el, range[0], range[1]);
    });
    return normalizeValue(hasIncludes ? [date, null] : range);
  }
  return normalizeValue([date, null]);
};