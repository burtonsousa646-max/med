type UseDeprecationWarningParamType = {
    customMessage?: string;
    newPropKey?: string;
    value: unknown;
};
export type UseDeprecationWarningParams = Record<string, UseDeprecationWarningParamType>;
export {};
//# sourceMappingURL=types.d.ts.map