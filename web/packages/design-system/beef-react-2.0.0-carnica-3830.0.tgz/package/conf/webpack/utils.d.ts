export function mapViewFiles(fn: (options: {
    name: string;
    filePath: string;
}) => any): any[];
import { replaceNonCSSCharacters } from "./getLocalIdent";
import { provideSmartGetLocalIdent } from "./getLocalIdent";
export declare namespace errorFilters {
    let silentFilter: string;
    let lazyCompilationFilter: string;
}
export { replaceNonCSSCharacters, provideSmartGetLocalIdent };
//# sourceMappingURL=utils.d.ts.map