# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.1](https://git.vimpelcom.ru:1122/products/wwwbeelineru2013/fe/fork-react-qr-rounded/compare/v1.0.0...v1.0.1) (2024-11-26)

**Note:** Version bump only for package @carnica/fork-react-qr-rounded





# 1.0.0 (2024-11-25)

**Note:** Version bump only for package @carnica/fork-react-qr-rounded





## [0.0.2](https://git.vimpelcom.ru:1122/products/wwwbeelineru2013/fe/fork-react-qr-rounded/compare/v0.0.1...v0.0.2) (2024-11-25)

**Note:** Version bump only for package @carnica/fork-react-qr-rounded





## 0.0.1 (2024-11-25)


### Features

* added repos and tools ([fc0d23f](https://git.vimpelcom.ru:1122/products/wwwbeelineru2013/fe/fork-react-qr-rounded/commits/fc0d23f5cf5c2406ecb519636ffdbe4c739503b4))
