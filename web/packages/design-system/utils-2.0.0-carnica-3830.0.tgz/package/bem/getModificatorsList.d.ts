import { NoStrictEntityMods } from './types';
export declare const getModificatorsList: (prefix: string, modificators: NoStrictEntityMods) => string[];
//# sourceMappingURL=getModificatorsList.d.ts.map