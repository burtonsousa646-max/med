import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "activated"];
import { cnBem, forwardRefWithMotion } from '@carnica/utils';
import React from 'react';
import { MotionComponent } from "../../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnBadgeStories = cnBem('badge-stories-v3', styles);
export var BadgeStories = forwardRefWithMotion(function (_ref, ref) {
  var className = _ref.className,
    activated = _ref.activated,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({
    "aria-current": activated,
    "aria-label": activated ? 'Не просмотрено' : 'Просмотрено',
    className: cnBadgeStories({
      activated: activated
    }, [className]),
    role: "img"
  }, props, {
    ref: ref,
    tagName: "span",
    "data-t-id": "Badge-V3"
  }));
});