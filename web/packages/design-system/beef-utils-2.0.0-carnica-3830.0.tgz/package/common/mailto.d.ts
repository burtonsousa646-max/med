type Params = {
    bcc?: string[];
    body?: string;
    cc?: string[];
    subject?: string;
    to: string;
};
export declare const getMailtoHref: ({ to, cc, bcc, subject, body }: Params) => string;
export {};
//# sourceMappingURL=mailto.d.ts.map