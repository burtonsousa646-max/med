import React from 'react';
import { cnBem } from '@carnica/utils';
import { Spinner } from "../../Spinner";
import { spinnerColorMap } from "../utils";
import styles from "../styles.module.css";
var cnButtonSpinner = cnBem('button-spinner', styles);
var getView = function getView(_ref) {
  var invert = _ref.invert,
    mode = _ref.mode,
    _ref$view = _ref.view,
    view = _ref$view === void 0 ? 'primary' : _ref$view;
  if (mode === 'default') {
    return spinnerColorMap[view];
  }
  return invert ? 'dark-yellow' : 'dark-white';
};
export var ButtonSpinner = function ButtonSpinner(props) {
  return /*#__PURE__*/React.createElement(Spinner, {
    "aria-hidden": true,
    className: cnButtonSpinner({
      mode: props.mode
    }),
    view: getView(props),
    "data-t-id": "Button-ButtonSpinner"
  });
};