export * from './useScrollToItem';
//# sourceMappingURL=index.d.ts.map