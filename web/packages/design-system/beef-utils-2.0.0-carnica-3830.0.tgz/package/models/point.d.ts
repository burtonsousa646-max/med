export declare class Point {
    readonly clientX: number;
    readonly clientY: number;
    constructor(clientX: number, clientY: number);
    static fromEvent(event: MouseEvent): Point;
    diff(origin: Point): {
        dx: number;
        dy: number;
    };
}
//# sourceMappingURL=point.d.ts.map