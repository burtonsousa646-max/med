import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';

/**
 * Wraps component by passing:
 * `finalProps` that can no longer be changed and
 * `defaultProps` that can be overridden
 */
export function defineProps(finalProps, defaultProps) {
  // eslint-disable-next-line @typescript-eslint/comma-dangle
  return function (WrappedComponent) {
    var RedefinedComponent = /*#__PURE__*/forwardRef(function (props, ref) {
      return /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, _objectSpread(_objectSpread(_objectSpread({}, defaultProps), props), finalProps), {
        ref: ref,
        "data-t-id": "src-enhancers"
      }));
    });
    if (process.env.NODE_ENV !== 'production') {
      RedefinedComponent.displayName = WrappedComponent.displayName || WrappedComponent.name || 'Component';
    }
    return RedefinedComponent;
  };
}