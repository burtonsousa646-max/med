import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "onFocus", "onBlur", "maxRows", "value", "error", "style", "onChange", "readOnly"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import styles from "./styles.module.css";
import { useTextAreaSize } from "../hooks/useTextAreaSize";
var cnTextAreaCore = cnBem('textarea-core', styles);
export var TextAreaCore = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    onFocusProp = props.onFocus,
    onBlurProp = props.onBlur,
    maxRows = props.maxRows,
    value = props.value,
    error = props.error,
    style = props.style,
    onChangeProp = props.onChange,
    readOnly = props.readOnly,
    otherProps = _objectWithoutProperties(props, _excluded);
  var onFocus = function onFocus(e) {
    return onFocusProp === null || onFocusProp === void 0 ? void 0 : onFocusProp(value, e);
  };
  var onBlur = function onBlur(e) {
    return onBlurProp === null || onBlurProp === void 0 ? void 0 : onBlurProp(value, e);
  };
  var _useTextAreaSize = useTextAreaSize({
      maxRows: maxRows,
      onChange: onChangeProp,
      value: value
    }),
    onChange = _useTextAreaSize.onChange,
    textAreaRef = _useTextAreaSize.textAreaRef,
    inputHeight = _useTextAreaSize.inputHeight,
    rows = _useTextAreaSize.rows,
    overflowFlag = _useTextAreaSize.overflowFlag;
  return /*#__PURE__*/React.createElement("div", {
    className: cnTextAreaCore({
      readOnly: readOnly
    }),
    "data-t-id": "TextArea-TextAreaCore"
  }, /*#__PURE__*/React.createElement("textarea", _extends({}, otherProps, {
    className: cnTextAreaCore('field', {
      size: rows < 4 ? 'large' : 'medium',
      overflow: overflowFlag,
      error: !!error
    }, [className]),
    onBlur: onBlur,
    onChange: onChange,
    onFocus: onFocus,
    readOnly: readOnly,
    ref: combineRefs([ref, textAreaRef]),
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty({}, '--text-area-height', "".concat(inputHeight, "px"))),
    value: value
  })));
});