import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useLayoutEffect, useState } from 'react';
import { removeCSS, updateCSS } from "../../helpers/dynamicCss";
import { getNodeScrollBarSize } from "../../helpers/getScrollbarSize";
import { getContainer, getSelector, isBodyOverflowing } from "./utils";
var UNIQUE_ID = "carnica-scroll-locker-".concat(Date.now());
var uuid = 0;
export var useBlockScroll = function useBlockScroll() {
  var blocked = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  var container = arguments.length > 1 ? arguments[1] : undefined;
  var _useState = useState(function () {
      uuid += 1;
      return "".concat(UNIQUE_ID, "_").concat(uuid);
    }),
    _useState2 = _slicedToArray(_useState, 1),
    id = _useState2[0];
  useLayoutEffect(function () {
    var node = getContainer(container);
    if (blocked && node) {
      var scrollbarSize = getNodeScrollBarSize(node).width;
      var isOverflow = isBodyOverflowing();
      var selector = getSelector(id, node);
      updateCSS("\n".concat(selector, " {\n  overflow-y: hidden !important;\n  ").concat(isOverflow ? "width: calc(100% - ".concat(scrollbarSize, "px);") : '', "\n}"), id);
    } else {
      removeCSS(id);
      node === null || node === void 0 || node.classList.remove(id);
    }
    return function () {
      removeCSS(id);
      node === null || node === void 0 || node.classList.remove(id);
    };
  }, [blocked, id]);
};