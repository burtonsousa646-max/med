export type AnyDict = Record<string, any>;
export type AnyFunc = (...args: any[]) => void;
//# sourceMappingURL=types.d.ts.map