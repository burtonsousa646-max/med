import React from 'react';
import { useEventListener } from "../useEventListener";
export var useLinkInterceptor = function useLinkInterceptor(handler) {
  var domNodeRef = React.useRef(null);
  var handleLinkClick = function handleLinkClick(event) {
    var _event$target;
    if (((_event$target = event.target) === null || _event$target === void 0 ? void 0 : _event$target.tagName) === 'A') {
      var href = event.target.getAttribute('href');
      handler(href, event);
    }
  };
  useEventListener('click', handleLinkClick, domNodeRef);
  return domNodeRef;
};