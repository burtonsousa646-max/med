export declare const useId: () => string;
//# sourceMappingURL=useId.d.ts.map