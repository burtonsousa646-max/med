import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "duration", "mode", "steps", "activeStep", "progress", "iterative", "invert", "onFinish", "onStepFinish", "infinite", "isActive", "onInit"];
import React, { forwardRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { useProgressBar } from "./hooks/useProgressBar";
var cnProgressBar = cnBem('progress-bar', styles);
var ProgressBarRender = function ProgressBarRender(props, ref) {
  var className = props.className,
    _props$duration = props.duration,
    durationProp = _props$duration === void 0 ? 2000 : _props$duration,
    _props$mode = props.mode,
    mode = _props$mode === void 0 ? 'auto' : _props$mode,
    _props$steps = props.steps,
    steps = _props$steps === void 0 ? 1 : _props$steps,
    _props$activeStep = props.activeStep,
    activeStep = _props$activeStep === void 0 ? 0 : _props$activeStep,
    _props$progress = props.progress,
    progress = _props$progress === void 0 ? 0 : _props$progress,
    iterative = props.iterative,
    invert = props.invert,
    onFinish = props.onFinish,
    onStepFinish = props.onStepFinish,
    infinite = props.infinite,
    _props$isActive = props.isActive,
    isActive = _props$isActive === void 0 ? true : _props$isActive,
    onInit = props.onInit,
    otherProps = _objectWithoutProperties(props, _excluded);
  var duration = Math.max(Math.abs(durationProp), 100);
  var _useProgressBar = useProgressBar({
      duration: duration,
      mode: mode,
      steps: steps,
      activeStep: activeStep,
      progress: progress,
      isActive: isActive,
      onFinish: onFinish,
      iterative: iterative,
      onStepFinish: onStepFinish,
      onInit: onInit,
      infinite: infinite
    }),
    containerRef = _useProgressBar.containerRef,
    currentStep = _useProgressBar.currentStep;
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({
    "aria-label": "\u0418\u043D\u0434\u0438\u043A\u0430\u0442\u043E\u0440 \u043F\u0440\u043E\u0433\u0440\u0435\u0441\u0441\u0430",
    "aria-valuemax": steps,
    "aria-valuemin": 0,
    "aria-valuenow": currentStep,
    className: cnProgressBar({
      mode: mode,
      invert: invert
    }, [className]),
    role: "progressbar"
  }, otherProps, {
    ref: combineRefs([ref, containerRef]),
    "data-t-id": "components-ProgressBar"
  }), /*#__PURE__*/React.createElement("span", {
    className: cnProgressBar('progress'),
    "data-t-id": "components-ProgressBar"
  }));
};
export var ProgressBar = /*#__PURE__*/forwardRef(ProgressBarRender);