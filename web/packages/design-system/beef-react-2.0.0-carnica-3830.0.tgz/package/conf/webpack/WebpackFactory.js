/* eslint-disable react-hooks/rules-of-hooks, import/order */
const {
  createRequireLinked
} = require('@beef/conf/utils');
const {
  WebpackFactory
} = require('@beef/conf');
const {
  mapViewFiles,
  provideSmartGetLocalIdent,
  errorFilters
} = require('./utils');
const FriendlyErrorOverlayPlugin = require('./FriendlyErrorOverlayWebpackPlugin');

// eslint-disable-next-line no-global-assign
require = createRequireLinked(__dirname);
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin');
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
class ReactWebpackBuilder extends WebpackFactory {
  get plugins() {
    return {
      ...super.plugins,
      MiniCssExtractPlugin,
      CssMinimizerPlugin,
      HtmlWebpackPlugin,
      ReactRefreshWebpackPlugin,
      FriendlyErrorOverlayPlugin,
      ForkTsCheckerWebpackPlugin
    };
  }
  get rawLoaders() {
    return {
      ...super.rawLoaders,
      expose: require.resolve('expose-loader'),
      css: require.resolve('css-loader'),
      pcss: require.resolve('postcss-loader'),
      style: require.resolve('style-loader'),
      svgr: require.resolve('@svgr/webpack'),
      miniCssExtractLoader: this.plugins?.MiniCssExtractPlugin?.loader,
      pug: require.resolve('pug-loader')
    };
  }
  get rules() {
    return {
      ...super.rules,
      pcss: /\.pcss$/i,
      css: /\.css$/i,
      img: /\.(png|jpe?g|gif)$/i,
      font: /\.(woff|woff2|eot|ttf|otf)$/i,
      svg: /\.svg$/i,
      pug: /\.pug$/i,
      docs: /\.(htm|pdf)$/i
    };
  }
  get loaders() {
    const {
      env: {
        isProduction,
        isServer,
        isHMR
      },
      rawLoaders: _loaders
    } = this;
    return {
      ...super.loaders,
      expose: exposes => ({
        loader: _loaders.expose,
        options: {
          exposes
        }
      }),
      pcss: {
        loader: _loaders.pcss
      },
      css: {
        loader: _loaders.css,
        options: {
          importLoaders: 1,
          modules: {
            localIdentName: isProduction ? '[smart-hash]' : '[smart-name]_[local]_[smart-hash]',
            getLocalIdent: provideSmartGetLocalIdent()
          }
        }
      },
      rawCss: {
        loader: _loaders.css
      },
      svg: {
        loader: _loaders.svgr,
        options: {
          svgo: true,
          svgoConfig: {
            plugins: [{
              name: 'preset-default',
              params: {
                overrides: {
                  removeViewBox: false,
                  // Запрещаем удалять <defs>
                  removeUselessDefs: false,
                  // Запрещаем удалять ID
                  cleanupIds: {
                    minify: true,
                    remove: false
                  },
                  // Отключаем схлопывание групп, чтобы сохранить transform
                  collapseGroups: false
                }
              }
            },
            // Убераем возможные пересечения ID при минификации
            'prefixIds']
          }
        },
        type: 'javascript/auto',
        issuer: /\.[jt]sx?$/
      },
      url: {
        loader: _loaders.url,
        options: {
          limit: 8192,
          name: 'assets/[hash:base64:10].[ext]'
        },
        type: 'javascript/auto'
      },
      cssExtract: !isHMR ? {
        loader: _loaders.miniCssExtractLoader,
        options: {
          emit: !isServer
        }
      } : undefined,
      style: isHMR ? {
        loader: _loaders.style
      } : undefined,
      pug: {
        loader: _loaders.pug
      },
      resourceUrl: {
        resourceQuery: /url/,
        type: 'asset/resource'
      }
    };
  }
  get config() {
    const {
      env: {
        isProduction,
        isHMR
      },
      options: {
        filePattern
      },
      usePlugin,
      useRule,
      oneOfLoaders,
      plugins,
      loaders,
      rules
    } = this;
    const config = super.config;
    return {
      ...config,
      module: {
        rules: [...config.module.rules, useRule(require.resolve('react'), loaders.expose('React')), useRule(require.resolve('react-dom'), loaders.expose('ReactDOM')), useRule(rules.pcss, [loaders.style, loaders.cssExtract, loaders.css, loaders.pcss]), useRule(rules.css, [loaders.style, loaders.cssExtract, loaders.rawCss]), useRule([rules.font, rules.img, rules.docs], loaders.asset), useRule(rules.svg, oneOfLoaders(loaders.resourceUrl, loaders.svg, loaders.asset)), useRule(rules.pug, loaders.pug)].filter(Boolean)
      },
      plugins: [...config.plugins, usePlugin(plugins.ReactRefreshWebpackPlugin, {
        overlay: false,
        exclude: this.options.monorepoExcludes
      }, isHMR), usePlugin(plugins.FriendlyErrorOverlayPlugin, {
        errorFilters: [errorFilters.silentFilter, errorFilters.lazyCompilationFilter]
      }, isHMR), ...mapViewFiles(({
        name,
        filePath
      }) => usePlugin(plugins.HtmlWebpackPlugin, {
        template: filePath,
        ...this.getHtmlOptions(name)
      })), usePlugin(plugins.MiniCssExtractPlugin, {
        filename: () => `${filePattern}.css`,
        chunkFilename: () => `${filePattern}.css`
      }, isProduction), usePlugin(plugins.ForkTsCheckerWebpackPlugin, {
        typescript: {
          build: true,
          mode: 'readonly',
          diagnosticOptions: {
            semantic: true,
            syntactic: true
          }
        }
      }, !isProduction)].filter(Boolean),
      optimization: {
        ...config.optimization,
        minimizer: [...config.optimization.minimizer, usePlugin(plugins.CssMinimizerPlugin, {
          parallel: true,
          warningsFilter: () => false,
          minimizerOptions: {
            preset: ['default', {
              discardComments: {
                removeAll: true
              }
            }]
          }
        })].filter(Boolean)
      },
      devServer: {
        ...config.devServer,
        client: {
          overlay: false,
          reconnect: 3,
          progress: false
        }
      }
    };
  }
  getHtmlOptions = name => {
    /**
     * При передаче опции legacyTemplate: true, beef-build генерирует index.htm с подключенными стилями и js,
     * В ином случае и по умолчанию, index.htm содержит виджетные зоны {{{headSection|bodySection}}}
     * Используемые NodeSSR-сервисом
     */
    const {
      legacyTemplate = false
    } = this.options;
    const defaultHtmlOptions = {
      templateParameters: {
        title: 'Локальная страница',
        Component: 'Components.App',
        isProduction: true,
        model: JSON.stringify({}),
        ...(legacyTemplate ? {
          headSection: '',
          bodySection: '',
          renderScript: ''
        } : {
          headSection: '{{{headSection}}}',
          bodySection: '{{{bodySection}}}',
          renderScript: ''
        })
      },
      inject: false
    };
    const {
      htmlOptions = defaultHtmlOptions
    } = this.options;
    return typeof htmlOptions === 'function' ? htmlOptions(name) : htmlOptions;
  };

  /**
   * На текущий момент - бесполезный враппер, сохранен для поддержания обратной совместимости
   *   и до тех пор, пока не будет влита ветка prototype
   */
  injectHMREntry = entry => Array.isArray(entry) ? entry : [entry];
}
module.exports = ReactWebpackBuilder;