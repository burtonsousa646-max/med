import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "invert", "color", "activated"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnAccordion = cnBem('skeleton-accordion', styles);
var buttonSize = {
  width: {
    desktop: 36,
    mobile: 24
  },
  height: {
    desktop: 36,
    mobile: 24
  }
};
var titleSize = {
  width: {
    desktop: 'calc(100% - 36px - 32px)',
    mobile: 'calc(100% - 24px - 32px)'
  },
  height: {
    desktop: 36,
    mobile: 24
  }
};
var contentSize = {
  width: {
    desktop: 400,
    mobile: 200
  },
  height: {
    desktop: 20,
    mobile: 12
  }
};
export var Accordion = function Accordion(_ref) {
  var className = _ref.className,
    invert = _ref.invert,
    color = _ref.color,
    _ref$activated = _ref.activated,
    activated = _ref$activated === void 0 ? true : _ref$activated,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnAccordion(null, [className])
  }, otherProps, {
    "data-t-id": "components-Accordion"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnAccordion('title')
  }, /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    color: color,
    invert: invert
  }, titleSize)), /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    color: color,
    invert: invert
  }, buttonSize))), activated && /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    color: color,
    invert: invert
  }, contentSize)));
};