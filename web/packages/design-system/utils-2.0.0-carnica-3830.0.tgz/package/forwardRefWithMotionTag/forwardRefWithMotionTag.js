import React from 'react';
export function forwardRefWithMotionTag(render) {
  return /*#__PURE__*/React.forwardRef(render);
}
export function forwardRefWithMotion(render) {
  return /*#__PURE__*/React.forwardRef(render);
}