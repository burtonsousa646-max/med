export declare const passAsIs: <T = any>(obj: T) => T;
export declare const passUndefined: () => undefined;
export declare const noop: () => void;
export declare const isNullOrUndefined: (value: any) => value is null | undefined;
export declare const valueOr: <T>(value: T, defaultValue: T, { undefined: replaceUndefined, null: replaceNull }?: {
    undefined?: boolean | undefined;
    null?: boolean | undefined;
}) => T;
export declare const valueOrFn: <T>(value: T | undefined, defaultValueGetter: () => T, { undefined: replaceUndefined, null: replaceNull }?: {
    undefined?: boolean | undefined;
    null?: boolean | undefined;
}) => T;
export declare const valueToString: (value: any) => string;
export declare const emptyObj: {};
export declare const emptyArr: never[];
//# sourceMappingURL=atomic.d.ts.map