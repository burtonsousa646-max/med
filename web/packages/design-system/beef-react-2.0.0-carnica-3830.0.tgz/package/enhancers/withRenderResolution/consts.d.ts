export declare const RESOLUTION_SIZES: number[];
export declare const LAST_KNOWN_RESOLUTION_COOKIE_NAME = "lastKnownResolution";
export declare const COOKIE_MAX_AGE = 31536000;
//# sourceMappingURL=consts.d.ts.map