export declare const cnTypography: import("@carnica/utils").ClassNameFormatter;
export declare const mixins: string[];
//# sourceMappingURL=mock.data.d.ts.map