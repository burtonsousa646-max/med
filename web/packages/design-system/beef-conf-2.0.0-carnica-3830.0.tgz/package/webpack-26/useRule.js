import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { combineRuleParams } from "../webpack/helpers";
import { PRIVATE_BUILDER_API } from "./builder.internals";
import { ensureArray } from "./helpers";
var _useRule = function _useRule(rule, use) {
  for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    args[_key - 2] = arguments[_key];
  }
  var _ref = typeof args[0] === 'boolean' ? [undefined, args[0]] : args,
    _ref2 = _slicedToArray(_ref, 2),
    _ref2$ = _ref2[0],
    extra = _ref2$ === void 0 ? {} : _ref2$,
    _ref2$2 = _ref2[1],
    flag = _ref2$2 === void 0 ? true : _ref2$2;
  var uses = ensureArray(use).filter(Boolean);
  if (!flag) return undefined;
  return _objectSpread(_objectSpread({
    test: ensureArray(rule).filter(Boolean)
  }, uses.map(function (_ref3) {
    var loader = _ref3.loader;
    return loader;
  }).filter(Boolean).length ? {
    use: uses.map(function (_ref4) {
      var loader = _ref4.loader,
        options = _ref4.options;
      return {
        loader: loader,
        options: options
      };
    })
  } : {}), combineRuleParams(uses, extra));
};

/**
 * Всегда добавляем символ замены, даже если flag = false
 * В этом случае старое правило будет удалено
 */
var useRule_replace = function useRule_replace(rule, use) {
  PRIVATE_BUILDER_API.assertBuilding('useRule.replace');
  for (var _len2 = arguments.length, args = new Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
    args[_key2 - 2] = arguments[_key2];
  }
  var newRule = _useRule.apply(void 0, [rule, use].concat(_toConsumableArray(args)));
  PRIVATE_BUILDER_API.replaceRule(rule, newRule);
  return newRule;
};
var useRule_exclude = function useRule_exclude(rule) {
  var flag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  PRIVATE_BUILDER_API.assertBuilding('useRule.exclude');
  if (!flag) return undefined;
  return PRIVATE_BUILDER_API.excludeRule(rule);
};
export var useRule = Object.assign(_useRule, {
  replace: useRule_replace,
  exclude: useRule_exclude
});