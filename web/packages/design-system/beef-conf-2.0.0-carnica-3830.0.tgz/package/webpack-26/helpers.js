import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 * Методы скопированы из @beef/utils, т.к. импортировать из @beef/utils пакету нельзя
 *   Возможное исправление - вынесение отдельного пакета на уровень выше конфига - мб @beef/babel
 */
export function map(obj, fn) {
  return Object.keys(obj).reduce(function (result, key) {
    result[key] = fn(obj[key], key);
    return result;
  }, {});
}
export function reduce(obj, fn, initialState) {
  return Object.keys(obj).reduce(function (result, key) {
    return fn(result, obj[key], key);
  }, initialState);
}
export function isPlainObject(obj) {
  return Object.prototype.toString.call(obj) === '[object Object]';
}

/**
 * Рекурсивно сливает две структуры данных
 *
 * Для массивов - вызывает mergeFn, при возврате undefined, берет b
 * Для объектов - вызывает mergeFn, при возврате undefined, рекурсивно сливает каждую пару key/value
 * Для всех остальных случаев - возвращает b
 *
 * NOTE: deepmerge & deepmerge-ts не подошли, т.к. не умеют работать с конкретными ключами
 */
export function deepmerge(a, b, mergeFn) {
  var _mergeFn;
  var path = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : [];
  if (Array.isArray(a) && Array.isArray(b)) return (_mergeFn = mergeFn === null || mergeFn === void 0 ? void 0 : mergeFn(a, b, path)) !== null && _mergeFn !== void 0 ? _mergeFn : b;
  if (isPlainObject(a) && isPlainObject(b)) {
    var _mergeFn2;
    return (_mergeFn2 = mergeFn === null || mergeFn === void 0 ? void 0 : mergeFn(a, b, path)) !== null && _mergeFn2 !== void 0 ? _mergeFn2 : reduce(b, function (accum, _v, key) {
      return _objectSpread(_objectSpread({}, accum), {}, _defineProperty({}, key, deepmerge(a[key], b[key], mergeFn, [].concat(_toConsumableArray(path), [key]))));
    }, a);
  }
  return b;
}
export var ensureArray = function ensureArray(value) {
  return Array.isArray(value) ? value : [value];
};