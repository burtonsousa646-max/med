import type { ComponentWithMotionTag, MotionTags } from '@carnica/utils/types';
import type { IconProps } from '../Icon';
import type { IconComponent, IconPropColor } from '../../types/IconComponent';
export type AnimatedIconProps = {
    activeIndex?: number;
    animationType?: 'cubic' | 'slide';
    colors?: IconPropColor[];
    icons: IconComponent[];
    rotations?: number[];
    transition?: number;
} & IconProps;
export type AnimatedIconComponent = ComponentWithMotionTag<AnimatedIconProps, MotionTags, 'span'>;
//# sourceMappingURL=types.d.ts.map