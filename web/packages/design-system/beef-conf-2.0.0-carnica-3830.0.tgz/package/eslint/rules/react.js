module.exports = {
  rules: {
    // can't really disable this now, too many usages
    'react/destructuring-assignment': 0,
    // force arrow components
    'react/function-component-definition': [2, {
      namedComponents: 'arrow-function',
      unnamedComponents: 'arrow-function'
    }],
    // use primarily links to our own sources; "noreferrer" is not needed.
    'react/jsx-no-target-blank': 0,
    // having them on separate lines is a bigger evil
    // 'react/jsx-max-props-per-line': [
    //   2,
    //   {
    //     maximum: { multi: 1, single: 3 },
    //   },
    // ],

    // FIXME: Probably at some point we should re-enable this rule,
    //  but for now it's just a show stopper
    'react/jsx-props-no-spreading': 0,
    // Everyone uses +index anyway
    'react/no-array-index-key': 1,
    'react/no-multi-comp': 0,
    // Removing propTypes is ...evil
    'react/prop-types': [1, {
      // ignore: ['children']
    }],
    'react/forbid-prop-types': 1,
    // default props are overrated
    'react/require-default-props': 0,
    'react/sort-comp': [2, {
      order: ['state', 'instance-properties', 'properties', 'static-methods', 'lifecycle', 'everything-else', 'render']
    }],
    // both legacy and useless
    'react/state-in-constructor': 0,
    // With great sadness, we had to change this rule to a warning.
    // You can't even call useEffect without dependencies with this rule on
    // While suggestions on how to fix this are plain dangerous
    'react-hooks/exhaustive-deps': 1
  }
};