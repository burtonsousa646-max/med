import { UseComponentSizePropSize } from './types';
export declare const getElementSize: (el: HTMLElement | SVGGraphicsElement | null) => UseComponentSizePropSize;
//# sourceMappingURL=helpers.d.ts.map