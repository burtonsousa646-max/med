import { BaseObserver } from './baseObserverMock';
export declare class MockResizeObserver extends BaseObserver<() => void> {
    observe(): void;
    unobserve(): void;
    disconnect(): void;
}
//# sourceMappingURL=mockResizeObserver.d.ts.map