type Params = {
    cutoutModuleArea?: number;
    isDarkArea?: (row: number, col: number) => boolean;
    moduleCount?: number;
    rounding: number;
    viewPortSize: number;
};
export declare const useQrPath: ({ viewPortSize, rounding, isDarkArea, moduleCount, cutoutModuleArea, }: Params) => string | null;
export {};
//# sourceMappingURL=useQrPath.d.ts.map