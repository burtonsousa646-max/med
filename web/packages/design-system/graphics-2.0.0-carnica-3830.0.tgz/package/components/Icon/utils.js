import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["multiColor", "size", "style", "ratio", "customColor", "color", "className", "tagName"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem } from '@carnica/utils';
import { iconPropColor } from "../../types/IconComponent";
import { getSize } from "../../utils/sizeMap";
import styles from "./styles.module.css";
var cnIcon = cnBem('icon', styles);
export var getColor = function getColor(color) {
  if (iconPropColor.includes(color)) {
    return "var(--icon-color-".concat(color, ")");
  }
  if (color.includes('--') && !color.includes('var')) {
    return "var(".concat(color, ")");
  }
  return color;
};
export var dataConverter = function dataConverter(_ref) {
  var _ref$multiColor = _ref.multiColor,
    multiColor = _ref$multiColor === void 0 ? true : _ref$multiColor,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    style = _ref.style,
    ratio = _ref.ratio,
    customColor = _ref.customColor,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'primary' : _ref$color,
    className = _ref.className,
    _ref$tagName = _ref.tagName,
    tagName = _ref$tagName === void 0 ? 'span' : _ref$tagName,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return _objectSpread(_objectSpread({}, otherProps), {}, {
    className: cnIcon(null, [className]),
    mode: multiColor ? 'mask' : 'background',
    tagName: tagName,
    style: _objectSpread(_objectSpread(_objectSpread({}, style), {}, _defineProperty({}, '--icon-size', getSize(size)), ratio === 1 ? {} : _defineProperty({}, '--icon-ratio', ratio)), multiColor ? _defineProperty({}, '--icon-color', getColor(customColor || color)) : {})
  });
};