export declare function useWillMount(fn: () => void): void;
//# sourceMappingURL=useWillMount.d.ts.map