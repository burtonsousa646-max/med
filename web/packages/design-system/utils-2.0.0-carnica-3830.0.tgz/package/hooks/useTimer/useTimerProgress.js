import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { useRef } from 'react';
import { getTimeIsOver } from "./helper";
import { useInterval } from "../useInterval";
import { useFlag } from "../useFlag";
import { TimerType } from "./types";
var isTimeBetween = function isTimeBetween(target, start, end) {
  return target <= end && target >= start || target >= end && target <= start;
};
export var useTimerProgress = function useTimerProgress(_ref) {
  var timerType = _ref.timerType,
    interval = _ref.interval,
    startTime = _ref.startTime,
    endTime = _ref.endTime,
    onTimeOver = _ref.onTimeOver,
    onInterval = _ref.onInterval;
  var _useFlag = useFlag(false),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isRunning = _useFlag2[0],
    setIsRunning = _useFlag2[1];
  var time = useRef(startTime);
  var shouldResetTimeRef = useRef(false);
  var onReached = function onReached() {
    var previousTime = time.current;
    var timeValue = timerType === TimerType.INCREMENTAL ? previousTime + interval : previousTime - interval;
    time.current = timeValue;
    onInterval === null || onInterval === void 0 || onInterval(timeValue);
    if (getTimeIsOver(timerType, timeValue, endTime)) {
      shouldResetTimeRef.current = true;
      intervalParams.cancelInterval();
      if (typeof onTimeOver === 'function') {
        onTimeOver();
      }
    }
  };
  var intervalParams = useInterval(interval, {
    onCreate: setIsRunning.on,
    onCancel: setIsRunning.off,
    onReached: onReached
  });
  var resetTime = function resetTime(newTime) {
    if (!newTime) {
      time.current = startTime;
      return;
    }
    var start = timerType === TimerType.DECREMENTAL ? endTime || 0 : startTime;
    var end = timerType === TimerType.DECREMENTAL ? startTime : endTime || 0;
    time.current = isTimeBetween(newTime, start, end) ? newTime : startTime;
  };
  return _objectSpread({
    time: time,
    shouldResetTimeRef: shouldResetTimeRef,
    isRunning: isRunning,
    resetTime: resetTime
  }, intervalParams);
};