var _require = require('@beef/conf/modules'),
  webpackCompiler = _require.webpack;
var config = require("../conf").resolveWebpackConfig();
var compiler = webpackCompiler(config);
compiler.run(function (err, result) {
  if (err) throw err;
  if (result !== null && result !== void 0 && result.errors) {
    throw result === null || result === void 0 ? void 0 : result.errors;
  }
});