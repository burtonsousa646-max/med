import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["layout", "children", "isRow", "className", "motion", "itemsCount", "loading"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { MotionComponent } from "../../../modules/MotionComponent";
import { Skeleton } from "../../Skeleton";
import styles from "../styles.module.css";
var cnChipsGroup = cnBem('chips-group', styles);
var ChipsGroupWrapperRender = function ChipsGroupWrapperRender(props, ref) {
  var layout = props.layout,
    children = props.children,
    isRow = props.isRow,
    className = props.className,
    motion = props.motion,
    _props$itemsCount = props.itemsCount,
    itemsCount = _props$itemsCount === void 0 ? 10 : _props$itemsCount,
    loading = props.loading,
    otherProps = _objectWithoutProperties(props, _excluded);
  var targetLayout = layout === 'collapse' && loading ? 'wrap' : layout;
  var isCollapse = targetLayout === 'collapse';
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({
    className: cnChipsGroup({
      layout: layout,
      isRow: isCollapse ? isRow : undefined
    }, [className]),
    motion: isCollapse || motion,
    role: "group",
    tagName: "div"
  }, isCollapse ? {
    layoutScroll: true
  } : {}, otherProps, {
    ref: ref,
    "data-t-id": "ChipsGroup-ChipsGroupWrapper"
  }), loading ? Array.from({
    length: itemsCount
  }).map(function (_, i) {
    return /*#__PURE__*/React.createElement(Skeleton.Chips, {
      key: cnChipsGroup('item', {
        i: i
      })
    });
  }) : children);
};
export var ChipsGroupWrapper = /*#__PURE__*/forwardRef(ChipsGroupWrapperRender);