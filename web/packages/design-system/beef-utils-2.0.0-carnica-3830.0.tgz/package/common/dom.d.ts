export declare const getNodeCenterOffset: (node: HTMLElement | null) => null | number;
export declare const getNodeLeftOffset: (node: HTMLElement | null) => null | number;
export declare const getAbsoluteClientPosition: (node?: Element) => { [key in "height" | "left" | "top" | "width"]: string; } | undefined;
export declare const smoothCenteredScroll: (node: Element | null, parentElement?: Element | Window | null) => void;
export declare const getDomSingletonById: (id: string, tagName?: string) => HTMLElement;
declare const defaultTriggerOptions: {
    eventInterface: string;
    bubbles: boolean;
    cancelable: boolean;
};
export declare const triggerCustomEvent: (domElement: HTMLElement, eventName: string, options?: Partial<typeof defaultTriggerOptions>) => void;
export declare const triggerFormSubmit: (form: HTMLFormElement | null) => void;
export declare const colorToRGBA: (webColor: string) => Uint8ClampedArray;
export declare const contrastBlackOrWhite: (webColor: string) => string;
export declare const contrastBgStyles: (backgroundColor: string) => {
    backgroundColor: string;
    color: string;
};
type ScrollLogicalPosition = 'center' | 'end' | 'nearest' | 'start';
export declare const scrollTo: (name: string, scrollLogicalPosition?: ScrollLogicalPosition) => void;
export declare const isInPage: (node: HTMLElement | null) => boolean;
export declare const scrollToTop: (top?: number) => void;
export {};
//# sourceMappingURL=dom.d.ts.map