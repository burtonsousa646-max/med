const {
  resolvePlugin
} = require('../utils');
module.exports = {
  plugins: ['@typescript-eslint'],
  parser: require.resolve('@typescript-eslint/parser'),
  extends: [
  // take all js rules as base
  './js-recommended',
  // apply community typescript rules
  'plugin:@typescript-eslint/recommended', 'plugin:@typescript-eslint/recommended-type-checked', 'airbnb-typescript',
  // apply custom rules
  '../rules/broken', '../rules/typescript',
  // disable rules that require project service to speed eslint
  // these rules are extracted to a separate config: ts-type-checked
  'plugin:@typescript-eslint/disable-type-checked'].map(resolvePlugin)
};