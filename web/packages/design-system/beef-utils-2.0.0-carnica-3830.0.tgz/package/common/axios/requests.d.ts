import type { AxiosPromise, AxiosRequestConfig } from 'axios';
interface ExtAxiosRequestConfig extends AxiosRequestConfig {
    originalResponse?: boolean;
    skipWaffleInterceptor?: boolean;
}
type TConfig<T extends boolean | undefined = false> = {
    originalResponse?: T;
} & Omit<ExtAxiosRequestConfig, 'originalResponse'>;
export declare function axiosBaseRequest<TResult>(config: TConfig<false | undefined>): Promise<TResult>;
export declare function axiosBaseRequest<TResult>(config: TConfig<true>): AxiosPromise<TResult>;
export declare function axiosBeelineRequest<TResult>(config: TConfig<false | undefined>): Promise<TResult>;
export declare function axiosBeelineRequest<TResult>(config: TConfig<true>): AxiosPromise<TResult>;
export {};
//# sourceMappingURL=requests.d.ts.map