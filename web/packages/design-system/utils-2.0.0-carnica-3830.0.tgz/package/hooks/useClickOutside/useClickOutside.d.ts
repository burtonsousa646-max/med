import { UseClickOutsideParams } from './types';
export declare function useClickOutside(params: UseClickOutsideParams): void;
//# sourceMappingURL=useClickOutside.d.ts.map