export * from './forwardRefWithMotionTag';
//# sourceMappingURL=index.d.ts.map