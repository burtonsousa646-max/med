export type PossibleError = string | undefined;
export type ValidatorFactory<T = string, P = undefined> = (message: string, params: P) => FieldValidator<T>;
export type FieldValidator<T = any> = (value: T, values: Record<string, any>) => PossibleError;
export type ValidatorsGetter = () => Record<string, [FieldValidator] | FieldValidator>;
export interface MinMax<T = number> {
    max?: T | void;
    min?: T | void;
}
export declare const composeFormValidator: (getValidators: ValidatorsGetter) => (values: Record<string, any>) => Record<string, string>;
export declare const composeRequiredValidator: ValidatorFactory<any>;
export declare const composePhoneValidator: ValidatorFactory;
export declare const composeEmailValidator: ValidatorFactory;
export declare const composeCheckedValidator: ValidatorFactory<boolean>;
export declare const composeNameValidator: ValidatorFactory;
export declare const composeSlugValidator: ValidatorFactory;
export declare const composeNumberValidator: ValidatorFactory<number, MinMax>;
export declare const composeLengthValidator: ValidatorFactory<string, MinMax>;
export declare const composeUrlValidator: ValidatorFactory;
export declare const composeDateValidator: ValidatorFactory<Date | number | string, MinMax<Date>>;
export declare const mergeErrorObject: (errors: Record<string, string>, ignoreFields?: string[]) => string;
//# sourceMappingURL=index.d.ts.map