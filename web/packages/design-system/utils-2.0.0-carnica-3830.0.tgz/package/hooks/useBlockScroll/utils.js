export var isBodyOverflowing = function isBodyOverflowing() {
  return document.body.scrollHeight > (window.innerHeight || document.documentElement.clientHeight) && window.innerWidth > document.body.offsetWidth;
};
export var getContainer = function getContainer(node) {
  if (!node) {
    return window.document.body;
  }
  return 'current' in node ? node.current : node;
};
export var getSelector = function getSelector(id, node) {
  if (!node || node.tagName === 'BODY') {
    return 'html body';
  }
  node.classList.add(id);
  return "".concat(node.tagName.toLowerCase(), ".").concat(id);
};