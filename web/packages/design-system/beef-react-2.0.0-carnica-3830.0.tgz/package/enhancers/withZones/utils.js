import React, { Children } from 'react';

/**
 * Утилита, которая возвращает объект с "вырезами"
 */
export function populateZones(children, allowedNames) {
  var zones = {};
  Children.forEach(children, function (child) {
    if (! /*#__PURE__*/React.isValidElement(child)) return;
    var holeName = child === null || child === void 0 ? void 0 : child.type;
    if (allowedNames.includes(holeName)) {
      zones[holeName] = child.props.children;
    }
  });
  return zones;
}