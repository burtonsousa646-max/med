import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["state", "emptyContent", "errorContent"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem } from '@carnica/utils';
import React, { useMemo } from 'react';
import { ErrorOrEmptyBlock } from "../../ErrorOrEmptyBlock";
import styles from "./styles.module.css";
import { emptyBlockMap } from "./utils";
var cnPickerEmptyMock = cnBem('picker-mock', styles);
export var PickerEmptyMock = function PickerEmptyMock(_ref) {
  var _ref$state = _ref.state,
    state = _ref$state === void 0 ? 'empty' : _ref$state,
    emptyContent = _ref.emptyContent,
    errorContent = _ref.errorContent,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var data = useMemo(function () {
    var contentByState = state === 'error' ? errorContent : emptyContent;
    return _objectSpread(_objectSpread({}, emptyBlockMap[state]), contentByState || {});
  }, [state]);
  return /*#__PURE__*/React.createElement("div", _extends({
    "aria-atomic": "true",
    "aria-live": "polite",
    className: cnPickerEmptyMock(null),
    role: "status"
  }, otherProps, {
    "data-t-id": "Picker-PickerEmptyMock"
  }), /*#__PURE__*/React.createElement(ErrorOrEmptyBlock, data));
};