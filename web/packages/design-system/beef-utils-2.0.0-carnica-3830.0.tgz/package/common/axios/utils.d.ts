export declare const insertFixedSequences: (baseString: string, secretKeys?: string[]) => string;
//# sourceMappingURL=utils.d.ts.map