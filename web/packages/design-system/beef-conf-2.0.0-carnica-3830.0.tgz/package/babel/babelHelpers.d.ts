export function getResolveAliases(cwd: any): {};
export function getLinkedModules(cwd?: string): {
    name: any;
    link: any;
    source: string;
}[];
export function usePlugin(plugin: any, options: any, isEnabled?: boolean): false | any[];
export function detectEnv(api: any): {
    modules: string;
    isNode: any;
    isProduction: any;
    isHMR: boolean;
    isPublish: boolean;
} | {
    modules: string | boolean;
    isNode: any;
    isProduction: boolean;
    isHMR: boolean;
    isPublish: boolean;
};
//# sourceMappingURL=babelHelpers.d.ts.map