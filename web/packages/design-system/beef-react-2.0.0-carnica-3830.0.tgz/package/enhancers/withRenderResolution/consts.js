export var RESOLUTION_SIZES = [320, 400, 512, 640, 800, 1024, 1280, 1600, 1920, Infinity];
export var LAST_KNOWN_RESOLUTION_COOKIE_NAME = 'lastKnownResolution';
export var COOKIE_MAX_AGE = 31536000;