import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["disabled", "title", "subTitle", "active", "avatarData", "priority", "className", "id", "reverse"];
import React, { forwardRef, useMemo } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { cnBem } from '@carnica/utils';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import { IconChevronRight } from '@carnica/graphics';
import { Cell } from "../../Cell";
import styles from "./styles.module.css";
import { renderAvatar, renderSubTitle, renderTitle } from "./utils";
var cnPickerItem = cnBem('picker-item', styles);
var opacityList = [1, 0.3, 0.15, 0.05];
var variants = {
  animate: function animate(priority) {
    return {
      x: 0,
      opacity: opacityList[Math.abs(priority)] || 0
    };
  },
  hidden: {
    x: -100,
    opacity: 0
  }
};
export var PickerItem = /*#__PURE__*/forwardRef(function (props, ref) {
  var disabled = props.disabled,
    title = props.title,
    subTitle = props.subTitle,
    active = props.active,
    avatarData = props.avatarData,
    _props$priority = props.priority,
    priority = _props$priority === void 0 ? 4 : _props$priority,
    className = props.className,
    id = props.id,
    reverse = props.reverse,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  var contentData = useMemo(function () {
    return {
      title: renderTitle({
        priority: priority,
        reverse: reverse,
        active: active,
        title: title,
        subTitle: subTitle
      }),
      subTitle: renderSubTitle({
        priority: priority,
        active: active,
        subTitle: subTitle
      })
    };
  }, [priority, reverse, active, title, subTitle]);
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    initial: false,
    mode: "wait",
    "data-t-id": "Picker-PickerItem"
  }, /*#__PURE__*/React.createElement(motion.li, {
    animate: "animate",
    className: cnPickerItem(),
    custom: priority,
    exit: "hidden",
    initial: "hidden",
    layout: true,
    transition: {
      opacity: {
        ease: 'linear',
        duration: 0.1
      }
    },
    variants: variants
  }, /*#__PURE__*/React.createElement(Cell, _extends({}, otherProps, contentData, {
    "aria-selected": active,
    background: isMobile ? 'none' : 'primary',
    className: cnPickerItem('cell', [className]),
    leftSide: renderAvatar(avatarData),
    offset: "500",
    radius: isMobile ? undefined : '600',
    ref: ref,
    reverse: reverse,
    rightSide: /*#__PURE__*/React.createElement(IconChevronRight, {
      color: "secondary",
      size: "m"
    }),
    role: "option",
    size: avatarData ? 's' : 'm',
    tagName: "button",
    type: "button"
  }))));
});