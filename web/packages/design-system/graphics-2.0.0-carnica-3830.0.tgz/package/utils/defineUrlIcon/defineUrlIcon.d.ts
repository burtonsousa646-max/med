import type { IconMainProps } from '../../components/Icon/types';
import type { IconComponent, LogoComponent } from '../../types/IconComponent';
export type DefineUrlIconParams<COLORED extends boolean = true> = {
    defaultSize?: number;
    multiColor?: COLORED;
} & Pick<IconMainProps, 'ratio' | 'url'>;
type Component<COLORED extends boolean> = COLORED extends true ? IconComponent : LogoComponent;
export declare const defineUrlIcon: <COLORED extends boolean = true>({ multiColor, defaultSize, ...params }: DefineUrlIconParams<COLORED>) => Component<COLORED>;
export {};
//# sourceMappingURL=defineUrlIcon.d.ts.map