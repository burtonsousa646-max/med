export type TResolutions = number[];
//# sourceMappingURL=types.d.ts.map