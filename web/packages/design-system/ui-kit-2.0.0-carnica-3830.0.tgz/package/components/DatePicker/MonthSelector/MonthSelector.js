import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "onChange", "locale", "value", "className"];
import React, { forwardRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { format, isSameMonth } from 'date-fns-new';
import { Text } from "../../Text";
import styles from "./styles.module.css";
import { useMonthSelectorKeyboardHandler } from "../hooks/useMonthSelectorKeyboardHandler";
var cnMonthSelector = cnBem('month-selector', styles);
export var MonthSelector = /*#__PURE__*/forwardRef(function (props, ref) {
  var items = props.items,
    onChange = props.onChange,
    locale = props.locale,
    value = props.value,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var activeIndex = items.findIndex(function (el) {
    return isSameMonth(value, el);
  });
  var _useMonthSelectorKeyb = useMonthSelectorKeyboardHandler({
      items: items,
      onChange: onChange,
      activeIndex: activeIndex
    }),
    refs = _useMonthSelectorKeyb.refs,
    listRef = _useMonthSelectorKeyb.listRef,
    onKeyDownByIndex = _useMonthSelectorKeyb.onKeyDownByIndex;
  return /*#__PURE__*/React.createElement("ul", _extends({
    className: cnMonthSelector(null, [className]),
    ref: combineRefs([ref, listRef]),
    role: "listbox"
  }, otherProps, {
    "data-t-id": "DatePicker-MonthSelector"
  }), items.map(function (date, i) {
    var stringMonth = format(date, 'LLLL', {
      locale: locale
    });
    var active = activeIndex === i;
    return /*#__PURE__*/React.createElement("li", {
      className: cnMonthSelector('option'),
      key: date.getMonth()
    }, /*#__PURE__*/React.createElement(Text, {
      "aria-label": stringMonth,
      "aria-selected": active,
      className: cnMonthSelector('item', {
        active: active
      }),
      onClick: function onClick(e) {
        return onChange === null || onChange === void 0 ? void 0 : onChange(date, e);
      },
      onKeyDown: onKeyDownByIndex(i),
      ref: refs[i],
      role: "option",
      tabIndex: active ? 0 : -1,
      tagName: "button",
      type: "button",
      variant: "body-medium"
    }, stringMonth));
  }));
});