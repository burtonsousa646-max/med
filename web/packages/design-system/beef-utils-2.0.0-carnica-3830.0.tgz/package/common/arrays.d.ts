export declare function removeFirstOccurrence<T>(arr: T[], value: T): T[];
export declare const spreadLast: <T extends (...args: any[]) => any>(wrappedFn: T, count?: number) => (...args: Parameters<T>) => ReturnType<T>;
export declare const sortWithUndefined: <T extends any[]>(arr: T, compareFn: (a: any, b: any) => number) => T;
type Iteratee = (index: number) => any;
export declare function times<T extends Iteratee>(n: number, iteratee: T): ReturnType<T>[];
export declare function distinctConcatBy<T extends any[]>(fieldName: string, source: T, added: T): T;
export declare const findLastIndex: <T>(haystack: T[], matchFn: (item: T) => boolean) => number;
export {};
//# sourceMappingURL=arrays.d.ts.map