export type UseFlag = (initialState?: boolean) => [
    boolean,
    {
        off: VoidFunction;
        on: VoidFunction;
        set: (flag: boolean) => void;
        toggle: VoidFunction;
    }
];
//# sourceMappingURL=types.d.ts.map