import React from 'react';
export declare function safeLazy<TProps>(dynamicImport: Parameters<typeof React.lazy>[0], fallback?: React.JSX.Element, serverSideFire?: boolean): (props: TProps) => React.JSX.Element;
//# sourceMappingURL=safeLazy.d.ts.map