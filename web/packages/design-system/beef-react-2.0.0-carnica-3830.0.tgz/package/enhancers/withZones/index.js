import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children"];
import React from 'react';
import { populateZones } from "./utils";

/**
 * HOC, который создает контейнер в который можно пробрасывать
 * кастомный лэйаут компонент с необходимым количеством "вырезов"
 *
 * @param WrappedComponent - Компонент с "вырезами" (должен быть "zones" пропс)
 * @param allowedTypes - Декларированные "вырезы"
 * @returns Контейнер с "вырезами"
 */
export function withZones(allowedNames) {
  return function (WrappedComponent) {
    // Компонент, который заполняет "вырезы"
    var Container = function Container(_ref) {
      var children = _ref.children,
        rest = _objectWithoutProperties(_ref, _excluded);
      return /*#__PURE__*/React.createElement(WrappedComponent, _extends({
        zones: populateZones(children, allowedNames)
      }, rest, {
        "data-t-id": "enhancers-withZones"
      }));
    };

    // Добавляет "вырезы" и позволяет доставать тип выреза
    allowedNames.forEach(function (zoneName) {
      var ZoneName = zoneName;
      Container[zoneName] = ZoneName;
    });
    return Container;
  };
}