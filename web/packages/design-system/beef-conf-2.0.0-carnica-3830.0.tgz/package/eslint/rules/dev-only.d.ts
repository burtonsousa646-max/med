export let rules: {
    'import/no-extraneous-dependencies': number;
    'no-console': number;
    'react/prop-types': number;
};
//# sourceMappingURL=dev-only.d.ts.map