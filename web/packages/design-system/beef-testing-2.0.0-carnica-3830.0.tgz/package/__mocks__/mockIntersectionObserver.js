import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime/helpers/getPrototypeOf";
import _inherits from "@babel/runtime/helpers/inherits";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import { BaseObserver } from "./baseObserverMock";
export var MockIntersectionObserver = /*#__PURE__*/function (_BaseObserver) {
  function MockIntersectionObserver() {
    _classCallCheck(this, MockIntersectionObserver);
    return _callSuper(this, MockIntersectionObserver, arguments);
  }
  _inherits(MockIntersectionObserver, _BaseObserver);
  return _createClass(MockIntersectionObserver, [{
    key: "observe",
    value: function observe(target) {
      var entry = {
        isIntersecting: true,
        target: target
      };
      this.callback([entry], this);
    }
  }, {
    key: "unobserve",
    value: function unobserve() {}
  }, {
    key: "disconnect",
    value: function disconnect() {}
  }]);
}(BaseObserver);

// Пример использования
// globalThis.IntersectionObserver = MockIntersectionObserver