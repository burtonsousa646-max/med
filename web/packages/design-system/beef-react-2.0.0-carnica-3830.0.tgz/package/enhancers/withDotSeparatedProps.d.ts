import React from 'react';
import { ValidationMap } from 'prop-types';
export declare function withDotSeparatedProps<S extends object, T extends object>(WrappedComponent: React.ComponentType<T>, propTypes: ValidationMap<S>): {
    (props: S): React.JSX.Element;
    propTypes: ValidationMap<S>;
};
//# sourceMappingURL=withDotSeparatedProps.d.ts.map