const {
  execSync
} = require('child_process');

// TODO: cover all functions with tests
const getCommitHash = () => execSync('git rev-parse --short HEAD').toString().substring(0, 7);
const getRemoteTagVersions = tagName => {
  const tagRegExp = new RegExp(`-${tagName}\\.\\d+`, 'g');
  return execSync('git ls-remote --tags --sort=v:refname', {
    maxBuffer: 15 * 1024 * 1024
  }).toString().trim().split('\n').filter(tag => tagRegExp.test(tag));
};
const getGitBranch = () => {
  const fullName = execSync('git rev-parse --abbrev-ref HEAD').toString().trim();
  const [prefix, task, summary] = fullName.replace(/^ci\//, '').split('/');
  if (!task || !task.match(/^[A-Z-][A-Z_\d]{1,12}-\d{1,5}$/)) {
    return {
      fullName
    };
  }
  return {
    fullName,
    prefix,
    summary,
    task
  };
};
const getTagVersion = () => {
  try {
    const currentHash = getCommitHash();
    const lastCommitWithTags = execSync("git log --tags --no-walk --pretty='%C(7)%h%d'").toString().trim().split('\n')[0];
    if (!lastCommitWithTags) {
      return currentHash;
    }
    const [tagCommitHash, tagsStr] = lastCommitWithTags.split(/ (.+)/);
    const lastMainTag = tagsStr.match(/tag: (.*)[,)]/g)[0].replace(/[^0-9.,]/g, '').split(',')[0];
    return currentHash === tagCommitHash ? `v${lastMainTag}` : `v${lastMainTag}_${currentHash}`;
  } catch (e) {
    return 'no-version';
  }
};
const gitHasUncommittedChanges = () => !!execSync('git status --porcelain').toString().trim();
const gitHasUnresolvedConflicts = () => !!execSync('git ls-files -u').toString().trim();
const gitRemoteBranchExists = (branchName, options, shOpts) => !!execSync(`git ls-remote origin ${options ? options.join(' ') : ''} ${branchName}`, shOpts).toString().trim();
const gitSetRemote = (remote, options, shOpts) => execSync(`git remote add origin ${options ? options.join(' ') : ''} ${remote}`, shOpts);
const gitTag = (tagName, options, shOpts) => execSync(`git tag ${options ? options.join(' ') : ''} ${tagName}`, shOpts).toString().trim();
const gitInit = (options, shOpts) => execSync(`git init ${options ? options.join(' ') : ''}`, shOpts);
const gitClone = (repository, options, shOpts) => execSync(`git clone ${options ? options.join(' ') : ''} ${repository}`, shOpts);
const gitFetch = (branchName, options, shOpts) => execSync(`git fetch ${options ? options.join(' ') : ''} ${branchName}`, shOpts);
const gitCheckout = (branchName, options, shOpts) => execSync(`git checkout ${options ? options.join(' ') : ''} ${branchName}`, shOpts);
const gitCommit = (options, shOpts) => execSync(`git commit ${options ? options.join(' ') : ''}`, shOpts);
const gitPush = (branchName, options, shOpts) => execSync(`git push ${options ? options.join(' ') : ''} ${branchName}`, shOpts);
const gitPull = (branchName, options, shOpts) => execSync(`git pull ${options ? options.join(' ') : ''} ${branchName}`, shOpts);
const gitMerge = (branchName, options, shOpts) => {
  try {
    execSync(`git merge ${branchName}  ${options ? options.join(' ') : ''}`, shOpts);
    return null;
  } catch (err) {
    console.info('Git merge failed, possibly due to conflicts.');
    const conflicts = execSync('git diff --name-only --diff-filter=U', {
      encoding: 'utf-8'
    }).split('\n').filter(Boolean);
    if (conflicts.length) {
      console.info('Conflicting files:', conflicts);
    }
    return conflicts;
  }
};
const gitDiff = (options, shOpts) => execSync(`git diff ${options ? options.join(' ') : ''}`, shOpts);
const gitAdd = (options, shOpts) => execSync(`git add ${options ? options.join(' ') : ''}`, shOpts);
module.exports = {
  getCommitHash,
  getGitBranch,
  getRemoteTagVersions,
  gitSetRemote,
  getTagVersion,
  gitHasUncommittedChanges,
  gitHasUnresolvedConflicts,
  gitTag,
  gitInit,
  gitPull,
  gitClone,
  gitRemoteBranchExists,
  gitCheckout,
  gitCommit,
  gitPush,
  gitFetch,
  gitMerge,
  gitDiff,
  gitAdd
};