type FunctionsType = {
    [key: number | string]: (e: any) => any;
};
export declare const setWindowFunctions: (functions: FunctionsType) => void;
export {};
//# sourceMappingURL=window.d.ts.map