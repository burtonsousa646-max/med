import React from 'react';
import type { MotionTagProps, MotionTags } from '@carnica/utils/types';
import type { IconPropColor, IconPropSize } from '../../types/IconComponent';
export type IconMainProps<COLORED extends boolean = true> = {
    color?: IconPropColor;
    iconClassName?: string;
    multiColor?: COLORED;
    ratio?: number;
    size?: IconPropSize | number;
    url: string;
} & (COLORED extends true ? {
    color?: IconPropColor;
    customColor?: string;
} : {
    color?: never;
    customColor?: never;
});
export type IconComponent = <TAG extends MotionTags | React.ElementType = 'span', COLORED extends boolean = true, MOTION extends boolean = false>(props: MotionTagProps<IconMainProps<COLORED>, MotionTags, TAG, MOTION>) => React.ReactElement | null;
type DefaultPickedProps = 'iconClassName' | 'size';
export type IconProps = Pick<IconMainProps, 'color' | 'customColor' | DefaultPickedProps>;
export type LogoProps = Pick<IconMainProps, DefaultPickedProps>;
export {};
//# sourceMappingURL=types.d.ts.map