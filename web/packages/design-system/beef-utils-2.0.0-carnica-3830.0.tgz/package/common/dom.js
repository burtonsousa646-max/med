import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _typeof from "@babel/runtime/helpers/typeof";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { filterDefined } from "./objects";
export var getNodeCenterOffset = function getNodeCenterOffset(node) {
  if (_typeof(node) !== 'object' || node === null || !('getBoundingClientRect' in node)) return null;
  var _node$getBoundingClie = node.getBoundingClientRect(),
    width = _node$getBoundingClie.width,
    left = _node$getBoundingClie.left;
  return left + width / 2;
};
export var getNodeLeftOffset = function getNodeLeftOffset(node) {
  if (_typeof(node) !== 'object' || node === null || !('getBoundingClientRect' in node)) return null;
  var _node$getBoundingClie2 = node.getBoundingClientRect(),
    left = _node$getBoundingClie2.left;
  return left;
};
export var getAbsoluteClientPosition = function getAbsoluteClientPosition(node) {
  if (!node) return undefined;
  var _node$getBoundingClie3 = node.getBoundingClientRect(),
    left = _node$getBoundingClie3.left,
    top = _node$getBoundingClie3.top,
    height = _node$getBoundingClie3.height,
    width = _node$getBoundingClie3.width;
  var _window = window,
    scrollY = _window.scrollY,
    scrollX = _window.scrollX;
  return {
    left: "".concat(left + scrollX, "px"),
    top: "".concat(top + scrollY, "px"),
    width: "".concat(width, "px"),
    height: "".concat(height, "px")
  };
};
var calculateScrollOffset = function calculateScrollOffset(viewportHeight, top, elementHeight) {
  return viewportHeight > elementHeight + 20 ? top - (viewportHeight - elementHeight) * 0.4 : top - 20;
};
var getElementScrollTop = function getElementScrollTop(obj) {
  return 'scrollY' in obj ? window.scrollY : obj.scrollTop;
};

/**
 * Плавный скролл к dom-элементу с центрированным
 * - Элементы больше экрана скроллся с запасом в 20px
 * - Небольшие элементы центрируются по соотношению 2:3 (верх:низ)
 */
export var smoothCenteredScroll = function smoothCenteredScroll(node) {
  var parentElement = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : window;
  if (!node || !document.body.contains(node) || !parentElement) return;
  var _node$getBoundingClie4 = node.getBoundingClientRect(),
    top = _node$getBoundingClie4.top,
    height = _node$getBoundingClie4.height;
  if (!top && !height) return;
  var scrollTargetTop = getElementScrollTop(parentElement);
  parentElement.scrollTo({
    top: calculateScrollOffset(window.innerHeight, scrollTargetTop + top, height),
    behavior: 'smooth'
  });
};
export var getDomSingletonById = function getDomSingletonById(id) {
  var tagName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'div';
  var el = document.getElementById(id) || document.body.appendChild(document.createElement(tagName));
  el.setAttribute('id', id);
  return el;
};
var defaultTriggerOptions = {
  eventInterface: 'Event',
  bubbles: true,
  cancelable: true
};
export var triggerCustomEvent = function triggerCustomEvent(domElement, eventName) {
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var _defaultTriggerOption = _objectSpread(_objectSpread({}, defaultTriggerOptions), filterDefined(options)),
    eventInterface = _defaultTriggerOption.eventInterface,
    bubbles = _defaultTriggerOption.bubbles,
    cancelable = _defaultTriggerOption.cancelable;
  var event = document.createEvent(eventInterface);
  event.initEvent(eventName, bubbles, cancelable);
  event.eventName = eventName;
  domElement.dispatchEvent(event);
};
export var triggerFormSubmit = function triggerFormSubmit(form) {
  if (!form) {
    return;
  }
  var handleFormSubmit = function handleFormSubmit(event) {
    if (!event.defaultPrevented) {
      form.submit();
    }
  };
  form.addEventListener('submit', handleFormSubmit);
  triggerCustomEvent(form, 'submit');
  form.removeEventListener('submit', handleFormSubmit);
};

/**
 * Takes color in any web format: named, rgb, rgba, hex, short hex
 * Returns array of [r, g, b, a]
 */
export var colorToRGBA = function colorToRGBA(webColor) {
  var cvs = document.createElement('canvas');
  cvs.height = 1;
  cvs.width = 1;
  var ctx = cvs.getContext('2d');
  ctx.fillStyle = webColor;
  ctx.fillRect(0, 0, 1, 1);
  return ctx.getImageData(0, 0, 1, 1).data;
};

/**
 * Takes color in any web format: named, rgb, rgba, hex, short hex
 * Returns black or white, that makes better contrast to given color
 */
export var contrastBlackOrWhite = function contrastBlackOrWhite(webColor) {
  if (!webColor) {
    return 'black';
  }
  var _colorToRGBA = colorToRGBA(webColor),
    _colorToRGBA2 = _slicedToArray(_colorToRGBA, 3),
    red = _colorToRGBA2[0],
    green = _colorToRGBA2[1],
    blue = _colorToRGBA2[2];
  return red * 0.299 + green * 0.587 + blue * 0.114 > 186 ? 'black' : 'white';
};
export var contrastBgStyles = function contrastBgStyles(backgroundColor) {
  return {
    backgroundColor: backgroundColor,
    color: contrastBlackOrWhite(backgroundColor)
  };
};

/**
 * Takes name attribute of a node as an argument and scrolls to the first found node with given name
 */

export var scrollTo = function scrollTo(name) {
  var _document, _element$scrollIntoVi;
  var scrollLogicalPosition = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'start';
  var element = (_document = document) === null || _document === void 0 || (_document = _document.getElementsByName(name)) === null || _document === void 0 ? void 0 : _document.item(0);
  element === null || element === void 0 || (_element$scrollIntoVi = element.scrollIntoView) === null || _element$scrollIntoVi === void 0 || _element$scrollIntoVi.call(element, {
    block: scrollLogicalPosition,
    behavior: 'smooth'
  });
};

/**
 * Проверка на наличие элемента на странице
 * @returns {boolean}
 */
export var isInPage = function isInPage(node) {
  return node === document.body ? false : document.body.contains(node);
};

/**
 * Прокрутка документа вверх до указанных координат
 */
export var scrollToTop = function scrollToTop() {
  var top = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  window.scrollTo({
    top: top,
    behavior: 'smooth'
  });
};