import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { PRIVATE_BUILDER_API } from "./builder.internals";
import { isPlainObject } from "./helpers";

// FIXME: Довольно грязный хак, возможно лучше будет переписать на рекурсивное пересечение

var isMultiConfigArgs = function isMultiConfigArgs(args) {
  return Array.isArray(args[1]);
};
var _useConfig = function _useConfig() {
  var _argsArr$find;
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  var argsArr = isMultiConfigArgs(args) ? args : [args];
  return (_argsArr$find = argsArr.find(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 2),
      _ = _ref2[0],
      _ref2$ = _ref2[1],
      enabled = _ref2$ === void 0 ? true : _ref2$;
    return enabled;
  })) === null || _argsArr$find === void 0 ? void 0 : _argsArr$find[0];
};
var useConfig_replace = function useConfig_replace() {
  var result = _useConfig.apply(void 0, arguments);
  if (!isPlainObject(result)) return result;
  return PRIVATE_BUILDER_API.replaceConfig(result);
};
export var useConfig = Object.assign(_useConfig, {
  replace: useConfig_replace
});