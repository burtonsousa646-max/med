module.exports = {
  rules: {
    'global-require': 0,
    // importing from dist/src folder is deprecated, should create re-export files instead
    // Should be disabled, why adding common extensions during import `.js` or `.ts`?
    'import/extensions': [2, {
      json: 'always',
      jsx: 'never',
      ts: 'never',
      tsx: 'never'
    }],
    //  although WebpackCircularDependencyPlugin does the job during build
    // 'import/no-cycle': 0,

    // FIXME: Rule takes tremendous amount of time
    // should actually ban default exports, but not today
    'import/prefer-default-export': 0,
    // Group imports better
    // https://github.com/benmosher/eslint-plugin-import/blob/master/docs/rules/order.md
    'import/order': ['error', {
      groups: [['builtin', 'external'], ['internal'], ['parent', 'sibling', 'index']],
      'newlines-between': 'always'
    }],
    // reason: dist and src imports will not work in linked mode
    'no-restricted-imports': [2, {
      patterns: [{
        group: ['@beef/*/dist/*'],
        message: 'Импорт из папки dist/ запрещен, используйте публичный интерфейса, предоставляемого пакетом'
      }, {
        group: ['@beef/*/src/*'],
        message: 'Импорт из папки src/ запрещен, используйте публичный интерфейса, предоставляемого пакетом'
      }, {
        group: ['@beef/*/source/*'],
        message: 'Импорт из папки source/ запрещен, используйте публичный интерфейса, предоставляемого пакетом'
      }]
    }]
  }
};