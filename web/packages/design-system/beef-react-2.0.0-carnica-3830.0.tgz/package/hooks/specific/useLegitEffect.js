import React from 'react';

/**
 * Works similarly to useEffect, except for one case:
 * - on update cycle cleanup callback fires before applying dom changes
 * (standard useEffect runs both callbacks after dom changes are applied)
 */
export function useLegitEffect(fn, dependencies, options) {
  var useEffect = options.useLayoutEffect ? React.useLayoutEffect : React.useEffect;
  var cleanupFnRef = React.useRef(null);
  var cleanupFn = function cleanupFn() {
    var _cleanupFnRef$current;
    return (_cleanupFnRef$current = cleanupFnRef.current) === null || _cleanupFnRef$current === void 0 ? void 0 : _cleanupFnRef$current.call(cleanupFnRef);
  };
  React.useMemo(function () {
    /**
     * Call cleanup before changing dom tree,
     * it will not be called on first render, because ref is empty
     */
    cleanupFn();
  }, dependencies); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(function () {
    cleanupFnRef.current = fn();
  }, dependencies); // eslint-disable-line react-hooks/exhaustive-deps

  /** finally call cleanup on unmount */
  useEffect(function () {
    return cleanupFn;
  }, []);
}