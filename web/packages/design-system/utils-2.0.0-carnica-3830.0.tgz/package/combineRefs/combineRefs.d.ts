import React from 'react';
export declare const combineRefs: <T>(refs: (React.Ref<T> | undefined)[]) => React.RefCallback<T> | null;
//# sourceMappingURL=combineRefs.d.ts.map