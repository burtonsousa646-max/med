export declare const lineHeight: readonly ["3xs", "2xs", "xs", "s", "m", "l", "xl", "2xl", "3xl", "4xl", "5xl"];
export type LineHeight = (typeof lineHeight)[number];
export declare const fontSize: readonly ["2xs", "xs", "s", "m", "l", "xl", "2xl"];
export type FontSize = (typeof fontSize)[number];
export declare const fontWeight: readonly ["regular", "medium", "bold", "black"];
export type FontWeight = (typeof fontWeight)[number];
export declare const spaces: readonly ["xs", "s", "m", "l", "xl", "2xl", "2xs", "3xl", "3xs", "4xl", "5xl", "6xl", "negative-400", "negative-300", "negative-250", "negative-200", "negative-150", "negative-100", "0", "50", "100", "150", "200", "250", "300", "400", "450", "500", "600", "800", "1000", "1200", "1600", "2000"];
export type Spaces = (typeof spaces)[number];
export declare const radius: readonly ["50", "100", "200", "300", "400", "600", "800", "1000", "infinite", "circle"];
export type Radius = (typeof radius)[number];
export declare const size: readonly ["200", "300", "400", "500", "600", "800", "1000", "1100", "1200", "1400", "1600", "2400"];
export type Size = (typeof size)[number];
export declare const border: readonly ["25", "50"];
export type Border = (typeof border)[number];
//# sourceMappingURL=index.d.ts.map