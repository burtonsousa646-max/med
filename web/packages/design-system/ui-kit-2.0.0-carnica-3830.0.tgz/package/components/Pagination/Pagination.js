import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["points", "activePoint", "onPointClick", "onPointChange", "className", "dotClassName", "duration", "activeDotClassName", "autoplay", "invert", "paused", "size", "loop", "direction"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/* eslint-disable jsx-a11y/control-has-associated-label */
import React, { forwardRef, useMemo } from 'react';
import { cnBem } from '@carnica/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { usePaginationKeyboardHandler } from "./hooks/usePaginationKeyboardHandler";
import { PaginationDot } from "./PaginationDot";
var cnPagination = cnBem('pagination', styles);
var PaginationRender = function PaginationRender(props, ref) {
  var _props$points = props.points,
    pointsProp = _props$points === void 0 ? 1 : _props$points,
    activePoint = props.activePoint,
    onPointClick = props.onPointClick,
    onPointChange = props.onPointChange,
    className = props.className,
    dotClassName = props.dotClassName,
    _props$duration = props.duration,
    duration = _props$duration === void 0 ? 6000 : _props$duration,
    activeDotClassName = props.activeDotClassName,
    autoplay = props.autoplay,
    invert = props.invert,
    paused = props.paused,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    loop = props.loop,
    _props$direction = props.direction,
    direction = _props$direction === void 0 ? 'column' : _props$direction,
    otherProps = _objectWithoutProperties(props, _excluded);
  var points = useMemo(function () {
    return new Array(Math.max(pointsProp, 1)).fill(null);
  }, [pointsProp]);
  var _usePaginationKeyboar = usePaginationKeyboardHandler(Math.max(pointsProp, 1)),
    itemRefs = _usePaginationKeyboar.itemRefs,
    onKeyDownByIndex = _usePaginationKeyboar.onKeyDownByIndex;
  var onDotChange = function onDotChange(i) {
    return function () {
      // проверяем что следующий шаг по индексу меньше или равен количеству шагов
      if (i + 2 <= points.length) {
        onPointChange === null || onPointChange === void 0 || onPointChange(i + 2);
        return;
      }
      if (loop) {
        onPointChange === null || onPointChange === void 0 || onPointChange(1);
      }
    };
  };
  var onDotClick = function onDotClick(i) {
    return function (e) {
      onPointClick === null || onPointClick === void 0 || onPointClick(i + 1, e);
      onPointChange === null || onPointChange === void 0 || onPointChange(i + 1, e);
    };
  };
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnPagination({
      direction: direction,
      size: size,
      invert: invert
    }, [className]),
    ref: ref,
    style: _objectSpread(_objectSpread({}, otherProps.style), {}, _defineProperty({}, '--pagination-dot-count', points.length)),
    tagName: "ul",
    "data-t-id": "components-Pagination"
  }), points.map(function (_, i) {
    var active = i + 1 === activePoint;
    return /*#__PURE__*/React.createElement("li", {
      key: cnPagination('item', {
        i: i
      })
    }, /*#__PURE__*/React.createElement(PaginationDot, {
      active: active,
      "aria-label": "\u041F\u0443\u043D\u043A\u0442 ".concat(i + 1),
      autoplay: autoplay,
      className: cnPagination('dot', [dotClassName, active ? activeDotClassName : undefined]),
      direction: direction,
      duration: duration,
      onClick: onDotClick(i),
      onComplete: onDotChange(i),
      onKeyDown: onKeyDownByIndex(i),
      paused: paused,
      ref: itemRefs[i]
    }));
  }));
};
export var Pagination = /*#__PURE__*/forwardRef(PaginationRender);