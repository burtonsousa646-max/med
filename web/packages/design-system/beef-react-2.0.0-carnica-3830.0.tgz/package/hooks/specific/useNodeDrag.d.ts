import React from 'react';
interface DragNodeHook {
    onDragDelta: (delta: {
        dx: number;
        dy: number;
    }) => void;
    onDragToggle?: (value: boolean) => void;
}
export declare const useNodeDrag: ({ onDragDelta, onDragToggle }: DragNodeHook) => React.RefObject<HTMLElement | null>;
export {};
//# sourceMappingURL=useNodeDrag.d.ts.map