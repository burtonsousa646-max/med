import { parseUrl, stringifyUrl } from 'query-string';
export var addQueryParam = function addQueryParam(urlStr, key, value) {
  if (!urlStr) return null;
  if (!key) return urlStr;
  var _parseUrl = parseUrl(urlStr),
    url = _parseUrl.url,
    query = _parseUrl.query;
  query[key] = value;
  return stringifyUrl({
    url: url,
    query: query
  });
};