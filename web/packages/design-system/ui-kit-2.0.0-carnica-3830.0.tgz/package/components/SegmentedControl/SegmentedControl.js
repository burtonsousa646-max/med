import _extends from "@babel/runtime/helpers/extends";
import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["value", "disabled", "items", "name", "invert", "onChange", "className", "getters", "convertItem", "style"];
import React, { forwardRef, useCallback, useMemo } from 'react';
import { withDataConverter } from '@beef/react';
import { compose } from '@beef/utils';
import { useMutableRef } from '@carnica/utils/hooks';
import { useConvertedItems } from "../../hooks/useConvertedItems";
import { convertItemToDefault, createItemProps, dataConverter, itemKeys } from "./utils";
import { SegmentedControlItem } from "./SegmentedControlItem";
import { useSegmentedControlKeyboardHandler } from "./hooks/useSegmentedControlKeyboardHandler";
import { SegmentedControlCore } from "./core";
var SegmentedControlRender = function SegmentedControlRender(props, ref) {
  var value = props.value,
    disabled = props.disabled,
    itemsProp = props.items,
    _props$name = props.name,
    name = _props$name === void 0 ? 'segmented-control' : _props$name,
    invert = props.invert,
    onChange = props.onChange,
    className = props.className,
    getters = props.getters,
    convertItem = props.convertItem,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  var onChangeRef = useMutableRef(onChange);
  var items = useConvertedItems({
    items: itemsProp || [],
    keys: itemKeys,
    getters: getters,
    convertItem: convertItem,
    withOriginal: true
  });
  var convertedValue = useMemo(function () {
    return value ? convertItemToDefault(getters, convertItem)(value) : undefined;
  }, [value]);
  var _useMemo = useMemo(function () {
      return {
        activeIndex: convertedValue && Array.isArray(items) ? items.findIndex(function (item) {
          return item.converted.key === convertedValue.key;
        }) : -1,
        disabledIndexes: items === null || items === void 0 ? void 0 : items.reduce(function (acc, val, i) {
          if (!val.converted.disabled && !disabled) {
            return acc;
          }
          return [].concat(_toConsumableArray(acc), [i]);
        }, [])
      };
    }, [items, convertedValue, disabled]),
    activeIndex = _useMemo.activeIndex,
    disabledIndexes = _useMemo.disabledIndexes;
  var _useSegmentedControlK = useSegmentedControlKeyboardHandler(items),
    tabRefs = _useSegmentedControlK.tabRefs,
    onKeyDownByItem = _useSegmentedControlK.onKeyDownByItem;
  var handleChange = useCallback(function (item) {
    return function (e) {
      var _onChangeRef$current;
      (_onChangeRef$current = onChangeRef.current) === null || _onChangeRef$current === void 0 || _onChangeRef$current.call(onChangeRef, item, e);
    };
  }, []);
  var convertedItems = useMemo(function () {
    return createItemProps({
      items: items,
      value: convertedValue,
      disabled: disabled,
      name: name,
      tabRefs: tabRefs,
      onKeyDown: onKeyDownByItem,
      onChange: handleChange
    });
  }, [items, convertedValue, onKeyDownByItem, disabled]);
  return /*#__PURE__*/React.createElement(SegmentedControlCore, _extends({}, otherProps, {
    activeIndex: activeIndex,
    disabled: disabled,
    disabledIndexes: disabledIndexes,
    invert: invert,
    itemsCount: (items === null || items === void 0 ? void 0 : items.length) || 0,
    ref: ref,
    "data-t-id": "components-SegmentedControl"
  }), convertedItems === null || convertedItems === void 0 ? void 0 : convertedItems.map(function (params) {
    return /*#__PURE__*/React.createElement(SegmentedControlItem, _extends({}, params, {
      invert: invert,
      key: params.key
    }));
  }));
};
export var SegmentedControl = compose(withDataConverter(dataConverter), forwardRef)(SegmentedControlRender);