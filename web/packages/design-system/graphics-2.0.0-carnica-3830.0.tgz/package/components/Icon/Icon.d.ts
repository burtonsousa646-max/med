import type { IconComponent } from './types';
export declare const Icon: IconComponent;
//# sourceMappingURL=Icon.d.ts.map