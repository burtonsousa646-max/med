import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import classNames from 'classnames/bind';
import { getClassList } from "./getClassList";
export var getClassName = function getClassName(prefix, styles, elemOrMods, elemModsOrBlockMix, elemMix) {
  var cx = classNames.bind(styles);
  if (typeof elemOrMods !== 'string') {
    return cx.apply(void 0, _toConsumableArray(getClassList(prefix, undefined, elemOrMods, elemModsOrBlockMix)));
  }
  if (typeof elemModsOrBlockMix === 'string' || Array.isArray(elemModsOrBlockMix)) {
    return cx.apply(void 0, _toConsumableArray(getClassList(prefix, elemOrMods, undefined, elemModsOrBlockMix)));
  }
  return cx.apply(void 0, _toConsumableArray(getClassList(prefix, elemOrMods, elemModsOrBlockMix, elemMix)));
};