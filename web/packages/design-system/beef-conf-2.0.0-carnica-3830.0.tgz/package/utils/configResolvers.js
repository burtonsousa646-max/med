const path = require('path');
const fs = require('fs');

/**
 * Resolves config of type `configName` closest to `currentPath`
 */
const configRootResolverSync = (configName, currentPath = process.cwd()) => {
  for (let attempts = 0; attempts < 15; attempts += 1) {
    if (fs.existsSync(path.resolve(currentPath, configName))) return currentPath;
    currentPath = path.resolve(currentPath, '..');
  }
  return null;
};

/**
 * Resolves config of type `configName` closest to `currentPath`
 */
const configResolverSync = (configName, currentPath = process.cwd()) => {
  const root = configRootResolverSync(configName, currentPath);
  return root ? path.join(root, configName) : null;
};
module.exports = {
  configResolverSync,
  configRootResolverSync
};