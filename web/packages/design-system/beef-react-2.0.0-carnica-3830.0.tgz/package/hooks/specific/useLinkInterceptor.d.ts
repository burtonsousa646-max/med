import React from 'react';
export declare const useLinkInterceptor: (handler: (href: null | string, e: Event) => void) => React.RefObject<HTMLElement | null>;
//# sourceMappingURL=useLinkInterceptor.d.ts.map