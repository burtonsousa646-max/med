import _typeof from "@babel/runtime/helpers/typeof";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { cnBem } from '@carnica/utils';
import styles from "./styles.module.css";
// Интервал смены текста
var CHANGE_PHRASE_INTERVAL = 2000;

// Время по истечении которого запустится анимация
var START_ANIMATION_TIME = 8000;
var cnSpinnerText = cnBem('spinner-text', styles);
var variants = {
  initial: {
    opacity: 0,
    y: 10,
    animationDelay: '20ms'
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      ease: [0.2, 0, 0, 1],
      y: {
        duration: 0.25
      },
      opacity: {
        duration: 0.5
      }
    }
  },
  exit: {
    opacity: 0,
    y: -10,
    transition: {
      ease: [0.2, 0, 0, 1],
      y: {
        duration: 0.15
      },
      opacity: {
        duration: 0.35
      }
    }
  }
};
export var FullScreenSpinnerText = function FullScreenSpinnerText(_ref) {
  var _ref2;
  var className = _ref.className,
    loadingPhrasesProp = _ref.loadingPhrases,
    _ref$animationStartMo = _ref.animationStartMode,
    animationStartMode = _ref$animationStartMo === void 0 ? 'delay' : _ref$animationStartMo;
  var loadingPhrases = Array.isArray(loadingPhrasesProp) ? loadingPhrasesProp.slice(0, 3) : loadingPhrasesProp;
  var _useState = useState(),
    _useState2 = _slicedToArray(_useState, 2),
    activePhrase = _useState2[0],
    setActivePhrase = _useState2[1];
  var intervalRef = useRef(undefined);
  var showPhrase = function showPhrase() {
    setActivePhrase(Array.isArray(loadingPhrases) ? loadingPhrases[0] : loadingPhrases);
    if (Array.isArray(loadingPhrases) && loadingPhrases.length > 1) {
      var activeIndex = 0;
      var handler = function handler() {
        activeIndex = activeIndex + 1 >= loadingPhrases.length ? 0 : activeIndex + 1;
        setActivePhrase(loadingPhrases[activeIndex]);
      };
      intervalRef.current = setInterval(handler, CHANGE_PHRASE_INTERVAL);
    }
  };
  useEffect(function () {
    var timeout;
    if (loadingPhrases && loadingPhrases.length > 0) {
      if (animationStartMode === 'delay') {
        timeout = setTimeout(showPhrase, START_ANIMATION_TIME);
      } else {
        showPhrase();
      }
    }
    return function () {
      clearInterval(intervalRef.current);
      clearTimeout(timeout);
    };
  }, [_typeof(loadingPhrases), loadingPhrases === null || loadingPhrases === void 0 ? void 0 : loadingPhrases.length]);
  var hasPhrases = typeof loadingPhrases === 'string' ? !!loadingPhrases : ((_ref2 = loadingPhrases || []) === null || _ref2 === void 0 ? void 0 : _ref2.length) > 0;
  if (!hasPhrases || !activePhrase) {
    return null;
  }
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    onExitComplete: function onExitComplete() {},
    "data-t-id": "components-FullscreenSpinner"
  }, /*#__PURE__*/React.createElement(motion.p, {
    animate: "animate",
    className: cnSpinnerText(null, [className]),
    exit: "exit",
    initial: "initial",
    key: activePhrase,
    variants: variants
  }, activePhrase));
};