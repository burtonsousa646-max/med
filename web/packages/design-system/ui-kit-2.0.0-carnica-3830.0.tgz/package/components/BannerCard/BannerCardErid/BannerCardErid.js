import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "invert", "isTooltip", "className"];
import React, { forwardRef } from 'react';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import { Text } from "../../Text";
import { AdTag } from "../../AdTag";
export var BannerCardErid = /*#__PURE__*/forwardRef(function (props, ref) {
  var children = props.children,
    invert = props.invert,
    isTooltip = props.isTooltip,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  if (isTooltip) {
    return /*#__PURE__*/React.createElement(AdTag, _extends({}, otherProps, {
      className: className,
      label: "\u0440\u0435\u043A\u043B\u0430\u043C\u0430",
      popoverProps: {
        theme: 'dark'
      },
      ref: ref,
      size: isMobile ? 's' : 'm',
      "data-t-id": "BannerCard-BannerCardErid"
    }), children);
  }
  return /*#__PURE__*/React.createElement(Text, {
    className: className,
    color: invert ? 'primary-invert' : 'primary',
    lineHeight: 12,
    size: 8,
    tagName: "span",
    weight: "regular"
  }, children);
});