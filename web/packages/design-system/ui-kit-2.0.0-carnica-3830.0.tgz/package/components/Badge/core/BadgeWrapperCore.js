import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
var _excluded = ["className", "children", "content", "badgeClassName", "offset", "component", "componentProps"];
import { cnBem } from '@carnica/utils';
import React, { forwardRef } from 'react';
import { MotionComponent } from "../../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnBadgeWrapperCore = cnBem('badge-wrapper-core', styles);
var getStyles = function getStyles(offset) {
  var _ref = typeof offset === 'number' ? {
      vertical: offset,
      horizontal: offset
    } : offset,
    _ref$vertical = _ref.vertical,
    vertical = _ref$vertical === void 0 ? 4 : _ref$vertical,
    _ref$horizontal = _ref.horizontal,
    horizontal = _ref$horizontal === void 0 ? 4 : _ref$horizontal;
  return _defineProperty(_defineProperty({}, '--badge-offset-vertical', "".concat(vertical, "px")), '--badge-offset-horizontal', "".concat(horizontal, "px"));
};
var BadgeWrapperCoreRender = function BadgeWrapperCoreRender(_ref3, ref) {
  var className = _ref3.className,
    children = _ref3.children,
    content = _ref3.content,
    badgeClassName = _ref3.badgeClassName,
    _ref3$offset = _ref3.offset,
    offset = _ref3$offset === void 0 ? 4 : _ref3$offset,
    Component = _ref3.component,
    componentProps = _ref3.componentProps,
    otherProps = _objectWithoutProperties(_ref3, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnBadgeWrapperCore(null, [className]),
    ref: ref,
    "data-t-id": "Badge-core"
  }), children, /*#__PURE__*/React.createElement(Component, _extends({}, componentProps, {
    className: cnBadgeWrapperCore('badge', [badgeClassName]),
    style: getStyles(offset),
    "data-t-id": "Badge-core"
  }), content));
};
export var BadgeWrapperCore = /*#__PURE__*/forwardRef(BadgeWrapperCoreRender);