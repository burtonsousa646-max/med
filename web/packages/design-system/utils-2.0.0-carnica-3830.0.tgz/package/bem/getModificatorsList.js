import { bemPreset } from "./preset";
export var getModificatorsList = function getModificatorsList(prefix, modificators) {
  var list = [];
  Object.keys(modificators).forEach(function (key) {
    if (Object.prototype.hasOwnProperty.call(modificators, key)) {
      var modVal = modificators[key];
      if (modVal) {
        list.push(modVal === true ? prefix + key : "".concat(prefix + key).concat(bemPreset.m).concat(modVal.toString()));
      }
    }
  });
  return list;
};