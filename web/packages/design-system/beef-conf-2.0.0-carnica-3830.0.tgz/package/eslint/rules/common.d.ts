export let rules: {
    'class-methods-use-this': number;
    'no-console': (string | {
        allow: string[];
    })[];
    'no-param-reassign': number;
    'no-underscore-dangle': number;
    'no-unused-vars': (number | {
        destructuredArrayIgnorePattern: string;
        ignoreRestSiblings: boolean;
    })[];
    'no-use-before-define': (string | number)[];
};
//# sourceMappingURL=common.d.ts.map