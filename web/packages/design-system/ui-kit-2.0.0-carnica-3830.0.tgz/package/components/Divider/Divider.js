import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["color", "size", "className", "orientation", "style", "offset"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnDivider = cnBem('divider', styles);
var DividerRender = function DividerRender(_ref, ref) {
  var _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'secondary' : _ref$color,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 1 : _ref$size,
    className = _ref.className,
    _ref$orientation = _ref.orientation,
    orientation = _ref$orientation === void 0 ? 'horizontal' : _ref$orientation,
    style = _ref.style,
    _ref$offset = _ref.offset,
    offset = _ref$offset === void 0 ? 0 : _ref$offset,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    "aria-hidden": true,
    className: cnDivider({
      orientation: orientation
    }, [className]),
    ref: ref,
    role: "presentation",
    style: _objectSpread(_defineProperty(_defineProperty(_defineProperty({}, '--divider-color', "var(--divider-bg-".concat(color, ")")), '--divider-size', "".concat(size, "px")), '--divider-offset', "".concat(offset, "px")), style),
    tagName: "hr",
    "data-t-id": "components-Divider"
  }));
};
export var Divider = /*#__PURE__*/forwardRef(DividerRender);