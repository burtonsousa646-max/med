import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useEffect, useState } from 'react';
var MAX_LOW_DEVICE_MEMORY = 2;
var cachedIsLowPerformance;
var detectLowPerformanceDevice = function detectLowPerformanceDevice() {
  var _carnicaMaxLowDeviceM;
  // тогл на случай проблем: 0 отключает определение, другое число меняет порог
  var maxLowDeviceMemory = (_carnicaMaxLowDeviceM = window.carnicaMaxLowDeviceMemory) !== null && _carnicaMaxLowDeviceM !== void 0 ? _carnicaMaxLowDeviceM : MAX_LOW_DEVICE_MEMORY;
  if (!maxLowDeviceMemory) {
    return false;
  }

  // connection и deviceMemory есть только в chromium, в тс их нет
  var _ref = navigator,
    connection = _ref.connection,
    deviceMemory = _ref.deviceMemory;
  return Boolean((connection === null || connection === void 0 ? void 0 : connection.saveData) || deviceMemory && deviceMemory <= maxLowDeviceMemory);
};

/** Определяет заведомо слабое устройство, на котором стоит отключать тяжелые эффекты (например, блюр) */
export var useLowPerformanceDevice = function useLowPerformanceDevice() {
  var _useState = useState(cachedIsLowPerformance !== null && cachedIsLowPerformance !== void 0 ? cachedIsLowPerformance : false),
    _useState2 = _slicedToArray(_useState, 2),
    isLowPerformance = _useState2[0],
    setIsLowPerformance = _useState2[1];
  useEffect(function () {
    if (cachedIsLowPerformance === undefined) {
      cachedIsLowPerformance = detectLowPerformanceDevice();
    }
    setIsLowPerformance(cachedIsLowPerformance);
  }, []);
  return isLowPerformance;
};