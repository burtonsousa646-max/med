export declare const useDerivedState: <T>(initialState: T, dependencies: any[]) => readonly [T, (newState: T) => void];
//# sourceMappingURL=useDerivedState.d.ts.map