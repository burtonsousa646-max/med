import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "children", "type"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { DIMENSION_TYPE, useBreakpoints } from '@carnica/utils/hooks';
import { AnimatePresence, motion } from 'framer-motion';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnLoadingWindowContentText = cnBem('loading-window-text', styles);
var textMobileInitialSettings = {
  y: 20,
  opacity: 0
};
var variants = {
  initial: {
    opacity: 0,
    y: 10,
    animationDelay: '20ms'
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      ease: [0.2, 0, 0, 1],
      y: {
        duration: 0.25
      },
      opacity: {
        duration: 0.5
      }
    }
  },
  exit: {
    opacity: 0,
    y: -10,
    transition: {
      ease: [0.2, 0, 0, 1],
      y: {
        duration: 0.15
      },
      opacity: {
        duration: 0.35
      }
    }
  }
};
export var LoadingWindowContentText = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var className = _ref.className,
    children = _ref.children,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'title' : _ref$type,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var isMobile = useBreakpoints()[0] === DIMENSION_TYPE.MOBILE;
  return /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    animate: isMobile ? textMobileInitialSettings : {},
    className: cnLoadingWindowContentText({
      type: type
    }, [className]),
    color: "black",
    motion: true,
    ref: ref,
    rows: 2,
    tagName: type === 'title' ? 'h1' : 'h2',
    truncate: true,
    variant: "display-small",
    "data-t-id": "LoadingWindow-LoadingWindowContent"
  }), children, /*#__PURE__*/React.createElement(AnimatePresence, {
    "data-t-id": "LoadingWindow-LoadingWindowContent"
  }, /*#__PURE__*/React.createElement(motion.span, {
    animate: "animate",
    "aria-hidden": true,
    className: cnLoadingWindowContentText('content'),
    exit: "exit",
    initial: "initial",
    key: children,
    variants: variants
  }, children)));
});