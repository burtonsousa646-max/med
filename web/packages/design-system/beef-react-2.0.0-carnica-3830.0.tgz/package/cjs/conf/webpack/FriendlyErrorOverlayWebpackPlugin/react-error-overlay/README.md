Forked from react-error-overlay to add errorFilters - allowing to ignore given errors
