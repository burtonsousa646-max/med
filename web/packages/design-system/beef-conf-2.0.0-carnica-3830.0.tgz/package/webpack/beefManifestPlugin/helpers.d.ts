export function generateManifest(compilation: any, files: any, { generate, seed, isServer }: {
    generate: any;
    seed?: {} | undefined;
    isServer: any;
}): any;
export function reduceAssets(files: any, asset: any, moduleAssets: any): any;
export function reduceChunk(files: any, chunk: any, options: any, auxiliaryFiles: any): any;
export function transformFiles(files: any, options: any): any;
export function removeServerManifest(compilation: any): void;
//# sourceMappingURL=helpers.d.ts.map