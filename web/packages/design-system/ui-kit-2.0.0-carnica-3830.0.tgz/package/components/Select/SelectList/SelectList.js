import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "anchorRef", "value", "getters", "convertItem", "items", "onChange", "onClose", "className", "loading", "notFoundLabel", "multiple", "onClickOutside"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useCallback } from 'react';
import { AnimatePresence } from 'framer-motion';
import { cnBem } from '@carnica/utils';
import { Popover } from "../../../modules/Popover";
import { ActionSheet } from "../../ActionSheet";
import styles from "./styles.module.css";
import { useSelectList } from "../hooks/useSelectList";
import { useSelectListKeyboardHandler } from "../hooks/useSelectListKeyboardHandler";
var cnSelectList = cnBem('select-list', styles);
var variants = {
  hidden: {
    poinerEvents: 'none',
    y: 12,
    opacity: 0
  },
  visible: {
    y: 0,
    opacity: 1,
    poinerEvents: 'all'
  }
};
var SelectListRender = function SelectListRender(props, ref) {
  var isOpen = props.isOpen,
    anchorRef = props.anchorRef,
    valueProp = props.value,
    getters = props.getters,
    convertItem = props.convertItem,
    _props$items = props.items,
    itemsProp = _props$items === void 0 ? [] : _props$items,
    onChange = props.onChange,
    onClose = props.onClose,
    className = props.className,
    loading = props.loading,
    notFoundLabel = props.notFoundLabel,
    multiple = props.multiple,
    onClickOutside = props.onClickOutside,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useSelectList = useSelectList({
      isOpen: isOpen,
      value: valueProp,
      items: itemsProp,
      onChange: onChange,
      multiple: multiple,
      getters: getters,
      convertItem: convertItem,
      onClickOutside: onClickOutside
    }),
    getItemActive = _useSelectList.getItemActive,
    onItemClick = _useSelectList.onItemClick,
    items = _useSelectList.items;
  var _useSelectListKeyboar = useSelectListKeyboardHandler({
      items: items,
      isOpen: isOpen,
      onClose: onClose,
      getItemActive: getItemActive
    }),
    getItemAttributes = _useSelectListKeyboar.getItemAttributes,
    getItemRef = _useSelectListKeyboar.getItemRef;
  var converter = useCallback(function (item) {
    var attributes = getItemAttributes(item);
    return _objectSpread(_objectSpread({}, item.converted), {}, {
      attributes: _objectSpread(_objectSpread({}, attributes), {}, {
        className: cnSelectList('item', [attributes.className])
      }),
      ref: getItemRef(item),
      checked: getItemActive(item),
      onClick: onItemClick(item)
    });
  }, [getItemActive, onItemClick, getItemAttributes]);
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait",
    onExitComplete: function onExitComplete() {
      return null;
    },
    "data-t-id": "Select-SelectList"
  }, isOpen && /*#__PURE__*/React.createElement(Popover, _extends({}, otherProps, {
    anchorRef: anchorRef,
    animate: "visible",
    className: cnSelectList(null, [className]),
    direction: "downStartLeft",
    equalAnchorWidth: true,
    exit: "hidden",
    initial: "hidden",
    motion: true,
    offsetVertical: 8,
    onClickOutside: onClickOutside,
    possibleDirections: ['downStartLeft', 'upStartLeft'],
    ref: ref,
    reposition: true,
    role: "listbox",
    transition: {
      transform: {
        duration: 0.3
      },
      opacity: {
        duration: 0.3
      }
    },
    variants: variants
  }), /*#__PURE__*/React.createElement(ActionSheet, {
    className: cnSelectList('list'),
    convertItem: converter,
    items: items,
    loading: loading,
    multiple: multiple,
    notFoundLabel: notFoundLabel,
    renderListAsMotion: true,
    role: "listbox",
    "data-t-id": "Select-SelectList"
  })));
};
export var SelectList = /*#__PURE__*/forwardRef(SelectListRender);