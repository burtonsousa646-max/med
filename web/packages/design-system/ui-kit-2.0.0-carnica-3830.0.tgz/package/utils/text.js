export var getTextColorVariable = function getTextColorVariable(color) {
  return "var(--text-color-".concat(color, ")");
};