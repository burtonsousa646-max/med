import { v4 as uuid } from 'uuid';
import { getRootCookieDomain, refreshCookie } from "./cookie";
export var unstable_refreshMetricVisitId = function unstable_refreshMetricVisitId() {
  return refreshCookie({
    name: '_am_vid',
    value: function value() {
      return process.env.NODE_ENV === 'test' ? '00000000-0000-0000-0000-000000000000' : uuid();
    },
    path: '/',
    ttl: 30 * 60 * 1000,
    domain: getRootCookieDomain()
  });
};
export var unstable_getBaseYmParams = function unstable_getBaseYmParams(user) {
  if (typeof window !== 'undefined') {
    var _window, _window2, _document;
    return {
      page_url: (_window = window) === null || _window === void 0 ? void 0 : _window.origin,
      page_path: (_window2 = window) === null || _window2 === void 0 || (_window2 = _window2.location) === null || _window2 === void 0 ? void 0 : _window2.pathname,
      page_title: (_document = document) === null || _document === void 0 ? void 0 : _document.title,
      account_type: user || 'none',
      vid: unstable_refreshMetricVisitId()
    };
  }
  return {};
};

/**
 * @deprecated Используйте getBaseYmParams from @beef/metric instead
 */
export var getCommonProps = unstable_getBaseYmParams;