import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["backgroundColor", "color", "cutout", "cutoutElement", "errorCorrectionLevel", "rounding", "viewPortSize", "url", "size"];
import React, { forwardRef } from 'react';
import { useQr } from "./hooks/useQr/useQr";
export var QR = /*#__PURE__*/forwardRef(function (props, ref) {
  var backgroundColor = props.backgroundColor,
    _props$color = props.color,
    color = _props$color === void 0 ? 'var(--color-background-primary-invert)' : _props$color,
    cutoutProp = props.cutout,
    cutoutElement = props.cutoutElement,
    _props$errorCorrectio = props.errorCorrectionLevel,
    errorCorrectionLevel = _props$errorCorrectio === void 0 ? 'H' : _props$errorCorrectio,
    _props$rounding = props.rounding,
    rounding = _props$rounding === void 0 ? 60 : _props$rounding,
    _props$viewPortSize = props.viewPortSize,
    viewPortSize = _props$viewPortSize === void 0 ? 1000 : _props$viewPortSize,
    url = props.url,
    _props$size = props.size,
    size = _props$size === void 0 ? 160 : _props$size,
    otherProps = _objectWithoutProperties(props, _excluded);
  var cutout = typeof cutoutProp === 'boolean' ? cutoutProp : !!cutoutElement;
  var _useQr = useQr({
      url: url,
      rounding: rounding,
      errorCorrectionLevel: errorCorrectionLevel,
      size: size,
      cutout: cutout
    }),
    moduleCount = _useQr.moduleCount,
    qrPath = _useQr.qrPath,
    cutoutModuleArea = _useQr.cutoutModuleArea;
  var moduleSize = viewPortSize / (moduleCount !== null && moduleCount !== void 0 ? moduleCount : 1);
  var cutoutSize = moduleSize * (cutoutModuleArea || 1);
  var cutoutPosition = (viewPortSize - cutoutSize) / 2;
  if (!qrPath) {
    return null;
  }
  return /*#__PURE__*/React.createElement("svg", _extends({
    height: size,
    ref: ref,
    viewBox: "0 0 ".concat(viewPortSize, " ").concat(viewPortSize),
    width: size,
    xmlns: "http://www.w3.org/2000/svg"
  }, otherProps), backgroundColor ? /*#__PURE__*/React.createElement("rect", {
    fill: backgroundColor,
    height: viewPortSize,
    width: viewPortSize,
    x: "0",
    y: "0"
  }) : null, /*#__PURE__*/React.createElement("path", {
    d: qrPath,
    fill: color
  }), !!cutoutElement && /*#__PURE__*/React.createElement("foreignObject", {
    height: cutoutSize,
    width: cutoutSize,
    x: cutoutPosition,
    y: cutoutPosition
  }, cutoutElement));
});