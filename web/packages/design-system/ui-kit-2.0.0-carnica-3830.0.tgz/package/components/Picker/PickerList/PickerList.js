import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "onChange", "items", "errorContent", "emptyContent", "loading", "offset", "reverse"],
  _excluded2 = ["avatar", "key", "groupKey"];
import React, { forwardRef, useCallback } from 'react';
import { cnBem } from '@carnica/utils';
import { motion } from 'framer-motion';
import { useIsMobileDimension, useMutableRef } from '@carnica/utils/hooks';
import { Skeleton } from "../../Skeleton";
import { Mapper } from "../../../modules/Mapper";
import styles from "./styles.module.css";
import { useListAnimation } from "../hooks/useListAnimation";
import { usePickerContext } from "../PickerContext";
import { PickerItem } from "../PickerItem";
import { usePickerListKeyboardHandler } from "../hooks/usePickerListKeyboardHandler";
var cnPickerList = cnBem('picker-list', styles);
var skeletonList = Array.from({
  length: 10
});
export var PickerList = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    onChange = props.onChange,
    items = props.items,
    errorContent = props.errorContent,
    emptyContent = props.emptyContent,
    loading = props.loading,
    offset = props.offset,
    reverse = props.reverse,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _usePickerContext = usePickerContext(),
    setSelectedIndex = _usePickerContext.setSelectedIndex,
    selectedIndex = _usePickerContext.selectedIndex,
    onClose = _usePickerContext.onClose,
    activeIndex = _usePickerContext.activeIndex;
  var _usePickerListKeyboar = usePickerListKeyboardHandler(items),
    getItemAttributes = _usePickerListKeyboar.getItemAttributes,
    getItemRef = _usePickerListKeyboar.getItemRef;
  var isMobile = useIsMobileDimension();
  var onChangeRef = useMutableRef(onChange);
  useListAnimation();
  var handleItemClick = useCallback(function (item, index) {
    return function (e) {
      if (index === selectedIndex) {
        var _onChangeRef$current;
        (_onChangeRef$current = onChangeRef.current) === null || _onChangeRef$current === void 0 || _onChangeRef$current.call(onChangeRef, item.original, e);
        onClose === null || onClose === void 0 || onClose(e);
      } else {
        setSelectedIndex(index);
      }
    };
  }, [selectedIndex, onClose]);
  return /*#__PURE__*/React.createElement(motion.ul, _extends({
    className: cnPickerList(null, [className]),
    layoutScroll: true,
    ref: ref,
    role: "list"
  }, otherProps), /*#__PURE__*/React.createElement(Mapper, {
    items: skeletonList,
    shouldRender: loading,
    "data-t-id": "Picker-PickerList"
  }, function (_, i) {
    return /*#__PURE__*/React.createElement(Skeleton.Cell, {
      key: i,
      view: isMobile ? 'invert' : 'default'
    });
  }), /*#__PURE__*/React.createElement(Mapper, {
    items: items,
    shouldRender: !loading
  }, function (item, i) {
    var _item$converted = item.converted,
      avatar = _item$converted.avatar,
      key = _item$converted.key,
      groupKey = _item$converted.groupKey,
      itemProps = _objectWithoutProperties(_item$converted, _excluded2);
    return /*#__PURE__*/React.createElement(PickerItem, _extends({}, getItemAttributes(item) || {}, itemProps, {
      active: selectedIndex === i,
      avatarData: avatar,
      id: key,
      key: key,
      offset: offset,
      onClick: handleItemClick(item, i),
      priority: i - activeIndex,
      ref: getItemRef(item),
      reverse: reverse
    }));
  }));
});