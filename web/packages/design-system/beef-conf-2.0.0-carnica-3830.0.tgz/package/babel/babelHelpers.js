const fs = require('fs');
const path = require('path');
const logger = require('loglevel');
const {
  createRequire
} = require('module');
const {
  tsconfigResolverSync
} = require('tsconfig-resolver');
const {
  isModuleAvailable,
  configRootResolverSync
} = require('../utils');
const {
  scopeExcludes
} = require('../registry');
const getResolveAliases = cwd => {
  let tsConfig;
  try {
    tsConfig = tsconfigResolverSync({
      cwd
    });
  } catch (err) {
    logger.debug(`[babel-conf]: No tsconfig found in ${cwd}`);
    return {};
  }
  try {
    const {
      paths = {},
      baseUrl = ''
    } = tsConfig.config?.compilerOptions || {};

    // NOTE: Раньше путь генерировался исходя из разницы текущей папки и process.cwd, пока не ясен кейс и необходимость
    // TODO: Либо выпилить этот коммент, либо вернуть старый формат,
    //    но делать проверку, что cwd за пределами папки (линковка)
    // const relativeBaseUrl = path.join(path.relative(process.cwd(), cwd), `./${baseUrl}`);
    const relativeBaseUrl = `./${baseUrl}`;
    return convertTsconfigPathToBabel(paths, relativeBaseUrl);
  } catch (err) {
    logger.warn(`[babel-conf]: Path parser crashed at ${cwd}`);
    logger.warn(err);
    return {};
  }
};

/**
 * Получаем список всех node_module'ей, которые резолвятся
 * стандартным nodeResolution-механизмом из текущей папки
 */
const getNodeModules = (cwd = process.cwd()) => {
  const cwdRequire = createRequire(`${cwd}/package.json`);
  const modulePaths = cwdRequire.resolve.paths('').filter(fs.existsSync);
  const nodeModules = [];
  modulePaths.forEach(modulesFolder => {
    fs.readdirSync(modulesFolder).forEach(pkg => {
      const source = path.join(modulesFolder, pkg);
      if (pkg[0] !== '@') {
        nodeModules.push({
          name: pkg,
          source
        });
        return;
      }
      fs.readdirSync(source).forEach(subPkg => {
        nodeModules.push({
          name: `${pkg}/${subPkg}`,
          source: path.join(source, subPkg)
        });
      });
    });
  });
  return nodeModules;
};

/**
 * Получить список всех прилинкованных через yarn link или npm link пакетов
 */
const getLinkedModules = (cwd = process.cwd()) => {
  const repositoryRoot = configRootResolverSync('lerna.json', cwd) || cwd;
  return getNodeModules(cwd).filter(({
    source
  }) => !scopeExcludes.test(source)).map(({
    name,
    source
  }) => ({
    name,
    link: source,
    source: fs.realpathSync(source)
  })).filter(({
    source
  }) => source.indexOf(repositoryRoot) === -1);
};
const convertTsconfigPathToBabel = (paths, baseUrl) => Object.keys(paths).reduce((accum, alias) => ({
  ...accum,
  [trimWildCard(alias)]: `./${path.join(baseUrl, trimWildCard(paths[alias][0]))}`
}), {});
const trimWildCard = pathname => pathname.replace(/\/\*$/, '');
const usePlugin = (plugin, options, isEnabled = true) => isModuleAvailable(plugin) && isEnabled && [require.resolve(plugin), options].filter(Boolean);
const detectEnv = api => {
  const isPublish = process.env.TARGET === 'publish';

  /**
   * Если вызывающий плагин (babel-loader, babel-jest) передает требования к транспиляции, применяем их.
   * UPD: @babel/cli начиная с @7.29 прокидывает caller.supportsStaticESM:false, но это не указание формата модуля
   * CLI пишет в файл, формат задаём сами через --env-name cjs
   * Поэтому исключаем @babel/cli из ветки.
   */
  const isCallerControlled = api.caller(caller => caller && typeof caller.supportsStaticESM !== 'undefined' && caller.name !== '@babel/cli');
  if (isCallerControlled) {
    const isProduction = api.env(['production']);
    return {
      modules: 'auto',
      isNode: api.caller(caller => caller?.target !== 'web'),
      isProduction,
      isHMR: !isProduction,
      isPublish
    };
  }

  /** Специальный кейс: публикация пакета под commonjs */
  const isNode = api.env(['cjs']);

  /** В любом ином случае - рендерим под esm, так безопаснее - если что-то не сработает, сразу об этом узнаем */
  return {
    modules: isNode ? 'commonjs' : false,
    isNode,
    isProduction: process.env.NODE_ENV === 'production',
    isHMR: false,
    isPublish
  };
};
module.exports = {
  getResolveAliases,
  getLinkedModules,
  usePlugin,
  detectEnv
};