import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["position", "autoCloseTime", "offset", "items", "theme", "onCloseTrigered", "truncate", "onItemClose", "convertItem", "getters", "className", "style"],
  _excluded2 = ["id"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useCallback, useEffect, useState } from 'react';
import { cnBem } from '@carnica/utils';
import { AnimatePresence } from 'framer-motion';
import { useFlag, useIsMobileDimension } from '@carnica/utils/hooks';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { ThemedPortal } from "../../modules/ThemedPortal";
import { useConvertedItems } from "../../hooks/useConvertedItems";
import styles from "./styles.module.css";
import { SnackBarItem } from "./SnackBarItem";
import { dataConverter, itemAnimationVariants, itemKeys } from "./utils";
var cnSnackBar = cnBem('snackbar', styles);
var getKey = function getKey(item) {
  return item.converted.id;
};
var SnackBarRender = function SnackBarRender(props, ref) {
  var _props$position = props.position,
    position = _props$position === void 0 ? 'bottomCenter' : _props$position,
    _props$autoCloseTime = props.autoCloseTime,
    autoCloseTime = _props$autoCloseTime === void 0 ? 3500 : _props$autoCloseTime,
    _props$offset = props.offset,
    offset = _props$offset === void 0 ? 24 : _props$offset,
    itemsProp = props.items,
    theme = props.theme,
    onCloseTrigered = props.onCloseTrigered,
    _props$truncate = props.truncate,
    truncate = _props$truncate === void 0 ? true : _props$truncate,
    onItemClose = props.onItemClose,
    convertItem = props.convertItem,
    getters = props.getters,
    className = props.className,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isNotificationVisible = _useFlag2[0],
    setIsNotificationVisible = _useFlag2[1];
  var _useState = useState(),
    _useState2 = _slicedToArray(_useState, 2),
    activeItem = _useState2[0],
    setActiveItem = _useState2[1];
  var isMobile = useIsMobileDimension();
  var items = useConvertedItems({
    items: itemsProp || [],
    getters: getters,
    convertItem: convertItem,
    keys: itemKeys,
    withOriginal: true
  });
  useEffect(function () {
    if (items.length) {
      setIsNotificationVisible.on();
      setActiveItem(items[0]);
    }
  }, [items]);
  var handleClose = useCallback(function (item) {
    return function () {
      setActiveItem(items.find(function (el) {
        return getKey(el) !== getKey(item);
      }));
      setIsNotificationVisible.off();
      onCloseTrigered === null || onCloseTrigered === void 0 || onCloseTrigered(item.original);
      // Необходимо чтоб отработала анимация, иначе игнорируется этап exit
      setTimeout(function () {
        onItemClose === null || onItemClose === void 0 || onItemClose(item.original);
        setIsNotificationVisible.on();
        setActiveItem(items.find(function (el) {
          return getKey(el) !== getKey(item);
        }));
      }, 350);
    };
  }, [items]);
  var _ref = (activeItem === null || activeItem === void 0 ? void 0 : activeItem.converted) || {},
    id = _ref.id,
    item = _objectWithoutProperties(_ref, _excluded2);
  return /*#__PURE__*/React.createElement(ThemedPortal, _extends({
    className: cnSnackBar(null, [className]),
    ref: ref,
    style: _objectSpread(_defineProperty(_defineProperty({}, '--snackbar-zindex', (style === null || style === void 0 ? void 0 : style.zIndex) || 10), '--snackbar-offset', typeof offset === 'number' ? "".concat(offset, "px") : offset), style)
  }, otherProps, {
    "data-t-id": "components-SnackBar"
  }), /*#__PURE__*/React.createElement(AnimatePresence, {
    mode: "wait",
    "data-t-id": "components-SnackBar"
  }, activeItem && isNotificationVisible && /*#__PURE__*/React.createElement(SnackBarItem, _extends({}, item, {
    animate: "animate",
    autoCloseTime: autoCloseTime,
    className: cnSnackBar('item', {
      position: position,
      mode: item.mode
    }),
    custom: {
      position: position,
      isMobile: isMobile,
      mode: item.mode
    },
    exit: "exit",
    initial: "initial",
    onClose: handleClose(activeItem),
    truncate: truncate,
    variants: itemAnimationVariants
  }))));
};
export var SnackBar = compose(withDataConverter(dataConverter), forwardRef)(SnackBarRender);