import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["icon", "type", "size", "originalColor"];
import React, { forwardRef } from 'react';
import { compose } from '@beef/utils';
import { withDataConverter, withRenderCondition } from '@beef/react';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { cnBem } from '@carnica/utils';
import { dataConverter } from "./utils";
import { BadgeCore } from "./core";
import styles from "./styles.module.css";
var cnBadge = cnBem('badge', styles);
var BadgeRender = function BadgeRender(_ref, ref) {
  var Icon = _ref.icon,
    type = _ref.type,
    size = _ref.size,
    originalColor = _ref.originalColor,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  useDeprecationWarning({
    size: {
      value: size,
      customMessage: 'Используйте взамен свойство `type` (`dot` для `s` и `text` для `l`)'
    },
    'color="dark"': {
      value: originalColor === 'dark' ? true : undefined,
      customMessage: 'Данный цвет более не поддерживаются используйте взамен `accent`'
    }
  });
  return /*#__PURE__*/React.createElement(BadgeCore, _extends({}, otherProps, {
    icon: Icon && /*#__PURE__*/React.createElement(Icon, {
      className: cnBadge('icon'),
      customColor: "var(--badge-color)",
      size: 12
    }),
    ref: ref,
    view: type,
    "data-t-id": "components-Badge"
  }));
};
export var Badge = compose(withDataConverter(dataConverter), withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref2) {
    var type = _ref2.type,
      icon = _ref2.icon,
      children = _ref2.children;
    return (type !== 'text' || !!children) && (type !== 'icon' || !!icon);
  }
}), forwardRef)(BadgeRender);