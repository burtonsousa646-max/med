export declare const mockLottie: {
    loadAnimation: jest.Mock<{
        playSegments: jest.Mock<any, any>;
        setSegment: jest.Mock<any, any>;
        goToAndStop: jest.Mock<any, any>;
        resetSegments: jest.Mock<any, any>;
        destroy: jest.Mock<any, any>;
        currentRawFrame: number;
        totalFrames: number;
    }, []>;
};
//# sourceMappingURL=mockLottie.d.ts.map