import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["disabled", "icon", "mode", "iconView", "onlyIcon", "className", "size", "loading", "invert"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import styles from "../styles.module.css";
var cnButtonIcon = cnBem('button-icon', styles);
var getIconSize = function getIconSize(mode, size, view, onlyIcon) {
  if (mode === 'default') {
    if (size === 's') {
      return 'xs';
    }
    return onlyIcon ? 'm' : 's';
  }
  return view === 'background' ? 'xs' : 's';
};
export var ButtonIcon = function ButtonIcon(_ref) {
  var disabled = _ref.disabled,
    Icon = _ref.icon,
    _ref$mode = _ref.mode,
    mode = _ref$mode === void 0 ? 'default' : _ref$mode,
    _ref$iconView = _ref.iconView,
    iconView = _ref$iconView === void 0 ? 'default' : _ref$iconView,
    onlyIcon = _ref.onlyIcon,
    className = _ref.className,
    size = _ref.size,
    loading = _ref.loading,
    invert = _ref.invert,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  if (!Icon) {
    return null;
  }
  return /*#__PURE__*/React.createElement(Icon, _extends({}, otherProps, {
    "aria-hidden": true,
    className: cnButtonIcon({
      view: iconView,
      loading: loading,
      invert: invert
    }, [className]),
    color: "primary",
    customColor: "var(--button-icon-color)",
    iconClassName: cnButtonIcon('container'),
    size: getIconSize(mode, size, iconView, onlyIcon),
    "data-t-id": "Button-ButtonIcon"
  }));
};