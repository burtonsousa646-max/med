// Polyfill "window.fetch"
require('whatwg-fetch');