export const browsers: string[];
//# sourceMappingURL=browsers.d.ts.map