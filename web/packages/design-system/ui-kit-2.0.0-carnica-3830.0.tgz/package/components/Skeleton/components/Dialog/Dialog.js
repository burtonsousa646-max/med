import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { Modal } from "../../../Modal";
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnDialog = cnBem('skeleton-dialog', styles);
export var Dialog = function Dialog(_ref) {
  var invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(Modal, _extends({
    className: cnDialog(null, [className]),
    closeOptions: {
      button: false,
      overlay: true,
      escape: true
    },
    isOpen: true,
    theme: invert ? 'dark' : 'light'
  }, props, {
    "data-t-id": "components-Dialog"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnDialog('content'),
    "data-t-id": "components-Dialog"
  }, /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 36,
    width: {
      desktop: 'calc(100% - 74px)',
      mobile: 'calc(100% - 100px)'
    }
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 20,
    width: "calc(100% - 40px)"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 20,
    width: {
      desktop: 158,
      mobile: 142
    }
  })));
};