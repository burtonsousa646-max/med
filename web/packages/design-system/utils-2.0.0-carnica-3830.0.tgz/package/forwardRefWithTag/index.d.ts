export { forwardRefWithTag } from './forwardRefWithTag';
//# sourceMappingURL=index.d.ts.map