export const scopeRegExpStr: string;
export const scopeMatchedExcludes: RegExp;
export const scopeExcludes: RegExp;
export const scopeIncludes: RegExp;
export declare let scopeRegExp: RegExp;
//# sourceMappingURL=matchers.d.ts.map