import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "className", "slideClass", "wrapperClass", "renderNode", "containerContent", "swiperNodeRef", "prevControlRef", "nextControlRef", "withControls", "swiper", "id", "controlsResponseArea", "onNavigationClick"];
import React, { forwardRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import styles from "./styles.module.css";
import { BannerControl } from "./BannerControl";
import { useBannerControls } from "./hooks";
var cnBanner = cnBem('banner-core', styles);
var defaultRender = function defaultRender(node) {
  return node;
};
export var BannerCore = /*#__PURE__*/forwardRef(function (props, ref) {
  var children = props.children,
    className = props.className,
    _props$slideClass = props.slideClass,
    slideClass = _props$slideClass === void 0 ? 'swiper-slide' : _props$slideClass,
    _props$wrapperClass = props.wrapperClass,
    wrapperClass = _props$wrapperClass === void 0 ? 'swiper-wrapper' : _props$wrapperClass,
    _props$renderNode = props.renderNode,
    renderNode = _props$renderNode === void 0 ? defaultRender : _props$renderNode,
    containerContent = props.containerContent,
    swiperNodeRef = props.swiperNodeRef,
    prevControlRef = props.prevControlRef,
    nextControlRef = props.nextControlRef,
    withControls = props.withControls,
    swiper = props.swiper,
    id = props.id,
    controlsResponseArea = props.controlsResponseArea,
    onNavigationClick = props.onNavigationClick,
    otherProps = _objectWithoutProperties(props, _excluded);
  var nodes = React.Children.toArray(children);
  var _useBannerControls = useBannerControls({
      withControls: withControls,
      swiperNodeRef: swiperNodeRef,
      swiper: swiper,
      controlsResponseArea: controlsResponseArea,
      onNavigationClick: onNavigationClick
    }),
    showNextControl = _useBannerControls.showNextControl,
    showPrevControl = _useBannerControls.showPrevControl,
    onButtonClick = _useBannerControls.onButtonClick;
  var slidesId = id ? "".concat(id, "-slides") : undefined;
  return /*#__PURE__*/React.createElement("div", _extends({
    "aria-roledescription": "\u041A\u0430\u0440\u0443\u0441\u0435\u043B\u044C \u0441\u043B\u0430\u0439\u0434\u043E\u0432",
    className: cnBanner(null, [className, 'swiper']),
    id: id,
    ref: combineRefs([swiperNodeRef, ref]),
    role: "region"
  }, otherProps, {
    "data-t-id": "components-Banner"
  }), containerContent, withControls && ['prev', 'next'].map(function (side) {
    return /*#__PURE__*/React.createElement(BannerControl, {
      "aria-controls": slidesId,
      className: cnBanner('control', {
        side: side,
        visible: side === 'prev' ? showPrevControl : showNextControl
      }),
      direction: side,
      key: side,
      onClick: onButtonClick(side),
      ref: side === 'prev' ? prevControlRef : nextControlRef
    });
  }), /*#__PURE__*/React.createElement("div", {
    "aria-live": "off",
    className: cnBanner('wrapper', [wrapperClass]),
    id: slidesId
  }, nodes.map(function (node, i) {
    return /*#__PURE__*/React.createElement("div", {
      "aria-label": "\u0421\u043B\u0430\u0439\u0434 ".concat(i + 1),
      "aria-roledescription": "\u0421\u043B\u0430\u0439\u0434",
      className: cnBanner('slide', [slideClass]),
      key: cnBanner('slide', {
        i: i
      }),
      role: "group"
    }, renderNode(node, i));
  })));
});