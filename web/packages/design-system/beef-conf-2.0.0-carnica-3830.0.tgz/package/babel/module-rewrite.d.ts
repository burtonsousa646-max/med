export = replaceImport;
declare function replaceImport(originalPath: any, callingFileName: any, options: any): any;
//# sourceMappingURL=module-rewrite.d.ts.map