// Run mock server
var _require = require('.'),
  server = _require.server;
beforeAll(function () {
  return server.listen();
});
afterEach(function () {
  return server.reset();
});
afterAll(function () {
  return server.close();
});