import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
export var withContext = function withContext(Context, mapContextToProps) {
  return function (WrappedComponent) {
    var ConnectedConsumer = function ConnectedConsumer(props) {
      return /*#__PURE__*/React.createElement(Context.Consumer, null, function (contextData) {
        return /*#__PURE__*/React.createElement(WrappedComponent
        // eslint-disable-next-line react/jsx-props-no-spreading
        , _extends({}, props, mapContextToProps ? mapContextToProps(contextData, props) : contextData, {
          "data-t-id": "src-enhancers"
        }));
      });
    };

    /**
     * Override Connector's name to withContext(%Component%)
     */
    if (process.env.NODE_ENV !== 'production') {
      var WrappedComponentName = WrappedComponent.displayName || WrappedComponent.name || 'Component';
      ConnectedConsumer.displayName = "withContext(".concat(WrappedComponentName, ")");
    }
    return ConnectedConsumer;
  };
};