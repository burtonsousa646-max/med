import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["onClear", "value", "className", "type", "view", "postFix", "status", "rightSide", "readOnly", "disabled", "invert", "hidePlaceholderOnFocus", "placeholder", "onChange", "withClearButton", "onFocus", "onBlur", "withPostFix"];
import React, { forwardRef, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { useFlag } from '@carnica/utils/hooks';
import { Text } from "../../Text";
import styles from "./styles.module.css";
import { defineAdditionalProps } from "./utils";
import { ResizeInput } from "./ResizeInput";
var cnInput = cnBem('input-core', styles);
var getPostFixColor = function getPostFixColor(invert, disabled, status) {
  if (status === 'error' && !disabled) {
    return 'var(--input-color-error)';
  }
  return "var(--input-color".concat(invert ? '-invert' : '').concat(disabled ? '-disabled' : '', ")");
};
export var InputCore = /*#__PURE__*/forwardRef(function (props, ref) {
  var _defineAdditionalProp = defineAdditionalProps(props),
    onClear = _defineAdditionalProp.onClear,
    value = _defineAdditionalProp.value,
    className = _defineAdditionalProp.className,
    _defineAdditionalProp2 = _defineAdditionalProp.type,
    type = _defineAdditionalProp2 === void 0 ? 'text' : _defineAdditionalProp2,
    _defineAdditionalProp3 = _defineAdditionalProp.view,
    viewProp = _defineAdditionalProp3 === void 0 ? 'bordered' : _defineAdditionalProp3,
    postFix = _defineAdditionalProp.postFix,
    status = _defineAdditionalProp.status,
    rightSide = _defineAdditionalProp.rightSide,
    readOnly = _defineAdditionalProp.readOnly,
    disabled = _defineAdditionalProp.disabled,
    invert = _defineAdditionalProp.invert,
    hidePlaceholderOnFocus = _defineAdditionalProp.hidePlaceholderOnFocus,
    placeholder = _defineAdditionalProp.placeholder,
    onChange = _defineAdditionalProp.onChange,
    withClearButton = _defineAdditionalProp.withClearButton,
    onFocus = _defineAdditionalProp.onFocus,
    onBlur = _defineAdditionalProp.onBlur,
    withPostFix = _defineAdditionalProp.withPostFix,
    otherProps = _objectWithoutProperties(_defineAdditionalProp, _excluded);
  var inputRef = useRef(null);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    inFocus = _useFlag2[0],
    setInFocus = _useFlag2[1];
  var onWrapperClick = function onWrapperClick() {
    var _inputRef$current;
    return (_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 ? void 0 : _inputRef$current.focus();
  };
  var focusEventHandler = function focusEventHandler(action) {
    return function (e) {
      var _ref;
      setInFocus.set(action === 'focus');
      (_ref = action === 'focus' ? onFocus : onBlur) === null || _ref === void 0 || _ref(e);
    };
  };
  var isPlaceholderVisible = !hidePlaceholderOnFocus || !inFocus;
  var placeholderString = postFix ? "".concat(placeholder, " ").concat(postFix) : placeholder;
  var view = readOnly ? 'default' : viewProp;
  return /*#__PURE__*/React.createElement("div", {
    className: cnInput({
      view: view,
      invert: invert
    }, [className]),
    "data-t-id": "Input-InputCore"
  }, /*#__PURE__*/React.createElement("div", {
    className: cnInput('wrapper', {
      disabled: disabled
    }),
    onClick: onWrapperClick
  }, /*#__PURE__*/React.createElement(ResizeInput, _extends({}, otherProps, {
    "aria-invalid": status === 'error',
    className: cnInput('field', {
      status: status,
      readOnly: readOnly
    }),
    containerClassName: cnInput('container'),
    disabled: disabled,
    onBlur: focusEventHandler('blur'),
    onChange: onChange,
    onFocus: focusEventHandler('focus'),
    placeholder: isPlaceholderVisible ? placeholderString : undefined,
    readOnly: readOnly,
    ref: combineRefs([ref, inputRef]),
    resizable: !!postFix,
    type: type,
    value: value
  })), withPostFix && /*#__PURE__*/React.createElement(Text, {
    "aria-hidden": true,
    className: cnInput('postfix'),
    style: _defineProperty({}, '--input-postfix-color', getPostFixColor(invert, disabled, status)),
    variant: "body-large"
  }, postFix)), (rightSide || onClear) && /*#__PURE__*/React.createElement("div", {
    className: cnInput('side', {
      disabled: disabled
    })
  }, rightSide, withClearButton && onClear && !readOnly && /*#__PURE__*/React.createElement(IconCloseRoundStroked, {
    "aria-label": "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u043F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430",
    className: cnInput('button'),
    color: invert ? 'tertiary-fake-invert' : 'tertiary',
    onClick: function onClick(e) {
      return onClear('', e);
    },
    tagName: "button",
    type: "button"
  })));
});