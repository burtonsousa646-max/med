export function ignoreState(getDerivedStateFromProps: any): (nextProps: any, prevState: any) => any;
export const __SecretPrevProps: "__prevRenderProps";
//# sourceMappingURL=ignoreState.d.ts.map