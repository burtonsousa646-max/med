export function getRegistry(): import("url").URL;
export function getWorkspacesInfo(): [string, any][] | undefined;
//# sourceMappingURL=common.d.ts.map