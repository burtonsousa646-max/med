import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "className"],
  _excluded2 = ["isOpen"];
import React, { forwardRef, useMemo, useRef } from 'react';
import { AnimatePresence } from 'framer-motion';
import { useFlag } from '@carnica/utils/hooks';
import { combineRefs } from '@carnica/utils';
import { Popover } from "../../../modules/Popover";
import { animationVariants, getClassName } from "./utils";
import { ActionSheetPopoverContext } from "./context";
var RenderPopover = /*#__PURE__*/forwardRef(function (props, ref) {
  var isOpen = props.isOpen,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    loading = _useFlag2[0],
    setLoading = _useFlag2[1];
  var popoverRef = useRef(null);
  var value = useMemo(function () {
    return {
      loading: loading,
      popoverRef: popoverRef,
      changeLoading: setLoading.set
    };
  }, [loading]);
  return /*#__PURE__*/React.createElement(ActionSheetPopoverContext.Provider, {
    value: value
  }, /*#__PURE__*/React.createElement(Popover, _extends({}, otherProps, {
    animate: "visible",
    className: getClassName(className, loading),
    direction: "downStartLeft",
    exit: "hidden",
    initial: "hidden",
    motion: true,
    offsetVertical: 8,
    possibleDirections: ['downStartLeft', 'upStartLeft'],
    ref: combineRefs([ref, popoverRef]),
    reposition: true,
    role: "listbox",
    variants: animationVariants,
    "data-t-id": "ActionSheet-ActionSheetPopover"
  })));
});
export var ActionSheetPopover = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var isOpen = _ref.isOpen,
    otherProps = _objectWithoutProperties(_ref, _excluded2);
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait",
    onExitComplete: function onExitComplete() {
      return null;
    }
  }, isOpen && /*#__PURE__*/React.createElement(RenderPopover, _extends({}, otherProps, {
    ref: ref
  })));
});