const {
  dirname,
  join,
  basename,
  resolve
} = require('path');
const fs = require('fs');

/**
 * Beef Changes Start
 * */
const generateBeefManifest = (compilation, files, {
  seed = {},
  isServer
}) => {
  let pages;
  const packageJson = resolve(process.cwd(), './package.json');
  if (packageJson) {
    try {
      pages = JSON.parse(fs.readFileSync(packageJson).toString())?.pages;
    } catch (e) {
      throw new Error('Something went wrong in process of parsing provided package.json');
    }
  }
  const result = files.reduce((manifest, file) => {
    const path = file.path.match(/^auto/) ? file.path.replace(/^auto\//, '') : file.path;
    return Object.assign(manifest, {
      [file.name]: isServer ? `server${path}` : path
    });
  }, seed);
  return {
    pages,
    paths: result
  };
};
/**
 * Beef Changes End
 * */

const generateManifest = (compilation, files, {
  generate,
  seed = {},
  isServer
}) => {
  let result;
  if (generate) {
    const entrypointsArray = Array.from(compilation.entrypoints.entries());
    const entrypoints = entrypointsArray.reduce((e, [name, entrypoint]) => Object.assign(e, {
      [name]: entrypoint.getFiles()
    }), {});
    result = generate(seed, files, entrypoints);
  } else {
    /**
     * Beef Changes Start
     * */
    result = generateBeefManifest(compilation, files, {
      generate,
      seed: {},
      isServer
    });
    /**
     * Beef Changes End
     * */
  }
  return result;
};
const getFileType = (fileName, {
  transformExtensions
}) => {
  const replaced = fileName.replace(/\?.*/, '');
  const split = replaced.split('.');
  const extension = split.pop();
  return transformExtensions.test(extension) ? `${split.pop()}.${extension}` : extension;
};
const reduceAssets = (files, asset, moduleAssets) => {
  let name;
  if (moduleAssets[asset.name]) {
    name = moduleAssets[asset.name];
  } else if (asset.info.sourceFilename) {
    name = join(dirname(asset.name), basename(asset.info.sourceFilename));
  }
  if (name) {
    return files.concat({
      isAsset: true,
      isChunk: false,
      isInitial: false,
      isModuleAsset: true,
      name,
      path: asset.name
    });
  }
  const isEntryAsset = asset.chunks && asset.chunks.length > 0;
  if (isEntryAsset) {
    return files;
  }
  return files.concat({
    isAsset: true,
    isChunk: false,
    isInitial: false,
    isModuleAsset: false,
    name: asset.name,
    path: asset.name
  });
};
const reduceChunk = (files, chunk, options, auxiliaryFiles) => {
  // auxiliary files contain things like images, fonts AND, most
  // importantly, other files like .map sourcemap files
  // we modify the auxiliaryFiles so that we can add any of these
  // to the manifest that was not added by another method
  // (sourcemaps files are not added via any other method)
  Array.from(chunk.auxiliaryFiles || []).forEach(auxiliaryFile => {
    auxiliaryFiles[auxiliaryFile] = {
      isAsset: true,
      isChunk: false,
      isInitial: false,
      isModuleAsset: true,
      name: basename(auxiliaryFile),
      path: auxiliaryFile
    };
  });
  return Array.from(chunk.files).reduce((prev, path) => {
    let name = chunk.name ? chunk.name : null;
    // chunk name, or for nameless chunks, just map the files directly.
    // eslint-disable-next-line no-nested-ternary,max-len
    name = name ? options.useEntryKeys && !path.endsWith('.map') ? name : `${name}.${getFileType(path, options)}` : path;
    return prev.concat({
      chunk,
      isAsset: false,
      isChunk: true,
      isInitial: chunk.isOnlyInitial(),
      isModuleAsset: false,
      name,
      path
    });
  }, files);
};
const standardizeFilePaths = file => {
  const result = {
    ...file
  };
  result.name = file.name.replace(/\\/g, '/');
  result.path = file.path.replace(/\\/g, '/');
  return result;
};
const transformFiles = (files, options) => ['filter', 'map', 'sort'].filter(fname => !!options[fname])
// TODO: deprecate these
.reduce(
// Note: We want to access the filter, map, and sort functions on an array. TS sucks at this
// so we cast to something it can't complain about
(prev, fname) => prev[fname](options[fname]), files).map(standardizeFilePaths);

/**
 * Beef Changes Start
 * */
const removeServerManifest = compilation => {
  const serverManifestFile = compilation.getAsset('server.manifest.json');
  if (serverManifestFile) {
    compilation.updateAsset('manifest.json', serverManifestFile.source);
    compilation.deleteAsset('server.manifest.json');
  }
};
/**
 * Beef Changes End
 * */

module.exports = {
  generateManifest,
  reduceAssets,
  reduceChunk,
  transformFiles,
  removeServerManifest
};