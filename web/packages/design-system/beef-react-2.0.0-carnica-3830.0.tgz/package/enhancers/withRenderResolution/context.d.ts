export type TRenderResolution = null | number;
export declare const RenderResolutionContext: import("react").Context<TRenderResolution>;
export declare const useRenderResolution: () => number;
//# sourceMappingURL=context.d.ts.map