import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["setActiveGroup", "searchValue", "activeGroup", "setSearchValue", "onClose", "searchProps", "value", "withSearchField", "groups", "onChangeGroup", "className", "loading", "filteredItemsMap"];
import React, { forwardRef, useCallback, useEffect, useRef } from 'react';
import { cnBem } from '@carnica/utils';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import { IconChevronLeft } from '@carnica/graphics';
import { Button } from "../../Button";
import { SearchField } from "../../SearchField";
import { Skeleton } from "../../Skeleton";
import styles from "./styles.module.css";
import { PickerTabs } from "./PickerTabs";
var cnPickerFilters = cnBem('picker-filters', styles);
export var PickerFilters = /*#__PURE__*/forwardRef(function (props, ref) {
  var setActiveGroup = props.setActiveGroup,
    searchValue = props.searchValue,
    activeGroup = props.activeGroup,
    setSearchValue = props.setSearchValue,
    onClose = props.onClose,
    searchProps = props.searchProps,
    value = props.value,
    withSearchField = props.withSearchField,
    groups = props.groups,
    onChangeGroup = props.onChangeGroup,
    className = props.className,
    loading = props.loading,
    filteredItemsMap = props.filteredItemsMap,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  var buttonRef = useRef(null);
  var handleChangeSearch = useCallback(function (newValue, e) {
    var _searchProps$onChange;
    setSearchValue(newValue);
    searchProps === null || searchProps === void 0 || (_searchProps$onChange = searchProps.onChange) === null || _searchProps$onChange === void 0 || _searchProps$onChange.call(searchProps, newValue, e);
  }, [searchProps === null || searchProps === void 0 ? void 0 : searchProps.onChange]);
  useEffect(function () {
    var _buttonRef$current;
    (_buttonRef$current = buttonRef.current) === null || _buttonRef$current === void 0 || _buttonRef$current.focus();
  }, []);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnPickerFilters(null, [className]),
    ref: ref
  }, otherProps, {
    "data-t-id": "Picker-PickerFilters"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnPickerFilters('filters')
  }, /*#__PURE__*/React.createElement(Button, {
    "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u043A\u043D\u043E \u0432\u044B\u0431\u043E\u0440\u0430",
    iconLeft: IconChevronLeft,
    onClick: onClose,
    onlyIcon: true,
    ref: buttonRef,
    size: "m",
    type: "button",
    view: "secondary-on-primary"
  }), withSearchField && /*#__PURE__*/React.createElement(SearchField, _extends({}, searchProps || {}, {
    className: cnPickerFilters('search', [searchProps === null || searchProps === void 0 ? void 0 : searchProps.className]),
    disabled: loading,
    onCancel: function onCancel() {
      return setSearchValue('');
    },
    onChange: handleChangeSearch,
    onClear: function onClear() {
      return setSearchValue('');
    },
    placeholder: (searchProps === null || searchProps === void 0 ? void 0 : searchProps.placeholder) || 'найти что-то?',
    value: searchValue
  }))), loading && !!groups.length && /*#__PURE__*/React.createElement(Skeleton.Tabs, {
    "aria-label": "\u0418\u0434\u0451\u0442 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0430",
    className: cnPickerFilters('skeleton'),
    length: 5,
    size: isMobile ? 's' : 'm'
  }), !loading && !!groups.length && /*#__PURE__*/React.createElement(PickerTabs, {
    activeGroup: activeGroup,
    filteredItemsMap: filteredItemsMap,
    groups: groups,
    isMobile: isMobile,
    onChangeGroup: onChangeGroup,
    setActiveGroup: setActiveGroup,
    value: value
  }));
});