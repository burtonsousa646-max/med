export function inheritPropTypes(Component: any, Ancestor: any, { omit }?: {
    omit?: never[] | undefined;
}): any;
//# sourceMappingURL=inheritPropTypes.d.ts.map