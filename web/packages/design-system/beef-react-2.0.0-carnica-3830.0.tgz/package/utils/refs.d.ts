import { MutableRefObject, RefCallback } from 'react';
export type MixedRef<T> = MutableRefObject<T> | RefCallback<T>;
export declare function setRef<T>(val: T, ...refs: (MixedRef<T> | undefined)[]): void;
//# sourceMappingURL=refs.d.ts.map