import React from 'react';
import type { HTMLMotionProps } from 'framer-motion';
import type { PropsWithTagAttributes } from './PropsWithAttributes';
import type { MotionTags, TagTypeAttributes } from './TagType';
export type HTMLAttributesWithMotion<TAG extends MotionTags = 'div', ELEMENT extends HTMLElement = HTMLDivElement> = ({
    motion: true;
} & HTMLMotionProps<TAG>) | ({
    motion?: false;
} & React.HTMLAttributes<ELEMENT>);
type PropsForTagElement<Tag extends MotionTags | React.ElementType> = Tag extends MotionTags ? HTMLMotionProps<Tag> : Omit<React.ComponentProps<Tag>, keyof HTMLMotionProps<'section'>> & HTMLMotionProps<'section'>;
type TagComponent<Tag extends React.ElementType> = React.ComponentProps<Tag> extends HTMLMotionProps<'section'> ? Tag : never;
type TagName<Tag extends MotionTags | React.ElementType> = Tag extends MotionTags ? Tag : TagComponent<Tag>;
export type PropsWithMotionTagAttributes<Props, AllowedTags extends MotionTags, Tag extends AllowedTags | React.ElementType> = Props & {
    motion?: boolean;
    tagName?: TagName<Tag>;
} & Omit<PropsForTagElement<Tag>, keyof Props>;
export type MotionTagProps<Props, AllowedTags extends MotionTags, Tag extends AllowedTags | React.ElementType, MOTION extends boolean = false> = {
    motion?: MOTION;
} & (MOTION extends true ? PropsWithMotionTagAttributes<Props, AllowedTags, Tag> : PropsWithTagAttributes<Props, AllowedTags, Tag>) & React.RefAttributes<Element>;
export type PropsWithMotionAttributes<Props, Tag extends MotionTags> = Props & Omit<HTMLMotionProps<Tag>, 'css' | keyof Props>;
type TagProps<Tag extends MotionTags | React.ElementType, MOTION extends boolean = false> = Tag extends MotionTags ? MOTION extends true ? HTMLMotionProps<Tag> : TagTypeAttributes<Tag> : React.ComponentProps<Tag> & (MOTION extends true ? HTMLMotionProps<'section'> : React.HTMLAttributes<HTMLElement>);
export type MotionProps<Props, Tag extends MotionTags | React.ElementType, MOTION extends boolean = false> = Props & {
    motion?: MOTION;
} & Omit<TagProps<Tag, MOTION>, keyof Props> & React.RefAttributes<Element>;
export type ComponentWithMotionTag<Props, AllowedTags extends MotionTags, DefaultTag extends AllowedTags> = <Tag extends AllowedTags | React.ElementType = DefaultTag, MOTION extends boolean = false>(props: MotionTagProps<Props, AllowedTags, Tag, MOTION>) => React.ReactElement | null;
export type ComponentWithMotion<Props, Tag extends MotionTags | React.ElementType> = <MOTION extends boolean = false>(props: MotionProps<Props, Tag, MOTION>) => React.ReactElement | null;
export {};
//# sourceMappingURL=MotionProps.d.ts.map