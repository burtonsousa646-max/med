export var badgeV3PropColor = ['default-on-bg-primary', 'default-on-bg-secondary', 'default-on-bg-tertiary', 'brand', 'invert', 'accent', 'error', 'success'];
export var badgeV3PropView = ['dot', 'text', 'icon', 'logo'];
export var badgeV3PropSize = ['xs', 's', 'm'];