import { addDays, addMonths, differenceInDays, differenceInMonths, endOfMonth, endOfWeek, endOfYear, isWithinInterval, startOfMonth, startOfWeek, startOfYear } from 'date-fns-new';
// TODO: Переработать в будующем на бесконечный виртуальный скролл
export var DEFAULT_START_YEAR = 1900;
export var DEFAULT_YEARS_COUNT = 201;
export var getDaysOfMonth = function getDaysOfMonth(date, locale) {
  var startDate = startOfWeek(startOfMonth(date), {
    locale: locale,
    weekStartsOn: 1
  });
  var endDate = endOfWeek(endOfMonth(date), {
    locale: locale,
    weekStartsOn: 1
  });
  var diffDays = differenceInDays(endDate, startDate) + 1;
  return Array.from({
    length: diffDays
  }).map(function (_, i) {
    return addDays(startDate, i);
  });
};
export var getMonthList = function getMonthList(date) {
  var startDate = startOfYear(date);
  var endDate = endOfYear(date);
  var diffMonths = differenceInMonths(endDate, startDate) + 1;
  return Array.from({
    length: diffMonths
  }).map(function (_, i) {
    return addMonths(startDate, i);
  });
};
export var isEqalDate = function isEqalDate(firstDate, secondDate) {
  return firstDate.getFullYear() === secondDate.getFullYear() && firstDate.getMonth() === secondDate.getMonth() && firstDate.getDate() === secondDate.getDate();
};
export var isToday = function isToday(date) {
  return isEqalDate(date, new Date());
};
export var isInInterval = function isInInterval(date, firstDate, secondDate) {
  if (firstDate && secondDate) {
    return isWithinInterval(date, {
      start: firstDate,
      end: secondDate
    });
  }
  if (firstDate) {
    return date.getTime() >= firstDate.getTime();
  }
  if (secondDate) {
    return date.getTime() <= secondDate.getTime();
  }
  return true;
};