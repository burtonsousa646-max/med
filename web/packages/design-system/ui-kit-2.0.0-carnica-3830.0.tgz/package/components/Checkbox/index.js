import { defineControl } from "./utils";
export var Checkbox = defineControl('checkbox');
export var Radio = defineControl('radio');