import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["tagName", "children", "className", "size", "disabled", "invert", "onClick", "accent"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithTag } from '@carnica/utils';
import React from 'react';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnTabBarItem = cnBem('tabbar-item', styles);
export var TabBarItem = forwardRefWithTag(function (props, ref) {
  var _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'button' : _props$tagName,
    children = props.children,
    className = props.className,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    disabled = props.disabled,
    invert = props.invert,
    onClickProp = props.onClick,
    accent = props.accent,
    otherProps = _objectWithoutProperties(props, _excluded);
  var onClick = function onClick(e) {
    if (!disabled) {
      onClickProp === null || onClickProp === void 0 || onClickProp(e);
    }
  };
  var innerProps = _objectSpread(_objectSpread({}, otherProps), {}, {
    ref: ref,
    tagName: tagName,
    onClick: onClick,
    disabled: disabled
  });
  return /*#__PURE__*/React.createElement(Text, _extends({}, innerProps, {
    className: cnTabBarItem({
      disabled: disabled,
      accent: accent,
      size: size,
      invert: invert
    }, [className]),
    variant: "body-small",
    "data-t-id": "TabBar-TabBarItem"
  }), children);
});