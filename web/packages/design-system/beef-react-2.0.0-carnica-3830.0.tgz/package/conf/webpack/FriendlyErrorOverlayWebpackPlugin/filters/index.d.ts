export function setErrorFiltersInlineTemplate(errorFilters: string[]): string;
export function runtimeErrorFilter(err: any): any;
//# sourceMappingURL=index.d.ts.map