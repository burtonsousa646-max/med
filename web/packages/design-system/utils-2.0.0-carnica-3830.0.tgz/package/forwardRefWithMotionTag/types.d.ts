import React from 'react';
import type { MotionTagProps, MotionTags, PropsWithMotionTagAttributes } from '../types';
export type ForwardRefWithMotionTag<Props, AllowedTags extends MotionTags = MotionTags, HTMLElementType = HTMLElement> = <Tag extends AllowedTags>(props: MotionTagProps<Props, AllowedTags, Tag>, ref: React.Ref<HTMLElementType>) => React.ReactElement | null;
export type ForwardRefWithMotion<Props, Tag extends MotionTags, HTMLElementType = HTMLElement> = (props: PropsWithMotionTagAttributes<Props, Tag, Tag>, ref: React.Ref<HTMLElementType>) => React.ReactElement | null;
//# sourceMappingURL=types.d.ts.map