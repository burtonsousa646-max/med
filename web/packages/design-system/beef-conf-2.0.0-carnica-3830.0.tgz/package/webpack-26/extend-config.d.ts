import type { Configuration } from 'webpack';
import type { BuildEnv } from './types';
type CloneConfiguration = {
    [key in keyof Configuration]: any;
};
export type { Configuration };
export declare const extendConfig: <C extends CloneConfiguration = Configuration, E extends CloneConfiguration = Configuration>(config: ((env: BuildEnv) => C) | C, extendFn: (env: BuildEnv) => E) => (env: BuildEnv) => C & E;
//# sourceMappingURL=extend-config.d.ts.map