export = ForgeModulePlugin;
declare class ForgeModulePlugin {
    static generateModulePath(prefix: any): string;
    constructor(options?: PluginOptions);
    pluginName: string;
    virtualModules: VirtualModulePlugin;
    options: PluginOptions;
    apply(compiler: Compiler): void;
    compiler: import("webpack").Compiler | undefined;
    insertModule(moduleName: any, moduleContent: any): void;
}
declare namespace ForgeModulePlugin {
    export { Compiler, VirtualModulePlugin, PluginOptions };
}
import VirtualModulePlugin = require("webpack-virtual-modules");
type Compiler = import("webpack").Compiler;
type VirtualModulePlugin = import("webpack-virtual-modules");
type PluginOptions = {
    replacePath?: string;
    moduleContent: string;
};
//# sourceMappingURL=index.d.ts.map