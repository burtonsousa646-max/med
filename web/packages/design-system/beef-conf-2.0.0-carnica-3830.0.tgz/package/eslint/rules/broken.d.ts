export let rules: {
    'react/no-unused-state': number;
    'import/no-extraneous-dependencies': number;
};
//# sourceMappingURL=broken.d.ts.map