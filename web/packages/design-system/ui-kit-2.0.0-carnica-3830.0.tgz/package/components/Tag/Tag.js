import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "iconLeft", "iconRight", "children", "view", "iconSize", "size", "icon"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { Text } from "../Text";
import { contentSizeMap, dataConverter, useWarning } from "./utils";
import styles from "./styles.module.css";
var cnTag = cnBem('tag', styles);
var TagRender = function TagRender(_ref, ref) {
  var className = _ref.className,
    IconLeft = _ref.iconLeft,
    IconRight = _ref.iconRight,
    children = _ref.children,
    view = _ref.view,
    iconSize = _ref.iconSize,
    size = _ref.size,
    icon = _ref.icon,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  useWarning({
    icon: icon,
    view: view
  });
  return /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    className: cnTag({
      size: size,
      view: view
    }, [className]),
    color: "primary",
    ref: ref,
    variant: contentSizeMap[size],
    "data-t-id": "components-Tag"
  }), IconLeft && /*#__PURE__*/React.createElement(IconLeft, {
    customColor: "var(--tag-color)",
    "data-side": "left",
    size: iconSize
  }), children && /*#__PURE__*/React.createElement("span", {
    className: cnTag('text')
  }, children), IconRight && /*#__PURE__*/React.createElement(IconRight, {
    customColor: "var(--tag-color)",
    "data-side": "right",
    size: iconSize
  }));
};
export var Tag = compose(withDataConverter(dataConverter), forwardRef)(TagRender);