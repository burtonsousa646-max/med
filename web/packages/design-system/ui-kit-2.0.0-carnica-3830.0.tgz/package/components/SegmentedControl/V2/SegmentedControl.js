import _extends from "@babel/runtime/helpers/extends";
import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["value", "disabled", "items", "name", "invert", "onChange", "convertItem"];
import React, { forwardRef, useCallback, useMemo } from 'react';
import { useMutableRef } from '@carnica/utils/hooks';
import { createItemProps, defaultConvertItem } from "./utils";
import { SegmentedControlItem } from "./SegmentedControlItem";
import { useSegmentedControlKeyboardHandler } from "../hooks/useSegmentedControlKeyboardHandler";
import { SegmentedControlCore } from "../core";
var SegmentedControlRender = function SegmentedControlRender(props, ref) {
  var value = props.value,
    disabled = props.disabled,
    itemsProp = props.items,
    _props$name = props.name,
    name = _props$name === void 0 ? 'segmented-control' : _props$name,
    invert = props.invert,
    onChange = props.onChange,
    _props$convertItem = props.convertItem,
    convertItem = _props$convertItem === void 0 ? defaultConvertItem : _props$convertItem,
    otherProps = _objectWithoutProperties(props, _excluded);
  var onChangeRef = useMutableRef(onChange);
  var convertItemRef = useMutableRef(convertItem);
  var items = useMemo(function () {
    return (itemsProp || []).map(function (item) {
      return {
        converted: convertItem(item),
        original: item
      };
    });
  }, [convertItem, itemsProp]);
  var _useMemo = useMemo(function () {
      return {
        activeIndex: value && Array.isArray(items) ? items.findIndex(function (_ref) {
          var converted = _ref.converted;
          return converted.key === convertItem(value).key;
        }) : -1,
        disabledIndexes: items === null || items === void 0 ? void 0 : items.reduce(function (acc, _ref2, i) {
          var converted = _ref2.converted;
          if (!converted.disabled && !disabled) {
            return acc;
          }
          return [].concat(_toConsumableArray(acc), [i]);
        }, [])
      };
    }, [items, value, disabled]),
    activeIndex = _useMemo.activeIndex,
    disabledIndexes = _useMemo.disabledIndexes;
  var _useSegmentedControlK = useSegmentedControlKeyboardHandler(items),
    tabRefs = _useSegmentedControlK.tabRefs,
    onKeyDownByItem = _useSegmentedControlK.onKeyDownByItem;
  var handleChange = useCallback(function (item) {
    return function (e) {
      var _onChangeRef$current;
      (_onChangeRef$current = onChangeRef.current) === null || _onChangeRef$current === void 0 || _onChangeRef$current.call(onChangeRef, item, e);
    };
  }, []);
  var convertedItems = useMemo(function () {
    return createItemProps({
      items: items,
      value: value,
      disabled: disabled,
      name: name,
      tabRefs: tabRefs,
      convertItem: convertItemRef.current,
      onKeyDown: onKeyDownByItem,
      onChange: handleChange
    });
  }, [items, value, onKeyDownByItem, disabled]);
  return /*#__PURE__*/React.createElement(SegmentedControlCore, _extends({}, otherProps, {
    activeIndex: activeIndex,
    disabled: disabled,
    disabledIndexes: disabledIndexes,
    invert: invert,
    itemsCount: (items === null || items === void 0 ? void 0 : items.length) || 0,
    ref: ref,
    "data-t-id": "SegmentedControl-V2"
  }), convertedItems === null || convertedItems === void 0 ? void 0 : convertedItems.map(function (params) {
    return /*#__PURE__*/React.createElement(SegmentedControlItem, _extends({}, params, {
      invert: invert,
      key: params.key
    }));
  }));
};
export var SegmentedControl = /*#__PURE__*/forwardRef(SegmentedControlRender);