import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "value", "multiple", "onChange", "getters", "onItemClick", "color", "convertItem", "renderItem", "layout", "disabled", "invert", "reorderItems"];
import React, { forwardRef, useCallback } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { MotionComponent } from "../../modules/MotionComponent";
import { dataConverter, defaultRenderChips, getItemActive, isNullbaleRender } from "./utils";
import { useChipsGroup } from "./hooks/useChipsGroup";
import { useWrapperAnimation } from "./hooks/useWrapperAnimation";
import { ChipsGroupWrapper } from "./ChipsGroupWrapper";
import styles from "./styles.module.css";
var cnChipsGroup = cnBem('chips-group', styles);
var ChipsGroupRender = function ChipsGroupRender(props, ref) {
  var itemsProp = props.items,
    valueProp = props.value,
    multiple = props.multiple,
    onChange = props.onChange,
    getters = props.getters,
    onItemClickProp = props.onItemClick,
    color = props.color,
    convertItem = props.convertItem,
    renderItem = props.renderItem,
    _props$layout = props.layout,
    layout = _props$layout === void 0 ? 'wrap' : _props$layout,
    disabled = props.disabled,
    invert = props.invert,
    reorderItems = props.reorderItems,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useChipsGroup = useChipsGroup({
      items: itemsProp,
      onItemClick: onItemClickProp,
      value: valueProp,
      onChange: onChange,
      multiple: multiple,
      getters: getters,
      convertItem: convertItem,
      reorderItems: reorderItems,
      layout: layout
    }),
    value = _useChipsGroup.value,
    onItemClick = _useChipsGroup.onItemClick,
    items = _useChipsGroup.items;
  var _useWrapperAnimation = useWrapperAnimation({
      layout: layout,
      isRow: !!value.length,
      itemsCount: items.length
    }),
    wrapperRef = _useWrapperAnimation.wrapperRef,
    itemRefs = _useWrapperAnimation.itemRefs;
  var renderItemDefault = useCallback(function (item, isActive) {
    return defaultRenderChips({
      params: {
        onItemClick: onItemClick,
        color: color,
        disabled: disabled,
        invert: invert
      },
      item: item,
      isActive: isActive
    });
  }, [color, disabled, invert, onItemClick]);
  return /*#__PURE__*/React.createElement(ChipsGroupWrapper, _extends({}, otherProps, {
    isRow: !!value.length,
    itemsCount: items.length || 10,
    layout: layout,
    ref: combineRefs([ref, wrapperRef]),
    "data-t-id": "components-ChipsGroup"
  }), items.map(function (item, i) {
    var isActive = getItemActive(item, value);
    var content = renderItem ? renderItem(item.original, isActive) : renderItemDefault(item, isActive);
    if (isNullbaleRender(content)) {
      return null;
    }
    return /*#__PURE__*/React.createElement(MotionComponent, _extends({
      key: item.converted.key
    }, layout === 'collapse' ? {
      motion: true,
      layout: true
    } : {}, {
      className: cnChipsGroup('item'),
      ref: itemRefs[i],
      tagName: "div"
    }), content);
  }));
};
export var ChipsGroup = compose(withDataConverter(dataConverter), forwardRef)(ChipsGroupRender);