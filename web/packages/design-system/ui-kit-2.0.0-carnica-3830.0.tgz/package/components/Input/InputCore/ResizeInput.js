import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "resizable", "readOnly", "containerClassName"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import styles from "./styles.module.css";
var cnResizeInput = cnBem('resize', styles);
var getCurrentValue = function getCurrentValue(props) {
  return props['data-masked-value'] || props.value || props.placeholder;
};
export var ResizeInput = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var className = _ref.className,
    _ref$resizable = _ref.resizable,
    resizable = _ref$resizable === void 0 ? true : _ref$resizable,
    readOnly = _ref.readOnly,
    containerClassName = _ref.containerClassName,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return resizable ? /*#__PURE__*/React.createElement("div", {
    className: cnResizeInput({
      readOnly: readOnly
    }, [containerClassName]),
    "data-t-id": "Input-InputCore"
  }, /*#__PURE__*/React.createElement("input", _extends({}, otherProps, {
    className: cnResizeInput('input', {
      readOnly: readOnly
    }, [className]),
    readOnly: readOnly,
    ref: ref
  })), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    className: cnResizeInput('text', {
      readOnly: readOnly
    })
  }, getCurrentValue(otherProps))) : /*#__PURE__*/React.createElement("input", _extends({}, otherProps, {
    className: className,
    readOnly: readOnly,
    ref: ref
  }));
});