import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/* eslint-disable react-hooks/rules-of-hooks, import/order */
import { createRequireLinked } from '@beef/conf/utils';
import { provideSmartGetLocalIdent } from "../webpack/utils";
import FriendlyErrorOverlayPlugin from "../webpack/FriendlyErrorOverlayWebpackPlugin";
import { baseToolkit, extendPlugin, extendToolkit } from '@beef/conf/webpack-26';
import HtmlWebpackPlugin from 'html-webpack-plugin';
import MiniCssExtractPlugin from 'mini-css-extract-plugin';
import CssMinimizerPlugin from 'css-minimizer-webpack-plugin';
import ReactRefreshWebpackPlugin from '@pmmmwh/react-refresh-webpack-plugin';
import ForkTsCheckerWebpackPlugin from 'fork-ts-checker-webpack-plugin';
/**
 * Очень грязный хак по сохранению типов при использовании относительных импортов через require
 */

var require = createRequireLinked(__dirname);
export var reactToolkit = extendToolkit(baseToolkit, function (base) {
  return {
    plugins: {
      MiniCssExtractPlugin: MiniCssExtractPlugin,
      CssMinimizerPlugin: CssMinimizerPlugin,
      HtmlWebpackPlugin: extendPlugin(HtmlWebpackPlugin, {
        /**
         * При передаче опции legacyTemplate: true, beef-build генерирует index.htm с подключенными стилями и js,
         * В ином случае и по умолчанию, index.htm содержит виджетные зоны {{{headSection|bodySection}}}
         * Используемые NodeSSR-сервисом
         */
        forEntry: function forEntry(_ref) {
          var filePath = _ref.filePath;
          var _ref2 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
            _ref2$legacyTemplate = _ref2.legacyTemplate,
            legacyTemplate = _ref2$legacyTemplate === void 0 ? false : _ref2$legacyTemplate;
          return {
            template: filePath,
            templateParameters: _objectSpread({
              title: 'Локальная страница',
              Component: 'Components.App',
              isProduction: true,
              model: JSON.stringify({})
            }, legacyTemplate ? {
              headSection: '',
              bodySection: '',
              renderScript: ''
            } : {
              headSection: '{{{headSection}}}',
              bodySection: '{{{bodySection}}}',
              renderScript: ''
            }),
            inject: false
          };
        }
      }),
      ReactRefreshWebpackPlugin: ReactRefreshWebpackPlugin,
      FriendlyErrorOverlayPlugin: FriendlyErrorOverlayPlugin,
      ForkTsCheckerWebpackPlugin: ForkTsCheckerWebpackPlugin
    },
    get _loaders() {
      return _objectSpread(_objectSpread({}, base._loaders), {}, {
        expose: require.resolve('expose-loader'),
        css: require.resolve('css-loader'),
        pcss: require.resolve('postcss-loader'),
        style: require.resolve('style-loader'),
        svgr: require.resolve('@svgr/webpack'),
        miniCssExtractLoader: this.plugins.MiniCssExtractPlugin.loader,
        pug: require.resolve('pug-loader')
      });
    },
    get rules() {
      return _objectSpread(_objectSpread({}, base.rules), {}, {
        pcss: /\.pcss$/i,
        css: /\.css$/i,
        img: /\.(png|jpe?g|gif)$/i,
        font: /\.(woff|woff2|eot|ttf|otf)$/i,
        svg: /\.svg$/i,
        pug: /\.pug$/i,
        docs: /\.(htm|pdf)$/i
      });
    },
    get loaders() {
      var _this = this;
      var _loaders = this._loaders;
      return _objectSpread(_objectSpread({}, base.loaders), {}, {
        expose: function expose(exposes) {
          return {
            loader: _this._loaders.expose,
            options: {
              exposes: exposes
            }
          };
        },
        pcss: {
          loader: _loaders.pcss
        },
        css: function css(_ref3) {
          var isProduction = _ref3.isProduction;
          return {
            loader: _loaders.css,
            options: {
              importLoaders: 1,
              modules: {
                localIdentName: isProduction ? '[smart-hash]' : '[smart-name]_[local]_[smart-hash]',
                getLocalIdent: provideSmartGetLocalIdent()
              }
            }
          };
        },
        rawCss: {
          loader: _loaders.css
        },
        svg: {
          loader: _loaders.svgr,
          options: {
            svgo: true,
            svgoConfig: {
              plugins: [{
                name: 'preset-default',
                params: {
                  overrides: {
                    removeViewBox: false,
                    // Запрещаем удалять <defs>
                    removeUselessDefs: false,
                    // Запрещаем удалять ID
                    cleanupIds: {
                      minify: true,
                      remove: false
                    },
                    // Отключаем схлопывание групп, чтобы сохранить transform
                    collapseGroups: false
                  }
                }
              },
              // Убераем возможные пересечения ID при минификации
              'prefixIds']
            }
          },
          type: 'javascript/auto',
          issuer: /\.[jt]sx?$/
        },
        url: {
          options: {
            limit: 8192,
            name: 'assets/[hash:base64:10].[ext]'
          },
          type: 'javascript/auto'
        },
        cssExtract: function cssExtract(_ref4) {
          var isServer = _ref4.isServer,
            isHMR = _ref4.isHMR;
          return isHMR ? undefined : {
            loader: _loaders.miniCssExtractLoader,
            options: {
              emit: !isServer
            }
          };
        },
        style: function style(_ref5) {
          var isHMR = _ref5.isHMR;
          return isHMR ? {
            loader: _loaders.style
          } : undefined;
        },
        pug: {
          loader: _loaders.pug
        },
        resourceUrl: {
          resourceQuery: /url/,
          type: 'asset/resource'
        }
      });
    }
  };
});