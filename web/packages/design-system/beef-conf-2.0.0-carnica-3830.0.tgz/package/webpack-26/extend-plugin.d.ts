import type { Ctor } from './common';
type ValueOrCompose<T> = ((...args: any[]) => T) | T;
export declare function extendPlugin<C, P extends Record<string, ValueOrCompose<C extends Ctor ? ConstructorParameters<C>[0] : never>>>(Plugin: C, presets: P): C & {
    [K in keyof P]: P[K] extends (...args: infer A) => any ? (...args: A) => InstanceType<C extends Ctor ? C : never> : InstanceType<C extends Ctor ? C : never>;
};
export {};
//# sourceMappingURL=extend-plugin.d.ts.map