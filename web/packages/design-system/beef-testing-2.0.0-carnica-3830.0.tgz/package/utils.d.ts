export declare const encodeUrl: (url: string) => string;
export declare const typeToExtension: (type: string) => "htm" | "json";
export declare const sanitizeUrl: (url: string) => string;
export declare const convertSearchParamsToObject: (searchParams: URLSearchParams) => Record<string, string>;
export declare const findFiles: (dirPath: string, fileName: string) => string[];
//# sourceMappingURL=utils.d.ts.map