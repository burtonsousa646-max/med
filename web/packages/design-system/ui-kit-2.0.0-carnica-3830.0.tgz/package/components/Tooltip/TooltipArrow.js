import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["direction", "style"],
  _excluded2 = ["width", "height"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React from 'react';
import { getTooltipArrowPosition, splitDirection } from "./utils";
var getPath = function getPath(dir) {
  var direction = splitDirection(dir)[0];
  if (direction === 'right') {
    return 'M7.99999 -1.07324e-07L11 -1.43098e-07L11 28L8 28L7.99999 24.7242C7.99999 23.6237 7.54658 22.5718 6.74649 21.8161L2.07911 17.4081C0.407771 15.8296 0.407767 13.1704 2.07911 11.592L6.74649 7.18386C7.54657 6.42823 7.99999 5.37633 7.99999 4.27581L7.99999 -1.07324e-07Z';
  }
  if (direction === 'left') {
    return 'M3.00001 28L8.58307e-06 28L4.14859e-06 1.76425e-06L3 1.80002e-06L3.00001 3.27582C3.00001 4.37633 3.45342 5.42822 4.25351 6.18386L8.92089 10.5919C10.5922 12.1704 10.5922 14.8296 8.92089 16.408L4.25351 20.8161C3.45343 21.5718 3.00001 22.6237 3.00001 23.7242L3.00001 28Z';
  }
  if (direction === 'up') {
    return 'M1.57361e-06 3.00001L2.09815e-06 8.58307e-06L28 8.71037e-06L28 3.00001L24.7242 3.00001C23.6237 3.00001 22.5718 3.45343 21.8161 4.25351L17.4081 8.92089C15.8296 10.5922 13.1704 10.5922 11.592 8.9209L7.18387 4.25352C6.42823 3.45343 5.37633 3.00001 4.27582 3.00001L1.57361e-06 3.00001Z';
  }
  return 'M28 7.99999L28 11L8.58276e-07 11L1.12054e-06 7.99999L3.27582 7.99999C4.37633 7.99999 5.42822 7.54658 6.18386 6.74649L10.5919 2.07911C12.1704 0.40777 14.8296 0.407766 16.408 2.0791L20.8161 6.74648C21.5718 7.54657 22.6237 7.99999 23.7242 7.99999L28 7.99999Z';
};
export var TooltipArrow = function TooltipArrow(_ref) {
  var direction = _ref.direction,
    style = _ref.style,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _getTooltipArrowPosit = getTooltipArrowPosition(direction),
    width = _getTooltipArrowPosit.width,
    height = _getTooltipArrowPosit.height,
    positionStyle = _objectWithoutProperties(_getTooltipArrowPosit, _excluded2);
  return /*#__PURE__*/React.createElement("svg", _extends({}, otherProps, {
    "aria-hidden": true,
    fill: "none",
    height: height,
    role: "presentation",
    style: _objectSpread(_objectSpread({}, style), positionStyle),
    viewBox: "0 0 ".concat(width, " ").concat(height),
    width: width,
    xmlns: "http://www.w3.org/2000/svg",
    "data-t-id": "components-Tooltip"
  }), /*#__PURE__*/React.createElement("path", {
    d: getPath(direction),
    fill: "var(--tooltip-color)"
  }));
};