import { getClassName } from "./getClassName";
export var cnBem = function cnBem(prefix, styles) {
  return function (elemOrMods, elemModsOrBlockMix, elemMix) {
    return getClassName(prefix, styles, elemOrMods, elemModsOrBlockMix, elemMix);
  };
};