import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "items", "convertItem", "getters", "counterSettings", "badgeClassName", "size", "disabled", "visibleCount", "wrap"],
  _excluded2 = ["className"];
import React, { forwardRef, useMemo } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { Avatar } from "../Avatar";
import { useConvertedItems } from "../../hooks/useConvertedItems";
import { avatarSizeMap } from "../Avatar/utils";
import { dataConverter, defaultGetItemBgColor, defaultGetItemInvert, getAvatarProps, itemKeys } from "./utils";
import styles from "./styles.module.css";
import { AvatarGroupCore } from "./core";
import { useVisibleItems } from "./hooks/useVisibleItems";
var cnAvatarGroup = cnBem('avatar-group', styles);
var AvatarGroupRender = function AvatarGroupRender(props, ref) {
  var className = props.className,
    itemsProp = props.items,
    convertItem = props.convertItem,
    getters = props.getters,
    counterSettings = props.counterSettings,
    badgeClassName = props.badgeClassName,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    disabled = props.disabled,
    visibleCount = props.visibleCount,
    wrap = props.wrap,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useVisibleItems = useVisibleItems((itemsProp === null || itemsProp === void 0 ? void 0 : itemsProp.length) || 0, avatarSizeMap[size], wrap && typeof visibleCount !== 'number' ? undefined : visibleCount),
    parentRef = _useVisibleItems.parentRef,
    hiddenCount = _useVisibleItems.hiddenCount,
    visibleItems = _useVisibleItems.visibleItems;
  var items = useConvertedItems({
    items: itemsProp || [],
    getters: getters,
    keys: itemKeys,
    convertItem: convertItem
  });
  var renderableItems = useMemo(function () {
    return items.slice(0, visibleItems);
  }, [items, visibleItems]);
  useDeprecationWarning({
    getItemInvert: {
      value: getters.getItemInvert === defaultGetItemInvert ? undefined : true,
      newPropKey: 'getItemColor'
    },
    getItemBgColor: {
      value: getters.getItemBgColor === defaultGetItemBgColor ? undefined : true,
      newPropKey: 'getItemColor'
    }
  });
  return /*#__PURE__*/React.createElement(AvatarGroupCore, _extends({}, otherProps, {
    className: cnAvatarGroup(null, [className]),
    ref: combineRefs([ref, parentRef]),
    size: size,
    wrap: wrap,
    "data-t-id": "components-AvatarGroup"
  }), renderableItems.map(function (item, i) {
    var _item$disabled;
    var _ref = item.attributes || {},
      itemClassName = _ref.className,
      itemProps = _objectWithoutProperties(_ref, _excluded2);
    return /*#__PURE__*/React.createElement(Avatar, _extends({}, itemProps, {
      badgeClassName: cnAvatarGroup('badge', [badgeClassName]),
      className: cnAvatarGroup('item', [itemClassName]),
      disabled: (_item$disabled = item.disabled) !== null && _item$disabled !== void 0 ? _item$disabled : disabled,
      key: cnAvatarGroup('item', {
        i: i
      }),
      size: size
    }, getAvatarProps(item)));
  }), hiddenCount > 0 && /*#__PURE__*/React.createElement(Avatar, _extends({}, counterSettings, {
    className: cnAvatarGroup('item', [counterSettings === null || counterSettings === void 0 ? void 0 : counterSettings.className]),
    disabled: disabled || (counterSettings === null || counterSettings === void 0 ? void 0 : counterSettings.disabled),
    name: "+".concat(hiddenCount),
    size: size
  })));
};
export var AvatarGroup = compose(withDataConverter(dataConverter), forwardRef)(AvatarGroupRender);