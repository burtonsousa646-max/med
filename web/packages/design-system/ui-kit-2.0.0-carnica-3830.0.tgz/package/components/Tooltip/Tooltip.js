import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "additionalContent", "className", "coordinates", "onClickOutside", "onChangeDirection", "anchorRef", "invert", "originalDirection", "closureModes", "closureOptions", "onClose", "container"],
  _excluded2 = ["isOpen"];
import React, { forwardRef, useRef, useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { cnBem, combineRefs } from '@carnica/utils';
import { withDataConverter } from '@beef/react';
import { useComponentSize, useDeprecationWarning } from '@carnica/utils/hooks';
import { Popover } from "../../modules/Popover";
import { Text } from "../Text";
import styles from "./styles.module.css";
import { convertPopoverDirection, dataConverter, getOffset, variants } from "./utils";
import { TooltipArrow } from "./TooltipArrow";
import { useClose } from "./hooks/useClose";
var cnTooltip = cnBem('tooltip', styles);
var getClassName = function getClassName(invert, className) {
  return function (dir) {
    var direction = convertPopoverDirection(dir);
    return cnTooltip({
      direction: direction,
      invert: invert
    }, [typeof className === 'function' ? className(convertPopoverDirection(direction)) : className]);
  };
};
var Content = /*#__PURE__*/forwardRef(function (props, ref) {
  var children = props.children,
    additionalContent = props.additionalContent,
    className = props.className,
    coordinates = props.coordinates,
    onClickOutsideProp = props.onClickOutside,
    onChangeDirectionProp = props.onChangeDirection,
    anchorRef = props.anchorRef,
    invert = props.invert,
    originalDirection = props.originalDirection,
    closureModes = props.closureModes,
    closureOptions = props.closureOptions,
    onClose = props.onClose,
    container = props.container,
    otherProps = _objectWithoutProperties(props, _excluded);
  useDeprecationWarning({
    onClickOutside: {
      value: onClickOutsideProp,
      newPropKey: 'onClose'
    }
  });
  var tooltipRef = useRef(null);
  var _useState = useState(otherProps.direction),
    _useState2 = _slicedToArray(_useState, 2),
    direction = _useState2[0],
    setDirection = _useState2[1];
  var anchorSize = useComponentSize(anchorRef || {
    current: null
  });
  var onChangeDirection = function onChangeDirection(dir) {
    onChangeDirectionProp === null || onChangeDirectionProp === void 0 || onChangeDirectionProp(dir);
    setDirection(dir);
  };
  var _useClose = useClose({
      anchorRef: anchorRef,
      onClickOutside: onClickOutsideProp,
      closureModes: closureModes,
      closureOptions: closureOptions,
      onClose: onClose,
      tooltipRef: tooltipRef
    }),
    onClickOutside = _useClose.onClickOutside;
  return /*#__PURE__*/React.createElement(Popover, _extends({}, otherProps, {
    anchorRef: anchorRef || {
      current: null
    },
    animate: "animate",
    className: getClassName(invert, className),
    container: container,
    "data-tooltip-direction": originalDirection,
    exit: "exit",
    initial: "initial",
    motion: true,
    onChangeDirection: onChangeDirection,
    onClickOutside: onClickOutside,
    ref: combineRefs([ref, tooltipRef]),
    role: "tooltip",
    variants: variants
  }, getOffset(direction, anchorSize), {
    "data-t-id": "components-Tooltip"
  }), function (popoverDirection) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Text, {
      align: "left",
      className: cnTooltip('content'),
      color: invert ? 'black' : 'primary-fake-invert',
      variant: "caption-medium"
    }, typeof children === 'function' ? children(convertPopoverDirection(popoverDirection)) : children), additionalContent, /*#__PURE__*/React.createElement(TooltipArrow, {
      className: cnTooltip('arrow'),
      direction: convertPopoverDirection(direction)
    }));
  });
});
var TooltipRender = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var isOpen = _ref.isOpen,
    otherProps = _objectWithoutProperties(_ref, _excluded2);
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    mode: "wait"
  }, isOpen && /*#__PURE__*/React.createElement(Content, _extends({
    ref: ref
  }, otherProps)));
});
export var Tooltip = withDataConverter(dataConverter)(TooltipRender);