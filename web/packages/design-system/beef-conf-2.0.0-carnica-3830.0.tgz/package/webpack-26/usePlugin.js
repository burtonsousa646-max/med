import { PRIVATE_BUILDER_API } from "./builder.internals";
import { isCtor } from "./common";
var _usePlugin = function _usePlugin(PluginCls) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }
  if (isCtor(PluginCls)) {
    var arg = args[0],
      _args$ = args[1],
      _enabled = _args$ === void 0 ? true : _args$;
    if (!_enabled) return false;
    return new PluginCls(arg);
  }
  var _args$2 = args[0],
    enabled = _args$2 === void 0 ? true : _args$2;
  if (!enabled) return undefined;
  return PluginCls;
};

/**
 * Если плагина в старом списке нет - добавляет новый в конец списка
 * Если есть - ставит новый на его место
 * Если новый плагин отключен (enabled: false) - удаляет старый
 */
var usePlugin_replace = function usePlugin_replace(PluginCls) {
  PRIVATE_BUILDER_API.assertBuilding('usePlugin.replace');
  for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
    args[_key2 - 1] = arguments[_key2];
  }
  var plugin = _usePlugin.apply(void 0, [PluginCls].concat(args));
  return plugin ? PRIVATE_BUILDER_API.replacePlugin(isCtor(PluginCls) ? PluginCls : PluginCls.constructor, plugin) : PRIVATE_BUILDER_API.excludePlugin(PluginCls);
};
var usePlugin_exclude = function usePlugin_exclude(Plugin) {
  var enabled = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  PRIVATE_BUILDER_API.assertBuilding('usePlugin.exclude');
  if (!enabled) return undefined;
  return PRIVATE_BUILDER_API.excludePlugin(Plugin);
};
export var usePlugin = Object.assign(_usePlugin, {
  replace: usePlugin_replace,
  exclude: usePlugin_exclude
});