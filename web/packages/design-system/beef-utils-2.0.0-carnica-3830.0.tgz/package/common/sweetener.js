import _typeof from "@babel/runtime/helpers/typeof";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime/helpers/getPrototypeOf";
import _get from "@babel/runtime/helpers/get";
import _inherits from "@babel/runtime/helpers/inherits";
import _wrapNativeSuper from "@babel/runtime/helpers/wrapNativeSuper";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
/* eslint-disable max-classes-per-file */
import { filter as _filter, forEach as _forEach, map as _map, mapKeys as _mapKeys, reduce as _reduce } from "./objects";
var SugarArray = /*#__PURE__*/function (_Array) {
  function SugarArray() {
    _classCallCheck(this, SugarArray);
    return _callSuper(this, SugarArray, arguments);
  }
  _inherits(SugarArray, _Array);
  return _createClass(SugarArray, [{
    key: "map",
    value:
    /**
     * Нативные функции без изменений, результат "подслащивается"
     */

    function map(fn) {
      return sweetenArr(_superPropGet(SugarArray, "map", this, 3)([fn]));
    }

    // NOTE: доступно начиная с es2019, есть опасность
  }, {
    key: "flatMap",
    value: function flatMap(fn) {
      return sweetenArr(_superPropGet(SugarArray, "flatMap", this, 3)([fn]));
    }
  }, {
    key: "filter",
    value: function filter(fn) {
      return sweetenArr(_superPropGet(SugarArray, "filter", this, 3)([fn]));
    }
  }, {
    key: "reduce",
    value: function reduce(fn, init) {
      return sweetenAny(_superPropGet(SugarArray, "reduce", this, 3)([fn, init]));
    }
  }, {
    key: "slice",
    value: function slice(start, end) {
      return sweetenArr(_superPropGet(SugarArray, "slice", this, 3)([start, end]));
    }

    /**
     * Расширенные функции, которых очень не хватает массивам.
     * NOTE: Добавление новых функций под конкретные задачи не подразумевается.
     *   Если не хватает функциональности - используйте .pipe(fn)
     */
  }, {
    key: "toObject",
    value: function toObject(getKey, getValue) {
      var obj = {};
      this.forEach(function (v, i) {
        var _ref;
        obj[getKey(v, i)] = typeof getValue === 'function' ? getValue(v, i) : (_ref = getValue) !== null && _ref !== void 0 ? _ref : i;
      });
      return sweetenObj(obj);
    }

    /**
     * Встроенные служебные функции
     */
  }, {
    key: "pipe",
    value: function pipe(fn) {
      return sweetenAny(fn(this));
    }
  }, {
    key: "raw",
    value: function raw() {
      return _toConsumableArray(this);
    }
  }]);
}(/*#__PURE__*/_wrapNativeSuper(Array));
var SugarObject = /*#__PURE__*/function () {
  function SugarObject() {
    _classCallCheck(this, SugarObject);
  }
  return _createClass(SugarObject, [{
    key: "map",
    value:
    /**
     * Расширенные функции, которых очень не хватает при работе с объектами.
     * NOTE: Добавление новых функций под конкретные задачи не подразумевается.
     *   Если не хватает функциональности - используйте .pipe(fn)
     */

    function map(fn) {
      return sweetenObj(_map(this, fn));
    }
  }, {
    key: "forEach",
    value: function forEach(fn) {
      _forEach(this, fn);
    }
  }, {
    key: "mapKeys",
    value: function mapKeys(fn) {
      return sweetenObj(_mapKeys(this, fn));
    }
  }, {
    key: "filter",
    value: function filter(fn) {
      return sweetenObj(_filter(this, fn));
    }
  }, {
    key: "reduce",
    value: function reduce(fn, init) {
      return sweetenAny(_reduce(this, fn, init));
    }
  }, {
    key: "keys",
    value: function keys() {
      return sweetenArr(Object.keys(this));
    }
  }, {
    key: "values",
    value: function values() {
      return sweetenArr(Object.values(this));
    }

    /**
     * Встроенные служебные функции
     */
  }, {
    key: "pipe",
    value: function pipe(fn) {
      return sweetenAny(fn(this));
    }
  }, {
    key: "raw",
    value: function raw() {
      return _objectSpread({}, this);
    }
  }]);
}();
var sweetenObj = function sweetenObj(obj) {
  return Object.assign(Object.create(SugarObject.prototype), obj);
};
var sweetenArr = function sweetenArr(arr) {
  return Object.setPrototypeOf(_toConsumableArray(arr), SugarArray.prototype);
};
var sweetenAny = function sweetenAny(value) {
  if (Array.isArray(value)) return sweetenArr(value);
  if (_typeof(value) === 'object' && value) return sweetenObj(value);
  return value;
};
export var S = Object.assign(sweetenAny, {
  Arr: sweetenArr,
  Obj: sweetenObj
});