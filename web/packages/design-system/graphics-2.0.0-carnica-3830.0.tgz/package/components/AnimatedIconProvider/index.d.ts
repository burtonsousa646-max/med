export * from './AnimatedIconProvider';
//# sourceMappingURL=index.d.ts.map