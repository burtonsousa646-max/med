import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["value", "rightSide", "placeholder"];
import React, { forwardRef, useMemo } from 'react';
import { LogoAlfabank, LogoMaestro, LogoRaiffeisen, LogoSberbank, LogoTinkoff, LogoVtb } from '@carnica/graphics';
import { Input } from "../../Input";
import { withMaskedInput } from "../../../hocs/withMaskedInput";
var bins = [{
  icon: LogoAlfabank,
  list: ['521178', '548673', '548601', '45841', '415428', '676371', '477964']
}, {
  icon: LogoSberbank,
  list: ['427683', '63900', '67758', '427901', '54693', '427644', '427601', '427901', '427631']
}, {
  icon: LogoTinkoff,
  list: ['521324', '437773']
}, {
  icon: LogoRaiffeisen,
  list: ['462730', '462729']
}, {
  icon: LogoVtb,
  list: ['427229', '46223', '527883', '447520']
}];
var BinPreparedInput = withMaskedInput('0000 0000 0000 0000')(Input);
export var CardInput = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var value = _ref.value,
    rightSide = _ref.rightSide,
    _ref$placeholder = _ref.placeholder,
    placeholder = _ref$placeholder === void 0 ? '0000 0000 0000 0000' : _ref$placeholder,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var side = useMemo(function () {
    var _bins$find;
    if (rightSide) {
      return rightSide;
    }
    if (!value) {
      return undefined;
    }
    var Icon = (_bins$find = bins.find(function (_ref2) {
      var list = _ref2.list;
      return list.includes(value.replace(/\s/gm, '').slice(0, 6));
    })) === null || _bins$find === void 0 ? void 0 : _bins$find.icon;
    if (Icon) {
      return /*#__PURE__*/React.createElement(Icon, {
        "data-t-id": "AdvancedInputs-CardInput"
      });
    }
    if ((value === null || value === void 0 ? void 0 : value.charAt(0)) === '6') {
      return /*#__PURE__*/React.createElement(LogoMaestro, null);
    }
    return null;
  }, [value, rightSide]);
  return /*#__PURE__*/React.createElement(BinPreparedInput, _extends({}, otherProps, {
    placeholder: placeholder,
    ref: ref,
    rightSide: side,
    value: value
  }));
});