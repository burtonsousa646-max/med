export declare function map<T extends Record<string, any>, V>(obj: T, fn: (value: T[keyof T], key: keyof T) => V): {
    [P in keyof T]: V;
};
export declare function reduce<T, R>(obj: Record<string, T>, fn: (result: R, value: T, key: string) => R, initialState: R): R;
export declare function isPlainObject<T extends Exclude<Record<string, unknown>, null | undefined | void>>(obj: unknown): obj is T;
export declare function deepmerge<A, B>(a: A, b: B, mergeFn?: (a: any, b: any, path: string[]) => any, path?: string[]): A & B;
export declare const ensureArray: <T>(value: T) => T extends any[] ? T : T[];
//# sourceMappingURL=helpers.d.ts.map