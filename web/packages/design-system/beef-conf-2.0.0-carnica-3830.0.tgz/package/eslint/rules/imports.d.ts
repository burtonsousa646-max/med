export let rules: {
    'global-require': number;
    'import/extensions': (number | {
        json: string;
        jsx: string;
        ts: string;
        tsx: string;
    })[];
    'import/prefer-default-export': number;
    'import/order': (string | {
        groups: string[][];
        'newlines-between': string;
    })[];
    'no-restricted-imports': (number | {
        patterns: {
            group: string[];
            message: string;
        }[];
    })[];
};
//# sourceMappingURL=imports.d.ts.map