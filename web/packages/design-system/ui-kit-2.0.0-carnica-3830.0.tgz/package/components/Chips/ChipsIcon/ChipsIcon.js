import React from 'react';
import { cnBem } from '@carnica/utils';
import styles from "../styles.module.css";
var cnChips = cnBem('chips', styles);
export var ChipsIcon = function ChipsIcon(_ref) {
  var Icon = _ref.icon,
    color = _ref.color;
  if (!Icon) return null;
  return /*#__PURE__*/React.createElement(Icon, {
    className: cnChips('icon'),
    color: color,
    size: "s",
    "data-t-id": "Chips-ChipsIcon"
  });
};