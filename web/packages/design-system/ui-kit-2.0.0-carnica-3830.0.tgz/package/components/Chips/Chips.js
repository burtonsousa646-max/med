import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["label", "className", "active", "colors", "disabled", "iconLeft", "iconRight", "withCloseIcon", "subTitle", "onClick", "color", "backgroundContent", "backgroundContentProps", "id", "focus"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { withDataConverter } from '@beef/react';
import { compose } from '@beef/utils';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { Text } from "../Text";
import { MotionComponent } from "../../modules/MotionComponent";
import { ChipsIcon } from "./ChipsIcon";
import styles from "./styles.module.css";
import { dataConverter } from "./utils";
import { ChipsBackgroundContent } from "./ChipsBackgroundContent";
var cnChips = cnBem('chips', styles);
var ChipsRender = function ChipsRender(_ref, ref) {
  var label = _ref.label,
    className = _ref.className,
    active = _ref.active,
    colors = _ref.colors,
    disabled = _ref.disabled,
    iconLeft = _ref.iconLeft,
    iconRight = _ref.iconRight,
    withCloseIcon = _ref.withCloseIcon,
    subTitle = _ref.subTitle,
    onClick = _ref.onClick,
    color = _ref.color,
    backgroundContent = _ref.backgroundContent,
    backgroundContentProps = _ref.backgroundContentProps,
    id = _ref.id,
    focus = _ref.focus,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  useDeprecationWarning({
    focus: {
      value: focus,
      newPropKey: 'active'
    }
  });
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnChips({
      active: active,
      disabled: disabled
    }, [className]),
    id: id,
    onClick: disabled ? undefined : onClick,
    ref: ref,
    "data-t-id": "components-Chips"
  }), /*#__PURE__*/React.createElement(ChipsBackgroundContent, _extends({
    backgroundContent: backgroundContent
  }, backgroundContentProps, {
    iconColor: colors.icon,
    "data-t-id": "components-Chips"
  })), /*#__PURE__*/React.createElement(ChipsIcon, {
    color: colors.icon,
    icon: iconLeft
  }), /*#__PURE__*/React.createElement(Text, {
    className: cnChips('label'),
    color: colors.title,
    tagName: "p",
    variant: "body-small"
  }, label, subTitle && /*#__PURE__*/React.createElement("span", {
    className: cnChips('subTitle')
  }, subTitle)), /*#__PURE__*/React.createElement(ChipsIcon, {
    color: withCloseIcon ? colors.closeIcon : colors.icon,
    icon: withCloseIcon ? IconCloseRoundStroked : iconRight
  }));
};
export var Chips = compose(withDataConverter(dataConverter), forwardRef)(ChipsRender);