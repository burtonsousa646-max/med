import { RuleSetRule } from 'webpack';
import { Loader } from './types';
export declare const oneOfLoaders: (...loaders: Loader[]) => {
    oneOf: any;
};
export declare const stringifyRule: (rule: RuleSetRule["test"]) => string;
//# sourceMappingURL=utilities.d.ts.map