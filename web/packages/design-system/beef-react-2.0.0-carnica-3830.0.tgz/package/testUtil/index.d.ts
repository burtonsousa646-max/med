export declare const testUtil: () => number;
export declare const selectStateFromRenderResult: <T extends readonly [any, any]>(result: {
    current: T;
}) => readonly [() => T[0], T[1]];
//# sourceMappingURL=index.d.ts.map