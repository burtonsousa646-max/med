export interface Fiber {
    alternate: Fiber | null;
    child: Fiber | null;
    dependencies: FiberDependencies | null;
    memoizedProps: any;
    memoizedState: any;
    return: Fiber | null;
    sibling: Fiber | null;
    stateNode: Node | null;
    type: any;
    updateQueue: any;
}
export type FiberDependencies = any[];
//# sourceMappingURL=types.d.ts.map