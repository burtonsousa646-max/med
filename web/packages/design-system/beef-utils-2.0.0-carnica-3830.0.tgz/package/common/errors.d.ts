export declare const throwNonBlockingError: (error: Error | string) => void;
//# sourceMappingURL=errors.d.ts.map