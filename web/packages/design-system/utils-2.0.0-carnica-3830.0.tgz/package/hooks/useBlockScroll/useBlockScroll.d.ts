export declare const useBlockScroll: (blocked?: boolean, container?: HTMLElement | React.RefObject<HTMLElement>) => void;
//# sourceMappingURL=useBlockScroll.d.ts.map