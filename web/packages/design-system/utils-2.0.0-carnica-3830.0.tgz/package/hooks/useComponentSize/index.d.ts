export * from './useComponentSize';
//# sourceMappingURL=index.d.ts.map