export var avatarPropSize = ['xl', 'l', 'm', 's'];
export var avatarPropColor = ['default-on-primary', 'default-on-secondary', 'default-on-tertiary', 'brand', 'invert', 'primary', 'secondary', 'tertiary', 'blue', 'teal', 'magenta', 'yellow', 'violet', 'green', 'red', 'orange'];
export var avatarPropBgColor = [/** @deprecated Используйте взамен 'default-on-primary' */
'default', 'default-on-primary', 'default-on-secondary', 'default-on-tertiary', /** @deprecated Используйте взамен 'default-on-primary' */
'invert', 'primary', 'dark'];