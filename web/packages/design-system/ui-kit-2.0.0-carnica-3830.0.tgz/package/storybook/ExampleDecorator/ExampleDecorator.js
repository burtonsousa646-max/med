import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
var _excluded = ["children", "direction"];
import React, { useEffect } from 'react';
import { ExampleDecorator as Decorator } from '@carnica/utils/storybook';
import { cnBem } from '@carnica/utils';
import { ThemeProvider, useThemeContext } from "../../modules/ThemeProvider";
import themeV1 from "../../styles/themeV1.module.css";
import themeV2 from "../../styles/themeV2.module.css";
import styles from "./styles.module.css";
var cnProvider = cnBem('provider', styles);
var getThemeStyles = function getThemeStyles(version) {
  if (version === 'v1') {
    return {
      light: themeV1,
      dark: themeV1
    };
  }
  return {
    light: themeV2,
    dark: themeV2
  };
};
var renderChildren = function renderChildren(_ref) {
  var children = _ref.children,
    themeVersion = _ref.themeVersion,
    theme = _ref.theme;
  return typeof children === 'function' ? children(theme, themeVersion || 'v1') : children;
};
var Content = function Content(_ref2) {
  var children = _ref2.children,
    themeVersion = _ref2.themeVersion,
    theme = _ref2.theme;
  var _useThemeContext = useThemeContext(),
    _useThemeContext2 = _slicedToArray(_useThemeContext, 2),
    currentTheme = _useThemeContext2[0],
    setTheme = _useThemeContext2[1];
  useEffect(function () {
    setTheme(theme);
  }, [theme]);
  return renderChildren({
    children: children,
    themeVersion: themeVersion,
    theme: currentTheme
  });
};
export var ExampleDecorator = function ExampleDecorator(_ref3) {
  var children = _ref3.children,
    direction = _ref3.direction,
    props = _objectWithoutProperties(_ref3, _excluded);
  return /*#__PURE__*/React.createElement(Decorator, _extends({
    direction: direction
  }, props, {
    "data-t-id": "storybook-ExampleDecorator"
  }), function (theme, themeVersion) {
    return /*#__PURE__*/React.createElement(ThemeProvider, {
      className: cnProvider({
        direction: direction
      }),
      themeStyles: getThemeStyles(themeVersion)
    }, /*#__PURE__*/React.createElement(Content, {
      children: children,
      theme: theme,
      themeVersion: themeVersion,
      "data-t-id": "storybook-ExampleDecorator"
    }));
  });
};