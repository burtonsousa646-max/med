var children = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut\nlabore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco\nlaboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in\nvoluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat\nnon proident, sunt in culpa qui officia deserunt mollit anim id est laborum";
export var getItems = function getItems() {
  var length = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 5;
  return Array.from({
    length: length
  }).map(function (_, i) {
    return {
      label: "\u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A ".concat(i + 1),
      children: children
    };
  });
};