export * from './getIconByName';
//# sourceMappingURL=index.d.ts.map