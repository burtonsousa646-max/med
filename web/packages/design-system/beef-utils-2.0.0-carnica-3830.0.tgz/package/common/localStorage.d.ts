export declare const getLocalStorageValue: (key: string) => null | string;
export declare const setLocalStorageValue: (key: string, data: string) => boolean;
//# sourceMappingURL=localStorage.d.ts.map