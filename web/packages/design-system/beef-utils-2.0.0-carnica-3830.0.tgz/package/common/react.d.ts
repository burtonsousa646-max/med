import type { DangerAndChildren } from '@beef/react/types';
import React, { FC, ReactNode } from 'react';
export declare const NullComponent: FC<void>;
export declare const NullContainer: FC<{
    children: ReactNode;
}>;
export declare const clientOnlyHook: <T extends (...args: any[]) => any>(hook: T) => T;
export declare const spreadDangerousChildren: (children: ReactNode) => DangerAndChildren;
export declare const cxBool: (classes: Record<string, boolean | undefined>) => Record<string, boolean | undefined>;
export declare function proxyHandler<T extends any[]>(originalHandler: ((...args: T) => void) | undefined, extraHandler: (...args: T) => void): (...args: T) => void;
export declare const getNodeDisplayName: (node: React.ReactNode) => null | string;
export declare function generateReactKey<T>(input: T): string;
//# sourceMappingURL=react.d.ts.map