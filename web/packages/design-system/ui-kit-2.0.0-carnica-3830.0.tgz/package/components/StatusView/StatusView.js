import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["title", "subTitle", "state", "icon", "children", "additionalContent", "actionGetters", "actions", "buttonGetters", "buttons", "loading", "loadingOptions", "convertAction", "convertButton", "className"];
import React, { forwardRef, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import { MotionComponent } from "../../modules/MotionComponent";
import { statusViewPropState } from "./types";
import { composePreparedProps } from "./utils";
import styles from "./styles.module.css";
import { StatusViewButtons } from "./StatusViewButtons";
import { StatusViewContent } from "./StatusViewContent";
import { StatusViewAnimateModal } from "./StatusViewAnimateModal";
var cnStatusView = cnBem('status-view', styles);
var StatusViewRender = function StatusViewRender(props, ref) {
  var _composePreparedProps = composePreparedProps(props),
    title = _composePreparedProps.title,
    subTitle = _composePreparedProps.subTitle,
    _composePreparedProps2 = _composePreparedProps.state,
    state = _composePreparedProps2 === void 0 ? statusViewPropState[0] : _composePreparedProps2,
    icon = _composePreparedProps.icon,
    children = _composePreparedProps.children,
    additionalContent = _composePreparedProps.additionalContent,
    actionGetters = _composePreparedProps.actionGetters,
    actions = _composePreparedProps.actions,
    buttonGetters = _composePreparedProps.buttonGetters,
    buttons = _composePreparedProps.buttons,
    loading = _composePreparedProps.loading,
    loadingOptions = _composePreparedProps.loadingOptions,
    convertAction = _composePreparedProps.convertAction,
    convertButton = _composePreparedProps.convertButton,
    className = _composePreparedProps.className,
    otherProps = _objectWithoutProperties(_composePreparedProps, _excluded);
  var isMobile = useIsMobileDimension();
  var wrapperRef = useRef(null);
  var renderContent = function renderContent() {
    return /*#__PURE__*/React.createElement(StatusViewContent, {
      actionGetters: actionGetters,
      actions: actions,
      additionalContent: additionalContent,
      convertAction: convertAction,
      icon: icon,
      loading: loading,
      loadingOptions: loadingOptions,
      state: state,
      subTitle: subTitle,
      title: title,
      wrapperRef: wrapperRef,
      "data-t-id": "components-StatusView"
    }, children);
  };
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    "aria-atomic": true,
    className: cnStatusView(null, [className]),
    ref: combineRefs([wrapperRef, ref]),
    role: "status",
    tagName: "section"
  }), isMobile ? /*#__PURE__*/React.createElement("div", {
    className: cnStatusView('wrapper')
  }, renderContent()) : renderContent(), /*#__PURE__*/React.createElement(StatusViewButtons, {
    buttons: buttons,
    className: cnStatusView('buttons'),
    convertButton: convertButton,
    getters: buttonGetters
  }));
};
export var StatusView = /*#__PURE__*/forwardRef(StatusViewRender);
StatusView.AnimateModal = StatusViewAnimateModal;