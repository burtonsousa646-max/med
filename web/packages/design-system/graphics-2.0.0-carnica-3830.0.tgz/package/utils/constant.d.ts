export declare const baseServerUrl = "https://static.beeline.ru/upload/images/carnica";
//# sourceMappingURL=constant.d.ts.map