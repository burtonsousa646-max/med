declare const _default: {
    name: string;
    value: string;
}[];
export default _default;
//# sourceMappingURL=space.mock.d.ts.map