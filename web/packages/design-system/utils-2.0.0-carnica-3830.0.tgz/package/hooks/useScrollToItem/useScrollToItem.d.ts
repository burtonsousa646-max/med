import { UseScrollToItemParams } from './types';
export declare const useScrollToItem: ({ containeRef, itemRefs, direction, resultAlign, }: UseScrollToItemParams) => (index: number) => void;
//# sourceMappingURL=useScrollToItem.d.ts.map