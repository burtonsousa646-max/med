import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["name"];
import React, { forwardRef } from 'react';
import { getIconByName } from "../../utils/getIconByName";
var BaseIconRender = function BaseIconRender(_ref, ref) {
  var name = _ref.name,
    props = _objectWithoutProperties(_ref, _excluded);
  var Icon = getIconByName(name);
  if (Icon) {
    return /*#__PURE__*/React.createElement(Icon, _extends({}, props, {
      ref: ref,
      "data-t-id": "components-BaseIcon"
    }));
  }
  return null;
};
export var BaseIcon = /*#__PURE__*/forwardRef(BaseIconRender);