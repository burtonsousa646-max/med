import logger from 'loglevel';
/**
 * A useful function to print result of another method call,
 * without interrupting the execution
 * do not delete even if unused
 *
 */
export var logFunctionResult = function logFunctionResult(title, fn) {
  return function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    var value = fn.apply(void 0, args);
    logger.info(title, {
      result: value,
      args: args
    });
    return value;
  };
};