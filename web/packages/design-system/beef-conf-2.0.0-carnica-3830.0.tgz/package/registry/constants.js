const BeelineDigitalScopeList = ['beef', 'beep', 'beefco', 'fttb', 'carnica'];
module.exports = {
  BeelineDigitalScopeList
};