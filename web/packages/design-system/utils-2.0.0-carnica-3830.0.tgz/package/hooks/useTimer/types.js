export var TimerType = /*#__PURE__*/function (TimerType) {
  TimerType[TimerType["DECREMENTAL"] = 0] = "DECREMENTAL";
  TimerType[TimerType["INCREMENTAL"] = 1] = "INCREMENTAL";
  return TimerType;
}({});