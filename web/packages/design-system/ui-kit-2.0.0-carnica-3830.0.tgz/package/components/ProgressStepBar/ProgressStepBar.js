import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["id", "className", "activeStep", "steps", "title", "subTitle", "progressProps", "progressRef"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { withDataConverter } from '@beef/react';
import { compose } from '@beef/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { dataConverter } from "./utils";
import { ProgressStepBarContent } from "./ProgressStepBarContent";
var cnProgressStepBar = cnBem('progress-step-bar', styles);
var ProgressStepBarRender = function ProgressStepBarRender(_ref, ref) {
  var id = _ref.id,
    className = _ref.className,
    activeStep = _ref.activeStep,
    steps = _ref.steps,
    title = _ref.title,
    subTitle = _ref.subTitle,
    progressProps = _ref.progressProps,
    progressRef = _ref.progressRef,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnProgressStepBar(null, [className]),
    ref: ref,
    tagName: "label",
    "data-t-id": "components-ProgressStepBar"
  }), /*#__PURE__*/React.createElement("progress", _extends({}, progressProps || {}, {
    className: cnProgressStepBar('line', [progressProps === null || progressProps === void 0 ? void 0 : progressProps.className]),
    id: id,
    max: steps,
    ref: progressRef,
    style: _defineProperty({}, '--progress-offset', "".concat(activeStep * 100 / steps, "%")),
    value: activeStep,
    "data-t-id": "components-ProgressStepBar"
  })), /*#__PURE__*/React.createElement(ProgressStepBarContent, {
    activeStep: activeStep,
    steps: steps,
    subTitle: subTitle,
    title: title
  }));
};
export var ProgressStepBar = compose(withDataConverter(dataConverter), forwardRef)(ProgressStepBarRender);