import type { IconComponent } from '../../types/IconComponent';
export type DefineAnimatedIconProps = {
    icons: IconComponent[];
    rotations?: number[];
    transition?: number;
};
export declare const defineAnimatedIcon: (params: DefineAnimatedIconProps) => IconComponent;
//# sourceMappingURL=defineAnimatedIcon.d.ts.map