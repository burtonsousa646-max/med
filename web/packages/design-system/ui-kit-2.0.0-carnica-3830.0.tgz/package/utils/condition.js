import _typeof from "@babel/runtime/helpers/typeof";
export var isIconComponent = function isIconComponent(component) {
  if (component && _typeof(component) === 'object') {
    return Reflect.has(component, 'render') && !Reflect.has(component, 'props');
  }
  return typeof component === 'function';
};