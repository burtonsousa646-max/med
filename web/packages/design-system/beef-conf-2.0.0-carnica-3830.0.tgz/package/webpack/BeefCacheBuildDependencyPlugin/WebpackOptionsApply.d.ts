export = WebpackCacheOptionsApply;
declare class WebpackCacheOptionsApply {
    constructor({ ignoreBuildDependencies, ...rest }?: {
        ignoreBuildDependencies?: never[] | undefined;
    });
    options: {
        ignoreBuildDependencies: any[];
    };
    excludeBeefPackageJsonFiles: (files: any) => Set<any>;
    get AddBuildDependenciesPlugin(): any;
    get MemoryCachePlugin(): any;
    get MemoryWithGcCachePlugin(): any;
    get IdleFileCachePlugin(): any;
    get PackFileCacheStrategy(): {
        new (...args: any[]): {};
    };
    process(options: WebpackOptions, compiler: Compiler): WebpackOptions;
}
declare namespace WebpackCacheOptionsApply {
    export { WebpackPluginFunction, WebpackOptions, Compiler, InputFileSystem, IntermediateFileSystem };
}
type WebpackPluginFunction = any;
type WebpackOptions = any;
type Compiler = any;
type InputFileSystem = any;
type IntermediateFileSystem = any;
//# sourceMappingURL=WebpackOptionsApply.d.ts.map