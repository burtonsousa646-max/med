export var sizeMap = {
  xs: 16,
  s: 20,
  m: 24,
  l: 32
};
export var getSize = function getSize(size) {
  return "".concat(typeof size === 'string' ? sizeMap[size] : size, "px");
};