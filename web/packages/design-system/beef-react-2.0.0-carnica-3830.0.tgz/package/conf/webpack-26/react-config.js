import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
/* eslint-disable react-hooks/rules-of-hooks */
import { baseConfig, extendConfig, oneOfLoaders, useConfig, usePlugin, useRule } from '@beef/conf/webpack-26';
import { reactToolkit } from "./react-toolkit";
import { errorFilters, mapViewFiles } from "../webpack/utils";
var plugins = reactToolkit.plugins,
  loaders = reactToolkit.loaders,
  rules = reactToolkit.rules,
  options = reactToolkit.options;
export var reactConfig = extendConfig(baseConfig, function (_ref) {
  var isProduction = _ref.isProduction,
    isServer = _ref.isServer,
    isHMR = _ref.isHMR;
  return {
    module: {
      rules: [useRule(require.resolve('react'), loaders.expose('React')), useRule(require.resolve('react-dom'), loaders.expose('ReactDOM')), useRule(rules.pcss, [loaders.style({
        isHMR: isHMR
      }), loaders.cssExtract({
        isServer: isServer,
        isHMR: isHMR
      }), loaders.css({
        isProduction: isProduction
      }), loaders.pcss]), useRule(rules.css, [loaders.style({
        isHMR: isHMR
      }), loaders.cssExtract({
        isServer: isServer,
        isHMR: isHMR
      }), loaders.rawCss]), useRule([rules.font, rules.img, rules.docs], loaders.asset), useRule(rules.svg, oneOfLoaders(loaders.resourceUrl, loaders.svg, loaders.asset)), useRule(rules.pug, loaders.pug)].filter(Boolean)
    },
    plugins: [usePlugin(plugins.ReactRefreshWebpackPlugin, {
      overlay: false,
      exclude: options.monorepoExcludes
    }, isHMR), usePlugin(plugins.FriendlyErrorOverlayPlugin, {
      errorFilters: [errorFilters.silentFilter, errorFilters.lazyCompilationFilter]
    }, isHMR)].concat(_toConsumableArray(mapViewFiles(function (_ref2) {
      var name = _ref2.name,
        filePath = _ref2.filePath;
      return usePlugin(plugins.HtmlWebpackPlugin.forEntry({
        name: name,
        filePath: filePath
      }));
    })), [usePlugin(plugins.MiniCssExtractPlugin, {
      filename: function filename() {
        return "".concat(options.filePattern(isProduction), ".css");
      },
      chunkFilename: function chunkFilename() {
        return "".concat(options.filePattern(isProduction), ".css");
      }
    }, isProduction), usePlugin(plugins.ForkTsCheckerWebpackPlugin, {
      typescript: {
        build: true,
        mode: 'readonly',
        diagnosticOptions: {
          semantic: true,
          syntactic: true
        }
      }
    }, !isProduction)]).filter(Boolean),
    optimization: {
      minimizer: [usePlugin(plugins.CssMinimizerPlugin, {
        parallel: true,
        warningsFilter: function warningsFilter() {
          return false;
        },
        minimizerOptions: {
          preset: ['default', {
            discardComments: {
              removeAll: true
            }
          }]
        }
      }, isProduction)]
    },
    devServer: useConfig({
      client: {
        overlay: false,
        reconnect: 3,
        progress: false
      }
    }, isHMR)
  };
});