/* eslint-disable no-await-in-loop */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-console */
const path = require('path');
const fetch = require('npm-registry-fetch');
const semver = require('semver');
const {
  execSync
} = require('child_process');
const {
  promises: fs
} = require('fs');
const {
  getRemoteTagVersions,
  getCommitHash
} = require('./git');
const {
  getRegistry
} = require('./common');
const {
  rewriteJsonFile,
  getWorkspacePackageJsonPaths
} = require('./fs');
const getPublishedPackagesList = () => execSync('yarn lerna list').toString().match(/@[/\w-]+/g);
const getHighestTagVersion = tag => getRemoteTagVersions(tag).pop()?.replace('^{}', '').split('/').pop().replace(/^v/, '');
class LernaVersionUpdater {
  constructor(options) {
    this.options = {
      fetchOptions: {
        strictSSL: false
      },
      lernaConfigPath: path.resolve('lerna.json'),
      registryUrl: getRegistry(options),
      ...options
    };
  }

  // todo: сейчас берутся все версии всех пакетов, рано или поздно это может навернуться
  // да и работает не оптимально
  async getHighestVersion({
    distTag,
    pkgNames
  }) {
    try {
      const {
        fetchOptions,
        registryUrl
      } = this.options;
      const tagVersion = getHighestTagVersion(distTag);
      const highestVersion = (await Promise.all(pkgNames.map(async pkgName => {
        console.log('Requesting the latest version of the package', pkgName);
        const data = await fetch.json(`${registryUrl}${pkgName}`, fetchOptions);
        return data?.['dist-tags']?.[distTag];
      }))).concat([tagVersion]).filter(Boolean).sort(semver.compare).pop();
      console.log('The highest version was found', highestVersion);
      return highestVersion;
    } catch (error) {
      console.error(error);
      return null;
    }
  }
  async updateVersion(version) {
    try {
      const {
        lernaConfigPath
      } = this.options;
      await rewriteJsonFile(lernaConfigPath, async fileContent => ({
        ...fileContent,
        version
      }));
    } catch (error) {
      console.error(error);
    }
  }
  async updateMonorepoResolutions(version) {
    try {
      const names = JSON.parse(execSync('yarn -s lerna list --all --json').toString()).map(pkg => pkg.name);
      const rootDir = process.cwd();
      const packageJsonPath = path.join(rootDir, 'package.json');
      await rewriteJsonFile(packageJsonPath, fileContent => {
        if (!fileContent.resolutions) return fileContent;
        const resolutions = names.reduce((acc, name) => {
          if (fileContent.resolutions[name]) {
            acc[name] = version;
          }
          return acc;
        }, {});
        return {
          ...fileContent,
          resolutions: {
            ...(fileContent.resolutions || {}),
            ...resolutions
          }
        };
      });
    } catch (error) {
      console.error(error);
    }
  }
  async addUpdateCommitHash() {
    try {
      const pkgs = await getWorkspacePackageJsonPaths();
      await Promise.all(pkgs.map(pkg => rewriteJsonFile(pkg, async fileContent => ({
        ...fileContent,
        updateCommitHash: getCommitHash()
      }))));
    } catch (error) {
      console.error(error);
    }
  }

  /**
   * Читает и парсит `lerna.json`
   * @returns {Promise<Object>} Конфигурация Lerna
   */
  async config() {
    try {
      const {
        lernaConfigPath
      } = this.options;
      const data = await fs.readFile(lernaConfigPath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error(error);
    }
    return {};
  }

  /**
   * Объединяет базовую версию и пререлизную версию,
   * возвращая новую версию в формате `<baseVersion>-<preReleaseLabel>.0`.
   *
   * Например:
   *  mergeVersions("1.0.5", "1.0.3-test.1") вернёт "1.0.5-test.0"
   *
   * @param {string} baseVersion - Основная версия без пререлизной части (например, "1.0.5")
   * @param {string} preReleaseVersion - Версия с пререлизной частью (например, "1.0.3-test.1")
   * @returns {string} Новая версия, состоящая из baseVersion и пререлизного лейбла с нулём (например, "1.0.5-test.0")
   * @throws {Error} Если входные строки не соответствуют семантическому формату версии
   * @throws {Error} Если пререлизная версия не содержит лейбл (например, "test" в "test.1")
   */
  mergeVersions(baseVersion, preReleaseVersion) {
    const semverRegex = /^(\d+)\.(\d+)\.(\d+)(?:-([\w.-]+))?$/;
    const baseMatch = baseVersion.match(semverRegex);
    const preMatch = preReleaseVersion.match(semverRegex);
    if (!baseMatch || !preMatch) {
      throw new Error('Invalid semver format');
    }
    const [, major, minor, patch] = baseMatch;
    const preLabel = preMatch[4]?.split('.')[0]; // Например: "test" из "test.1"

    if (!preLabel) {
      throw new Error('Pre-release version must contain a label like "test.1"');
    }
    return `${major}.${minor}.${patch}-${preLabel}.0`;
  }
}
module.exports = {
  LernaVersionUpdater,
  getPublishedPackagesList
};