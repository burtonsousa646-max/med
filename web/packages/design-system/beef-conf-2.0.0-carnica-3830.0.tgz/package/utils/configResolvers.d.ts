export function configResolverSync(configName: any, currentPath?: string): string | null;
export function configRootResolverSync(configName: any, currentPath?: string): string | null;
//# sourceMappingURL=configResolvers.d.ts.map