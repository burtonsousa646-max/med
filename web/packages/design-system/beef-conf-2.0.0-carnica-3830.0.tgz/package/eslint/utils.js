const path = require('path');
const isFixMode = process.argv.includes('--fix');
const resolvePlugin = pluginPath => pluginPath.indexOf('.') === 0 ? require.resolve(`./${path.join('./configs', pluginPath)}`) : pluginPath;
const getTsCheckEslintConfigPath = () => path.resolve(__dirname, 'slow-ts.config.js');
const filter = (obj, fn) => Object.keys(obj).reduce((result, key) => {
  if (fn(obj[key], key)) result[key] = obj[key];
  return result;
}, {});
module.exports = {
  filter,
  getTsCheckEslintConfigPath,
  isFixMode,
  resolvePlugin
};