import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnSelect = cnBem('skeleton-select', styles);
export var Select = function Select(_ref) {
  var invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnSelect(null, [className])
  }, props, {
    "data-t-id": "components-Select"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 12,
    invert: invert,
    width: 100
  }), /*#__PURE__*/React.createElement("div", {
    className: cnSelect('wrapper')
  }, /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 28,
    invert: invert,
    width: "100%"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 28,
    invert: invert,
    width: 28
  })));
};