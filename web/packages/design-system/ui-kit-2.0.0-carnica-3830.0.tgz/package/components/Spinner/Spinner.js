import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["size", "className", "view"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnSpinner = cnBem('spinner', styles);
var SpinnerRender = function SpinnerRender(_ref, ref) {
  var _ref$size = _ref.size,
    size = _ref$size === void 0 ? 20 : _ref$size,
    className = _ref.className,
    _ref$view = _ref.view,
    view = _ref$view === void 0 ? 'dark-yellow' : _ref$view,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, props, {
    "aria-atomic": true,
    "aria-label": "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430",
    "aria-live": "polite",
    className: cnSpinner({
      view: view
    }, [className]),
    ref: ref,
    role: "status",
    style: _objectSpread(_objectSpread({}, props.style), {}, _defineProperty({}, '--spinner-size', "".concat(size, "px"))),
    tagName: "span",
    "data-t-id": "components-Spinner"
  }));
};
export var Spinner = /*#__PURE__*/forwardRef(SpinnerRender);