export declare const data: {
    group: string;
    icons: {
        name: string;
        icon: import("../../types").IconComponent;
    }[];
}[];
//# sourceMappingURL=mock.data.d.ts.map