import { type RenderResult } from '@testing-library/react';
export declare const getRender: (testId: string) => HTMLElement;
type Render = (() => Promise<RenderResult>) | (() => RenderResult) | RenderResult;
export declare const testRender: (render: Render) => void;
export declare const executeTestCases: (testId: string, render?: Render, beforeComponentTest?: VoidFunction) => (func: jest.EmptyFunction) => void;
export declare const delay: (time?: number) => Promise<void>;
export declare const getRandomValue: (count?: number) => string;
export declare const NAMING_TEST_MAP: {
    a11y: string;
    behavior: string;
    props: string;
    snapshot: string;
};
export {};
//# sourceMappingURL=index.d.ts.map