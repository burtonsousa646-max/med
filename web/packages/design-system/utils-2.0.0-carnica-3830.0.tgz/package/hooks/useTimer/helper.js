import { TimerType } from "./types";
export var initialConfig = {
  interval: 1000,
  endTime: null,
  startTime: 0,
  timerType: TimerType.INCREMENTAL
};
export var getTimeIsOver = function getTimeIsOver(timerType, time, endTime) {
  return endTime !== null && (timerType === TimerType.INCREMENTAL ? time >= endTime : time <= endTime);
};