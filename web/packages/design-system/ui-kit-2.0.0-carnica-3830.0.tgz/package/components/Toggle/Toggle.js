import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "onFocus", "onBlur", "onChange", "labelRef", "forwardedRef", "labelProps", "inputClassName", "children", "invert", "disabled", "labelClassName", "checked", "type"];
import React, { forwardRef } from 'react';
import { combineRefs } from '@carnica/utils';
import { Text } from "../Text";
import { MotionComponent } from "../../modules/MotionComponent";
import { getLabelColor } from "./utils";

// Чисто системный компонент, не для личного пользования)
export var Toggle = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    _onFocus = props.onFocus,
    _onBlur = props.onBlur,
    _onChange = props.onChange,
    labelRef = props.labelRef,
    forwardedRef = props.forwardedRef,
    _props$labelProps = props.labelProps,
    labelProps = _props$labelProps === void 0 ? {} : _props$labelProps,
    inputClassName = props.inputClassName,
    children = props.children,
    invert = props.invert,
    disabled = props.disabled,
    labelClassName = props.labelClassName,
    _props$checked = props.checked,
    checked = _props$checked === void 0 ? false : _props$checked,
    _props$type = props.type,
    type = _props$type === void 0 ? 'checkbox' : _props$type,
    otherProps = _objectWithoutProperties(props, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, labelProps, {
    className: className,
    ref: labelRef,
    tagName: children ? 'label' : 'div',
    "data-t-id": "components-Toggle"
  }), /*#__PURE__*/React.createElement("input", _extends({
    "aria-labelledby": otherProps.id && children ? "".concat(otherProps.id, "-label") : undefined,
    checked: checked,
    className: inputClassName,
    disabled: disabled,
    onBlur: function onBlur(e) {
      return _onBlur === null || _onBlur === void 0 ? void 0 : _onBlur(checked, e);
    },
    onChange: function onChange(e) {
      return _onChange === null || _onChange === void 0 ? void 0 : _onChange(e.target.checked, e);
    },
    onFocus: function onFocus(e) {
      return _onFocus === null || _onFocus === void 0 ? void 0 : _onFocus(checked, e);
    },
    type: type
  }, otherProps, {
    ref: combineRefs([ref, forwardedRef]),
    "data-t-id": "components-Toggle"
  })), children && /*#__PURE__*/React.createElement(Text, {
    className: labelClassName,
    color: getLabelColor({
      disabled: disabled,
      invert: invert
    }),
    id: otherProps.id ? "".concat(otherProps.id, "-label") : undefined,
    tagName: "span",
    variant: "body-small"
  }, children));
});