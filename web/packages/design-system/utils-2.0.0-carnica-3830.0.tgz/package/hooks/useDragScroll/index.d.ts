export * from './useDragScroll';
//# sourceMappingURL=index.d.ts.map