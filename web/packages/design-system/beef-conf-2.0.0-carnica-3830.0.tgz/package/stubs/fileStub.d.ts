declare const _exports: string;
export = _exports;
//# sourceMappingURL=fileStub.d.ts.map