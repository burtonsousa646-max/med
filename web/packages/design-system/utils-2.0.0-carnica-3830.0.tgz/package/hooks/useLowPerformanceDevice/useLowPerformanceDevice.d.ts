export declare const useLowPerformanceDevice: () => boolean;
//# sourceMappingURL=useLowPerformanceDevice.d.ts.map