export function isLocalhost(): boolean;
//# sourceMappingURL=env-is.d.ts.map