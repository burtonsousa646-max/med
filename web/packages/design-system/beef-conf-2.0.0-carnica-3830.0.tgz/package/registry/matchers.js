const {
  BeelineDigitalScopeList
} = require('./constants');
const scopeRegExpStr = `@(${BeelineDigitalScopeList.join('|')})`;
const scopeIncludes = new RegExp(`(?:^|[/\\\\])${scopeRegExpStr}(?:[/\\\\]|$)`);
const scopeExcludes = new RegExp(`^((?!${scopeRegExpStr}(?:[/\\\\]|$)).)*$`);

// То же самое, что и scopeIncludes, но весь путь записывается в matching group
const scopeMatchedExcludes = new RegExp(`^(.*[/\\\\]node_modules[/\\\\](?!${scopeRegExpStr}[/\\\\][^/\\\\]+))`);
module.exports = {
  scopeRegExpStr,
  scopeRegExp: new RegExp(scopeRegExpStr),
  scopeMatchedExcludes,
  scopeExcludes,
  scopeIncludes
};