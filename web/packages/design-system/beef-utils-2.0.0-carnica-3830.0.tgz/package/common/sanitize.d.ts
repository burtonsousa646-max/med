export declare const sanitize: (string: string, replaceValue?: string) => string;
export declare const sanitizeSearch: (string: string, replaceValue?: string) => string;
export declare const checkDangerousChars: (value?: null | string, onDangerous?: () => void) => boolean;
//# sourceMappingURL=sanitize.d.ts.map