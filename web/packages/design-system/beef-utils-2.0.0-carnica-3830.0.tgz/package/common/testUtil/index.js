export var testUtil = function testUtil() {
  return 5;
};