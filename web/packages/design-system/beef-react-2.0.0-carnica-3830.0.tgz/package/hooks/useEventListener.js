import React from 'react';

/**
 * Similar to https://github.com/donavon/use-event-listener
 * Except accepts domNodes and refs as domTarget
 */

function getIsRef(input) {
  return input ? 'current' in input : false;
}
export function useEventListener(eventName, handler) {
  var domTarget = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : global;
  var _ref = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {},
    mode = _ref.mode,
    useLayoutEffect = _ref.useLayoutEffect;
  var savedHandler = React.useRef(null);
  React.useEffect(function () {
    savedHandler.current = handler;
  }, [handler]);
  var useEffect = useLayoutEffect ? React.useLayoutEffect : React.useEffect;
  useEffect(function () {
    var domNode = getIsRef(domTarget) ? domTarget.current : domTarget;
    if (!domNode || !domNode.addEventListener) return undefined;
    var eventListener = function eventListener(event) {
      var _savedHandler$current;
      (_savedHandler$current = savedHandler.current) === null || _savedHandler$current === void 0 || _savedHandler$current.call(savedHandler, event);
    };
    domNode.addEventListener(eventName, eventListener, mode);
    return function () {
      domNode.removeEventListener(eventName, eventListener, mode);
    };
  }, [eventName, domTarget, mode]);
}