import { cnBem } from '@carnica/utils';
import themeV1 from "./themeV1.module.css";
import themeV2 from "./themeV2.module.css";
import alternator from "./alternator.module.css";
export { theme as themeV1 } from "./themeV1";
export { theme as themeV2 } from "./themeV2";
export var cnComponentsTheme = function cnComponentsTheme(theme, version) {
  return cnBem('theme', version === 'v2' ? themeV2 : themeV1)({
    theme: theme !== null && theme !== void 0 ? theme : 'light'
  });
};
export var cnAlternator = cnBem('alternator', alternator);
export var cnAlternateComponentsTheme = function cnAlternateComponentsTheme(theme) {
  return cnBem('theme', themeV2)({
    theme: theme !== null && theme !== void 0 ? theme : 'light'
  });
};