import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["style", "size", "transition", "activeIndex", "rotations", "tagName"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { getSize } from "../../utils/sizeMap";
export var dataConverter = function dataConverter(_ref) {
  var style = _ref.style,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    _ref$transition = _ref.transition,
    transition = _ref$transition === void 0 ? 200 : _ref$transition,
    _ref$activeIndex = _ref.activeIndex,
    activeIndex = _ref$activeIndex === void 0 ? 0 : _ref$activeIndex,
    _ref$rotations = _ref.rotations,
    rotations = _ref$rotations === void 0 ? [] : _ref$rotations,
    _ref$tagName = _ref.tagName,
    tagName = _ref$tagName === void 0 ? 'span' : _ref$tagName,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return _objectSpread(_objectSpread({}, otherProps), {}, {
    tagName: tagName,
    size: size,
    activeIndex: activeIndex,
    transition: transition,
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty(_defineProperty({}, '--icon-size', getSize(size)), '--animate-icon-transition', "".concat(transition, "ms")), typeof rotations[activeIndex] === 'number' && _defineProperty({}, '--animate-icon-rotation', "rotate(".concat(rotations[activeIndex], "deg)")))
  });
};
var getCubicAnimationVariants = function getCubicAnimationVariants(duration) {
  return {
    initial: {
      opacity: 0.3,
      scale: 0.5
    },
    animate: {
      opacity: 1,
      scale: 1,
      transition: {
        ease: [0.14, 0.64, 0.89, 0.87],
        duration: duration / 2
      }
    },
    exit: {
      opacity: 0.2,
      scale: 0.5,
      transition: {
        ease: [0.14, 0.64, 0.89, 0.87],
        duration: duration / 2
      }
    }
  };
};
var getSlideAnimationVariants = function getSlideAnimationVariants(duration) {
  return {
    initial: {
      opacity: 0,
      translateX: '-50%'
    },
    animate: {
      opacity: 1,
      translateX: 0,
      transition: {
        ease: [0.69, -0.01, 0.46, 1.02],
        duration: duration / 2
      }
    },
    exit: {
      opacity: 0,
      translateX: '50%',
      transition: {
        ease: [0.2, 0, 0, 1],
        duration: duration / 2
      }
    }
  };
};
export var getAnimationSettings = function getAnimationSettings(type, transition) {
  return (type === 'slide' ? getSlideAnimationVariants : getCubicAnimationVariants)(transition / 1000);
};