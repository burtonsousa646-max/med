import React from 'react';
export declare const useDidUpdateEffect: (callback: React.EffectCallback, deps?: React.DependencyList) => void;
//# sourceMappingURL=useDidUpdateEffect.d.ts.map