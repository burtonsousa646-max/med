import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { useLink } from "./LinkContext";
export var GenericLink = function GenericLink(props) {
  var Tag = useLink();
  return /*#__PURE__*/React.createElement(Tag, _extends({}, props, {
    "data-t-id": "contexts-link"
  }));
};