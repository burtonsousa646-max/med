import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["icon", "size"];
import React, { forwardRef } from 'react';
import { compose } from '@beef/utils';
import { withDataConverter, withRenderCondition } from '@beef/react';
import { cnBem } from '@carnica/utils';
import { BadgeCore } from "../core";
import { dataConverter, iconSizeMap, logoSizeMap } from "./utils";
import { BadgeStories } from "./BadgeStories";
import styles from "./styles.module.css";
var cnBadge = cnBem('badge-v3', styles);
var BadgeRender = function BadgeRender(_ref, ref) {
  var Icon = _ref.icon,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 's' : _ref$size,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(BadgeCore, _extends({}, props, {
    icon: Icon && /*#__PURE__*/React.createElement(Icon, {
      className: cnBadge('icon'),
      customColor: props.view === 'logo' ? undefined : 'var(--badge-color)',
      size: (props.view === 'logo' ? logoSizeMap : iconSizeMap)[size]
    }),
    ref: ref,
    "data-t-id": "Badge-V3"
  }));
};
export var Badge = compose(withDataConverter(dataConverter), withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref2) {
    var view = _ref2.view,
      icon = _ref2.icon,
      children = _ref2.children;
    return (view !== 'text' || !!children) && (view !== 'icon' && view !== 'logo' || !!icon);
  }
}), forwardRef)(BadgeRender);
Badge.Stories = BadgeStories;