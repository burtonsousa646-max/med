import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnChips = cnBem('skeleton-chips', styles);
export var Chips = function Chips(_ref) {
  var className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    className: cnChips(null, [className]),
    height: 44,
    width: 96
  }, props, {
    "data-t-id": "components-Chips"
  }));
};