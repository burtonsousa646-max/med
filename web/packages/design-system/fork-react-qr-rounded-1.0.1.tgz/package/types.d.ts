import React from 'react';
import type { PropsWithHTMLAttributes } from '@carnica/utils/types';
export type QRPropErrorCorrectionLevel = 'H' | 'L' | 'M' | 'Q';
export type QRProps = PropsWithHTMLAttributes<{
    backgroundColor?: string;
    children?: never;
    color?: string;
    cutout?: boolean;
    cutoutElement?: React.ReactNode;
    errorCorrectionLevel?: QRPropErrorCorrectionLevel;
    rounding?: number;
    size?: number;
    url: string;
    viewPortSize?: number;
}, SVGSVGElement>;
//# sourceMappingURL=types.d.ts.map