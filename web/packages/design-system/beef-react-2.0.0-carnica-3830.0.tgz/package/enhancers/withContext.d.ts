export function withContext(Context: any, mapContextToProps: any): (WrappedComponent: any) => {
    (props: any): React.JSX.Element;
    displayName: string;
};
import React from 'react';
//# sourceMappingURL=withContext.d.ts.map