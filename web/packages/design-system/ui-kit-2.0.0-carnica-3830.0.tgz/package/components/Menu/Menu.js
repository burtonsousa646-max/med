import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "getters", "convertItem", "isOpen", "invert", "onClose", "onItemClick", "onKeyDown", "className"],
  _excluded2 = ["attributes", "key"];
import React, { forwardRef, useState } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { AnimatePresence } from 'framer-motion';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { Popover } from "../../modules/Popover";
import { List } from "../../modules/List";
import { useConvertedItems } from "../../hooks/useConvertedItems";
import { animationVariants, dataConverter, getAnimationDirection, itemKeys } from "./utils";
import styles from "./styles.module.css";
import { MenuItem } from "./MenuItem";
import { useMenuKeyboardHandler } from "./hooks/useMenuKeyboardHandler";
var cnMenu = cnBem('menu', styles);
var MenuRender = function MenuRender(props, ref) {
  var itemsProp = props.items,
    getters = props.getters,
    convertItem = props.convertItem,
    isOpen = props.isOpen,
    invert = props.invert,
    onClose = props.onClose,
    onItemClick = props.onItemClick,
    onKeyDownProp = props.onKeyDown,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useState = useState(otherProps.direction || 'upStartLeft'),
    _useState2 = _slicedToArray(_useState, 2),
    direction = _useState2[0],
    setDirection = _useState2[1];
  var items = useConvertedItems({
    items: itemsProp || [],
    keys: itemKeys,
    convertItem: convertItem,
    getters: getters,
    withOriginal: true
  });
  var _useState3 = useState(),
    _useState4 = _slicedToArray(_useState3, 2),
    hoveredKey = _useState4[0],
    setHoveredKey = _useState4[1];
  var getState = function getState(key) {
    if (typeof hoveredKey === 'undefined') {
      return 'default';
    }
    return key === hoveredKey ? 'hover' : 'faded';
  };
  var onKeyDown = function onKeyDown(e) {
    onKeyDownProp === null || onKeyDownProp === void 0 || onKeyDownProp(e);
    if (e.key === 'Escape') {
      onClose === null || onClose === void 0 || onClose(e);
    }
  };
  var _useMenuKeyboardHandl = useMenuKeyboardHandler(items),
    itemRefs = _useMenuKeyboardHandl.itemRefs,
    onKeyDownByItem = _useMenuKeyboardHandl.onKeyDownByItem;
  var renderItem = function renderItem(item) {
    var handleClick = function handleClick(e) {
      var _item$converted$onCli, _item$converted;
      (_item$converted$onCli = (_item$converted = item.converted).onClick) === null || _item$converted$onCli === void 0 || _item$converted$onCli.call(_item$converted, e);
      onItemClick === null || onItemClick === void 0 || onItemClick(item.original, e);
    };
    var _item$converted2 = item.converted,
      attributes = _item$converted2.attributes,
      key = _item$converted2.key,
      itemProps = _objectWithoutProperties(_item$converted2, _excluded2);
    var attr = attributes;
    var onMouseEnter = function onMouseEnter(e) {
      var _attr$onMouseEnter;
      attr === null || attr === void 0 || (_attr$onMouseEnter = attr.onMouseEnter) === null || _attr$onMouseEnter === void 0 || _attr$onMouseEnter.call(attr, e);
      setHoveredKey(key);
    };
    var state = getState(key);
    var index = items ? items === null || items === void 0 ? void 0 : items.indexOf(item) : -1;
    return /*#__PURE__*/React.createElement(MenuItem, _extends({}, attr, itemProps, {
      invert: invert,
      onClick: handleClick,
      onKeyDown: onKeyDownByItem(item),
      onMouseEnter: onMouseEnter,
      ref: combineRefs([itemRefs[index], item.converted.ref]),
      state: state,
      "data-t-id": "components-Menu"
    }));
  };
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    mode: "wait"
  }, isOpen && /*#__PURE__*/React.createElement(Popover, _extends({}, otherProps, {
    animate: "visible",
    className: cnMenu(null, [className]),
    custom: getAnimationDirection(direction),
    direction: "upStartLeft",
    exit: "hidden",
    initial: "hidden",
    motion: true,
    offsetVertical: 18,
    onChangeDirection: setDirection,
    onClickOutside: onClose,
    onKeyDown: onKeyDown,
    possibleDirections: ['upStartLeft', 'downStartLeft'],
    ref: ref,
    reposition: true,
    transition: {
      duration: 0.3
    },
    variants: animationVariants
  }), /*#__PURE__*/React.createElement(List, {
    className: cnMenu('list', {
      invert: invert
    }),
    convertItem: function convertItem(item) {
      return item.converted;
    },
    items: items,
    onMouseLeave: function onMouseLeave() {
      return setHoveredKey(undefined);
    },
    renderItem: renderItem,
    role: "menu",
    "data-t-id": "components-Menu"
  })));
};
export var Menu = compose(withDataConverter(dataConverter), forwardRef)(MenuRender);