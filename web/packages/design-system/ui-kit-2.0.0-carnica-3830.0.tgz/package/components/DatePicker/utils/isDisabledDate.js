import { isSameDay } from 'date-fns-new';
var clearTime = function clearTime(date, type, params) {
  var _ref = params !== null && params !== void 0 ? params : {},
    hours = _ref.hours,
    minutes = _ref.minutes,
    seconds = _ref.seconds,
    miliseconds = _ref.miliseconds;
  var copyDate = new Date(date);
  if (hours) {
    copyDate.setHours(type === 'start' ? 0 : 23);
  }
  if (minutes) {
    copyDate.setMinutes(type === 'start' ? 0 : 59);
  }
  if (seconds) {
    copyDate.setSeconds(type === 'start' ? 0 : 59);
  }
  if (miliseconds) {
    copyDate.setMilliseconds(type === 'start' ? 0 : 999);
  }
  return copyDate;
};
var isInRangeWithoutTime = function isInRangeWithoutTime(date, min, max) {
  var minTime = min.getTime();
  var maxTime = max.getTime();
  var dateTime = [clearTime(date, 'start', {
    hours: true,
    minutes: true,
    seconds: true,
    miliseconds: true
  }).getTime(), clearTime(date, 'end', {
    hours: true,
    minutes: true,
    seconds: true,
    miliseconds: true
  }).getTime()];
  return minTime <= dateTime[0] && dateTime[0] <= maxTime && minTime <= dateTime[1] && dateTime[1] <= maxTime;
};
export var isDisableDate = function isDisableDate(params) {
  var disableDates = params.disableDates,
    date = params.date;
  if (!disableDates) {
    return false;
  }
  return !!disableDates.find(function (compareDate) {
    return compareDate instanceof Date ? isSameDay(compareDate, date) : isInRangeWithoutTime(date, compareDate[0], compareDate[1]);
  });
};