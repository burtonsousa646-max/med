export declare const ATTRIBUTE_PORTAL = "portal";
export declare const ATTRIBUTE_PORTAL_VALUE = "portal";
export declare const ATTRIBUTE_SEARCH_MODAL = "searchmodal";
//# sourceMappingURL=index.d.ts.map