export const BeelineDigitalScopeList: string[];
//# sourceMappingURL=constants.d.ts.map