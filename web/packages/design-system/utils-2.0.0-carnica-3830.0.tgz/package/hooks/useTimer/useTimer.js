import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { initialConfig } from "./helper";
import { useTimerProgress } from "./useTimerProgress";
export function useTimer(userConfig) {
  var config = _objectSpread(_objectSpread({}, initialConfig), userConfig);
  var _useTimerProgress = useTimerProgress(config),
    isRunning = _useTimerProgress.isRunning,
    time = _useTimerProgress.time,
    intervalRef = _useTimerProgress.intervalRef,
    cancelInterval = _useTimerProgress.cancelInterval,
    createInterval = _useTimerProgress.createInterval,
    resetTime = _useTimerProgress.resetTime,
    shouldResetTimeRef = _useTimerProgress.shouldResetTimeRef;
  var pause = function pause() {
    cancelInterval();
  };
  var reset = function reset(newTime) {
    cancelInterval();
    if (newTime) {
      shouldResetTimeRef.current = false;
    }
    resetTime(newTime);
  };
  var start = function start() {
    var _config$onInterval;
    (_config$onInterval = config.onInterval) === null || _config$onInterval === void 0 || _config$onInterval.call(config, time.current);
    if (intervalRef.current) {
      return;
    }
    if (shouldResetTimeRef.current) {
      resetTime();
      shouldResetTimeRef.current = false;
    }
    createInterval();
  };
  return {
    isRunning: isRunning,
    pause: pause,
    reset: reset,
    start: start,
    time: time
  };
}