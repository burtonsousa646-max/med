import React from 'react';
export declare const useDragScroll: (scrollableRef: React.RefObject<HTMLElement | null>, direction?: "horizontal" | "vertical", isActive?: boolean) => void;
//# sourceMappingURL=useDragScroll.d.ts.map