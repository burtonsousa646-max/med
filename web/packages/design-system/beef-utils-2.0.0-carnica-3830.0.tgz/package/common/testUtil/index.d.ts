export declare const testUtil: () => number;
//# sourceMappingURL=index.d.ts.map