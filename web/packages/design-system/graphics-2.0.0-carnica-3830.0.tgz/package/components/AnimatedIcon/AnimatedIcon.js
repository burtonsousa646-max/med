import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "activeIndex", "iconClassName", "icons", "transition", "size", "colors", "color", "customColor", "animationType"];
import { cnBem } from '@carnica/utils';
import React, { forwardRef } from 'react';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { AnimatePresence } from 'framer-motion';
import { MotionComponent } from "../MotionComponent";
import styles from "./styles.module.css";
import { dataConverter, getAnimationSettings } from "./utils";
var cnAnimatedIcon = cnBem('animated-icon', styles);
var AnimatedIconRender = function AnimatedIconRender(props, ref) {
  var className = props.className,
    _props$activeIndex = props.activeIndex,
    activeIndex = _props$activeIndex === void 0 ? 0 : _props$activeIndex,
    iconClassName = props.iconClassName,
    icons = props.icons,
    _props$transition = props.transition,
    transition = _props$transition === void 0 ? 200 : _props$transition,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    _props$colors = props.colors,
    colors = _props$colors === void 0 ? [] : _props$colors,
    _props$color = props.color,
    color = _props$color === void 0 ? 'primary' : _props$color,
    customColor = props.customColor,
    _props$animationType = props.animationType,
    animationType = _props$animationType === void 0 ? 'cubic' : _props$animationType,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _icons = _slicedToArray(icons, 1),
    FirstIcon = _icons[0];
  var ActiveIcon = icons[activeIndex];
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnAnimatedIcon({
      size: size
    }, [className]),
    ref: ref,
    "data-t-id": "components-AnimatedIcon"
  }), icons.length === 1 ? /*#__PURE__*/React.createElement(FirstIcon, {
    color: colors[activeIndex] || customColor || color,
    iconClassName: iconClassName,
    size: size
  }) : /*#__PURE__*/React.createElement(AnimatePresence, {
    initial: false,
    mode: "wait"
  }, /*#__PURE__*/React.createElement(ActiveIcon, _extends({}, getAnimationSettings(animationType, transition), {
    className: cnAnimatedIcon('icon', {
      animationType: animationType
    }),
    color: colors[activeIndex] || color,
    customColor: customColor,
    iconClassName: iconClassName,
    key: activeIndex,
    motion: true,
    size: size,
    "data-t-id": "components-AnimatedIcon"
  }))));
};
export var AnimatedIcon = compose(withDataConverter(dataConverter), forwardRef)(AnimatedIconRender);