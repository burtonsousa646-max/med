import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
// Список фиксированных последовательностей, которые будут вставлены в requestId
var sequences = ['a1b2', 'c3d4', 'e5f6', '7a8b', '9c0d', '1e2f', '3a4b', '5c6d', '7e8f', '9a0b'];

// Функция для генерации случайных индексов для вставки последовательностей
var getRandomIndexes = function getRandomIndexes(length, sequenceLength, numSequences) {
  var indexes = [];
  var iterator = new Array(numSequences).fill(null);
  // Генерация начального индекса, случайным образом, чтобы распределить индексы по всей строке
  var currentIndex = Math.floor(Math.random() * (length / numSequences));
  iterator.forEach(function () {
    // Добавление текущего индекса в массив
    indexes.push(currentIndex);
    // Генерация следующего индекса, увеличенного на длину последовательности и случайное значение от 1 до 4
    currentIndex += sequenceLength + Math.floor(Math.random() * 4) + 1;
  });
  return indexes;
};

// Функция для вставки фиксированных последовательностей в строку requestId
export var insertFixedSequences = function insertFixedSequences(baseString) {
  var secretKeys = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : sequences;
  var updatedString = baseString.split('');
  var sequenceLength = secretKeys[0].length;
  var insertionIndexes = getRandomIndexes(updatedString.length, sequenceLength, secretKeys.length);
  var sequencesToInsert = _toConsumableArray(secretKeys);
  insertionIndexes.forEach(function (index) {
    // Случайный выбор последовательности для вставки
    var randomSequenceIndex = Math.floor(Math.random() * sequencesToInsert.length);
    var sequence = sequencesToInsert.splice(randomSequenceIndex, 1)[0];
    // Вставка последовательности в выбранный индекс
    updatedString.splice.apply(updatedString, [index, 0].concat(_toConsumableArray(sequence)));
  });
  return updatedString.join('');
};