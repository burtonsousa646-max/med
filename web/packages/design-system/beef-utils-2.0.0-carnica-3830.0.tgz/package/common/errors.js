export var throwNonBlockingError = function throwNonBlockingError(error) {
  setTimeout(function () {
    if (error instanceof Error) throw error;
    throw new Error(error);
  }, 0);
};