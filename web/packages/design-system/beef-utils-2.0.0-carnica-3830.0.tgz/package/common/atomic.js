export var passAsIs = function passAsIs(obj) {
  return obj;
};
export var passUndefined = function passUndefined() {
  return undefined;
};
export var noop = function noop() {
  return undefined;
};
export var isNullOrUndefined = function isNullOrUndefined(value) {
  return value === null || typeof value === 'undefined';
};
export var valueOr = function valueOr(value, defaultValue) {
  var _ref = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
    _ref$undefined = _ref.undefined,
    replaceUndefined = _ref$undefined === void 0 ? true : _ref$undefined,
    _ref$null = _ref.null,
    replaceNull = _ref$null === void 0 ? true : _ref$null;
  return replaceUndefined && typeof value === 'undefined' || replaceNull && value === null ? defaultValue : value;
};
export var valueOrFn = function valueOrFn(value, defaultValueGetter) {
  var _ref2 = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
    _ref2$undefined = _ref2.undefined,
    replaceUndefined = _ref2$undefined === void 0 ? true : _ref2$undefined,
    _ref2$null = _ref2.null,
    replaceNull = _ref2$null === void 0 ? true : _ref2$null;
  if (replaceUndefined && typeof value === 'undefined' || replaceNull && value === null) return defaultValueGetter();
  return value;
};
export var valueToString = function valueToString(value) {
  return isNullOrUndefined(value) ? '' : value.toString();
};
export var emptyObj = {};
export var emptyArr = [];