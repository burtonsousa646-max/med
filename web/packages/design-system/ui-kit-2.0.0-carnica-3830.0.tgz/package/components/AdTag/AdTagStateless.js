import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _extends from "@babel/runtime/helpers/extends";
var _excluded = ["children", "label", "invert", "background", "className", "icon", "popoverProps", "size", "bottomSheetTitle", "id", "onKeyDown", "tooltipOpen", "tooltipDirection"],
  _excluded2 = ["onClickOutside", "closureModes", "closureOptions", "onClose", "container", "theme", "portalClassName", "id"];
import React, { forwardRef, useCallback, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { useDeprecationWarning, useIsMobileDimension } from '@carnica/utils/hooks';
import { IconDotsRoundOutline } from '@carnica/graphics';
import { Tooltip } from "../Tooltip";
import { BottomSheet } from "../../modules/BottomSheet";
import { Text } from "../Text";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { getSettings } from "./utils";
var cnAdTag = cnBem('ad-tag', styles);
var DefaultIcon = function DefaultIcon(props) {
  return /*#__PURE__*/React.createElement(IconDotsRoundOutline, _extends({}, props, {
    iconClassName: cnAdTag('dots', [props.iconClassName]),
    "data-t-id": "components-AdTag"
  }));
};
var getTheme = function getTheme(invert, theme) {
  if (typeof invert === 'boolean') {
    return invert ? 'dark' : 'light';
  }
  return theme;
};
var AdTagStatelessRender = function AdTagStatelessRender(props, ref) {
  var children = props.children,
    _props$label = props.label,
    label = _props$label === void 0 ? 'реклама' : _props$label,
    invert = props.invert,
    _props$background = props.background,
    background = _props$background === void 0 ? 'light' : _props$background,
    className = props.className,
    _props$icon = props.icon,
    Icon = _props$icon === void 0 ? DefaultIcon : _props$icon,
    popoverProps = props.popoverProps,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    _props$bottomSheetTit = props.bottomSheetTitle,
    bottomSheetTitle = _props$bottomSheetTit === void 0 ? 'реклама' : _props$bottomSheetTit,
    id = props.id,
    onKeyDownProp = props.onKeyDown,
    tooltipOpen = props.tooltipOpen,
    _props$tooltipDirecti = props.tooltipDirection,
    tooltipDirection = _props$tooltipDirecti === void 0 ? 'upCenter' : _props$tooltipDirecti,
    otherProps = _objectWithoutProperties(props, _excluded);
  var buttonRef = useRef(null);
  var isMobile = useIsMobileDimension();
  var _getSettings = getSettings(size),
    iconSize = _getSettings.iconSize,
    labelSettings = _getSettings.labelSettings;
  useDeprecationWarning({
    invert: {
      value: invert,
      customMessage: 'Используй вместо него свойство `theme` из `popoverProps`.'
    }
  });
  var _ref = popoverProps || {},
    onClickOutside = _ref.onClickOutside,
    closureModes = _ref.closureModes,
    closureOptions = _ref.closureOptions,
    onClose = _ref.onClose,
    container = _ref.container,
    theme = _ref.theme,
    portalClassName = _ref.portalClassName,
    _ref$id = _ref.id,
    popoverId = _ref$id === void 0 ? id ? "popover-".concat(id) : undefined : _ref$id,
    otherPopoverProps = _objectWithoutProperties(_ref, _excluded2);
  var handleBottomSheetClose = useCallback(function (e) {
    onClose === null || onClose === void 0 || onClose(e, 'outsideClick');
  }, [onClose]);
  var onKeyDown = useCallback(function (e) {
    if (e.code === 'Escape') {
      onClose === null || onClose === void 0 || onClose(e, 'outsideClick');
    }
    onKeyDownProp === null || onKeyDownProp === void 0 || onKeyDownProp(e);
  }, [onClose, onKeyDownProp]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(MotionComponent, _extends({
    "aria-describedby": popoverId,
    "aria-label": "\u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E \u0440\u0435\u043A\u043B\u0430\u043C\u0435",
    className: cnAdTag({
      size: size,
      background: background
    }, [className]),
    id: id,
    onKeyDown: onKeyDown,
    tagName: "button",
    type: "button"
  }, otherProps, {
    ref: combineRefs([ref, buttonRef])
  }), /*#__PURE__*/React.createElement(Text, _extends({}, labelSettings, {
    className: cnAdTag('label'),
    color: "white",
    rows: 1,
    tagName: "span",
    truncate: true,
    "data-t-id": "components-AdTag"
  }), label), Icon && /*#__PURE__*/React.createElement(Icon, {
    className: cnAdTag('icon'),
    color: "white",
    size: iconSize
  })), isMobile ? /*#__PURE__*/React.createElement(BottomSheet, _extends({
    id: popoverId,
    isOpen: tooltipOpen,
    onClose: handleBottomSheetClose,
    portalClassName: portalClassName
  }, otherPopoverProps), /*#__PURE__*/React.createElement(Text, {
    className: cnAdTag('title'),
    color: "primary",
    variant: "display-small",
    "data-t-id": "components-AdTag"
  }, bottomSheetTitle), /*#__PURE__*/React.createElement(Text, {
    color: "secondary",
    tagName: "div",
    variant: "body-small"
  }, children)) : /*#__PURE__*/React.createElement(Tooltip, _extends({
    anchorRef: buttonRef,
    closureModes: closureModes,
    closureOptions: closureOptions,
    container: container,
    direction: tooltipDirection,
    id: popoverId,
    invert: background === 'dark',
    isOpen: tooltipOpen,
    onClickOutside: onClickOutside,
    onClose: onClose,
    theme: getTheme(invert, theme)
  }, otherPopoverProps), children));
};
export var AdTagStateless = /*#__PURE__*/forwardRef(AdTagStatelessRender);