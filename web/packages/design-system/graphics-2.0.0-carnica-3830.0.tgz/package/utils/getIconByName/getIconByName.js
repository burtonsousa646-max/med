import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { defineUrlIcon } from "../defineUrlIcon";
import { baseServerUrl } from '..';
import { iconNamesMap, iconsSpecificSettings } from "./utils";
var getServerFolder = function getServerFolder(name) {
  var _name$match;
  return "".concat((_name$match = name.match(/[A-Z][a-z]+/g)) === null || _name$match === void 0 ? void 0 : _name$match[0].toLowerCase(), "s");
};
export var getIconByName = function getIconByName(name) {
  return defineUrlIcon(_objectSpread({
    multiColor: name.startsWith('Icon'),
    url: "".concat(baseServerUrl, "/").concat(getServerFolder(name), "/").concat(iconNamesMap[name] || name, ".svg")
  }, iconsSpecificSettings[name] || {}));
};