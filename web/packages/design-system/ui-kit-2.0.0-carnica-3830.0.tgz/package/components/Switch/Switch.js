import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "labelColor", "disabled", "labelProps", "labelPosition"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { getTextColorVariable } from "../../utils/text";
import styles from "./styles.module.css";
import { Toggle } from "../Toggle";
var cnSwitch = cnBem('switch', styles);
export var Switch = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var className = _ref.className,
    _ref$labelColor = _ref.labelColor,
    labelColor = _ref$labelColor === void 0 ? 'primary' : _ref$labelColor,
    disabled = _ref.disabled,
    labelProps = _ref.labelProps,
    _ref$labelPosition = _ref.labelPosition,
    labelPosition = _ref$labelPosition === void 0 ? 'right' : _ref$labelPosition,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(Toggle, _extends({}, otherProps, {
    className: cnSwitch({
      labelPosition: labelPosition,
      interactive: !disabled
    }, [className]),
    disabled: disabled,
    inputClassName: cnSwitch('input'),
    labelClassName: cnSwitch('label'),
    labelProps: _objectSpread(_objectSpread({}, labelProps || {}), {}, {
      style: _objectSpread(_objectSpread({}, (labelProps === null || labelProps === void 0 ? void 0 : labelProps.style) || {}), {}, _defineProperty({}, '--switch-label-color', getTextColorVariable(labelColor)))
    }),
    ref: ref,
    "data-t-id": "components-Switch"
  }));
});