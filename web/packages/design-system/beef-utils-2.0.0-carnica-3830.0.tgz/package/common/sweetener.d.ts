export type SweetenObj<T extends Record<any, any>> = T & SugarObject<T>;
export type SweetenArr<T> = SugarArray<T>;
export type SweetenAny<T> = T extends any[] ? SweetenArr<T[number]> : T extends Record<any, any> ? SweetenObj<T> : T;
declare abstract class SugarArray<T> extends Array {
    map<U>(fn: (value: T, index: number, obj: T[]) => U): SweetenArr<U>;
    flatMap<U>(fn: (value: T, index: number, array: T[]) => ReadonlyArray<U> | U): SweetenArr<U>;
    filter(fn: (value: T, index: number, arr: T[]) => boolean): SweetenArr<T>;
    reduce<U>(fn: (accum: T, value: T, index: number, arr: T[]) => U): SweetenAny<U>;
    reduce<U>(fn: (accum: U, value: T, index: number, arr: U) => U, init: U): SweetenAny<U>;
    slice(start?: number, end?: number): SweetenArr<T>;
    toObject<K extends PropertyKey>(getKey: (value: T, index: number) => K): SweetenObj<Record<K, number>>;
    toObject<K extends PropertyKey, V = T>(getKey: (value: T, index: number) => K, getValue: V): SweetenObj<Record<K, V>>;
    toObject<K extends PropertyKey, V = T>(getKey: (value: T, index: number) => K, getValue: (value: T, index: number) => V): SweetenObj<Record<K, V>>;
    pipe<R>(fn: (a: T[]) => R): SweetenAny<R>;
    raw(): T[];
}
declare abstract class SugarObject<T extends Record<any, any>> {
    map<U>(fn: (value: T[keyof T], key: keyof T) => U): SweetenObj<Record<keyof T, U>>;
    forEach<U>(fn: (value: T[keyof T], key: keyof T) => U): void;
    mapKeys<U extends PropertyKey>(fn: (key: keyof T, value: T[keyof T]) => U): SweetenObj<Record<U, T[keyof T]>>;
    filter(fn: (value: T[keyof T], key: keyof T) => boolean): SweetenObj<{
        [key in keyof T]: T[key];
    }>;
    reduce<U>(fn: (acc: U, val: T[keyof T], key: keyof T) => U, init: U): SweetenAny<U>;
    keys(): SweetenArr<keyof T>;
    values(): SweetenArr<T[keyof T]>;
    pipe<R>(fn: (a: T) => R): SweetenAny<R>;
    raw(): T;
}
export declare const S: (<T>(value: T) => SweetenAny<T>) & {
    Arr: <T>(arr: T[]) => SweetenArr<T>;
    Obj: <T extends Record<PropertyKey, any>>(obj: T) => SweetenObj<T>;
};
export {};
//# sourceMappingURL=sweetener.d.ts.map