import { createContext, useContext } from 'react';
export var ActionSheetPopoverContext = /*#__PURE__*/createContext({
  loading: false,
  changeLoading: function changeLoading() {}
});
export var useActionSheetPopoverContext = function useActionSheetPopoverContext() {
  return useContext(ActionSheetPopoverContext);
};