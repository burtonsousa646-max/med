const configUtils = require('./configUtils');
module.exports = configUtils;