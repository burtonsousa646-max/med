import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import sha256 from 'crypto-js/sha256';
import { insertFixedSequences } from "./utils";
export var secureRequestInterceptor = function secureRequestInterceptor(config) {
  var timestamp = new Date().toISOString();
  // Создание хэша из текущего времени
  var timestampHash = sha256(Date.now().toString()).toString();
  // Вставка фиксированных последовательностей в хэш
  var requestId = insertFixedSequences(timestampHash, config === null || config === void 0 ? void 0 : config.secretKeys);

  // Создание подписи запроса на основе URL, requestId и времени
  var requestSign = sha256(config.url + requestId + timestamp).toString();
  return _objectSpread(_objectSpread({}, config), {}, {
    headers: _objectSpread(_objectSpread({}, config.headers), {}, {
      'X-Request-Id': requestId,
      'X-Request-Sign': requestSign,
      'X-Request-Timestamp': timestamp
    })
  });
};
export function softSecureRequestInterceptor(filter) {
  return function (config) {
    return filter(config) ? secureRequestInterceptor(config) : config;
  };
}
export var createWaffleInterceptor = function createWaffleInterceptor(selectors) {
  return function (error) {
    try {
      var _headers$contentType;
      // @ts-expect-error TS2339: error.response is present in catch block for HTTP-errors
      var _error$response = error.response,
        status = _error$response.status,
        headers = _error$response.headers,
        data = _error$response.data;
      var config = error.config;
      var contentType = ((_headers$contentType = headers['content-type']) === null || _headers$contentType === void 0 ? void 0 : _headers$contentType.toLowerCase()) || '';
      if (!(config !== null && config !== void 0 && config.skipWaffleInterceptor) && !(config !== null && config !== void 0 && config.__accessDeniedHandled) && status === 403 && contentType.includes('text/html')) {
        // skip duplicate call this interceptor
        config.__accessDeniedHandled = true;
        var parser = new DOMParser();
        var htmlResponse = parser.parseFromString(data, 'text/html');
        var _selectors = selectors || {};
        var pluckValue = function pluckValue(key) {
          var _window$beeWaffleIron;
          return typeof (_selectors === null || _selectors === void 0 ? void 0 : _selectors[key]) === 'function' ? _selectors[key](data) : htmlResponse.querySelector(
          // @ts-expect-error TS2339: Property beeWaffleIron does not exist on type Window & typeof globalThis
          (_selectors === null || _selectors === void 0 ? void 0 : _selectors[key]) || ((_window$beeWaffleIron = window.beeWaffleIron) === null || _window$beeWaffleIron === void 0 || (_window$beeWaffleIron = _window$beeWaffleIron.selectors) === null || _window$beeWaffleIron === void 0 ? void 0 : _window$beeWaffleIron[key]) || "#d-".concat(key)).textContent;
        };
        var _id = pluckValue('id');
        var _ip = pluckValue('ip');
        var waffleEvent = new CustomEvent('safety-waffle-iron:access-denied', {
          detail: {
            ip: _ip.startsWith('IP-') ? _ip.split('IP-')[1] : _ip,
            id: _id.startsWith('IDB-') ? _id.split('IDB-')[1] : _id
          }
        });
        window.dispatchEvent(waffleEvent);
      }
      return Promise.reject(error);
    } catch (e) {
      console.error('[WaffleInterceptor] Parsing failed:', e);
      return Promise.reject(error);
    }
  };
};