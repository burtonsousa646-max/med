export default [{
  name: 'Background',
  colors: [{
    name: '--color-background-primary',
    value: 'rgba(240, 243, 245, 1)'
  }, {
    name: '--color-background-secondary',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-background-tertiary',
    value: 'rgba(240, 243, 245, 1)'
  }, {
    name: '--color-background-additional01',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-background-additional02',
    value: 'rgba(119, 132, 157, 0.12)'
  }, {
    name: '--color-background-primary-fake-invert',
    value: 'rgba(24, 28, 35, 1)'
  }, {
    name: '--color-background-secondary-fake-invert',
    value: 'rgba(32, 38, 50, 1)'
  }, {
    name: '--color-background-tertiary-fake-invert',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-background-additional-fake-invert',
    value: 'rgba(119, 132, 157, 0.12)'
  }]
}, {
  name: 'Elements',
  colors: [{
    name: '--color-elements-primary',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-elements-secondary',
    value: 'rgba(240, 243, 245, 1)'
  }, {
    name: '--color-elements-tertiary',
    value: 'rgba(226, 230, 237, 1)'
  }, {
    name: '--color-elements-disabled',
    value: 'rgba(226, 230, 237, 1)'
  }, {
    name: '--color-elements-additional01',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-elements-additional02',
    value: 'rgba(119, 132, 157, 0.12)'
  }, {
    name: '--color-elements-active',
    value: 'rgba(32, 38, 50, 1)'
  }, {
    name: '--color-elements-primary-fake-invert',
    value: 'rgba(32, 38, 50, 1)'
  }, {
    name: '--color-elements-secondary-fake-invert',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-elements-tertiary-fake-invert',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-elements-disabled-fake-invert',
    value: 'rgba(50, 60, 78, 1)'
  }, {
    name: '--color-elements-additional01-fake-invert',
    value: 'rgba(119, 132, 157, 0.12)'
  }, {
    name: '--color-elements-additional02-fake-invert',
    value: 'rgba(119, 132, 157, 0.12)'
  }, {
    name: '--color-elements-active-fake-invert',
    value: 'rgba(255, 255, 255, 1)'
  }]
}, {
  name: 'Content',
  colors: [{
    name: '--color-content-primary',
    value: 'rgba(40, 48, 63, 1)'
  }, {
    name: '--color-content-secondary',
    value: 'rgba(119, 132, 157, 1)'
  }, {
    name: '--color-content-tertiary',
    value: 'rgba(142, 153, 175, 1)'
  }, {
    name: '--color-content-disabled',
    value: 'rgba(165, 174, 192, 1)'
  }, {
    name: '--color-content-primary-fake-invert',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-content-secondary-fake-invert',
    value: 'rgba(165, 174, 192, 1)'
  }, {
    name: '--color-content-tertiary-fake-invert',
    value: 'rgba(119, 132, 157, 1)'
  }, {
    name: '--color-content-disabled-fake-invert',
    value: 'rgba(88, 101, 126, 1)'
  }, {
    name: '--color-content-primary-invert',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-content-secondary-invert',
    value: 'rgba(165, 174, 192, 1)'
  }, {
    name: '--color-content-tertiary-invert',
    value: 'rgba(119, 132, 157, 1)'
  }, {
    name: '--color-content-disabled-invert',
    value: 'rgba(88, 101, 126, 1)'
  }]
}, {
  name: 'Overlay',
  colors: [{
    name: '--color-overlay-xl',
    value: 'rgba(24, 28, 35, 0.9)'
  }, {
    name: '--color-overlay-l',
    value: 'rgba(40, 48, 63, 0.2)'
  }, {
    name: '--color-overlay-m',
    value: 'rgba(240, 243, 245, 0.8)'
  }, {
    name: '--color-overlay-s',
    value: 'rgba(240, 243, 245, 0.3)'
  }, {
    name: '--color-overlay-xs',
    value: 'rgba(255, 255, 255, 0.1)'
  }]
}, {
  name: 'Glass',
  colors: [{
    name: '--color-glass-primary',
    value: 'rgba(255, 255, 255, 0.5)'
  }, {
    name: '--color-glass-secondary',
    value: 'rgba(240, 243, 245, 0.5)'
  }, {
    name: '--color-glass-disabled',
    value: 'rgba(226, 230, 237, 0.6)'
  }, {
    name: '--color-glass-invert',
    value: 'rgba(32, 38, 50, 0.8)'
  }, {
    name: '--color-glass-primary-fake-invert',
    value: 'rgba(119, 132, 157, 0.12)'
  }, {
    name: '--color-glass-secondary-fake-invert',
    value: 'rgba(119, 132, 157, 0.12)'
  }, {
    name: '--color-glass-disabled-fake-invert',
    value: 'rgba(50, 60, 78, 0.6)'
  }, {
    name: '--color-glass-active-fake-invert',
    value: 'rgba(255, 255, 255, 0.8)'
  }, {
    name: '--color-glass-brand',
    value: 'rgba(255, 200, 0, 0.8)'
  }, {
    name: '--color-glass-error',
    value: 'rgba(248, 74, 0, 0.8)'
  }]
}, {
  name: 'Border',
  colors: [{
    name: '--color-border-primary',
    value: 'rgba(195, 201, 213, 1)'
  }, {
    name: '--color-border-secondary',
    value: 'rgba(226, 230, 237, 1)'
  }, {
    name: '--color-border-primary-fake-invert',
    value: 'rgba(88, 101, 126, 1)'
  }, {
    name: '--color-border-secondary-fake-invert',
    value: 'rgba(60, 71, 93, 1)'
  }, {
    name: '--color-border-primary-invert',
    value: 'rgba(88, 101, 126, 1)'
  }, {
    name: '--color-border-secondary-invert',
    value: 'rgba(60, 71, 93, 1)'
  }]
}, {
  name: 'Constant',
  colors: [{
    name: '--color-constant-light',
    value: 'rgba(255, 255, 255, 1)'
  }, {
    name: '--color-constant-dark',
    value: 'rgba(40, 48, 63, 1)'
  }]
}, {
  name: 'Brand',
  colors: [{
    name: '--color-brand-primary',
    value: 'rgba(255, 200, 0, 1)'
  }, {
    name: '--color-brand-secondary',
    value: 'rgba(255, 213, 70, 1)'
  }, {
    name: '--color-brand-tertiary',
    value: 'rgba(244, 184, 7, 1)'
  }]
}, {
  name: 'Success',
  colors: [{
    name: '--color-success-primary',
    value: 'rgba(0, 165, 94, 1)'
  }, {
    name: '--color-success-secondary',
    value: 'rgba(0, 192, 109, 1)'
  }, {
    name: '--color-success-tertiary',
    value: 'rgba(0, 143, 81, 1)'
  }]
}, {
  name: 'Error',
  colors: [{
    name: '--color-error-primary',
    value: 'rgba(248, 74, 0, 1)'
  }, {
    name: '--color-error-secondary',
    value: 'rgba(255, 101, 36, 1)'
  }, {
    name: '--color-error-tertiary',
    value: 'rgba(184, 55, 0, 1)'
  }]
}, {
  name: 'Link',
  colors: [{
    name: '--color-link-primary',
    value: 'rgba(16, 134, 249, 1)'
  }, {
    name: '--color-link-secondary',
    value: 'rgba(46, 148, 250, 1)'
  }, {
    name: '--color-link-tertiary',
    value: 'rgba(6, 112, 219, 1)'
  }]
}, {
  name: 'Surface',
  colors: [{
    name: '--color-surface-01-green',
    value: 'rgba(203, 246, 227, 1)'
  }, {
    name: '--color-surface-02-teal',
    value: 'rgba(191, 248, 241, 1)'
  }, {
    name: '--color-surface-03-blue',
    value: 'rgba(215, 235, 254, 1)'
  }, {
    name: '--color-surface-04-violet',
    value: 'rgba(231, 223, 251, 1)'
  }, {
    name: '--color-surface-05-magenta',
    value: 'rgba(251, 219, 236, 1)'
  }, {
    name: '--color-surface-06-red',
    value: 'rgba(253, 216, 216, 1)'
  }, {
    name: '--color-surface-07-orange',
    value: 'rgba(255, 216, 199, 1)'
  }, {
    name: '--color-surface-08-yellow',
    value: 'rgba(255, 233, 153, 1)'
  }]
}, {
  name: 'Accent',
  colors: [{
    name: '--color-accent-01-green-primary',
    value: 'rgba(0, 165, 94, 1)'
  }, {
    name: '--color-accent-01-green-secondary',
    value: 'rgba(0, 165, 94, 0.44)'
  }, {
    name: '--color-accent-01-green-tertiary',
    value: 'rgba(0, 165, 94, 0.24)'
  }, {
    name: '--color-accent-02-teal-primary',
    value: 'rgba(0, 168, 148, 1)'
  }, {
    name: '--color-accent-02-teal-secondary',
    value: 'rgba(0, 168, 148, 0.44)'
  }, {
    name: '--color-accent-02-teal-tertiary',
    value: 'rgba(0, 168, 148, 0.24)'
  }, {
    name: '--color-accent-03-blue-primary',
    value: 'rgba(16, 134, 249, 1)'
  }, {
    name: '--color-accent-03-blue-secondary',
    value: 'rgba(16, 134, 249, 0.44)'
  }, {
    name: '--color-accent-03-blue-tertiary',
    value: 'rgba(16, 134, 249, 0.24)'
  }, {
    name: '--color-accent-04-violet-primary',
    value: 'rgba(126, 86, 235, 1)'
  }, {
    name: '--color-accent-04-violet-secondary',
    value: 'rgba(126, 86, 235, 0.44)'
  }, {
    name: '--color-accent-04-violet-tertiary',
    value: 'rgba(126, 86, 235, 0.24)'
  }, {
    name: '--color-accent-05-magenta-primary',
    value: 'rgba(229, 46, 144, 1)'
  }, {
    name: '--color-accent-05-magenta-secondary',
    value: 'rgba(229, 46, 144, 0.44)'
  }, {
    name: '--color-accent-05-magenta-tertiary',
    value: 'rgba(229, 46, 144, 0.24)'
  }, {
    name: '--color-accent-06-red-primary',
    value: 'rgba(244, 52, 52, 1)'
  }, {
    name: '--color-accent-06-red-secondary',
    value: 'rgba(244, 52, 52, 0.44)'
  }, {
    name: '--color-accent-06-red-tertiary',
    value: 'rgba(244, 52, 52, 0.24)'
  }, {
    name: '--color-accent-07-orange-primary',
    value: 'rgba(248, 74, 0, 1)'
  }, {
    name: '--color-accent-07-orange-secondary',
    value: 'rgba(248, 74, 0, 0.44)'
  }, {
    name: '--color-accent-07-orange-tertiary',
    value: 'rgba(248, 74, 0, 0.24)'
  }, {
    name: '--color-accent-08-yellow-primary',
    value: 'rgba(255, 200, 0, 1)'
  }, {
    name: '--color-accent-08-yellow-secondary',
    value: 'rgba(255, 200, 0, 0.44)'
  }, {
    name: '--color-accent-08-yellow-tertiary',
    value: 'rgba(255, 200, 0, 0.24)'
  }]
}];