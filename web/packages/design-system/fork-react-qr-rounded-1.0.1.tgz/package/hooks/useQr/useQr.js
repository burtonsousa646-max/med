import { useMemo } from 'react';
import qrGenerator from 'qrcode-generator';
import { useQrPath } from "./useQrPath";
import { calculateCutoutArea } from "./utils";
export var useQr = function useQr(_ref) {
  var url = _ref.url,
    _ref$rounding = _ref.rounding,
    rounding = _ref$rounding === void 0 ? 60 : _ref$rounding,
    _ref$errorCorrectionL = _ref.errorCorrectionLevel,
    errorCorrectionLevel = _ref$errorCorrectionL === void 0 ? 'H' : _ref$errorCorrectionL,
    size = _ref.size,
    cutout = _ref.cutout,
    _ref$viewPortSize = _ref.viewPortSize,
    viewPortSize = _ref$viewPortSize === void 0 ? 1000 : _ref$viewPortSize;
  var qrData = useMemo(function () {
    var _loop = function _loop() {
        try {
          qrGenerator.stringToBytes = qrGenerator.stringToBytesFuncs['UTF-8'];
          var qr = qrGenerator(version, errorCorrectionLevel);
          qr.addData(url);
          qr.make();
          var moduleCount = qr.getModuleCount();
          var isDarkArea = function isDarkArea(row, col) {
            return row >= 0 && row < moduleCount && col >= 0 && col < moduleCount && qr.isDark(row, col);
          };
          return {
            v: {
              moduleCount: moduleCount,
              isDarkArea: isDarkArea
            }
          };
        } catch (err) {
          if (!(version < 40 && /code length overflow/i.test(String(err)))) {
            throw err;
          }
        }
      },
      _ret;
    for (var version = 1; version <= 40; version += 1) {
      _ret = _loop();
      if (_ret) return _ret.v;
    }
    return null;
  }, [url, errorCorrectionLevel]);
  var cutoutModuleArea = calculateCutoutArea(size, qrData === null || qrData === void 0 ? void 0 : qrData.moduleCount);
  var qrPath = useQrPath({
    viewPortSize: viewPortSize,
    rounding: rounding,
    isDarkArea: qrData === null || qrData === void 0 ? void 0 : qrData.isDarkArea,
    cutoutModuleArea: cutout ? cutoutModuleArea : undefined,
    moduleCount: qrData === null || qrData === void 0 ? void 0 : qrData.moduleCount
  });
  return {
    cutoutModuleArea: cutoutModuleArea,
    qrPath: qrPath,
    moduleCount: qrData === null || qrData === void 0 ? void 0 : qrData.moduleCount
  };
};