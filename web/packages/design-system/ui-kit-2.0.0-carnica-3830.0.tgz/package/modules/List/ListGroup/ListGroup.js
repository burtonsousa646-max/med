import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "className"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { Text } from "../../../components/Text";
import styles from "./styles.module.css";
var cnListGroup = cnBem('list--group', styles);
export var ListGroup = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var children = _ref.children,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    align: "left",
    className: cnListGroup(null, [className]),
    color: "tertiary-invert",
    ref: ref,
    tagName: "span",
    variant: "body-small",
    "data-t-id": "List-ListGroup"
  }), children);
});