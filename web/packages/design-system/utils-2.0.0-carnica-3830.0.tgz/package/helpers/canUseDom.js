export var canUseDom = function canUseDom() {
  var _window;
  return !!(typeof window !== 'undefined' && (_window = window) !== null && _window !== void 0 && (_window = _window.document) !== null && _window !== void 0 && _window.createElement);
};