import { IconPropSize } from '../types/IconComponent';
export declare const sizeMap: Record<IconPropSize, number>;
export declare const getSize: (size: IconPropSize | number) => string;
//# sourceMappingURL=sizeMap.d.ts.map