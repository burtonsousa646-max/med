import { type Ctor } from './common';
import type { Plugin, PluginArgs } from './types';
export type UsePlugin = <C extends Plugin>(PluginCls: C, ...args: PluginArgs<C>) => (C extends Ctor ? InstanceType<C> : C) | undefined;
export declare const usePlugin: UsePlugin & {
    replace: UsePlugin;
    exclude: (Plugin: Ctor, enabled?: boolean) => undefined;
};
//# sourceMappingURL=usePlugin.d.ts.map