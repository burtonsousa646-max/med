import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "range", "value", "onChange", "onFocus", "onBlur", "minDate", "maxDate", "disableDates", "onClear"];
import React, { forwardRef } from 'react';
import { format } from 'date-fns-new';
import { MonthInput as SingleMonthInput } from "../../../AdvancedInputs";
import { monthFormat, useMonthInput } from "../../hooks/usePickerInput";
export var MontInput = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    range = props.range,
    value = props.value,
    onChange = props.onChange,
    _onFocus = props.onFocus,
    _onBlur = props.onBlur,
    minDate = props.minDate,
    maxDate = props.maxDate,
    disableDates = props.disableDates,
    _onClear = props.onClear,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useMonthInput = useMonthInput({
      range: range,
      value: value,
      disableDates: disableDates,
      onChange: onChange,
      minDate: minDate,
      maxDate: maxDate
    }),
    maskOptions = _useMonthInput.maskOptions,
    handleChange = _useMonthInput.onChange;
  return /*#__PURE__*/React.createElement(SingleMonthInput, _extends({}, otherProps, {
    maskOptions: maskOptions,
    onBlur: function onBlur(_, e) {
      return _onBlur === null || _onBlur === void 0 ? void 0 : _onBlur(value || null, e);
    },
    onChange: handleChange,
    onClear: function onClear(_, e) {
      return _onClear === null || _onClear === void 0 ? void 0 : _onClear(null, e);
    },
    onFocus: function onFocus(_, e) {
      return _onFocus === null || _onFocus === void 0 ? void 0 : _onFocus(value || null, e);
    },
    ref: ref,
    unmask: false,
    value: value ? format(value, monthFormat) : '',
    "data-t-id": "Input-MonthInput"
  }));
});