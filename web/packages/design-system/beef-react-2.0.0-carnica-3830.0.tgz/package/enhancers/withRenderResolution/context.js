import { createContext, useContext } from 'react';
export var RenderResolutionContext = /*#__PURE__*/createContext(null);
export var useRenderResolution = function useRenderResolution() {
  var context = useContext(RenderResolutionContext);
  return context !== null && context !== void 0 ? context : null;
};