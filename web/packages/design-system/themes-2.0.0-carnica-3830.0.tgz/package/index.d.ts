export { cnTheme } from './utils';
//# sourceMappingURL=index.d.ts.map