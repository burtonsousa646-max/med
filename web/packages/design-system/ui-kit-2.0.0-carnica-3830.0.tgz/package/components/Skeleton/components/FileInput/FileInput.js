import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "invert", "color", "withLabel"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnFileInput = cnBem('skeleton-file-input', styles);
export var FileInput = function FileInput(_ref) {
  var className = _ref.className,
    invert = _ref.invert,
    color = _ref.color,
    _ref$withLabel = _ref.withLabel,
    withLabel = _ref$withLabel === void 0 ? true : _ref$withLabel,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnFileInput(null, [className])
  }, props, {
    "data-t-id": "components-FileInput"
  }), withLabel && /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 16,
    invert: invert,
    width: 100
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 148,
    invert: invert,
    width: "100%"
  }));
};