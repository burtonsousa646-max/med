import { IconCheckShieldOutline, IconInfoOutline, IconTrashOutline } from '@carnica/graphics';
export var items = [{
  icon: IconCheckShieldOutline,
  key: '1',
  disabled: true
}, {
  icon: IconInfoOutline,
  key: '2',
  badge: true
}, {
  icon: IconTrashOutline,
  key: '3',
  state: 'error'
}];