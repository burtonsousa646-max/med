import _asyncToGenerator from "@babel/runtime/helpers/asyncToGenerator";
import _regeneratorRuntime from "@babel/runtime/regenerator";
export var polling = function polling(requestFn, nextFn, _ref) {
  var _ref$timeout = _ref.timeout,
    timeout = _ref$timeout === void 0 ? 60000 : _ref$timeout,
    _ref$interval = _ref.interval,
    interval = _ref$interval === void 0 ? 1000 : _ref$interval,
    _ref$initialTimeout = _ref.initialTimeout,
    initialTimeout = _ref$initialTimeout === void 0 ? 500 : _ref$initialTimeout;
  return function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return new Promise(function (resolve, reject) {
      var timerValue = initialTimeout;
      setTimeout(/*#__PURE__*/function () {
        var _poll = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
          var start, result, finish, timeIsOver, _nextFn, isDone, isFailed, _result, _result2, _t;
          return _regeneratorRuntime.wrap(function (_context) {
            while (1) switch (_context.prev = _context.next) {
              case 0:
                start = window.performance.now();
                _context.prev = 1;
                _context.next = 2;
                return requestFn.apply(void 0, args);
              case 2:
                result = _context.sent;
                _context.next = 4;
                break;
              case 3:
                _context.prev = 3;
                _t = _context["catch"](1);
                reject(_t);
                return _context.abrupt("return");
              case 4:
                finish = window.performance.now();
                timerValue += finish - start;
                timeIsOver = timeout ? timerValue >= timeout : undefined;
                _nextFn = nextFn(result), isDone = _nextFn.isDone, isFailed = _nextFn.isFailed;
                if (timeIsOver || isFailed) {
                  reject(new Error((_result = result) === null || _result === void 0 ? void 0 : _result.data));
                } else if (isDone) {
                  resolve((_result2 = result) === null || _result2 === void 0 ? void 0 : _result2.data);
                } else {
                  timerValue += interval;
                  setTimeout(poll, interval);
                }
              case 5:
              case "end":
                return _context.stop();
            }
          }, _callee, null, [[1, 3]]);
        }));
        function poll() {
          return _poll.apply(this, arguments);
        }
        return poll;
      }(), initialTimeout);
    });
  };
};