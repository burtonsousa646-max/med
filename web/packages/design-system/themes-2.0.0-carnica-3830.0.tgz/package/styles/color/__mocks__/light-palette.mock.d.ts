declare const _default: {
    name: string;
    colors: {
        name: string;
        value: string;
    }[];
}[];
export default _default;
//# sourceMappingURL=light-palette.mock.d.ts.map