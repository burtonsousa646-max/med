import { ClassNameFormatter } from './types';
export declare const cnBem: (prefix: string, styles?: Record<string, string>) => ClassNameFormatter;
export type { ClassNameFormatter, ClassNameList, NoStrictEntityMods } from './types';
//# sourceMappingURL=index.d.ts.map