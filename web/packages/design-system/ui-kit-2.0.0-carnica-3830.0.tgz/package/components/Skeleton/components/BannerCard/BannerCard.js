import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnBannerCard = cnBem('skeleton-banner-card', styles);
export var BannerCard = function BannerCard(_ref) {
  var invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnBannerCard({
      invert: invert
    }, [className])
  }, props, {
    "data-t-id": "components-BannerCard"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 20,
    invert: invert,
    width: "min(100%, 160px)"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 12,
    invert: invert,
    width: "min(100%, 100px)"
  }));
};