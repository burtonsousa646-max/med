import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["mode"];
import React, { forwardRef } from 'react';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { ButtonGrid } from "./ButtonGrid";
import { ButtonCore } from "./ButtonCore";
var ButtonRender = function ButtonRender(_ref, ref) {
  var mode = _ref.mode,
    props = _objectWithoutProperties(_ref, _excluded);
  useDeprecationWarning({
    'view="secondary"': {
      value: props.view === 'secondary' && mode !== 'inline' ? true : undefined,
      customMessage: 'Используйте взамен `secondary-on-primary`'
    },
    'view="secondary-invert"': {
      value: props.view === 'secondary-invert' && mode !== 'inline' ? true : undefined,
      customMessage: 'Используйте взамен `secondary-on-secondary`'
    }
  });
  if (mode === 'grid') {
    return /*#__PURE__*/React.createElement(ButtonGrid, _extends({}, props, {
      ref: ref,
      "data-t-id": "components-Button"
    }));
  }
  return /*#__PURE__*/React.createElement(ButtonCore, _extends({}, props, {
    mode: mode,
    ref: ref
  }));
};
export var Button = /*#__PURE__*/forwardRef(ButtonRender);