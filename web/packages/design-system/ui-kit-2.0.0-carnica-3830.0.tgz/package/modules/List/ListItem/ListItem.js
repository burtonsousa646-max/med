import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["tagName", "children", "className", "onClick", "disabled", "label", "description", "leftSide", "rightSide", "checked", "invert"];
import { cnBem, forwardRefWithTag } from '@carnica/utils';
import React from 'react';
import { Text } from "../../../components/Text";
import styles from "./styles.module.css";
import { isSideIcon } from "./utils";
var cnListItem = cnBem('list--item', styles);
var renderSide = function renderSide(Side, disabled, invert) {
  if (!Side) {
    return null;
  }
  if (isSideIcon(Side)) {
    var getIconColor = function getIconColor() {
      if (disabled) {
        return invert ? 'disabled-fake-invert' : 'disabled';
      }
      return invert ? 'secondary-fake-invert' : 'secondary';
    };
    return /*#__PURE__*/React.createElement(Side, {
      className: cnListItem('side'),
      color: getIconColor(),
      size: "s",
      "data-t-id": "List-ListItem"
    });
  }
  return Side;
};
var getColor = function getColor(mainColor, invert, disabled) {
  if (disabled) {
    return invert ? 'disabled-fake-invert' : 'tertiary';
  }
  return invert ? "".concat(mainColor, "-fake-invert") : mainColor;
};
export var ListItem = forwardRefWithTag(function (props, ref) {
  var _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'button' : _props$tagName,
    children = props.children,
    className = props.className,
    onClick = props.onClick,
    disabled = props.disabled,
    label = props.label,
    description = props.description,
    leftSide = props.leftSide,
    rightSide = props.rightSide,
    checked = props.checked,
    invert = props.invert,
    otherProps = _objectWithoutProperties(props, _excluded);
  var Tag = tagName;
  var handleClick = function handleClick(e) {
    if (!disabled) {
      onClick === null || onClick === void 0 || onClick(e);
    }
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    "aria-selected": checked,
    className: cnListItem({
      checked: checked,
      disabled: disabled,
      invert: invert
    }, [className]),
    onClick: handleClick,
    role: "option"
  }, otherProps, {
    ref: ref
  }), renderSide(leftSide, disabled, invert), /*#__PURE__*/React.createElement("div", {
    className: cnListItem('content'),
    "data-t-id": "List-ListItem"
  }, label && /*#__PURE__*/React.createElement(Text, {
    color: getColor('primary', invert, disabled),
    "data-block-type": "label",
    tagName: "span",
    variant: "body-small"
  }, label), description && /*#__PURE__*/React.createElement(Text, {
    color: getColor('secondary', invert, disabled),
    "data-block-type": "description",
    tagName: "span",
    variant: "caption-medium"
  }, description)), renderSide(rightSide, disabled));
});