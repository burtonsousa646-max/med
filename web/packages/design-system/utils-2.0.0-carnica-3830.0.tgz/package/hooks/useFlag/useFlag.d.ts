import { UseFlag } from './types';
export declare const useFlag: UseFlag;
//# sourceMappingURL=useFlag.d.ts.map