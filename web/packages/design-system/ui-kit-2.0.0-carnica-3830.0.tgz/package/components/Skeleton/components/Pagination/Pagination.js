import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["direction"];
import React from 'react';
import { SkeletonBrick } from "../../Skeleton";
var sizeMap = {
  horizontal: {
    desktop: 12,
    mobile: 8
  },
  vertical: {
    desktop: 92,
    mobile: 60
  }
};
export var Pagination = function Pagination(_ref) {
  var _ref$direction = _ref.direction,
    direction = _ref$direction === void 0 ? 'horizontal' : _ref$direction,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    height: sizeMap[direction],
    width: sizeMap[direction === 'horizontal' ? 'vertical' : 'horizontal']
  }, props, {
    "data-t-id": "components-Pagination"
  }));
};