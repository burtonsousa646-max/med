const getLintStagedConf = require('./base.config');
module.exports = getLintStagedConf(false);