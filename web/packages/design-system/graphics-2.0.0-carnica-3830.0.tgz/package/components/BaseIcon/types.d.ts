import { MotionTagProps, MotionTags } from '@carnica/utils/types';
import React from 'react';
import type { IconPropColor, IconPropSize } from '../../types/IconComponent';
import { IconComponentNames, IconComponentNamesIcon } from '../../types/iconNames';
export type BaseIconProps<NAME extends IconComponentNames> = {
    iconClassName?: string;
    name: NAME;
    size?: IconPropSize;
} & (NAME extends IconComponentNamesIcon ? {
    color?: IconPropColor;
    customColor?: string;
} : {
    color?: never;
    customColor?: never;
});
export type BaseIconComponent = <NAME extends IconComponentNames, TAG extends MotionTags = 'span', MOTION extends boolean = false>(props: MotionTagProps<BaseIconProps<NAME>, MotionTags, TAG, MOTION>) => React.ReactElement | null;
//# sourceMappingURL=types.d.ts.map