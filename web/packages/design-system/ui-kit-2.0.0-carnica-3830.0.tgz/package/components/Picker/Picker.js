import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "itemGetters", "groups", "activeGroup", "groupGetters", "value", "onChange", "onChangeGroup", "convertGroup", "convertItem", "maxGroupsVisible", "withSearchField", "errorContent", "emptyContent", "onClose", "searchFunction", "loading", "className", "searchProps", "offset", "reverse", "anchorRef"],
  _excluded2 = ["filteredItems"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useEffect, useMemo, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { convertGroupToDefault, convertItemToDefault, dataConverter, getComponentState } from "./utils";
import styles from "./styles.module.css";
import { PickerList } from "./PickerList";
import { useGroupedItems } from "./hooks/useGroupedItems";
import { useItemsFiltration } from "./hooks/useItemsFiltration";
import { PickerWrapper } from "./PickerWrapper";
import { PickerProvider } from "./PickerContext";
import { PickerFilters } from "./PickerFilters";
import { PickerEmptyMock } from "./PickerEmptyMock";
var cnPicker = cnBem('picker', styles);
var PickerRender = function PickerRender(props, ref) {
  var items = props.items,
    itemGetters = props.itemGetters,
    _props$groups = props.groups,
    groups = _props$groups === void 0 ? [] : _props$groups,
    activeGroup = props.activeGroup,
    groupGetters = props.groupGetters,
    value = props.value,
    onChange = props.onChange,
    onChangeGroup = props.onChangeGroup,
    convertGroup = props.convertGroup,
    convertItem = props.convertItem,
    _props$maxGroupsVisib = props.maxGroupsVisible,
    maxGroupsVisible = _props$maxGroupsVisib === void 0 ? 6 : _props$maxGroupsVisib,
    _props$withSearchFiel = props.withSearchField,
    withSearchField = _props$withSearchFiel === void 0 ? true : _props$withSearchFiel,
    errorContent = props.errorContent,
    emptyContent = props.emptyContent,
    onClose = props.onClose,
    searchFunction = props.searchFunction,
    loading = props.loading,
    className = props.className,
    searchProps = props.searchProps,
    offset = props.offset,
    reverse = props.reverse,
    anchorRef = props.anchorRef,
    otherProps = _objectWithoutProperties(props, _excluded);
  var portalRef = useRef(null);
  var groupedItems = useGroupedItems({
    items: items,
    groups: groups,
    maxGroupsVisible: maxGroupsVisible,
    itemGetters: itemGetters,
    groupGetters: groupGetters,
    convertGroup: convertGroup,
    convertItem: convertItem
  });
  var _useItemsFiltration = useItemsFiltration(_objectSpread(_objectSpread({}, groupedItems), {}, {
      withSearchField: withSearchField,
      activeGroup: activeGroup ? convertGroupToDefault(groupGetters, convertGroup)(activeGroup) : undefined,
      searchFunction: searchFunction
    })),
    filteredItems = _useItemsFiltration.filteredItems,
    filterData = _objectWithoutProperties(_useItemsFiltration, _excluded2);
  var state = getComponentState(_objectSpread(_objectSpread({}, filterData), {}, {
    hasItems: Boolean(filteredItems === null || filteredItems === void 0 ? void 0 : filteredItems.length),
    items: items
  }));
  var convertedValue = useMemo(function () {
    return value ? convertItemToDefault(itemGetters, convertItem)(value) : undefined;
  }, [value]);
  var defaultIndex = useMemo(function () {
    if (convertedValue) {
      return filteredItems.findIndex(function (el) {
        return el.converted.key === convertedValue.converted.key;
      });
    }
    return 0;
  }, [convertedValue, items]);
  useEffect(function () {
    return function () {
      if (otherProps.isOpen) {
        var _anchorRef$current;
        anchorRef === null || anchorRef === void 0 || (_anchorRef$current = anchorRef.current) === null || _anchorRef$current === void 0 || _anchorRef$current.focus();
      }
    };
  }, [otherProps.isOpen]);
  return /*#__PURE__*/React.createElement(PickerProvider, {
    defaultIndex: defaultIndex,
    onClose: onClose,
    portalRef: portalRef,
    "data-t-id": "components-Picker"
  }, /*#__PURE__*/React.createElement(PickerWrapper, _extends({}, otherProps, {
    className: cnPicker({
      state: state,
      loading: loading
    }, [className]),
    onClose: onClose,
    ref: combineRefs([ref, portalRef]),
    "data-t-id": "components-Picker"
  }), /*#__PURE__*/React.createElement(PickerFilters, _extends({
    groups: groupedItems.groups,
    loading: loading,
    onChangeGroup: onChangeGroup,
    onClose: onClose,
    searchProps: searchProps,
    value: convertedValue === null || convertedValue === void 0 ? void 0 : convertedValue.converted,
    withSearchField: withSearchField && ((items === null || items === void 0 ? void 0 : items.length) || 0) > 3
  }, filterData, {
    "data-t-id": "components-Picker"
  })), state === 'filled' || loading ? /*#__PURE__*/React.createElement(PickerList, {
    className: cnPicker('list'),
    emptyContent: emptyContent,
    errorContent: errorContent,
    items: filteredItems,
    loading: loading,
    offset: offset,
    onChange: onChange,
    reverse: reverse
  }) : /*#__PURE__*/React.createElement(PickerEmptyMock, {
    emptyContent: emptyContent,
    errorContent: errorContent,
    state: state
  })));
};
export var Picker = compose(withDataConverter(dataConverter), forwardRef)(PickerRender);