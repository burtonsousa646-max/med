import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "codeLength", "autoComplete", "disabled", "value", "status", "invert", "ariaLabel", "id", "autoFocus", "name", "onChange", "onFocus", "onBlur", "onKeyDown", "onKeyUp", "onComplete", "inputProps"],
  _excluded2 = ["refs", "value", "length"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import styles from "./styles.module.css";
import { useCodeInput } from "../hooks/useCodeInput";
var cnCodeInputField = cnBem('code-input', styles);
export var CodeInputField = /*#__PURE__*/forwardRef(function (props, ref) {
  var className = props.className,
    _props$codeLength = props.codeLength,
    codeLength = _props$codeLength === void 0 ? 6 : _props$codeLength,
    _props$autoComplete = props.autoComplete,
    autoComplete = _props$autoComplete === void 0 ? 'one-time-code' : _props$autoComplete,
    disabled = props.disabled,
    _props$value = props.value,
    valueProp = _props$value === void 0 ? '' : _props$value,
    status = props.status,
    invert = props.invert,
    ariaLabel = props.ariaLabel,
    id = props.id,
    autoFocus = props.autoFocus,
    _props$name = props.name,
    name = _props$name === void 0 ? 'field' : _props$name,
    onChange = props.onChange,
    onFocus = props.onFocus,
    onBlur = props.onBlur,
    onKeyDown = props.onKeyDown,
    onKeyUp = props.onKeyUp,
    onComplete = props.onComplete,
    inputProps = props.inputProps,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useCodeInput = useCodeInput({
      codeLength: codeLength,
      onChange: onChange,
      onFocus: onFocus,
      value: valueProp,
      onKeyDown: onKeyDown,
      onComplete: onComplete,
      autoFocus: autoFocus
    }),
    refs = _useCodeInput.refs,
    value = _useCodeInput.value,
    length = _useCodeInput.length,
    params = _objectWithoutProperties(_useCodeInput, _excluded2);
  return /*#__PURE__*/React.createElement("ul", _extends({
    className: cnCodeInputField({
      status: status,
      invert: invert
    }, []),
    ref: ref
  }, otherProps, {
    "data-t-id": "CodeInput-CodeInputField"
  }), Array(length).fill(null).map(function (_, i) {
    return /*#__PURE__*/React.createElement("li", {
      className: cnCodeInputField('wrapper'),
      key: cnCodeInputField('input', {
        i: i
      })
    }, /*#__PURE__*/React.createElement("input", _extends({
      "aria-label": ariaLabel || "\u041F\u043E\u043B\u0435 \u0434\u043B\u044F \u0432\u0432\u043E\u0434\u0430 \u043A\u043E\u0434\u0430 \u043D\u043E\u043C\u0435\u0440 ".concat(i + 1),
      "data-id": "".concat(name, "-").concat(i),
      id: id ? "".concat(id, "-").concat(i) : undefined,
      inputMode: "numeric",
      max: 9,
      maxLength: 1,
      min: 0,
      name: "code-".concat(i),
      onKeyUp: onKeyUp,
      spellCheck: false
    }, typeof inputProps === 'function' ? inputProps(i) : inputProps, {
      autoComplete: autoComplete,
      className: cnCodeInputField('input'),
      disabled: disabled,
      pattern: "[0-9]*",
      ref: refs[i],
      type: "number",
      value: value === null || value === void 0 ? void 0 : value.charAt(i).replace(/_/, '')
    }, params)));
  }));
});