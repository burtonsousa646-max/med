export declare function isPlainObject<T extends Exclude<Record<string, unknown>, never | null | undefined | void>>(obj: unknown): obj is T;
export declare const isPromise: (inst: any) => inst is PromiseLike<any>;
export declare const isFunction: (func: any) => func is CallableFunction;
export declare const isDateValid: (date: Date) => boolean;
//# sourceMappingURL=checks.d.ts.map