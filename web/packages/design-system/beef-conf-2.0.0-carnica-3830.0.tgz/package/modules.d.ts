export const webpack: typeof import("webpack");
//# sourceMappingURL=modules.d.ts.map