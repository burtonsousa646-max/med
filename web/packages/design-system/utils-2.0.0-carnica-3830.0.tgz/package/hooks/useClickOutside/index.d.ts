export * from './useClickOutside';
//# sourceMappingURL=index.d.ts.map