import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import { useCallback, useEffect, useState } from 'react';
import { useRenderResolution } from '@beef/react';
import { DIMENSION_TYPE } from "./types";
import { isPointsEqual, mapping } from "./utils";
export var defaultMap = _defineProperty(_defineProperty(_defineProperty({}, DIMENSION_TYPE.MOBILE, 0), DIMENSION_TYPE.TABLET, 768), DIMENSION_TYPE.DESKTOP, 1024);
export var useBreakpoints = function useBreakpoints() {
  var map = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : defaultMap;
  var isActive = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  var initialRenderResolution = useRenderResolution();
  var getMappedData = useCallback(function () {
    var _window;
    return mapping(typeof window === 'undefined' ? initialRenderResolution || 0 : (_window = window) === null || _window === void 0 ? void 0 : _window.innerWidth, map);
  }, []);
  var _useState = useState(getMappedData()),
    _useState2 = _slicedToArray(_useState, 2),
    points = _useState2[0],
    setPoints = _useState2[1];
  useEffect(function () {
    var subscribe = function subscribe() {
      var next = getMappedData();
      setPoints(function (prev) {
        return isPointsEqual(prev, next) ? prev : next;
      });
    };
    subscribe();
    if (isActive) {
      window.addEventListener('resize', subscribe);
    }
    return function () {
      return window.removeEventListener('resize', subscribe);
    };
  }, [isActive]);
  return points;
};
export var useIsMobileDimension = function useIsMobileDimension(map, isActive) {
  return DIMENSION_TYPE.MOBILE === useBreakpoints(map, isActive)[0];
};
export var useIsTabletDimension = function useIsTabletDimension(map, isActive) {
  return DIMENSION_TYPE.TABLET === useBreakpoints(map, isActive)[0];
};
export var useIsDesktopDimension = function useIsDesktopDimension(map, isActive) {
  return DIMENSION_TYPE.DESKTOP === useBreakpoints(map, isActive)[0];
};