import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import { valueOr } from "./atomic";
export function removeFirstOccurrence(arr, value) {
  var index = arr.indexOf(value);
  if (index === -1) return arr;
  return [].concat(_toConsumableArray(arr.slice(0, index)), _toConsumableArray(arr.slice(index + 1)));
}

/**
 * A missing rest spread helper for last arguments
 * Desired spread:
 * (...args, lastArg) => { ... }
 * (...args, lastArg1, lastARg2) => { ... }
 *
 * How to:
 * spreadLast((args, lastArg) => { ... })
 * spreadLast((args, lastArg1, lastArg2) => { ... }, 2)
 */
export var spreadLast = function spreadLast(wrappedFn) {
  var count = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
  return function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    var restArgs = args.slice();
    var lastArgs = restArgs.splice(-count, count);
    return wrappedFn.apply(void 0, [restArgs].concat(_toConsumableArray(lastArgs)));
  };
};

/**
 * Fixes super bizarre error, ruining search result if undefined is passed in
 */
export var sortWithUndefined = function sortWithUndefined(arr, compareFn) {
  if (process.env.NODE_ENV !== 'production') {
    if (arr.indexOf(undefined) !== -1 && arr.indexOf(null) !== -1) {
      throw Error('An array passed to sortWithUndefined must not contain both `null` and `undefined`');
    }
  }
  if (arr.indexOf(undefined) === -1) {
    return arr.slice().sort(compareFn);
  }
  /** replace undefined with null, sort, replace back */
  return arr.map(function () {
    var val = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
    return val;
  }).sort(compareFn).map(function (val) {
    return valueOr(val, undefined);
  });
};
export function times(n, iteratee) {
  if (n < 1) {
    return [];
  }
  return _toConsumableArray(Array.from({
    length: n
  })).map(function (_, index) {
    return iteratee(index);
  });
}
export function distinctConcatBy(fieldName, source, added) {
  var existingIds = source.map(function (item) {
    return item[fieldName];
  });
  return [].concat(_toConsumableArray(source), _toConsumableArray(added.filter(function (item) {
    return existingIds.indexOf(item[fieldName]) === -1;
  })));
}
export var findLastIndex = function findLastIndex(haystack, matchFn) {
  var index = haystack.slice().reverse().findIndex(matchFn);
  if (index === -1) return -1;
  return haystack.length - index - 1;
};