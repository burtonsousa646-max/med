interface AnalyticsContextProps {
    account_type: string;
    page_path: string;
    page_title: string;
    page_url: string;
    vid: string;
}
export declare const unstable_refreshMetricVisitId: () => string;
export declare const unstable_getBaseYmParams: (user?: string) => AnalyticsContextProps | NonNullable<unknown>;
export declare const getCommonProps: (user?: string) => AnalyticsContextProps | NonNullable<unknown>;
export {};
//# sourceMappingURL=ymBase.d.ts.map