import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "iconLeft", "iconRight", "loading", "onClick", "onlyIcon", "type", "view", "size", "tagName", "disabled", "className"];
import React from 'react';
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import { useFlag } from '@carnica/utils/hooks';
import { MotionComponent } from "../../modules/MotionComponent";
import { Text } from "../Text";
import styles from "./styles.module.css";
import { ButtonCore } from "./ButtonCore";
var cnButtonGrid = cnBem('button-grid', styles);
export var ButtonGrid = forwardRefWithMotionTag(function (_ref, ref) {
  var children = _ref.children,
    iconLeft = _ref.iconLeft,
    iconRight = _ref.iconRight,
    loading = _ref.loading,
    onClick = _ref.onClick,
    onlyIcon = _ref.onlyIcon,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'button' : _ref$type,
    _ref$view = _ref.view,
    view = _ref$view === void 0 ? 'primary' : _ref$view,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    _ref$tagName = _ref.tagName,
    tagName = _ref$tagName === void 0 ? 'button' : _ref$tagName,
    disabled = _ref.disabled,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isPressed = _useFlag2[0],
    setIsPressed = _useFlag2[1];
  var handleClick = function handleClick(e) {
    onClick === null || onClick === void 0 || onClick(e);
    setIsPressed.on();
    setTimeout(setIsPressed.off, 310);
  };
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnButtonGrid({
      loading: loading
    }, [className]),
    "data-pressed": isPressed,
    disabled: disabled,
    onClick: handleClick,
    ref: ref,
    tagName: tagName,
    type: type,
    "data-t-id": "components-Button"
  }), /*#__PURE__*/React.createElement(ButtonCore, {
    className: cnButtonGrid('content'),
    "data-pressed": isPressed,
    disabled: disabled,
    iconLeft: iconLeft,
    iconRight: iconRight,
    innerView: true,
    loading: loading,
    mode: "default",
    onlyIcon: true,
    size: size,
    tagName: "div",
    view: view,
    "data-t-id": "components-Button"
  }), /*#__PURE__*/React.createElement(Text, {
    align: "center",
    color: disabled ? 'disabled' : 'primary',
    variant: "caption-accent-medium"
  }, children));
});