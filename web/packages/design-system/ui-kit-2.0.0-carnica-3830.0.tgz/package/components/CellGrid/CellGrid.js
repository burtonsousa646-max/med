import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["size", "icon", "title", "disabled", "className"];
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import React from 'react';
import { Avatar } from "../Avatar";
import { Text } from "../Text";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnCellGrid = cnBem('cell-grid', styles);
export var CellGrid = forwardRefWithMotionTag(function (_ref, ref) {
  var _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    icon = _ref.icon,
    title = _ref.title,
    disabled = _ref.disabled,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnCellGrid({
      size: size
    }, [className])
  }, otherProps.tagName === 'button' ? {
    disabled: disabled
  } : {}, {
    ref: ref,
    "data-t-id": "components-CellGrid"
  }), /*#__PURE__*/React.createElement(Avatar, {
    "aria-hidden": true,
    color: "default-on-primary",
    disabled: disabled,
    icon: icon,
    size: size === 'm' ? 'l' : 'xl',
    "data-t-id": "components-CellGrid"
  }), /*#__PURE__*/React.createElement(Text, {
    align: "center",
    color: disabled ? 'disabled' : 'secondary',
    variant: size === 'm' ? 'caption-medium' : 'body-small'
  }, title));
});