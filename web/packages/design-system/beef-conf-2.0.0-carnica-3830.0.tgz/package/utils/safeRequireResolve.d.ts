export function isModuleAvailable(moduleName: any): boolean;
export function safeRequireResolve(moduleName: any): string | null;
//# sourceMappingURL=safeRequireResolve.d.ts.map