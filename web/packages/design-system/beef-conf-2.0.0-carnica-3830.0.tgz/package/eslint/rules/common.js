module.exports = {
  rules: {
    // Disabled by the mighty will of a shrimp
    'class-methods-use-this': 0,
    'no-console': ['error', {
      allow: ['warn', 'info', 'error', 'assert']
    }],
    // Sometimes its cleaner to reassign parameter with default value
    'no-param-reassign': 0,
    // When destructuring arrays, there must be a way to ignore variables
    // Example: [used, _unused, alsoUsed]
    // this is actually used
    'no-underscore-dangle': 0,
    // Spreading dictionary
    'no-unused-vars': [2, {
      destructuredArrayIgnorePattern: '^_',
      ignoreRestSiblings: true
    }],
    // When making chains of functions
    'no-use-before-define': [0, 'nofunc']
  }
};