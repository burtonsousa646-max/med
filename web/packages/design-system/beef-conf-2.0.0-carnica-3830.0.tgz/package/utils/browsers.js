// FIXME: ROLLBACK of BCW-5758, возможная причина краша SSR
// const browsers = ['last 2 versions and > 0.25% in RU', 'not ie > 0', 'not op_mini all', 'not dead'];
const browsers = ['last 2 versions', 'not ie > 0', 'not op_mini all'];
module.exports = {
  browsers
};