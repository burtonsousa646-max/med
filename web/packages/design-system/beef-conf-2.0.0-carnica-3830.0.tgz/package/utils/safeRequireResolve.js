const safeRequireResolve = moduleName => {
  try {
    return require.resolve(moduleName);
  } catch (e) {
    return null;
  }
};
const isModuleAvailable = moduleName => !!safeRequireResolve(moduleName);
module.exports = {
  isModuleAvailable,
  safeRequireResolve
};