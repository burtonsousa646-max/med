import _extends from "@babel/runtime/helpers/extends";
import React, { forwardRef } from 'react';

/**
 * HOC for converting incoming data to new format
 * */
export var withDataConverter = function withDataConverter(dataConverter) {
  return function (WrappedComponent) {
    return /*#__PURE__*/forwardRef(function (props, ref) {
      return /*#__PURE__*/React.createElement(WrappedComponent
      // eslint-disable-next-line react/jsx-props-no-spreading
      , _extends({}, dataConverter(props), {
        ref: ref,
        "data-t-id": "src-enhancers"
      }));
    });
  };
};