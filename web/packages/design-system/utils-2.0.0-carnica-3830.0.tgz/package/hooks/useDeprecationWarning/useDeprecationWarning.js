import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useEffect, useState } from 'react';
export var useDeprecationWarning = function useDeprecationWarning(deprecatedProps) {
  var _useState = useState([]),
    _useState2 = _slicedToArray(_useState, 2),
    shownKeys = _useState2[0],
    setShownKeys = _useState2[1];
  useEffect(function () {
    if (process.env.NODE_ENV !== 'production') {
      Object.entries(deprecatedProps).forEach(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 2),
          k = _ref2[0],
          _ref2$ = _ref2[1],
          value = _ref2$.value,
          newPropKey = _ref2$.newPropKey,
          customMessage = _ref2$.customMessage;
        if (typeof value !== 'undefined' && !shownKeys.includes(k)) {
          console.warn("[DEPRECATED]: Prop \"".concat(k, "\" is deprecated. ").concat(customMessage !== null && customMessage !== void 0 ? customMessage : "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0432\u0437\u0430\u043C\u0435\u043D \u0441\u0432\u043E\u0439\u0441\u0442\u0432\u043E `".concat(newPropKey, "`.")));
          setShownKeys(function (prev) {
            return [].concat(_toConsumableArray(prev), [k]);
          });
        }
      });
    }
  }, [deprecatedProps]);
};