export function composeConfigValidator(validator: any): (fn: any) => (...args: any[]) => any;
//# sourceMappingURL=configValidators.d.ts.map