export declare abstract class BaseObserver<T> {
    callback: T;
    constructor(callback: T);
    abstract observe(target: Element): void;
    abstract unobserve(target: Element): void;
    abstract disconnect(): void;
}
//# sourceMappingURL=baseObserverMock.d.ts.map