import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "className", "style", "providerOptions"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { createContext, forwardRef, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { cnBem } from '@carnica/utils';
import { isEmpty, merge } from 'lodash';
import { convertComponentStylesToVariables, dataConverter, getThemeStyles } from "./utils";
import { MotionComponent } from "../MotionComponent";
import defaultStyles from "../../styles/themeV1.module.css";
var themeContext = /*#__PURE__*/createContext(['light', function () {}, {
  baseName: 'theme',
  componentStyles: {},
  initialTheme: 'light',
  themeStyles: {}
}]);
var ThemeProviderRender = function ThemeProviderRender(props, ref) {
  var children = props.children,
    classNameProp = props.className,
    style = props.style,
    providerOptions = props.providerOptions,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useThemeContext = useThemeContext(),
    _useThemeContext2 = _slicedToArray(_useThemeContext, 3),
    mainTheme = _useThemeContext2[0],
    _ = _useThemeContext2[1],
    options = _useThemeContext2[2];
  var isThemeManuallyChanged = useRef(false);
  var _merge = merge({}, options, providerOptions),
    initialTheme = _merge.initialTheme,
    _merge$baseName = _merge.baseName,
    baseName = _merge$baseName === void 0 ? 'theme' : _merge$baseName,
    componentStyles = _merge.componentStyles;
  var themeStyles = providerOptions.themeStyles || options.themeStyles;
  var _useState = useState(providerOptions.initialTheme || mainTheme),
    _useState2 = _slicedToArray(_useState, 2),
    theme = _useState2[0],
    setTheme = _useState2[1];
  var styles = useMemo(function () {
    if (isEmpty(themeStyles)) {
      return defaultStyles;
    }
    return getThemeStyles(themeStyles, theme);
  }, [theme, themeStyles]);
  var className = cnBem(baseName, styles)({
    theme: theme
  }, [classNameProp]);
  var value = useMemo(function () {
    return [theme, function (val) {
      setTheme(val);
      isThemeManuallyChanged.current = true;
    }, {
      initialTheme: initialTheme,
      themeStyles: themeStyles,
      baseName: baseName,
      componentStyles: componentStyles
    }];
  }, [theme, initialTheme, themeStyles, baseName, componentStyles]);
  useEffect(function () {
    if (!isThemeManuallyChanged.current) {
      setTheme(providerOptions.initialTheme || mainTheme);
    }
  }, [mainTheme, providerOptions.initialTheme]);
  return /*#__PURE__*/React.createElement(themeContext.Provider, {
    value: value
  }, /*#__PURE__*/React.createElement(MotionComponent, _extends({
    className: className,
    style: _objectSpread(_objectSpread({}, style), componentStyles ? convertComponentStylesToVariables(componentStyles, theme) : {})
  }, otherProps, {
    ref: ref,
    "data-t-id": "modules-ThemeProvider"
  }), typeof children === 'function' ? children(theme) : children));
};
export var useThemeContext = function useThemeContext() {
  return useContext(themeContext);
};
export var ThemeProvider = compose(withDataConverter(dataConverter), forwardRef)(ThemeProviderRender);