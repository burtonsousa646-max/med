/* eslint-disable class-methods-use-this, react-hooks/rules-of-hooks */
const path = require('path');
const {
  EnvironmentPlugin,
  DefinePlugin
} = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const CircularDependencyPlugin = require('circular-dependency-plugin');
const {
  WebpackManifestPlugin
} = require('webpack-manifest-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const {
  BeefManifestPlugin
} = require('./beefManifestPlugin');
const {
  BeefCacheBuildDependencyPlugin
} = require('./BeefCacheBuildDependencyPlugin');
const {
  getCommitHash,
  isLocalhost
} = require('../utils');
const {
  filterRules,
  filterLoaders,
  combineRuleParams
} = require('./helpers');
const {
  scopeIncludes,
  scopeMatchedExcludes
} = require('../registry');
const defaultOptions = {
  excludePlugins: [],
  excludeRules: [],
  cwd: process.cwd(),
  /**
   * Wrapped in capture group for snapshot.managedPaths
   * See: https://webpack.js.org/configuration/other-options/#managedpaths
   */
  monorepoExcludes: scopeMatchedExcludes,
  /**
   * Обратная регулярка, проверяем, что пакеты являются внутренним кодом:
   * используется в @beef/node/conf
   */
  monorepoIncludes: scopeIncludes
};
class WebpackFactory {
  constructor(options = {}, overrideEnv = {}) {
    this.setEnv(overrideEnv);
    const version = options.version || process.env.CI_COMMIT_SHORT_SHA || getCommitHash();
    this.options = {
      ...defaultOptions,
      version,
      // eslint-disable-next-line sonarjs/no-nested-template-literals
      filePattern: `static/[name]${this.env.isProduction ? `.${version}` : ''}`,
      ...options
    };
    if (this.env.isDebug) process.traceDeprecation = true;
  }
  static getConfig(env, options) {
    return new WebpackFactory(env, options).config;
  }
  setEnv(overrideEnv) {
    this.env = {
      isProduction: process.env.NODE_ENV === 'production',
      isDebug: process.env.DEBUG === 'true',
      isHMR: isLocalhost(),
      isServer: process.env.RUN_ENV === 'server',
      isSkipClean: process.env.SKIP_CLEAN === 'true',
      ...overrideEnv
    };
  }
  get rawLoaders() {
    return {
      babel: require.resolve('babel-loader')
    };
  }
  get rules() {
    return {
      code: /\.(js|ts)x?$/i
    };
  }
  get loaders() {
    const {
      rawLoaders: _loaders
    } = this;
    return {
      babel: {
        loader: _loaders.babel,
        options: {
          cacheDirectory: true,
          rootMode: 'upward-optional'
        },
        exclude: this.options.monorepoExcludes
      },
      asset: {
        type: 'asset'
      }
    };
  }
  get plugins() {
    return {
      CopyWebpackPlugin,
      BeefCacheBuildDependencyPlugin,
      CircularDependencyPlugin,
      WebpackManifestPlugin,
      BeefManifestPlugin,
      EnvironmentPlugin,
      TerserPlugin,
      DefinePlugin
    };
  }

  /**
   * if plugin is `isEnabled` and not among `excludePlugins`
   * Initialize `WebpackPluginClass` with given `options`
   * @param {Function} WebpackPluginClass
   * @param {any} [options]
   * @param {boolean} [isEnabled]
   */
  usePlugin = (WebpackPluginClass, options, isEnabled = true) => {
    const {
      excludePlugins
    } = this.options;
    const nameOfClass = WebpackPluginClass?.prototype?.constructor?.name;
    if (!isEnabled || excludePlugins.indexOf(WebpackPluginClass) !== -1 || excludePlugins.indexOf(nameOfClass) !== -1) return undefined;
    return new WebpackPluginClass(options);
  };

  /**
   * returns rule, unless it is among `excludeRules`
   */
  useRule = (rules, loaders, overrideParams = {}) => {
    const {
      excludeRules
    } = this.options;
    rules = filterRules(rules, excludeRules);
    loaders = filterLoaders(loaders);
    return rules.length ? {
      test: rules,
      ...(loaders.map(({
        loader
      }) => loader).filter(Boolean).length ? {
        use: loaders.map(({
          loader,
          options
        }) => ({
          loader,
          options
        }))
      } : {}),
      ...combineRuleParams(loaders, overrideParams)
    } : undefined;
  };
  oneOfLoaders = (...loaders) => ({
    oneOf: filterLoaders(loaders).map(({
      loader,
      options,
      ...params
    }) => ({
      ...(loader ? {
        use: [{
          loader,
          options
        }]
      } : {}),
      ...params
    }))
  });
  get config() {
    const {
      env: {
        isProduction,
        isSkipClean,
        isHMR,
        isServer
      },
      usePlugin,
      useRule,
      plugins,
      loaders,
      rules,
      options,
      options: {
        filePattern,
        monorepoExcludes
      }
    } = this;
    return {
      mode: isProduction ? 'production' : 'development',
      // NOTE: snapshot.managedPaths & watchOptions.ignored нужны для того,
      //   чтобы изменения в linked-пакетах триггерили HMR
      snapshot: {
        managedPaths: [monorepoExcludes]
      },
      watchOptions: {
        ignored: options.monorepoExcludes,
        followSymlinks: true
      },
      output: {
        filename: `${filePattern}.js`,
        publicPath: '/',
        path: path.resolve(this.options.cwd, './build'),
        hotUpdateMainFilename: 'static/[runtime].[fullhash].hot-update.json',
        hotUpdateChunkFilename: 'static/[id].[fullhash].hot-update.js',
        assetModuleFilename: 'static/assets/[name].[hash][ext][query]',
        clean: !isSkipClean,
        devtoolModuleFilenameTemplate: info => isHMR ? path.resolve(info.absoluteResourcePath).replace(/\\/g, '/') : info
      },
      resolve: {
        extensions: ['.js', '.jsx', '.ts', '.tsx'],
        symlinks: false
      },
      module: {
        rules: [useRule(rules.code, loaders.babel)]
      },
      plugins: [usePlugin(plugins.WebpackManifestPlugin), usePlugin(plugins.CircularDependencyPlugin, {
        exclude: monorepoExcludes,
        failOnError: false
      }), usePlugin(plugins.EnvironmentPlugin, {
        NODE_ENV: isProduction ? 'production' : 'development',
        RUN_ENV: process.env.RUN_ENV || '',
        VERSION: options.version || ''
      }), usePlugin(plugins.DefinePlugin, {
        'typeof window': JSON.stringify(isServer ? 'undefined' : 'object')
      })],
      optimization: {
        minimize: isProduction,
        minimizer: [usePlugin(plugins.TerserPlugin, {
          extractComments: false,
          terserOptions: {
            format: {
              comments: false
            }
          }
        })].filter(Boolean)
      },
      devtool: isProduction ? 'source-map' : 'cheap-module-source-map',
      stats: {
        chunks: false,
        colors: true,
        children: false
      },
      ...(!isServer && isHMR ? {
        devServer: {
          hot: true,
          port: process.env.WEBPACK_PORT || 8081,
          headers: {
            'Access-Control-Allow-Origin': '*'
          }
        }
      } : {})
    };
  }
}
module.exports = WebpackFactory;