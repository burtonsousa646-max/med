import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["state", "icon", "className"];
import React, { forwardRef } from 'react';
import { AnimatedIcon, IconCheckMarkCheck, IconDangerFilled, IconInfoFilled, IconTimeOutline } from '@carnica/graphics';
import { cnBem } from '@carnica/utils';
import { statusViewPropState } from "../types";
import styles from "./styles.module.css";
var cnStatusViewIndicator = cnBem('status-view-indicator', styles);
var indicatorColorMap = {
  info: 'black',
  progress: 'black',
  success: 'white',
  error: 'tertiary'
};
export var StatusViewIndicator = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var _ref$state = _ref.state,
    state = _ref$state === void 0 ? statusViewPropState[0] : _ref$state,
    icon = _ref.icon,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({}, otherProps, {
    "aria-hidden": true,
    className: cnStatusViewIndicator({
      state: state
    }, [className]),
    ref: ref,
    role: "presentation",
    "data-t-id": "StatusView-StatusViewIndicator"
  }), /*#__PURE__*/React.createElement(AnimatedIcon, {
    activeIndex: statusViewPropState.indexOf(state),
    color: indicatorColorMap[state],
    icons: [icon || IconTimeOutline, IconDangerFilled, icon || IconInfoFilled, IconCheckMarkCheck],
    size: 60
  }));
});