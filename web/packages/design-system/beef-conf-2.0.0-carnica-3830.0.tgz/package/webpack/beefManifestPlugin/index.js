/**
 * WebpackManifestPlugin fork
 */

/* eslint-disable no-void */
const {
  relative,
  resolve
} = require('path');
const NormalModule = require('webpack/lib/NormalModule');
const {
  beforeRunHook,
  emitHook,
  getCompilerHooks,
  normalModuleLoaderHook
} = require('./hooks');
const emitCountMap = new Map();

/**
 * Beef Changes Start
 * */
const beefDefaults = {
  serverFileName: 'server.manifest.json'
};
/**
 * Beef Changes End
 * */

const defaults = {
  assetHookStage: Infinity,
  basePath: '',
  fileName: 'manifest.json',
  filter: null,
  generate: void 0,
  map: null,
  publicPath: null,
  removeKeyHash: /([a-f0-9]{16,32}\.?)/gi,
  // Note: seed must be reset for each compilation. let the code initialize it to {}
  seed: void 0,
  serialize(manifest) {
    return JSON.stringify(manifest, null, 2);
  },
  sort: null,
  transformExtensions: /^(gz|map)$/i,
  useEntryKeys: false,
  useLegacyEmit: false,
  writeToFileEmit: false
};
class BeefManifestPlugin {
  options;
  constructor(opts) {
    this.options = {
      ...defaults,
      ...opts,
      /**
       * Beef Changes Start
       * */
      fileName: opts?.isServer ? beefDefaults.serverFileName : defaults.fileName
      /**
       * Beef Changes End
       * */
    };
  }
  apply(compiler) {
    const moduleAssets = {};
    const manifestFileName = resolve(compiler.options.output?.path || './', this.options.fileName);
    const manifestAssetId = relative(compiler.options.output?.path || './', manifestFileName);
    const beforeRun = beforeRunHook.bind(this, {
      emitCountMap,
      manifestFileName
    });
    const emit = emitHook.bind(this, {
      compiler,
      emitCountMap,
      manifestAssetId,
      manifestFileName,
      moduleAssets,
      options: this.options
    });
    const normalModuleLoader = normalModuleLoaderHook.bind(this, {
      moduleAssets
    });
    const hookOptions = {
      name: 'BeefManifestPlugin',
      stage: this.options.assetHookStage
    };
    compiler.hooks.compilation.tap(hookOptions, compilation => {
      // eslint-disable-next-line max-len
      const hook = NormalModule.getCompilationHooks ? NormalModule.getCompilationHooks(compilation).loader : compilation.hooks.normalModuleLoader;
      hook.tap(hookOptions, normalModuleLoader);
    });
    if (this.options.useLegacyEmit === true) {
      compiler.hooks.emit.tap(hookOptions, emit);
    } else {
      compiler.hooks.thisCompilation.tap(hookOptions, compilation => {
        compilation.hooks.processAssets.tap(hookOptions, () => emit(compilation));
      });
    }
    compiler.hooks.run.tapAsync(hookOptions, beforeRun);
    compiler.hooks.watchRun.tapAsync(hookOptions, beforeRun);
  }
}
module.exports = {
  getCompilerHooks,
  BeefManifestPlugin
};