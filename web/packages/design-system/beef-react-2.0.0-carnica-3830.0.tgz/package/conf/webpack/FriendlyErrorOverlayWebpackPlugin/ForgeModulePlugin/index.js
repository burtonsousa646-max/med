const VirtualModulePlugin = require('webpack-virtual-modules');

/**
 * Replaces given module with
 * @typedef {import('webpack').Compiler} Compiler
 * @typedef {import('webpack-virtual-modules')} VirtualModulePlugin
 * @typedef {{ replacePath?: string, moduleContent: string }} PluginOptions
 */
class ForgeModulePlugin {
  pluginName = this.constructor.name;
  virtualModules = new VirtualModulePlugin();

  /** @type {PluginOptions} */
  options;

  /**
   * @param options {PluginOptions}
   */
  constructor(options = {}) {
    this.options = options;
    this.options.replacePath ??= ForgeModulePlugin.generateModulePath('chunk');
  }
  static generateModulePath(prefix) {
    return `./${prefix}-${Math.random().toString().substring(2)}`;
  }

  /**
   * @param compiler {Compiler}
   */
  apply(compiler) {
    this.virtualModules.apply(compiler);
    this.compiler = compiler;
    this.insertModule(this.options.replacePath, this.options.moduleContent);
    // this.replaceModule(this.options.replacePath, this.options.replacePath);
  }
  insertModule(moduleName, moduleContent) {
    this.compiler.hooks.compilation.tap(this.pluginName, async () => {
      this.virtualModules.writeModule(moduleName, moduleContent);
    });
  }

  /**
   * @param originalModule {string}
   * @param newResource {string}
   */
  // replaceModule(originalModule, newResource) {
  //   this.compiler.hooks.normalModuleFactory.tap('NormalModuleReplacementPlugin', (nmf) => {
  //     nmf.hooks.beforeResolve.tap('NormalModuleReplacementPlugin', (result) => {
  //       if (result.request === originalModule) {
  //         result.request = newResource;
  //       }
  //     });
  //   });
  // }
}
module.exports = ForgeModulePlugin;