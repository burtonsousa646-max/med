export var items = [{
  key: 1,
  label: 'связь и SIM',
  disabled: true
}, {
  key: 2,
  label: 'для дома'
}, {
  key: 3,
  label: 'бизнес',
  disabled: true
}, {
  key: 4,
  label: 'карьера в билайн'
}, {
  key: 5,
  label: 'доступность'
}];
export var itemsString = ['связь и SIM', 'для дома', 'бизнес', 'карьера в билайн', 'доступность'];