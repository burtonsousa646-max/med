import { baseServerUrl } from "../utils/constant";
import { defineUrlIcon } from "../utils/defineUrlIcon";
export var Logo2GisRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/Logo2GisRound.svg"),
  defaultSize: 56,
  multiColor: false
});
export var Logo2GisSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/Logo2GisSquare.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoAkbars = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoAkbars.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoAlfaMoneyRed = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoAlfaMoneyRed.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoAlfaMoneyWhite = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoAlfaMoneyWhite.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoAlfabank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoAlfabank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoApplemusicRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoApplemusicRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoApplemusicRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoApplemusicRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoApplemusicRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoApplemusicRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoApplemusicSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoApplemusicSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoApplemusicSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoApplemusicSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoApplemusicSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoApplemusicSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoArvand = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoArvand.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoBeelineColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoBeelineColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoBeelineMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoBeelineMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoBspb = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoBspb.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoDomrfbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoDomrfbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoEnergobank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoEnergobank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoEnergotransbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoEnergotransbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoFinambank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoFinambank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoGazprombank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGazprombank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoGoskey = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGoskey.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoGosuslugiRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGosuslugiRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoGosuslugiRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGosuslugiRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoGosuslugiRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGosuslugiRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoGosuslugiSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGosuslugiSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoGosuslugiSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGosuslugiSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoGosuslugiSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoGosuslugiSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoHomecredit = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoHomecredit.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoHumo = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoHumo.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoIconGoldDefault = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoIconGoldDefault.svg"),
  multiColor: false
});
export var LogoIconGoldGold = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoIconGoldGold.svg"),
  multiColor: false
});
export var LogoIconTokenBackgroundFree = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoIconTokenBackgroundFree.svg"),
  defaultSize: 32,
  multiColor: false
});
export var LogoIconTokenBlue = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoIconTokenBlue.svg"),
  multiColor: false
});
export var LogoIconTokenBlueShadow = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoIconTokenBlueShadow.svg"),
  defaultSize: 36,
  multiColor: false
});
export var LogoIconTokenDefault = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoIconTokenDefault.svg"),
  multiColor: false
});
export var LogoIconTokenViolet = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoIconTokenViolet.svg"),
  multiColor: false
});
export var LogoKinopoiskRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoKinopoiskRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoKinopoiskRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoKinopoiskRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoKinopoiskRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoKinopoiskRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoKinopoiskSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoKinopoiskSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoKinopoiskSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoKinopoiskSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoKinopoiskSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoKinopoiskSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoMaestro = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMaestro.svg"),
  multiColor: false
});
export var LogoMastercard = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMastercard.svg"),
  multiColor: false
});
export var LogoMaxMessengerRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMaxMessengerRoundColor.png"),
  defaultSize: 56,
  multiColor: false
});
export var LogoMaxMessengerRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMaxMessengerRoundColor.png"),
  defaultSize: 56,
  multiColor: false
});
export var LogoMaxMessengerRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMaxMessengerRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoMaxMessengerSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMaxMessengerSquareColor.png"),
  defaultSize: 56,
  multiColor: false
});
export var LogoMaxMessengerSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMaxMessengerSquareColor.png"),
  defaultSize: 56,
  multiColor: false
});
export var LogoMaxMessengerSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMaxMessengerSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoMinbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMinbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoMir = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMir.svg"),
  ratio: 1.9166666666666667,
  multiColor: false
});
export var LogoMkb = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMkb.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoModulbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoModulbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoMosEnergoSbit = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoMosEnergoSbit.svg"),
  defaultSize: 46,
  multiColor: false
});
export var LogoNationalStandardBank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoNationalStandardBank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoOdnoklassnikiRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoOdnoklassnikiRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoOdnoklassnikiRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoOdnoklassnikiRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoOdnoklassnikiSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoOdnoklassnikiSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoOdnoklassnikiSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoOdnoklassnikiSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoOpen = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoOpen.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoOzonbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoOzonbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoPerekrestokRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPerekrestokRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoPerekrestokRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPerekrestokRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoPerekrestokSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPerekrestokSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoPerekrestokSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPerekrestokSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoPochtabank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPochtabank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoPrimsotsbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPrimsotsbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoPyaterochkaRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPyaterochkaRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoPyaterochkaRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPyaterochkaRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoPyaterochkaSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPyaterochkaSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoPyaterochkaSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoPyaterochkaSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoRaiffeisen = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRaiffeisen.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoRencredit = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRencredit.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoRosbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRosbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoRosselkhozbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRosselkhozbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoRsb = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRsb.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoRutubeRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRutubeRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoRutubeRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRutubeRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoRutubeSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRutubeSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoRutubeSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoRutubeSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoSberPayBackground = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSberPayBackground.svg"),
  ratio: 1.9166666666666667,
  multiColor: false
});
export var LogoSberPayStroked = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSberPayStroked.svg"),
  ratio: 1.9166666666666667,
  multiColor: false
});
export var LogoSberbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSberbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoSdco = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSdco.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoSnapchatRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSnapchatRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoSnapchatRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSnapchatRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoSnapchatRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSnapchatRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoSnapchatSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSnapchatSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoSnapchatSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSnapchatSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoSnapchatSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSnapchatSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoSovcombank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSovcombank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoSpb = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoSpb.svg"),
  multiColor: false
});
export var LogoTelegramRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTelegramRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTelegramRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTelegramRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTelegramSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTelegramSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTelegramSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTelegramSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTiktokRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTiktokRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTiktokRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTiktokRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTiktokRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTiktokRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTiktokSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTiktokSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTiktokSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTiktokSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTiktokSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTiktokSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoTinkoff = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTinkoff.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoTkbbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTkbbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoTochkabank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoTochkabank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoUnicreditbank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoUnicreditbank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoUnionPay = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoUnionPay.svg"),
  ratio: 1.9166666666666667,
  multiColor: false
});
export var LogoUralsib = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoUralsib.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoVKMusicRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKMusicRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKMusicRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKMusicRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKMusicRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKMusicRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKMusicSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKMusicSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKMusicSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKMusicSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKMusicSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKMusicSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKPlayRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKPlayRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKPlayRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKPlayRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKPlayRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKPlayRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKPlaySquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKPlaySquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKPlaySquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKPlaySquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKPlaySquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKPlaySquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKVideoRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKVideoRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKVideoRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKVideoRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKVideoRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKVideoRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKVideoSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKVideoSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKVideoSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKVideoSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVKVideoSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVKVideoSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVisa = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVisa.svg"),
  ratio: 1.9166666666666667,
  multiColor: false
});
export var LogoVkClipsRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkClipsRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkClipsRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkClipsRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkClipsRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkClipsRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkClipsSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkClipsSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkClipsSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkClipsSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkClipsSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkClipsSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoVkpay = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVkpay.svg"),
  ratio: 1.9166666666666667,
  multiColor: false
});
export var LogoVtb = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoVtb.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoWbBank = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWbBank.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoWebmoney = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWebmoney.svg"),
  defaultSize: 44,
  multiColor: false
});
export var LogoWechatRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWechatRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWechatRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWechatRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWechatRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWechatRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWechatSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWechatSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWechatSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWechatSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWechatSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWechatSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWhatsappRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWhatsappRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWhatsappRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWhatsappRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWhatsappRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWhatsappRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWhatsappSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWhatsappSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWhatsappSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWhatsappSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoWhatsappSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoWhatsappSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoX5PointsReceived = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoX5PointsReceived.svg"),
  multiColor: false
});
export var LogoX5PointsSpent = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoX5PointsSpent.svg"),
  multiColor: false
});
export var LogoX5paketRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoX5paketRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoX5paketRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoX5paketRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoX5paketSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoX5paketSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoX5paketSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoX5paketSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaDiskRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaDiskRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaDiskRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaDiskRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaDiskRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaDiskRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaDiskSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaDiskSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaDiskSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaDiskSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaDiskSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaDiskSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMapsRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMapsRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMapsRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMapsRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMapsRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMapsRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMapsSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMapsSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMapsSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMapsSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMapsSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMapsSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMarketRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMarketRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMarketRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMarketRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMarketRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMarketRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMarketSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMarketSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMarketSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMarketSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYaMarketSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYaMarketSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexBooksDefault = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexBooksDefault.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexMusicRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexMusicRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexMusicRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexMusicRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexMusicRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexMusicRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexMusicSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexMusicSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexMusicSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexMusicSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexMusicSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexMusicSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexNavigatorRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexNavigatorRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexNavigatorRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexNavigatorRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexNavigatorRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexNavigatorRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexNavigatorSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexNavigatorSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexNavigatorSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexNavigatorSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexNavigatorSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexNavigatorSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexPay = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexPay.svg"),
  ratio: 1.9166666666666667,
  multiColor: false
});
export var LogoYandexProRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexProRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexProRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexProRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexProRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexProRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexProSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexProSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexProSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexProSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexProSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexProSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexTaxiRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexTaxiRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexTaxiRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexTaxiRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexTaxiRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexTaxiRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexTaxiSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexTaxiSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexTaxiSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexTaxiSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexTaxiSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexTaxiSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexZenRound = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexZenRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexZenRoundColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexZenRoundColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexZenRoundMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexZenRoundMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexZenSquare = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexZenSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexZenSquareColor = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexZenSquareColor.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYandexZenSquareMonochrome = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYandexZenSquareMonochrome.svg"),
  defaultSize: 56,
  multiColor: false
});
export var LogoYoomoney = defineUrlIcon({
  url: "".concat(baseServerUrl, "/logos/LogoYoomoney.svg"),
  defaultSize: 44,
  multiColor: false
});