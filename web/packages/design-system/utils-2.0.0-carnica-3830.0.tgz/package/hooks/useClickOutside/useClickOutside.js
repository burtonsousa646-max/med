import { useEffect } from 'react';
import { useMutableRef } from "../useMutableRef";
export function useClickOutside(params) {
  var onClick = useMutableRef(params.onClick);
  var ignoreClicksInsideRefs = useMutableRef(params.ignoreClicksInsideRefs);
  var isActive = useMutableRef(params.isActive);
  useEffect(function () {
    var subscribe = function subscribe(event) {
      var _ignoreClicksInsideRe;
      if (!isActive.current) {
        return;
      }
      if ((_ignoreClicksInsideRe = ignoreClicksInsideRefs.current) !== null && _ignoreClicksInsideRe !== void 0 && _ignoreClicksInsideRe.every(function (ref) {
        var _ref$current;
        return !((_ref$current = ref.current) !== null && _ref$current !== void 0 && _ref$current.contains(event.target));
      })) {
        var _onClick$current;
        (_onClick$current = onClick.current) === null || _onClick$current === void 0 || _onClick$current.call(onClick, event);
      }
    };
    document.addEventListener('mousedown', subscribe);
    return function () {
      document.removeEventListener('mousedown', subscribe);
    };
  }, []);
}