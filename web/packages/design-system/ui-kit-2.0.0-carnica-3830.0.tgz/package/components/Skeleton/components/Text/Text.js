import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["tagName", "style", "width", "invert", "className"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import React from 'react';
import { Text as Typography } from "../../../Text";
import styles from "./styles.module.css";
var cnText = cnBem('skeleton-text', styles);
export var Text = forwardRefWithMotionTag(function (_ref, ref) {
  var _ref$tagName = _ref.tagName,
    tagName = _ref$tagName === void 0 ? 'span' : _ref$tagName,
    style = _ref.style,
    _ref$width = _ref.width,
    width = _ref$width === void 0 ? '100%' : _ref$width,
    invert = _ref.invert,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(Typography, _extends({}, otherProps, {
    className: cnText(null, [className]),
    color: invert ? 'disabled-fake-invert' : 'disabled',
    ref: ref,
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty({}, '--skeleton-width', typeof width === 'number' ? "".concat(width, "px") : width)),
    tagName: tagName,
    "data-t-id": "components-Text"
  }));
});