import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var CHAT_WIDGET_EVENT_CHAT = 'CHAT_WIDGET_EVENT_CHAT';
var CHAT_WIDGET_EVENT_MENU = 'CHAT_WIDGET_EVENT_MENU';
var createWidgetEvent = function createWidgetEvent(type, detail) {
  return new CustomEvent(type === 'menu' ? CHAT_WIDGET_EVENT_MENU : CHAT_WIDGET_EVENT_CHAT, {
    detail: detail
  });
};
var generateHandler = function generateHandler(type) {
  return function (flag, options) {
    var event = createWidgetEvent(type, _objectSpread({
      flag: flag
    }, options || {}));
    window.dispatchEvent(event);
  };
};
export var setChatWidgetOpen = generateHandler('chat');
export var setChatWidgetMenuOpen = generateHandler('menu');