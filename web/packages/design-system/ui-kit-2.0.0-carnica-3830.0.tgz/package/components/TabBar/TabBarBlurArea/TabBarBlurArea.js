import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["withCounter", "count", "side"],
  _excluded2 = ["side", "withControl", "withCounter", "count", "onButtonClick", "invert", "className", "Icon", "position"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { IconChevronLeft, IconChevronRight } from '@carnica/graphics';
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { withDataConverter } from '@beef/react';
import { compose } from '@beef/utils';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnTabBarBlurArea = cnBem('blur-area', styles);
var dataConverter = function dataConverter(_ref) {
  var withCounter = _ref.withCounter,
    _ref$count = _ref.count,
    count = _ref$count === void 0 ? 0 : _ref$count,
    _ref$side = _ref.side,
    side = _ref$side === void 0 ? 'left' : _ref$side,
    props = _objectWithoutProperties(_ref, _excluded);
  return _objectSpread(_objectSpread({}, props), {}, {
    withCounter: withCounter && count > 0,
    side: side,
    count: count,
    Icon: side === 'left' ? IconChevronLeft : IconChevronRight
  });
};
var TabBarBlurAreaRender = function TabBarBlurAreaRender(_ref2, ref) {
  var _ref2$side = _ref2.side,
    side = _ref2$side === void 0 ? 'left' : _ref2$side,
    withControl = _ref2.withControl,
    withCounter = _ref2.withCounter,
    _ref2$count = _ref2.count,
    count = _ref2$count === void 0 ? 0 : _ref2$count,
    onButtonClick = _ref2.onButtonClick,
    invert = _ref2.invert,
    className = _ref2.className,
    Icon = _ref2.Icon,
    position = _ref2.position,
    otherProps = _objectWithoutProperties(_ref2, _excluded2);
  return /*#__PURE__*/React.createElement("div", _extends({}, otherProps, {
    className: cnTabBarBlurArea({
      side: side,
      position: position,
      invert: invert
    }, [className]),
    ref: ref,
    "data-t-id": "TabBar-TabBarBlurArea"
  }), withControl && /*#__PURE__*/React.createElement(Icon, {
    "aria-label": "\u043F\u0435\u0440\u0435\u0439\u0442\u0438 \u0432 ".concat(side === 'left' ? 'начало' : 'конец'),
    className: cnTabBarBlurArea('button', {
      hidden: withCounter
    }),
    color: invert ? 'tertiary-fake-invert' : 'tertiary',
    onClick: onButtonClick,
    size: "s",
    tabIndex: -1,
    tagName: "button",
    type: "button"
  }), withCounter && /*#__PURE__*/React.createElement(Text, {
    className: cnTabBarBlurArea('counter'),
    color: invert ? 'tertiary-fake-invert' : 'tertiary',
    variant: "body-small"
  }, "\u2022 ".concat(count)));
};
export var TabBarBlurArea = compose(withDataConverter(dataConverter), forwardRef)(TabBarBlurAreaRender);