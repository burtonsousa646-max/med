import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _typeof from "@babel/runtime/helpers/typeof";
var _excluded = ["initialTheme", "themeStyles"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var isStylesThemeMap = function isStylesThemeMap(themeStyles, theme) {
  return !!themeStyles[theme];
};
export var getThemeStyles = function getThemeStyles(themeStyles, theme) {
  return isStylesThemeMap(themeStyles, theme) ? themeStyles[theme] : themeStyles;
};
var getInitialTheme = function getInitialTheme(_ref) {
  var initialTheme = _ref.initialTheme,
    themeStyles = _ref.themeStyles;
  if (initialTheme) {
    return initialTheme;
  }
  var defaultTheme = Object.keys(themeStyles !== null && themeStyles !== void 0 ? themeStyles : {})[0];
  return _typeof(themeStyles === null || themeStyles === void 0 ? void 0 : themeStyles[defaultTheme]) === 'object' ? defaultTheme : 'light';
};
export var dataConverter = function dataConverter(_ref2) {
  var initialTheme = _ref2.initialTheme,
    themeStyles = _ref2.themeStyles,
    props = _objectWithoutProperties(_ref2, _excluded);
  return _objectSpread(_objectSpread({}, props), {}, {
    initialTheme: getInitialTheme({
      initialTheme: initialTheme,
      themeStyles: themeStyles
    }),
    themeStyles: themeStyles
  });
};