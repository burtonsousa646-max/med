import _createClass from "@babel/runtime/helpers/createClass";
import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
export var BaseObserver = /*#__PURE__*/_createClass(function BaseObserver(callback) {
  _classCallCheck(this, BaseObserver);
  this.callback = callback;
});