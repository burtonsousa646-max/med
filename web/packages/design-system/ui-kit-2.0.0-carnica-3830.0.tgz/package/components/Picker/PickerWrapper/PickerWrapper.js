import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "onClose", "theme", "className", "children"];
import React, { forwardRef } from 'react';
import { AnimatePresence } from 'framer-motion';
import { cnBem } from '@carnica/utils';
import { useKeys } from '@carnica/utils/hooks';
import { EKeyCodes } from '@carnica/utils/types';
import { FocusTrap } from 'focus-trap-react';
import { ThemedPortal } from "../../../modules/ThemedPortal";
import styles from "./styles.module.css";
var cnPickerWrapper = cnBem('picker-wrapper', styles);
export var PickerWrapper = /*#__PURE__*/forwardRef(function (props, ref) {
  var isOpen = props.isOpen,
    onClose = props.onClose,
    _props$theme = props.theme,
    theme = _props$theme === void 0 ? 'light' : _props$theme,
    className = props.className,
    children = props.children,
    otherProps = _objectWithoutProperties(props, _excluded);
  useKeys(_defineProperty({}, EKeyCodes.Escape, function (e) {
    return isOpen && (onClose === null || onClose === void 0 ? void 0 : onClose(e));
  }));
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait",
    "data-t-id": "Picker-PickerWrapper"
  }, isOpen && /*#__PURE__*/React.createElement(FocusTrap, {
    active: isOpen,
    focusTrapOptions: {
      fallbackFocus: function fallbackFocus() {
        var _document;
        return (_document = document) === null || _document === void 0 ? void 0 : _document.body;
      }
    }
  }, /*#__PURE__*/React.createElement(ThemedPortal, _extends({}, otherProps, {
    animate: {
      opacity: 1
    },
    "aria-modal": true,
    className: cnPickerWrapper(null, [className]),
    exit: {
      opacity: 0
    },
    initial: {
      opacity: 0
    },
    motion: true,
    ref: ref,
    role: "dialog",
    theme: theme,
    "data-t-id": "Picker-PickerWrapper"
  }), children)));
});