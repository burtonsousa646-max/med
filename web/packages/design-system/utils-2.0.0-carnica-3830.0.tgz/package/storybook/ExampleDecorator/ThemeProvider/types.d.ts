import type { PropsWithHTMLAttributes } from '@carnica/utils/types';
import React from 'react';
export type ThemeProviderPropThemeStylesObject = Record<string, string>;
export type ThemeProviderBaseThemes = 'dark' | 'light';
export type ThemeProviderPropThemeStyles = Record<ThemeProviderBaseThemes, ThemeProviderPropThemeStylesObject> | ThemeProviderPropThemeStylesObject;
export type ThemeProviderProps = PropsWithHTMLAttributes<{
    baseName?: string;
    children?: ((theme: ThemeProviderBaseThemes) => React.ReactNode) | React.ReactNode;
    initialTheme?: ThemeProviderBaseThemes;
    themeStyles?: ThemeProviderPropThemeStyles;
}, HTMLDivElement>;
//# sourceMappingURL=types.d.ts.map