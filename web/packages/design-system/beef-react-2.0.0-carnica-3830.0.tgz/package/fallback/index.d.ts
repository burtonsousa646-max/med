export function useId(): string;
//# sourceMappingURL=index.d.ts.map