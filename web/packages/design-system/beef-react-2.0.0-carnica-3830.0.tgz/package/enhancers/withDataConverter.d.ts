export function withDataConverter(dataConverter: any): (WrappedComponent: any) => React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from 'react';
//# sourceMappingURL=withDataConverter.d.ts.map