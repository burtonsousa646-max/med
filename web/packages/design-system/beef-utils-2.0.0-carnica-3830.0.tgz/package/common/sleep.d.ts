export declare const waitForLayout: () => Promise<void>;
//# sourceMappingURL=sleep.d.ts.map