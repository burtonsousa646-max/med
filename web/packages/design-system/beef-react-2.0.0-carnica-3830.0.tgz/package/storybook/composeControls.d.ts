import type { ArgTypes, Args } from '@storybook/core/types';
import { getPreparedArgs } from './controls';
type ControlsData = {
    argTypes: ArgTypes;
    args: Args;
};
type ControlsMap = Record<string, ControlsData>;
export type GetControlsType<T extends Record<string, ReturnType<typeof getPreparedArgs>>> = {
    [K in keyof T]: T[K] extends {
        _type: infer U;
    } ? U : never;
};
export declare const composeControls: (controlsMap: ControlsMap) => ControlsData;
export {};
//# sourceMappingURL=composeControls.d.ts.map