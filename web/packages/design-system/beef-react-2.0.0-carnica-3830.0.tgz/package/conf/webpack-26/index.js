export { reactConfig } from "./react-config";
export { reactToolkit } from "./react-toolkit";
export { extendConfig, extendPlugin, extendToolkit, useConfig, usePlugin, useRule } from '@beef/conf/webpack-26';