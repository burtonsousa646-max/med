export var testUtil = function testUtil() {
  return 5;
};
export var selectStateFromRenderResult = function selectStateFromRenderResult(result) {
  return [function () {
    return result.current[0];
  }, result.current[1]];
};