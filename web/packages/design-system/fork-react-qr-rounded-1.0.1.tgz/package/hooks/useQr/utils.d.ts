export declare const isEyeInnerCorner: (row: number, col: number, moduleCount: number) => boolean;
export declare const isEyeOuterCorner: (row: number, col: number, moduleCount: number, isLight?: boolean) => boolean;
type Params = {
    col: number;
    endCutoutIndex?: number;
    isDarkArea: (row: number, col: number) => boolean;
    moduleCount: number;
    rounding: number;
    row: number;
    size: number;
    startCutoutIndex?: number;
};
export declare const drawMod: ({ isDarkArea, rounding, size, row, col, moduleCount, startCutoutIndex, endCutoutIndex, }: Params) => string;
export declare const calculateCutoutArea: (size: number, moduleCount?: number) => number;
export {};
//# sourceMappingURL=utils.d.ts.map