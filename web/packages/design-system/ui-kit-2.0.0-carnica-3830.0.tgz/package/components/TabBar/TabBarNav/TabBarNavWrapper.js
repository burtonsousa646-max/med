import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "position", "className", "wrapperRef", "invert", "onUlMouseLeave", "onScrollButtonClick", "blurAreaRefs", "hiddenCount"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import styles from "./styles.module.css";
import { TabBarBlurArea } from "../TabBarBlurArea";
var cnTabBarNav = cnBem('tabbar-nav', styles);
export var TabBarNavWrapper = /*#__PURE__*/forwardRef(function (props, ref) {
  var children = props.children,
    position = props.position,
    className = props.className,
    wrapperRef = props.wrapperRef,
    invert = props.invert,
    onUlMouseLeave = props.onUlMouseLeave,
    onScrollButtonClick = props.onScrollButtonClick,
    blurAreaRefs = props.blurAreaRefs,
    hiddenCount = props.hiddenCount,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  var showButtons = !isMobile && position === 'default';
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnTabBarNav({
      position: position,
      invert: invert
    }, [className]),
    ref: ref
  }, otherProps, {
    "data-t-id": "TabBar-TabBarNav"
  }), /*#__PURE__*/React.createElement(TabBarBlurArea, {
    invert: invert,
    onButtonClick: onScrollButtonClick === null || onScrollButtonClick === void 0 ? void 0 : onScrollButtonClick('left'),
    position: position,
    ref: blurAreaRefs === null || blurAreaRefs === void 0 ? void 0 : blurAreaRefs.left,
    side: "left",
    withControl: showButtons
  }), /*#__PURE__*/React.createElement("ul", {
    className: cnTabBarNav('list'),
    onMouseLeave: onUlMouseLeave,
    ref: wrapperRef
  }, children), /*#__PURE__*/React.createElement(TabBarBlurArea, {
    count: hiddenCount,
    invert: invert,
    onButtonClick: onScrollButtonClick === null || onScrollButtonClick === void 0 ? void 0 : onScrollButtonClick('right'),
    position: position,
    ref: blurAreaRefs === null || blurAreaRefs === void 0 ? void 0 : blurAreaRefs.right,
    side: "right",
    withControl: showButtons,
    withCounter: true
  }));
});