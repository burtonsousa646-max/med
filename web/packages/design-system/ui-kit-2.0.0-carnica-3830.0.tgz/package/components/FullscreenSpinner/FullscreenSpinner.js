import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["loadingPhrases", "animationStartMode", "className", "isOpen"];
import React, { forwardRef } from 'react';
import { AnimatePresence } from 'framer-motion';
import { cnBem } from '@carnica/utils';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import { ThemedPortal } from "../../modules/ThemedPortal";
import { Spinner } from "../Spinner";
import styles from "./styles.module.css";
import { FullScreenSpinnerText } from "./FullScreenSpinnerText";
var cnFullscreenSpinner = cnBem('fullscreen-spinner', styles);
export var FullscreenSpinner = /*#__PURE__*/forwardRef(function (props, ref) {
  var loadingPhrases = props.loadingPhrases,
    animationStartMode = props.animationStartMode,
    className = props.className,
    isOpen = props.isOpen,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    "data-t-id": "components-FullscreenSpinner"
  }, isOpen && /*#__PURE__*/React.createElement(ThemedPortal, _extends({
    animate: {
      opacity: 1
    },
    "aria-atomic": true,
    "aria-label": "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430. \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u043F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435.",
    "aria-live": "assertive",
    "aria-modal": true,
    className: cnFullscreenSpinner(null, [className]),
    exit: {
      opacity: 0
    },
    initial: {
      opacity: 0
    },
    motion: true,
    ref: ref,
    role: "dialog",
    tagName: "section",
    transition: {
      ease: [0.2, 0, 0, 1],
      duration: 0.15
    }
  }, otherProps), /*#__PURE__*/React.createElement("div", {
    className: cnFullscreenSpinner('content'),
    "data-t-id": "components-FullscreenSpinner"
  }, /*#__PURE__*/React.createElement(Spinner, {
    size: isMobile ? 32 : 44,
    view: "yellow-white"
  }), /*#__PURE__*/React.createElement(FullScreenSpinnerText, {
    animationStartMode: animationStartMode,
    loadingPhrases: loadingPhrases
  }))));
});