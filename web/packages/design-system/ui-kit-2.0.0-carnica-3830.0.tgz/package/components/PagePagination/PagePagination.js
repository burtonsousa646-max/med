import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["onChange", "pages", "value", "className", "color", "shouldRender"];
import React, { forwardRef, useCallback } from 'react';
import { cnBem } from '@carnica/utils';
import { useMutableRef } from '@carnica/utils/hooks';
import { withRenderCondition } from '@beef/react';
import { compose } from '@beef/utils';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { usePages } from "./hooks/usePages/usePages";
import { PagePaginationItem } from "./PagePaginationItem";
import { PagePaginationNavigateButton } from "./PagePaginationNavigateButton";
import { usePagePaginationKeyboardHandler } from "./hooks/usePagePaginationKeyboardHandler";
var cnPagePagination = cnBem('page-pagination', styles);
var PagePaginationRender = function PagePaginationRender(props, ref) {
  var _ref = props,
    onChange = _ref.onChange,
    _ref$pages = _ref.pages,
    pages = _ref$pages === void 0 ? 0 : _ref$pages,
    _ref$value = _ref.value,
    value = _ref$value === void 0 ? 1 : _ref$value,
    className = _ref.className,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'primary' : _ref$color,
    shouldRender = _ref.shouldRender,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var currentPage = Math.max(Math.min(value, pages || 0), 0);
  var _usePages = usePages(currentPage, pages),
    list = _usePages.list,
    showNextButton = _usePages.showNextButton,
    showPrevButton = _usePages.showPrevButton;
  var onChangeRef = useMutableRef(onChange);
  var _usePagePaginationKey = usePagePaginationKeyboardHandler(list, pages),
    pageRefs = _usePagePaginationKey.pageRefs,
    onKeyDownByPage = _usePagePaginationKey.onKeyDownByPage;
  var handleChange = useCallback(function (page) {
    return function (e) {
      var _onChangeRef$current;
      return (_onChangeRef$current = onChangeRef.current) === null || _onChangeRef$current === void 0 ? void 0 : _onChangeRef$current.call(onChangeRef, page, e);
    };
  }, []);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    "aria-label": "\u041F\u043E\u0441\u0442\u0440\u0430\u043D\u0438\u0447\u043D\u0430\u044F \u043D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F",
    className: cnPagePagination(null, [className]),
    ref: ref,
    tagName: "ul",
    "data-t-id": "components-PagePagination"
  }), showPrevButton && /*#__PURE__*/React.createElement("li", {
    className: cnPagePagination('item')
  }, /*#__PURE__*/React.createElement(PagePaginationNavigateButton, {
    color: color,
    direction: "prev",
    disabled: currentPage < 2,
    onClick: handleChange(currentPage - 1)
  })), list.map(function (el, i) {
    return /*#__PURE__*/React.createElement("li", {
      className: cnPagePagination('item'),
      key: "".concat(el.type, "-").concat(el.type === 'page' ? el.page : i)
    }, /*#__PURE__*/React.createElement(PagePaginationItem, _extends({}, el, {
      active: el.page === currentPage,
      color: color,
      "data-item-type": el.type,
      "data-page": el.page,
      onChangePage: onChange,
      onKeyDown: el.type === 'page' ? onKeyDownByPage(el.page) : undefined,
      ref: el.type === 'page' ? pageRefs[el.page - 1] : undefined
    })));
  }), showNextButton && /*#__PURE__*/React.createElement("li", {
    className: cnPagePagination('item')
  }, /*#__PURE__*/React.createElement(PagePaginationNavigateButton, {
    color: color,
    direction: "next",
    disabled: currentPage >= pages,
    onClick: handleChange(currentPage + 1)
  })));
};
export var PagePagination = compose(withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref2) {
    var _ref2$pages = _ref2.pages,
      pages = _ref2$pages === void 0 ? 0 : _ref2$pages;
    return pages > 1;
  }
}), forwardRef)(PagePaginationRender);