import { AnyFunc } from './types';
export declare const logFunctionResult: (title: string, fn: AnyFunc) => (...args: any[]) => void;
//# sourceMappingURL=helpers.d.ts.map