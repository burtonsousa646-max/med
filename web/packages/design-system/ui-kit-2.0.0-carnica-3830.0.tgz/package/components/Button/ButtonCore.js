import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["mode", "children", "sale", "disabled", "view", "onlyIcon", "loading", "invert", "iconLeftProps", "iconRightProps", "onlyIconProps", "onClick", "originalView", "innerView"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { useFlag } from '@carnica/utils/hooks';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { MotionComponent } from "../../modules/MotionComponent";
import { ButtonIcon } from "./ButtonIcon";
import { ButtonSpinner } from "./ButtonSpinner";
import { dataConverter } from "./utils";
import styles from "./styles.module.css";
var cnButtonContent = cnBem('button-content', styles);
var ButtonCoreRender = function ButtonCoreRender(_ref, ref) {
  var _ref$mode = _ref.mode,
    mode = _ref$mode === void 0 ? 'default' : _ref$mode,
    children = _ref.children,
    sale = _ref.sale,
    disabled = _ref.disabled,
    _ref$view = _ref.view,
    view = _ref$view === void 0 ? 'primary' : _ref$view,
    onlyIcon = _ref.onlyIcon,
    loading = _ref.loading,
    invert = _ref.invert,
    iconLeftProps = _ref.iconLeftProps,
    iconRightProps = _ref.iconRightProps,
    onlyIconProps = _ref.onlyIconProps,
    onClick = _ref.onClick,
    originalView = _ref.originalView,
    innerView = _ref.innerView,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isPressed = _useFlag2[0],
    setIsPressed = _useFlag2[1];
  var handleClick = function handleClick(e) {
    onClick === null || onClick === void 0 || onClick(e);
    if (!innerView) {
      setIsPressed.on();
      setTimeout(setIsPressed.off, 310);
    }
  };
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({
    "data-pressed": innerView ? undefined : isPressed
  }, otherProps, {
    "data-disabled": disabled,
    disabled: disabled,
    onClick: handleClick,
    ref: ref,
    "data-t-id": "components-Button"
  }), loading && /*#__PURE__*/React.createElement(ButtonSpinner, {
    invert: invert,
    mode: mode,
    view: view
  }), onlyIcon ? /*#__PURE__*/React.createElement(ButtonIcon, onlyIconProps) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ButtonIcon, _extends({
    className: cnButtonContent('icon', {
      position: 'left',
      mode: mode
    })
  }, iconLeftProps)), /*#__PURE__*/React.createElement(MotionComponent, {
    className: cnButtonContent('label'),
    tagName: mode === 'inline' ? 'span' : 'p'
  }, children, mode === 'default' && sale && /*#__PURE__*/React.createElement("span", {
    className: cnButtonContent('sale')
  }, sale)), /*#__PURE__*/React.createElement(ButtonIcon, _extends({
    className: cnButtonContent('icon', {
      position: 'right',
      mode: mode
    })
  }, iconRightProps))));
};
export var ButtonCore = compose(withDataConverter(dataConverter), forwardRef)(ButtonCoreRender);