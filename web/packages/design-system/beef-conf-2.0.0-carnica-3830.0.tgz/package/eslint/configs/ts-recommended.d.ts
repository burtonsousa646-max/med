export declare let plugins: string[];
export declare let parser: string;
declare let _extends: any[];
export { _extends as extends };
//# sourceMappingURL=ts-recommended.d.ts.map