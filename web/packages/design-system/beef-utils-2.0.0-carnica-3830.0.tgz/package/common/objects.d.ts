import { Defined } from 'yargs';
import { AnyDict } from './types';
export declare function map<T extends Record<string, any>, V>(obj: T, fn: (value: T[keyof T], key: keyof T) => V): {
    [P in keyof T]: V;
};
export declare function mapKeys<K extends PropertyKey, KK extends PropertyKey, V>(obj: {
    [P in K]: V;
}, fn: (key: K, value: V) => KK): {
    [P in KK]: V;
};
export declare function forEach<T>(obj: Record<string, T>, fn: (value: T, key: string) => void): void;
export declare function reduce<T, R>(obj: Record<string, T>, fn: (result: R, value: T, key: string) => R, initialState: R): R;
export declare function filter<T extends Record<string, any>>(obj: T, fn: (value: T[keyof T], key: keyof T) => boolean): T;
export declare function take<T, K extends keyof T>(fields: K[], obj: T): Pick<T, K>;
export declare const flatten: <T>(arrayOfArrays: Array<Array<T>>) => Array<T>;
export declare const distinct: <T extends any[]>(arrayWithDuplicates: T) => T;
export declare const filterDefined: <T, R extends Defined<T, keyof T>>(obj: any) => R;
export declare const filterValuable: (obj: any) => any;
export declare const convertListToObjectBy: (field: ((item: AnyDict, index?: number) => string) | string) => (list: AnyDict[]) => AnyDict;
export declare const objectHasValue: (obj: Record<string, any>, value: any) => boolean;
export { compose } from 'redux';
export declare const shallowEqual: (objA: Record<any, any>, objB: Record<any, any>) => boolean;
//# sourceMappingURL=objects.d.ts.map