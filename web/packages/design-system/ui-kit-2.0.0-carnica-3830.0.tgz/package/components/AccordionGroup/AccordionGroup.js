import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "getters", "convertItem", "openIcon", "openRotate", "closeIcon", "closeRotate", "className", "size", "id"],
  _excluded2 = ["attributes"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { Accordion } from "../Accordion/Accordion";
import { MotionComponent } from "../../modules/MotionComponent";
import { useConvertedItems } from "../../hooks/useConvertedItems";
import styles from "./styles.module.css";
import { dataConverter, itemKeys } from "./utils";
import { useAccordionGroupKeyboardHandler } from "./hooks/useAccordionGroupKeyboardHandler";
var cnAccordionGroup = cnBem('accordion-group', styles);
var AccordionGroupRender = function AccordionGroupRender(props, ref) {
  var _props$items = props.items,
    itemsProp = _props$items === void 0 ? [] : _props$items,
    getters = props.getters,
    convertItem = props.convertItem,
    openIcon = props.openIcon,
    openRotate = props.openRotate,
    closeIcon = props.closeIcon,
    closeRotate = props.closeRotate,
    className = props.className,
    _props$size = props.size,
    size = _props$size === void 0 ? 'l' : _props$size,
    id = props.id,
    otherProps = _objectWithoutProperties(props, _excluded);
  var iconParams = closeIcon ? {
    closeIcon: closeIcon
  } : {
    closeRotate: closeRotate,
    openRotate: openRotate
  };
  var _useAccordionGroupKey = useAccordionGroupKeyboardHandler(itemsProp.length),
    summaryRefs = _useAccordionGroupKey.summaryRefs,
    onKeyDownByIndex = _useAccordionGroupKey.onKeyDownByIndex;
  var items = useConvertedItems({
    items: itemsProp,
    convertItem: convertItem,
    keys: itemKeys,
    getters: getters
  });
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnAccordionGroup({
      size: size
    }, [className]),
    id: id,
    ref: ref,
    role: "group",
    tagName: "section",
    "data-t-id": "components-AccordionGroup"
  }), items.map(function (_ref, i) {
    var attributes = _ref.attributes,
      item = _objectWithoutProperties(_ref, _excluded2);
    return /*#__PURE__*/React.createElement(Accordion, _extends({
      id: id ? "".concat(id, "-accordion-").concat(i + 1) : undefined,
      key: cnAccordionGroup('item', {
        i: i
      }),
      openIcon: openIcon,
      size: size,
      summaryProps: {
        onKeyDown: onKeyDownByIndex(i)
      },
      summaryRef: summaryRefs[i]
    }, item, attributes, iconParams));
  }));
};
export var AccordionGroup = compose(withDataConverter(dataConverter), forwardRef)(AccordionGroupRender);