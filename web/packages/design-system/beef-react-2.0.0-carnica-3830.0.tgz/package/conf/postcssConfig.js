const {
  browsers
} = require('@beef/conf/utils');

// fixes module resolution
const _ = require.resolve;

// FIXME: rather keep pluginOverrides empty at all times, added for migration
module.exports = opts => ({
  plugins: {
    [_('postcss-import')]: {
      /** FIXME: should use babel resolver, same way as other tools */
      addModulesDirectories: ['node_modules', 'src']
    },
    // this check is necessary, because first argument can be used by postcss-loader to pass webpack options
    // if following fields are missing, opts === customMixins
    [_('postcss-mixins')]: opts.env || opts.file ? {} : opts,
    [_('postcss-url')]: {},
    [_('postcss-preset-env')]: {
      browsers,
      stage: 2,
      preserve: false,
      features: {
        'nesting-rules': false,
        'focus-visible-pseudo-class': {
          preserve: true
        },
        'custom-properties': {
          preserve: true
        },
        'custom-media-queries': {
          preserve: true
        }
      }
    },
    [_('postcss-simple-vars')]: {
      silent: true
    },
    [_('postcss-nested')]: {},
    [_('postcss-hexrgba')]: {}
  }
});