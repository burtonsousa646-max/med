export var accessibilityConfig = {
  announceChanges: true,
  rootNode: function rootNode(emblaRoot) {
    return emblaRoot.parentElement;
  },
  carouselAriaLabel: 'Карусель',
  carouselAriaRoleDescription: 'карусель',
  previousButtonAriaLabel: 'Предыдущий слайд',
  nextButtonAriaLabel: 'Следующий слайд',
  slideAriaRoleDescription: 'слайд',
  slideAriaLabel: function slideAriaLabel(hasAnyGroupedSlides, firstSlideIndex, lastSlideIndex, totalSlides, selectedSnapIndex, totalSnaps) {
    var slide = firstSlideIndex + 1;
    var lastSlide = lastSlideIndex + 1;
    var isGrouped = firstSlideIndex !== lastSlideIndex;
    var groupInfo = "(\u0433\u0440\u0443\u043F\u043F\u0430 ".concat(selectedSnapIndex + 1, " \u0438\u0437 ").concat(totalSnaps, ")");
    if (!hasAnyGroupedSlides) {
      return "\u0421\u043B\u0430\u0439\u0434 ".concat(slide, " \u0438\u0437 ").concat(totalSlides);
    }
    if (!isGrouped) {
      return "\u0421\u043B\u0430\u0439\u0434 ".concat(slide, " \u0438\u0437 ").concat(totalSlides, " ").concat(groupInfo);
    }
    return "\u0421\u043B\u0430\u0439\u0434\u044B ".concat(slide, "-").concat(lastSlide, " \u0438\u0437 ").concat(totalSlides, " ").concat(groupInfo);
  },
  dotButtonAriaLabel: function dotButtonAriaLabel(hasAnyGroupedSlides, firstSlideIndex, lastSlideIndex, totalSlides, selectedSnapIndex, totalSnaps) {
    var slide = firstSlideIndex + 1;
    var lastSlide = lastSlideIndex + 1;
    var isSlideGrouped = firstSlideIndex !== lastSlideIndex;
    var groupInfo = "(\u0433\u0440\u0443\u043F\u043F\u0430 ".concat(selectedSnapIndex + 1, " \u0438\u0437 ").concat(totalSnaps, ")");
    if (!hasAnyGroupedSlides) {
      return "\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u0441\u043B\u0430\u0439\u0434\u0443 ".concat(slide, " \u0438\u0437 ").concat(totalSlides);
    }
    if (!isSlideGrouped) {
      return "\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u0441\u043B\u0430\u0439\u0434\u0443 ".concat(slide, " \u0438\u0437 ").concat(totalSlides, " ").concat(groupInfo);
    }
    return "\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u0441\u043B\u0430\u0439\u0434\u0430\u043C ".concat(slide, "-").concat(lastSlide, " \u0438\u0437 ").concat(totalSlides, " ").concat(groupInfo);
  },
  liveRegionContent: function liveRegionContent(hasAnyGroupedSlides, firstSlideIndex, lastSlideIndex, totalSlides, selectedSnapIndex, totalSnaps) {
    var slide = firstSlideIndex + 1;
    var lastSlide = lastSlideIndex + 1;
    var isSlideGrouped = firstSlideIndex !== lastSlideIndex;
    var groupInfo = "(\u0433\u0440\u0443\u043F\u043F\u0430 ".concat(selectedSnapIndex + 1, " \u0438\u0437 ").concat(totalSnaps, ")");
    if (!hasAnyGroupedSlides) {
      return "\u041F\u043E\u043A\u0430\u0437\u0430\u043D \u0441\u043B\u0430\u0439\u0434 ".concat(slide, " \u0438\u0437 ").concat(totalSlides);
    }
    if (!isSlideGrouped) {
      return "\u041F\u043E\u043A\u0430\u0437\u0430\u043D \u0441\u043B\u0430\u0439\u0434 ".concat(slide, " \u0438\u0437 ").concat(totalSlides, " ").concat(groupInfo);
    }
    return "\u041F\u043E\u043A\u0430\u0437\u0430\u043D\u044B \u0441\u043B\u0430\u0439\u0434\u044B ".concat(slide, "-").concat(lastSlide, " \u0438\u0437 ").concat(totalSlides, " ").concat(groupInfo);
  }
};