export var snackBarItemMap = {
  info: {
    id: 1,
    title: 'знаем о проблеме в вашем регионе',
    subTitle: 'исправим в течение часа',
    view: 'info'
  },
  success: {
    id: 2,
    title: 'услуга привет подключена',
    subTitle: 'пользуйтесь с удовольствием',
    view: 'success'
  },
  error: {
    id: 3,
    title: 'при подключении возникла ошибка',
    subTitle: 'исправим в течение часа',
    view: 'error'
  },
  warning: {
    id: 4,
    title: 'обратите внимание',
    subTitle: 'так это не работает',
    view: 'warning'
  }
};