import { MotionTagProps, MotionTags } from '@carnica/utils/types';
import type { HTMLMotionProps } from 'framer-motion';
import type { AnimatedIconProps } from './types';
type Result = Omit<MotionTagProps<AnimatedIconProps, MotionTags, 'span'>, 'rotations'>;
export declare const dataConverter: ({ style, size, transition, activeIndex, rotations, tagName, ...otherProps }: MotionTagProps<AnimatedIconProps, MotionTags, "span">) => Result;
export declare const getAnimationSettings: (type: AnimatedIconProps["animationType"], transition: number) => HTMLMotionProps<"div">;
export {};
//# sourceMappingURL=utils.d.ts.map