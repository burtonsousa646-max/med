import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["backgroundContent", "className", "iconColor"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import styles from "../styles.module.css";
var cnChips = cnBem('chips', styles);
export var ChipsBackgroundContent = function ChipsBackgroundContent(_ref) {
  var Image = _ref.backgroundContent,
    className = _ref.className,
    _ref$iconColor = _ref.iconColor,
    iconColor = _ref$iconColor === void 0 ? 'primary' : _ref$iconColor,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  if (!Image) {
    return null;
  }
  return /*#__PURE__*/React.createElement("div", _extends({}, otherProps, {
    className: cnChips('background', {
      type: typeof Image === 'string' ? 'image' : 'icon'
    }),
    role: "presentation",
    "data-t-id": "Chips-ChipsBackgroundContent"
  }), typeof Image === 'string' ? /*#__PURE__*/React.createElement("img", {
    alt: "\u0444\u043E\u043D",
    className: cnChips('image'),
    src: Image
  }) : /*#__PURE__*/React.createElement(Image, {
    className: cnChips('bgIcon'),
    color: iconColor,
    size: 68
  }));
};