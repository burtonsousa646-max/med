export declare const bordersMock: {
    name: string;
    value: string;
}[];
export declare const spaceMock: {
    name: string;
    value: string;
}[];
export declare const radiusMock: {
    name: string;
    value: string;
}[];
export declare const sizeMock: {
    name: string;
    value: string;
}[];
//# sourceMappingURL=mock.data.d.ts.map