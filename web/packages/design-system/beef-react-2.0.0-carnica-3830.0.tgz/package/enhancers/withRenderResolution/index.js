import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { RenderResolutionContext } from "./context";
import { usePersistedResolution } from "./usePersistedResolution";
import { RESOLUTION_SIZES } from "./consts";
export var withRenderResolution = function withRenderResolution() {
  var resolutions = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : RESOLUTION_SIZES;
  return function (WrappedComponent) {
    return function (props) {
      var _ref, _ref2, _props$__meta_interna, _props$__meta_interna2, _props$meta, _props$data;
      var lastKnownResolution = (_ref = (_ref2 = (_props$__meta_interna = props === null || props === void 0 || (_props$__meta_interna2 = props.__meta_internals) === null || _props$__meta_interna2 === void 0 ? void 0 : _props$__meta_interna2.lastKnownResolution) !== null && _props$__meta_interna !== void 0 ? _props$__meta_interna : props === null || props === void 0 || (_props$meta = props.meta) === null || _props$meta === void 0 ? void 0 : _props$meta.lastKnownResolution) !== null && _ref2 !== void 0 ? _ref2 : (_props$data = props.data) === null || _props$data === void 0 ? void 0 : _props$data.lastKnownResolution) !== null && _ref !== void 0 ? _ref : props.lastKnownResolution;
      var initialRenderResolution = usePersistedResolution(lastKnownResolution, resolutions);
      return /*#__PURE__*/React.createElement(RenderResolutionContext.Provider, {
        value: initialRenderResolution
      }, /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, props, {
        initialRenderResolution: lastKnownResolution,
        "data-t-id": "enhancers-withRenderResolution"
      })));
    };
  };
};