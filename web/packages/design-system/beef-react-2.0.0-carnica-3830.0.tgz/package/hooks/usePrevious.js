import { useEffect, useRef } from 'react';

/** Хук для отслеживания предыдущего значения переменной */
export var usePrevious = function usePrevious(value) {
  var ref = useRef(null);
  useEffect(function () {
    ref.current = value;
  }, [value]);
  return ref.current;
};