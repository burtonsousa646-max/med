import React from 'react';

/**
 * Check if component is still mounted, or is already unmounted
 * Useful for short-circuiting debounced scenarios
 */
export var useCheckMounted = function useCheckMounted() {
  var mounted = React.useRef(true);
  React.useEffect(function () {
    return function () {
      mounted.current = false;
    };
  }, []);
  return function () {
    return mounted.current;
  };
};