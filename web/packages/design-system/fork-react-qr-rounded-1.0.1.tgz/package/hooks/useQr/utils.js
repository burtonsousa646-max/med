// Размер угловых квадратов в ячейках
var QR_EYE_SIZE = 7;
var drawM = function drawM(x, y) {
  return "M ".concat(Math.round(x), " ").concat(Math.round(y));
};
var drawL = function drawL(x, y) {
  return "L ".concat(Math.round(x), " ").concat(Math.round(y));
};
var drawA = function drawA(x, y, rad) {
  return "A ".concat(Math.round(rad), " ").concat(Math.round(rad), " 0 0 1 ").concat(Math.round(x), " ").concat(Math.round(y));
};
var drawDark = function drawDark(left, top, right, bottom, rad, isLightTopLeft, isLightTopRight, isLightBottomRight, isLightBottomLeft) {
  var path = [];
  if (isLightTopLeft) {
    path.push(drawM(left + rad, top));
  } else {
    path.push(drawM(left, top));
  }
  if (isLightTopRight) {
    path.push(drawL(right - rad, top), drawA(right, top + rad, rad));
  } else {
    path.push(drawL(right, top));
  }
  if (isLightBottomRight) {
    path.push(drawL(right, bottom - rad), drawA(right - rad, bottom, rad));
  } else {
    path.push(drawL(right, bottom));
  }
  if (isLightBottomLeft) {
    path.push(drawL(left + rad, bottom), drawA(left, bottom - rad, rad));
  } else {
    path.push(drawL(left, bottom));
  }
  if (isLightTopLeft) {
    path.push(drawL(left, top + rad), drawA(left + rad, top, rad));
  } else {
    path.push(drawL(left, top));
  }
  return path.join(' ');
};
var drawLight = function drawLight(left, top, right, bottom, rad, isDarkTopLeft, isDarkTopRight, isDarkBottomRight, isDarkBottomLeft) {
  var path = [];
  if (isDarkTopLeft) {
    path.push(drawM(left + rad, top), drawL(left, top), drawL(left, top + rad), drawA(left + rad, top, rad));
  }
  if (isDarkTopRight) {
    path.push(drawM(right, top + rad), drawL(right, top), drawL(right - rad, top), drawA(right, top + rad, rad));
  }
  if (isDarkBottomRight) {
    path.push(drawM(right - rad, bottom), drawL(right, bottom), drawL(right, bottom - rad), drawA(right - rad, bottom, rad));
  }
  if (isDarkBottomLeft) {
    path.push(drawM(left, bottom - rad), drawL(left, bottom), drawL(left + rad, bottom), drawA(left, bottom - rad, rad));
  }
  return path.join(' ');
};
export var isEyeInnerCorner = function isEyeInnerCorner(row, col, moduleCount) {
  var isTopLeftEye = (row === QR_EYE_SIZE - 5 || row === QR_EYE_SIZE - 3) && (col === QR_EYE_SIZE - 5 || col === QR_EYE_SIZE - 3);
  var isBottomLeftEye = (row === moduleCount - 3 || row === moduleCount - 5) && (col === QR_EYE_SIZE - 5 || col === QR_EYE_SIZE - 3);
  var isTopRightEye = (row === QR_EYE_SIZE - 5 || row === QR_EYE_SIZE - 3) && (col === moduleCount - 5 || col === moduleCount - 3);
  return isTopLeftEye || isTopRightEye || isBottomLeftEye;
};
export var isEyeOuterCorner = function isEyeOuterCorner(row, col, moduleCount, isLight) {
  var startPosition = 0;
  if (isLight) {
    startPosition = 1;
  }
  var isTopLeftEye = (row === startPosition || row === QR_EYE_SIZE - 1 - startPosition) && (col === startPosition || col === QR_EYE_SIZE - 1 - startPosition);
  var isBottomLeftEye = (row === moduleCount - QR_EYE_SIZE + startPosition || row === moduleCount - 1 - startPosition) && (col === startPosition || col === QR_EYE_SIZE - 1 - startPosition);
  var isTopRightEye = (row === startPosition || row === QR_EYE_SIZE - 1 - startPosition) && (col === moduleCount - QR_EYE_SIZE + startPosition || col === moduleCount - 1 - startPosition);
  return isTopLeftEye || isTopRightEye || isBottomLeftEye;
};
var getIsDarkFunction = function getIsDarkFunction(isDarkArea, startCutoutIndex, endCutoutIndex) {
  return function (rowIndex, colIndex) {
    var cutoutFlag = !!endCutoutIndex && !!startCutoutIndex ? !(colIndex <= endCutoutIndex && colIndex >= startCutoutIndex && rowIndex <= endCutoutIndex && rowIndex >= startCutoutIndex) : true;
    return isDarkArea(rowIndex, colIndex) && cutoutFlag;
  };
};
var getRadius = function getRadius(isInnerCorner, isOuterCorner, isDark, radius) {
  if (isOuterCorner) {
    return radius * (isDark ? 6 : 2);
  }
  if (isInnerCorner) {
    return radius * 2;
  }
  return radius;
};
export var drawMod = function drawMod(_ref) {
  var isDarkArea = _ref.isDarkArea,
    rounding = _ref.rounding,
    size = _ref.size,
    row = _ref.row,
    col = _ref.col,
    moduleCount = _ref.moduleCount,
    startCutoutIndex = _ref.startCutoutIndex,
    endCutoutIndex = _ref.endCutoutIndex;
  var left = col * size;
  var top = row * size;
  var right = left + size;
  var bottom = top + size;
  var prevRow = row - 1;
  var topRightxtRow = row + 1;
  var prevCol = col - 1;
  var topRightxtCol = col + 1;
  var isDark = getIsDarkFunction(isDarkArea, startCutoutIndex, endCutoutIndex);
  var isDarkCenter = isDark(row, col);
  var isDarkTopLeft = isDark(prevRow, prevCol);
  var isDarkTop = isDark(prevRow, col);
  var isDarkTopRight = isDark(prevRow, topRightxtCol);
  var isDarkRight = isDark(row, topRightxtCol);
  var isDarkBottomRight = isDark(topRightxtRow, topRightxtCol);
  var isDarkBottom = isDark(topRightxtRow, col);
  var isDarkBottomLeft = isDark(topRightxtRow, prevCol);
  var isDarkLeft = isDark(row, prevCol);
  var isOuterCorner = isEyeOuterCorner(row, col, moduleCount, !isDarkCenter);
  var isInnerCorner = isEyeInnerCorner(row, col, moduleCount);
  var radius = getRadius(isInnerCorner, isOuterCorner, isDarkCenter, rounding * 0.005 * size);
  if (isDarkCenter) {
    return drawDark(left, top, right, bottom, radius, !isDarkTop && !isDarkLeft, !isDarkTop && !isDarkRight, !isDarkBottom && !isDarkRight, !isDarkBottom && !isDarkLeft);
  }
  return drawLight(left, top, right, bottom, radius, isDarkTop && isDarkLeft && isDarkTopLeft, isDarkTop && isDarkRight && isDarkTopRight, isDarkBottom && isDarkRight && isDarkBottomRight, isDarkBottom && isDarkLeft && isDarkBottomLeft);
};
export var calculateCutoutArea = function calculateCutoutArea(size) {
  var moduleCount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
  var moduleSizePx = size / moduleCount;
  var factor = 20;
  if (size >= 240) {
    factor = 60;
  } else if (size >= 160) {
    factor = 40;
  }
  var cutoutModuleSize = factor / moduleSizePx;
  var cutoutModuleCount = factor === 20 ? Math.ceil(cutoutModuleSize) : Math.round(cutoutModuleSize);
  return moduleCount % 2 === cutoutModuleCount % 2 ? cutoutModuleCount : cutoutModuleCount + 1;
};