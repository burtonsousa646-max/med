import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useEffect, useState } from 'react';
import { getMobileOS } from '@beef/utils';
import { detectInstalledAndroidApp } from "./utils/detectInstallAndroidApp";
var BEFORE_INSTALL_PROMPT_TIMEOUT = 10000;
export var useAndroidEffect = function useAndroidEffect(effect) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var deps = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
  var _options$waitInstalle = options.waitInstalledAppStatus,
    waitInstalledAppStatus = _options$waitInstalle === void 0 ? false : _options$waitInstalle;
  var _useState = useState(null),
    _useState2 = _slicedToArray(_useState, 2),
    isInstalledApp = _useState2[0],
    setIsInstalledApp = _useState2[1];
  useEffect(function () {
    if (getMobileOS() !== 'android') return;
    if (waitInstalledAppStatus && isInstalledApp === null) {
      // eslint-disable-next-line consistent-return
      return detectInstalledAndroidApp(BEFORE_INSTALL_PROMPT_TIMEOUT, setIsInstalledApp);
    }

    // eslint-disable-next-line consistent-return
    return effect({
      isInstalledApp: isInstalledApp
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isInstalledApp, waitInstalledAppStatus].concat(_toConsumableArray(deps)));
};