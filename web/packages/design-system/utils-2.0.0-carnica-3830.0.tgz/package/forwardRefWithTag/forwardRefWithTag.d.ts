import React from 'react';
import { ComponentWithTag, ElementFromTag, PropsWithTagAttributes, TagTypes } from '../types';
export declare function forwardRefWithTag<Props, AllowedTags extends TagTypes, Tag extends AllowedTags, HTMLElementType extends HTMLElement = ElementFromTag<Tag>>(render: React.ForwardRefRenderFunction<HTMLElementType, React.PropsWithoutRef<PropsWithTagAttributes<Props, AllowedTags, Tag>>>): ComponentWithTag<Props, AllowedTags, Tag>;
//# sourceMappingURL=forwardRefWithTag.d.ts.map