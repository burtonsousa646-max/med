import type { DebouncedFunction, Options } from 'debounce';
export type { DebouncedFunction };
type AnyFunc = (...args: readonly any[]) => void;
export declare function debounce<F extends AnyFunc>(f: F, interval?: number, options?: Options): DebouncedFunction<F>;
export declare function throttle<F extends AnyFunc>(f: F, interval: number): F;
//# sourceMappingURL=timed-functions.d.ts.map