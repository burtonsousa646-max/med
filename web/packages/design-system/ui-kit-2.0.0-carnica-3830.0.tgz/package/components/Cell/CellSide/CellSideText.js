import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["variant", "icon", "disabled", "type", "className", "children", "color"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnCellSide = cnBem('cell-side', styles);
export var CellSideText = function CellSideText(_ref) {
  var _ref$variant = _ref.variant,
    variant = _ref$variant === void 0 ? 'body-small' : _ref$variant,
    Icon = _ref.icon,
    disabled = _ref.disabled,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'title' : _ref$type,
    className = _ref.className,
    children = _ref.children,
    color = _ref.color,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  if (!children) {
    return null;
  }
  return /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    align: "right",
    className: cnCellSide('text'),
    style: _defineProperty({}, '--cell-side-text-color', "var(--cell-".concat(type, "-").concat(disabled ? 'color-disabled' : 'color', ")")),
    tagName: "span",
    variant: variant,
    "data-t-id": "Cell-CellSide"
  }), children, Icon && /*#__PURE__*/React.createElement(Icon, {
    className: cnCellSide('icon'),
    customColor: "currentColor",
    size: variant === 'body-accent-medium' ? 's' : 'xs'
  }));
};