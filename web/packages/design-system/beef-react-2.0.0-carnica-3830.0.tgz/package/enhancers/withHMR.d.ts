export function withHMR(): (WrappedComponent: any) => any;
//# sourceMappingURL=withHMR.d.ts.map