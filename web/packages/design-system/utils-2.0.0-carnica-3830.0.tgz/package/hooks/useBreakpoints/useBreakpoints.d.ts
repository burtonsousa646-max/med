import { BreakpointsMap, BreakpointsResult, DIMENSION_TYPE } from './types';
export declare const defaultMap: BreakpointsMap<string>;
export declare const useBreakpoints: <POINTS extends string>(map?: BreakpointsMap<POINTS>, isActive?: boolean) => BreakpointsResult<POINTS>;
export declare const useIsMobileDimension: (map?: BreakpointsMap<DIMENSION_TYPE>, isActive?: boolean) => boolean;
export declare const useIsTabletDimension: (map?: BreakpointsMap<DIMENSION_TYPE>, isActive?: boolean) => boolean;
export declare const useIsDesktopDimension: (map?: BreakpointsMap<DIMENSION_TYPE>, isActive?: boolean) => boolean;
//# sourceMappingURL=useBreakpoints.d.ts.map