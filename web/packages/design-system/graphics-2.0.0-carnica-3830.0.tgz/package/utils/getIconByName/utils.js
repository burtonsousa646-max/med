export var iconsSpecificSettings = {
  Logo2GisRound: {
    defaultSize: 56
  },
  Logo2GisSquare: {
    defaultSize: 56
  },
  LogoAkbars: {
    defaultSize: 44
  },
  LogoAlfaMoneyRed: {
    defaultSize: 44
  },
  LogoAlfaMoneyWhite: {
    defaultSize: 44
  },
  LogoAlfabank: {
    defaultSize: 44
  },
  LogoApplemusicRound: {
    defaultSize: 56
  },
  LogoApplemusicRoundColor: {
    defaultSize: 56
  },
  LogoApplemusicRoundMonochrome: {
    defaultSize: 56
  },
  LogoApplemusicSquare: {
    defaultSize: 56
  },
  LogoApplemusicSquareColor: {
    defaultSize: 56
  },
  LogoApplemusicSquareMonochrome: {
    defaultSize: 56
  },
  LogoArvand: {
    defaultSize: 44
  },
  LogoBeelineColor: {
    defaultSize: 56
  },
  LogoBeelineMonochrome: {
    defaultSize: 56
  },
  LogoBspb: {
    defaultSize: 44
  },
  LogoDomrfbank: {
    defaultSize: 44
  },
  LogoEnergobank: {
    defaultSize: 44
  },
  LogoEnergotransbank: {
    defaultSize: 44
  },
  LogoFinambank: {
    defaultSize: 44
  },
  LogoGazprombank: {
    defaultSize: 44
  },
  LogoGoskey: {
    defaultSize: 56
  },
  LogoGosuslugiRound: {
    defaultSize: 56
  },
  LogoGosuslugiRoundColor: {
    defaultSize: 56
  },
  LogoGosuslugiRoundMonochrome: {
    defaultSize: 56
  },
  LogoGosuslugiSquare: {
    defaultSize: 56
  },
  LogoGosuslugiSquareColor: {
    defaultSize: 56
  },
  LogoGosuslugiSquareMonochrome: {
    defaultSize: 56
  },
  LogoHomecredit: {
    defaultSize: 44
  },
  LogoHumo: {
    defaultSize: 44
  },
  LogoIconTokenBackgroundFree: {
    defaultSize: 32
  },
  LogoIconTokenBlueShadow: {
    defaultSize: 36
  },
  LogoKinopoiskRound: {
    defaultSize: 56
  },
  LogoKinopoiskRoundColor: {
    defaultSize: 56
  },
  LogoKinopoiskRoundMonochrome: {
    defaultSize: 56
  },
  LogoKinopoiskSquare: {
    defaultSize: 56
  },
  LogoKinopoiskSquareColor: {
    defaultSize: 56
  },
  LogoKinopoiskSquareMonochrome: {
    defaultSize: 56
  },
  LogoMaxMessengerRound: {
    defaultSize: 56
  },
  LogoMaxMessengerRoundColor: {
    defaultSize: 56
  },
  LogoMaxMessengerRoundMonochrome: {
    defaultSize: 56
  },
  LogoMaxMessengerSquare: {
    defaultSize: 56
  },
  LogoMaxMessengerSquareColor: {
    defaultSize: 56
  },
  LogoMaxMessengerSquareMonochrome: {
    defaultSize: 56
  },
  LogoMinbank: {
    defaultSize: 44
  },
  LogoMir: {
    ratio: 1.9166666666666667
  },
  LogoMkb: {
    defaultSize: 44
  },
  LogoModulbank: {
    defaultSize: 44
  },
  LogoMosEnergoSbit: {
    defaultSize: 46
  },
  LogoNationalStandardBank: {
    defaultSize: 44
  },
  LogoOdnoklassnikiRoundColor: {
    defaultSize: 56
  },
  LogoOdnoklassnikiRoundMonochrome: {
    defaultSize: 56
  },
  LogoOdnoklassnikiSquareColor: {
    defaultSize: 56
  },
  LogoOdnoklassnikiSquareMonochrome: {
    defaultSize: 56
  },
  LogoOpen: {
    defaultSize: 44
  },
  LogoOzonbank: {
    defaultSize: 44
  },
  LogoPerekrestokRoundColor: {
    defaultSize: 56
  },
  LogoPerekrestokRoundMonochrome: {
    defaultSize: 56
  },
  LogoPerekrestokSquareColor: {
    defaultSize: 56
  },
  LogoPerekrestokSquareMonochrome: {
    defaultSize: 56
  },
  LogoPochtabank: {
    defaultSize: 44
  },
  LogoPrimsotsbank: {
    defaultSize: 44
  },
  LogoPyaterochkaRoundColor: {
    defaultSize: 56
  },
  LogoPyaterochkaRoundMonochrome: {
    defaultSize: 56
  },
  LogoPyaterochkaSquareColor: {
    defaultSize: 56
  },
  LogoPyaterochkaSquareMonochrome: {
    defaultSize: 56
  },
  LogoRaiffeisen: {
    defaultSize: 44
  },
  LogoRencredit: {
    defaultSize: 44
  },
  LogoRosbank: {
    defaultSize: 44
  },
  LogoRosselkhozbank: {
    defaultSize: 44
  },
  LogoRsb: {
    defaultSize: 44
  },
  LogoRutubeRoundColor: {
    defaultSize: 56
  },
  LogoRutubeRoundMonochrome: {
    defaultSize: 56
  },
  LogoRutubeSquareColor: {
    defaultSize: 56
  },
  LogoRutubeSquareMonochrome: {
    defaultSize: 56
  },
  LogoSberPayBackground: {
    ratio: 1.9166666666666667
  },
  LogoSberPayStroked: {
    ratio: 1.9166666666666667
  },
  LogoSberbank: {
    defaultSize: 44
  },
  LogoSdco: {
    defaultSize: 44
  },
  LogoSnapchatRound: {
    defaultSize: 56
  },
  LogoSnapchatRoundColor: {
    defaultSize: 56
  },
  LogoSnapchatRoundMonochrome: {
    defaultSize: 56
  },
  LogoSnapchatSquare: {
    defaultSize: 56
  },
  LogoSnapchatSquareColor: {
    defaultSize: 56
  },
  LogoSnapchatSquareMonochrome: {
    defaultSize: 56
  },
  LogoSovcombank: {
    defaultSize: 44
  },
  LogoTelegramRoundColor: {
    defaultSize: 56
  },
  LogoTelegramRoundMonochrome: {
    defaultSize: 56
  },
  LogoTelegramSquareColor: {
    defaultSize: 56
  },
  LogoTelegramSquareMonochrome: {
    defaultSize: 56
  },
  LogoTiktokRound: {
    defaultSize: 56
  },
  LogoTiktokRoundColor: {
    defaultSize: 56
  },
  LogoTiktokRoundMonochrome: {
    defaultSize: 56
  },
  LogoTiktokSquare: {
    defaultSize: 56
  },
  LogoTiktokSquareColor: {
    defaultSize: 56
  },
  LogoTiktokSquareMonochrome: {
    defaultSize: 56
  },
  LogoTinkoff: {
    defaultSize: 44
  },
  LogoTkbbank: {
    defaultSize: 44
  },
  LogoTochkabank: {
    defaultSize: 44
  },
  LogoUnicreditbank: {
    defaultSize: 44
  },
  LogoUnionPay: {
    ratio: 1.9166666666666667
  },
  LogoUralsib: {
    defaultSize: 44
  },
  LogoVKMusicRound: {
    defaultSize: 56
  },
  LogoVKMusicRoundColor: {
    defaultSize: 56
  },
  LogoVKMusicRoundMonochrome: {
    defaultSize: 56
  },
  LogoVKMusicSquare: {
    defaultSize: 56
  },
  LogoVKMusicSquareColor: {
    defaultSize: 56
  },
  LogoVKMusicSquareMonochrome: {
    defaultSize: 56
  },
  LogoVKPlayRound: {
    defaultSize: 56
  },
  LogoVKPlayRoundColor: {
    defaultSize: 56
  },
  LogoVKPlayRoundMonochrome: {
    defaultSize: 56
  },
  LogoVKPlaySquare: {
    defaultSize: 56
  },
  LogoVKPlaySquareColor: {
    defaultSize: 56
  },
  LogoVKPlaySquareMonochrome: {
    defaultSize: 56
  },
  LogoVKVideoRound: {
    defaultSize: 56
  },
  LogoVKVideoRoundColor: {
    defaultSize: 56
  },
  LogoVKVideoRoundMonochrome: {
    defaultSize: 56
  },
  LogoVKVideoSquare: {
    defaultSize: 56
  },
  LogoVKVideoSquareColor: {
    defaultSize: 56
  },
  LogoVKVideoSquareMonochrome: {
    defaultSize: 56
  },
  LogoVisa: {
    ratio: 1.9166666666666667
  },
  LogoVkClipsRound: {
    defaultSize: 56
  },
  LogoVkClipsRoundColor: {
    defaultSize: 56
  },
  LogoVkClipsRoundMonochrome: {
    defaultSize: 56
  },
  LogoVkClipsSquare: {
    defaultSize: 56
  },
  LogoVkClipsSquareColor: {
    defaultSize: 56
  },
  LogoVkClipsSquareMonochrome: {
    defaultSize: 56
  },
  LogoVkRoundColor: {
    defaultSize: 56
  },
  LogoVkRoundMonochrome: {
    defaultSize: 56
  },
  LogoVkSquareColor: {
    defaultSize: 56
  },
  LogoVkSquareMonochrome: {
    defaultSize: 56
  },
  LogoVkpay: {
    ratio: 1.9166666666666667
  },
  LogoVtb: {
    defaultSize: 44
  },
  LogoWbBank: {
    defaultSize: 44
  },
  LogoWebmoney: {
    defaultSize: 44
  },
  LogoWechatRound: {
    defaultSize: 56
  },
  LogoWechatRoundColor: {
    defaultSize: 56
  },
  LogoWechatRoundMonochrome: {
    defaultSize: 56
  },
  LogoWechatSquare: {
    defaultSize: 56
  },
  LogoWechatSquareColor: {
    defaultSize: 56
  },
  LogoWechatSquareMonochrome: {
    defaultSize: 56
  },
  LogoWhatsappRound: {
    defaultSize: 56
  },
  LogoWhatsappRoundColor: {
    defaultSize: 56
  },
  LogoWhatsappRoundMonochrome: {
    defaultSize: 56
  },
  LogoWhatsappSquare: {
    defaultSize: 56
  },
  LogoWhatsappSquareColor: {
    defaultSize: 56
  },
  LogoWhatsappSquareMonochrome: {
    defaultSize: 56
  },
  LogoX5paketRoundColor: {
    defaultSize: 56
  },
  LogoX5paketRoundMonochrome: {
    defaultSize: 56
  },
  LogoX5paketSquareColor: {
    defaultSize: 56
  },
  LogoX5paketSquareMonochrome: {
    defaultSize: 56
  },
  LogoYaDiskRound: {
    defaultSize: 56
  },
  LogoYaDiskRoundColor: {
    defaultSize: 56
  },
  LogoYaDiskRoundMonochrome: {
    defaultSize: 56
  },
  LogoYaDiskSquare: {
    defaultSize: 56
  },
  LogoYaDiskSquareColor: {
    defaultSize: 56
  },
  LogoYaDiskSquareMonochrome: {
    defaultSize: 56
  },
  LogoYaMapsRound: {
    defaultSize: 56
  },
  LogoYaMapsRoundColor: {
    defaultSize: 56
  },
  LogoYaMapsRoundMonochrome: {
    defaultSize: 56
  },
  LogoYaMapsSquare: {
    defaultSize: 56
  },
  LogoYaMapsSquareColor: {
    defaultSize: 56
  },
  LogoYaMapsSquareMonochrome: {
    defaultSize: 56
  },
  LogoYaMarketRound: {
    defaultSize: 56
  },
  LogoYaMarketRoundColor: {
    defaultSize: 56
  },
  LogoYaMarketRoundMonochrome: {
    defaultSize: 56
  },
  LogoYaMarketSquare: {
    defaultSize: 56
  },
  LogoYaMarketSquareColor: {
    defaultSize: 56
  },
  LogoYaMarketSquareMonochrome: {
    defaultSize: 56
  },
  LogoYandexBooksDefault: {
    defaultSize: 56
  },
  LogoYandexMusicRound: {
    defaultSize: 56
  },
  LogoYandexMusicRoundColor: {
    defaultSize: 56
  },
  LogoYandexMusicRoundMonochrome: {
    defaultSize: 56
  },
  LogoYandexMusicSquare: {
    defaultSize: 56
  },
  LogoYandexMusicSquareColor: {
    defaultSize: 56
  },
  LogoYandexMusicSquareMonochrome: {
    defaultSize: 56
  },
  LogoYandexNavigatorRound: {
    defaultSize: 56
  },
  LogoYandexNavigatorRoundColor: {
    defaultSize: 56
  },
  LogoYandexNavigatorRoundMonochrome: {
    defaultSize: 56
  },
  LogoYandexNavigatorSquare: {
    defaultSize: 56
  },
  LogoYandexNavigatorSquareColor: {
    defaultSize: 56
  },
  LogoYandexNavigatorSquareMonochrome: {
    defaultSize: 56
  },
  LogoYandexPay: {
    ratio: 1.9166666666666667
  },
  LogoYandexProRound: {
    defaultSize: 56
  },
  LogoYandexProRoundColor: {
    defaultSize: 56
  },
  LogoYandexProRoundMonochrome: {
    defaultSize: 56
  },
  LogoYandexProSquare: {
    defaultSize: 56
  },
  LogoYandexProSquareColor: {
    defaultSize: 56
  },
  LogoYandexProSquareMonochrome: {
    defaultSize: 56
  },
  LogoYandexRoundColor: {
    defaultSize: 56
  },
  LogoYandexRoundMonochrome: {
    defaultSize: 56
  },
  LogoYandexSquareColor: {
    defaultSize: 56
  },
  LogoYandexSquareMonochrome: {
    defaultSize: 56
  },
  LogoYandexTaxiRound: {
    defaultSize: 56
  },
  LogoYandexTaxiRoundColor: {
    defaultSize: 56
  },
  LogoYandexTaxiRoundMonochrome: {
    defaultSize: 56
  },
  LogoYandexTaxiSquare: {
    defaultSize: 56
  },
  LogoYandexTaxiSquareColor: {
    defaultSize: 56
  },
  LogoYandexTaxiSquareMonochrome: {
    defaultSize: 56
  },
  LogoYandexZenRound: {
    defaultSize: 56
  },
  LogoYandexZenRoundColor: {
    defaultSize: 56
  },
  LogoYandexZenRoundMonochrome: {
    defaultSize: 56
  },
  LogoYandexZenSquare: {
    defaultSize: 56
  },
  LogoYandexZenSquareColor: {
    defaultSize: 56
  },
  LogoYandexZenSquareMonochrome: {
    defaultSize: 56
  },
  LogoYoomoney: {
    defaultSize: 44
  }
};
export var iconNamesMap = {
  IconCallingFilled: 'IconCallingOnFilled',
  IconCallingFilled1: 'IconCallingOffFilled',
  IconCallingOutline: 'IconCallingOnOutline',
  IconCallingOutline1: 'IconCallingOffOutline',
  LogoApplemusicRound: 'LogoApplemusicRoundColor',
  LogoApplemusicSquare: 'LogoApplemusicSquareColor',
  LogoGosuslugiRound: 'LogoGosuslugiRoundColor',
  LogoGosuslugiSquare: 'LogoGosuslugiSquareColor',
  LogoKinopoiskRound: 'LogoKinopoiskRoundColor',
  LogoKinopoiskSquare: 'LogoKinopoiskSquareColor',
  LogoMaxMessengerRound: 'LogoMaxMessengerRoundColor',
  LogoMaxMessengerSquare: 'LogoMaxMessengerSquareColor',
  LogoSnapchatRound: 'LogoSnapchatRoundColor',
  LogoSnapchatSquare: 'LogoSnapchatSquareColor',
  LogoTiktokRound: 'LogoTiktokRoundColor',
  LogoTiktokSquare: 'LogoTiktokSquareColor',
  LogoVKMusicRound: 'LogoVKMusicRoundColor',
  LogoVKMusicSquare: 'LogoVKMusicSquareColor',
  LogoVKPlayRound: 'LogoVKPlayRoundColor',
  LogoVKPlaySquare: 'LogoVKPlaySquareColor',
  LogoVKVideoRound: 'LogoVKVideoRoundColor',
  LogoVKVideoSquare: 'LogoVKVideoSquareColor',
  LogoVkClipsRound: 'LogoVkClipsRoundColor',
  LogoVkClipsSquare: 'LogoVkClipsSquareColor',
  LogoWechatRound: 'LogoWechatRoundColor',
  LogoWechatSquare: 'LogoWechatSquareColor',
  LogoWhatsappRound: 'LogoWhatsappRoundColor',
  LogoWhatsappSquare: 'LogoWhatsappSquareColor',
  LogoYaDiskRound: 'LogoYaDiskRoundColor',
  LogoYaDiskSquare: 'LogoYaDiskSquareColor',
  LogoYaMapsRound: 'LogoYaMapsRoundColor',
  LogoYaMapsSquare: 'LogoYaMapsSquareColor',
  LogoYaMarketRound: 'LogoYaMarketRoundColor',
  LogoYaMarketSquare: 'LogoYaMarketSquareColor',
  LogoYandexMusicRound: 'LogoYandexMusicRoundColor',
  LogoYandexMusicSquare: 'LogoYandexMusicSquareColor',
  LogoYandexNavigatorRound: 'LogoYandexNavigatorRoundColor',
  LogoYandexNavigatorSquare: 'LogoYandexNavigatorSquareColor',
  LogoYandexProRound: 'LogoYandexProRoundColor',
  LogoYandexProSquare: 'LogoYandexProSquareColor',
  LogoYandexTaxiRound: 'LogoYandexTaxiRoundColor',
  LogoYandexTaxiSquare: 'LogoYandexTaxiSquareColor',
  LogoYandexZenRound: 'LogoYandexZenRoundColor',
  LogoYandexZenSquare: 'LogoYandexZenSquareColor'
};