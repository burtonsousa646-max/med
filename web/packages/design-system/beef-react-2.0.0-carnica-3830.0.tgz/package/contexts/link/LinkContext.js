import React, { useContext } from 'react';
export var LinkContext = /*#__PURE__*/React.createContext('a');
export var useLink = function useLink() {
  return useContext(LinkContext);
};