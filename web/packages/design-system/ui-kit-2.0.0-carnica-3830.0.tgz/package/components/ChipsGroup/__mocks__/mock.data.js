import { IconCalculatorOutline, IconCheckShieldFilled, IconGamepadOutline, IconPhoneOutline, IconSwap } from '@carnica/graphics';
export var items = [{
  key: 1,
  label: 'оплатить',
  iconLeft: IconCalculatorOutline,
  tagName: 'a'
}, {
  key: 2,
  label: 'услуги связи',
  iconLeft: IconPhoneOutline,
  tagName: 'a'
}, {
  key: 3,
  label: 'перевести',
  iconLeft: IconSwap,
  tagName: 'a'
}, {
  key: 4,
  label: 'забота о финансах',
  iconLeft: IconCheckShieldFilled,
  tagName: 'a'
}, {
  key: 5,
  label: 'развлечения',
  iconLeft: IconGamepadOutline,
  tagName: 'a'
}, {
  key: 6,
  label: 'оплатить',
  iconLeft: IconCalculatorOutline,
  tagName: 'a'
}, {
  key: 7,
  label: 'услуги связи',
  iconLeft: IconPhoneOutline,
  tagName: 'a'
}, {
  key: 8,
  label: 'перевести',
  iconLeft: IconSwap,
  tagName: 'a'
}, {
  key: 9,
  label: 'забота о финансах',
  iconLeft: IconCheckShieldFilled,
  tagName: 'a'
}, {
  key: 10,
  label: 'развлечения',
  iconLeft: IconGamepadOutline,
  tagName: 'a'
}];