export declare const useDebounce: <T extends (...args: any) => void>(fn: T, time: number) => T;
//# sourceMappingURL=useDebounce.d.ts.map