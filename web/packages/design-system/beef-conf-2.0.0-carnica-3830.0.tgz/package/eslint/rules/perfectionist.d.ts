export let rules: {
    'perfectionist/sort-classes': number;
    'perfectionist/sort-imports': number;
    'perfectionist/sort-astro-attributes': number;
    'perfectionist/sort-array-includes': number;
    'perfectionist/sort-maps': number;
    'perfectionist/sort-objects': number;
    'perfectionist/sort-enums': number;
};
//# sourceMappingURL=perfectionist.d.ts.map