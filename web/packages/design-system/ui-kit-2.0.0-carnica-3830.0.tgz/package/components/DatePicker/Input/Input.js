import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["type", "isCalendarOpen", "disabled", "invert", "rightSide"];
import React, { forwardRef, useMemo } from 'react';
import { IconCalendarFilled } from '@carnica/graphics';
import { DateInput } from "./DateInput";
import { MontInput } from "./MonthInput";
import { getIconColor } from "./utils";
var componentsMap = {
  date: DateInput,
  month: MontInput
};
var getDefaultAriaLabel = function getDefaultAriaLabel(type, range, hasLabel) {
  if (hasLabel) {
    return undefined;
  }
  if (range) {
    return 'Поле ввода периода дат';
  }
  return "\u041F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430 ".concat(type === 'date' ? 'даты' : 'месяца');
};
export var Input = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'date' : _ref$type,
    isCalendarOpen = _ref.isCalendarOpen,
    disabled = _ref.disabled,
    invert = _ref.invert,
    rightSide = _ref.rightSide,
    props = _objectWithoutProperties(_ref, _excluded);
  var Component = useMemo(function () {
    return componentsMap[type];
  }, [type]);
  return /*#__PURE__*/React.createElement(Component, _extends({
    "aria-autocomplete": "none",
    "aria-expanded": isCalendarOpen,
    "aria-haspopup": "dialog",
    "aria-label": getDefaultAriaLabel(type, props.range, !!props.label),
    "aria-roledescription": "\u041F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430 \u0434\u0430\u0442\u044B",
    disabled: disabled,
    inputMode: "tel",
    invert: invert,
    rightSide: rightSide || /*#__PURE__*/React.createElement(IconCalendarFilled, {
      "aria-haspopup": "dialog",
      color: getIconColor(disabled, invert),
      size: "m"
    }),
    role: "combobox"
  }, props, {
    ref: ref,
    "data-t-id": "DatePicker-Input"
  }));
});