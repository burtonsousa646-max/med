export = WebpackFactory;
declare class WebpackFactory {
    static getConfig(env: any, options: any): {
        devServer?: {
            hot: boolean;
            port: string | number;
            headers: {
                'Access-Control-Allow-Origin': string;
            };
        } | undefined;
        mode: string;
        snapshot: {
            managedPaths: RegExp[];
        };
        watchOptions: {
            ignored: RegExp;
            followSymlinks: boolean;
        };
        output: {
            filename: string;
            publicPath: string;
            path: string;
            hotUpdateMainFilename: string;
            hotUpdateChunkFilename: string;
            assetModuleFilename: string;
            clean: boolean;
            devtoolModuleFilenameTemplate: (info: any) => any;
        };
        resolve: {
            extensions: string[];
            symlinks: boolean;
        };
        module: {
            rules: any[];
        };
        plugins: any[];
        optimization: {
            minimize: any;
            minimizer: any[];
        };
        devtool: string;
        stats: {
            chunks: boolean;
            colors: boolean;
            children: boolean;
        };
    };
    constructor(options?: {}, overrideEnv?: {});
    options: {
        version: any;
        filePattern: string;
        excludePlugins: never[];
        excludeRules: never[];
        cwd: string;
        monorepoExcludes: RegExp;
        monorepoIncludes: RegExp;
    };
    setEnv(overrideEnv: any): void;
    env: any;
    get rawLoaders(): {
        babel: string;
    };
    get rules(): {
        code: RegExp;
    };
    get loaders(): {
        babel: {
            loader: string;
            options: {
                cacheDirectory: boolean;
                rootMode: string;
            };
            exclude: RegExp;
        };
        asset: {
            type: string;
        };
    };
    get plugins(): {
        CopyWebpackPlugin: typeof CopyWebpackPlugin;
        BeefCacheBuildDependencyPlugin: typeof BeefCacheBuildDependencyPlugin;
        CircularDependencyPlugin: typeof CircularDependencyPlugin;
        WebpackManifestPlugin: typeof WebpackManifestPlugin;
        BeefManifestPlugin: typeof BeefManifestPlugin;
        EnvironmentPlugin: typeof EnvironmentPlugin;
        TerserPlugin: typeof TerserPlugin;
        DefinePlugin: typeof DefinePlugin;
    };
    usePlugin: (WebpackPluginClass: Function, options?: any, isEnabled?: boolean) => any;
    useRule: (rules: any, loaders: any, overrideParams?: {}) => any;
    oneOfLoaders: (...loaders: any[]) => {
        oneOf: any;
    };
    get config(): {
        devServer?: {
            hot: boolean;
            port: string | number;
            headers: {
                'Access-Control-Allow-Origin': string;
            };
        } | undefined;
        mode: string;
        snapshot: {
            managedPaths: RegExp[];
        };
        watchOptions: {
            ignored: RegExp;
            followSymlinks: boolean;
        };
        output: {
            filename: string;
            publicPath: string;
            path: string;
            hotUpdateMainFilename: string;
            hotUpdateChunkFilename: string;
            assetModuleFilename: string;
            clean: boolean;
            devtoolModuleFilenameTemplate: (info: any) => any;
        };
        resolve: {
            extensions: string[];
            symlinks: boolean;
        };
        module: {
            rules: any[];
        };
        plugins: any[];
        optimization: {
            minimize: any;
            minimizer: any[];
        };
        devtool: string;
        stats: {
            chunks: boolean;
            colors: boolean;
            children: boolean;
        };
    };
}
import CopyWebpackPlugin = require("copy-webpack-plugin");
import { BeefCacheBuildDependencyPlugin } from "./BeefCacheBuildDependencyPlugin";
import CircularDependencyPlugin = require("circular-dependency-plugin");
import { WebpackManifestPlugin } from "webpack-manifest-plugin";
import { BeefManifestPlugin } from "./beefManifestPlugin";
import { EnvironmentPlugin } from "webpack";
import TerserPlugin = require("terser-webpack-plugin");
import { DefinePlugin } from "webpack";
//# sourceMappingURL=WebpackFactory.d.ts.map