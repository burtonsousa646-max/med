export type ContainerType = Element | ShadowRoot;
export type Prepend = 'queue' | boolean;
export type AppendType = 'append' | 'prepend' | 'prependQueue';
type Options = {
    attachTo?: ContainerType;
    csp?: {
        nonce?: string;
    };
    mark?: string;
    prepend?: Prepend;
    priority?: number;
    styles?: HTMLElement[];
};
export declare const injectCSS: (css: string, option?: Options) => HTMLStyleElement | null;
export default function contains(root: Node | null | undefined, n?: Node): boolean;
export declare const removeCSS: (key: string, option?: Options) => void;
export declare const updateCSS: (css: string, key: string, originOption?: Options) => HTMLElement | null;
export {};
//# sourceMappingURL=dynamicCss.d.ts.map