import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["icon", "children", "view"];
import React, { forwardRef } from 'react';
import { MotionComponent } from "../../../modules/MotionComponent";
export var BadgeCore = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var icon = _ref.icon,
    children = _ref.children,
    view = _ref.view,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, props, {
    ref: ref,
    tagName: "span",
    "data-t-id": "Badge-core"
  }), (view === 'icon' || view === 'logo') && icon, view === 'text' && children);
});