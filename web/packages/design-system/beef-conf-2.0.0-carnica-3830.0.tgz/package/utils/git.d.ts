export function getCommitHash(): string;
export function getGitBranch(): {
    fullName: string;
    prefix?: undefined;
    summary?: undefined;
    task?: undefined;
} | {
    fullName: string;
    prefix: string;
    summary: string;
    task: string;
};
export function getRemoteTagVersions(tagName: any): string[];
export function gitSetRemote(remote: any, options: any, shOpts: any): string;
export function getTagVersion(): string;
export function gitHasUncommittedChanges(): boolean;
export function gitHasUnresolvedConflicts(): boolean;
export function gitTag(tagName: any, options: any, shOpts: any): string;
export function gitInit(options: any, shOpts: any): string;
export function gitPull(branchName: any, options: any, shOpts: any): string;
export function gitClone(repository: any, options: any, shOpts: any): string;
export function gitRemoteBranchExists(branchName: any, options: any, shOpts: any): boolean;
export function gitCheckout(branchName: any, options: any, shOpts: any): string;
export function gitCommit(options: any, shOpts: any): string;
export function gitPush(branchName: any, options: any, shOpts: any): string;
export function gitFetch(branchName: any, options: any, shOpts: any): string;
export function gitMerge(branchName: any, options: any, shOpts: any): string[] | null;
export function gitDiff(options: any, shOpts: any): string;
export function gitAdd(options: any, shOpts: any): string;
//# sourceMappingURL=git.d.ts.map