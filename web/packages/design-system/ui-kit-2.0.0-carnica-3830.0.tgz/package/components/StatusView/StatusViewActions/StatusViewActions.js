import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["getters", "actions", "convertAction", "className"],
  _excluded2 = ["attributes", "label"];
import { cnBem } from '@carnica/utils';
import React from 'react';
import { withRenderCondition } from '@beef/react';
import { CellGrid } from "../../CellGrid";
import { useConvertedItems } from "../../../hooks/useConvertedItems";
import styles from "./styles.module.css";
var actionKeys = ['attributes', 'disabled', 'icon', 'label', 'onClick', 'ref', 'tagName'];
var cnStatusViewActions = cnBem('status-view-actions', styles);
var StatusViewActionsRender = function StatusViewActionsRender(_ref) {
  var getters = _ref.getters,
    _ref$actions = _ref.actions,
    actions = _ref$actions === void 0 ? [] : _ref$actions,
    convertAction = _ref.convertAction,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var items = useConvertedItems({
    items: actions,
    convertItem: convertAction,
    keys: actionKeys,
    prefix: 'action',
    getters: getters
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnStatusViewActions(null, [className]),
    role: "group"
  }, otherProps, {
    "data-t-id": "StatusView-StatusViewActions"
  }), items.slice(0, 3).map(function (_ref2, i) {
    var attributes = _ref2.attributes,
      label = _ref2.label,
      params = _objectWithoutProperties(_ref2, _excluded2);
    return /*#__PURE__*/React.createElement(CellGrid, _extends({}, attributes, params, {
      className: cnStatusViewActions('action', [attributes === null || attributes === void 0 ? void 0 : attributes.className]),
      key: cnStatusViewActions('item', {
        i: i
      }),
      role: "button",
      size: "m",
      tabIndex: 0,
      title: label
    }));
  }));
};
export var StatusViewActions = withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref3) {
    var actions = _ref3.actions;
    return !!(actions !== null && actions !== void 0 && actions.length);
  }
})(StatusViewActionsRender);