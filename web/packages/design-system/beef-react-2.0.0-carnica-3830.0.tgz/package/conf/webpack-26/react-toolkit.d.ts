import FriendlyErrorOverlayPlugin from '../webpack/FriendlyErrorOverlayWebpackPlugin';
import HtmlWebpackPlugin from 'html-webpack-plugin';
import MiniCssExtractPlugin from 'mini-css-extract-plugin';
import CssMinimizerPlugin from 'css-minimizer-webpack-plugin';
import ReactRefreshWebpackPlugin from '@pmmmwh/react-refresh-webpack-plugin';
import ForkTsCheckerWebpackPlugin from 'fork-ts-checker-webpack-plugin';
import type { CssMinimizerPluginCssNano } from './types';
export declare const reactToolkit: import("@beef/conf/webpack-26").MergeBuilders<{
    _loaders: {
        babel: string;
    };
    rules: {
        code: RegExp;
    };
    readonly loaders: {
        babel: {
            loader: string;
            options: {
                cacheDirectory: boolean;
                rootMode: string;
            };
            exclude: any;
        };
        asset: {
            type: string;
        };
    };
    plugins: {
        CopyWebpackPlugin: typeof import("copy-webpack-plugin");
        CircularDependencyPlugin: typeof import("circular-dependency-plugin") & {
            failOnError: import("circular-dependency-plugin");
            warnOnError: import("circular-dependency-plugin");
        };
        WebpackManifestPlugin: typeof import("webpack-manifest-plugin").WebpackManifestPlugin;
        BeefManifestPlugin: typeof import("@beef/conf/webpack-26").BeefManifestPlugin;
        BeefCacheBuildDependencyPlugin: typeof import("@beef/conf/webpack-26").BeefCacheBuildDependencyPlugin;
        EnvironmentPlugin: typeof import("webpack").EnvironmentPlugin;
        TerserPlugin: typeof import("terser-webpack-plugin") & import("@beef/conf/webpack-26").TerserPluginTyped & {
            eraseComments: any;
        };
        DefinePlugin: typeof import("webpack").DefinePlugin;
    };
    readonly options: {
        monorepoExcludes: RegExp;
        monorepoIncludes: RegExp;
        version: string;
        filePattern: (isProduction?: boolean) => string;
        cwd: string;
    };
}, {
    plugins: {
        MiniCssExtractPlugin: typeof MiniCssExtractPlugin;
        CssMinimizerPlugin: typeof CssMinimizerPlugin & CssMinimizerPluginCssNano;
        HtmlWebpackPlugin: typeof HtmlWebpackPlugin & {
            forEntry: (args_0: {
                filePath: string;
                name: string;
            }, args_1?: any) => HtmlWebpackPlugin;
        };
        ReactRefreshWebpackPlugin: typeof ReactRefreshWebpackPlugin;
        FriendlyErrorOverlayPlugin: typeof FriendlyErrorOverlayPlugin;
        ForkTsCheckerWebpackPlugin: typeof ForkTsCheckerWebpackPlugin;
    };
    readonly _loaders: {
        expose: string;
        css: string;
        pcss: string;
        style: string;
        svgr: string;
        miniCssExtractLoader: string;
        pug: string;
        babel: string;
    };
    readonly rules: {
        pcss: RegExp;
        css: RegExp;
        img: RegExp;
        font: RegExp;
        svg: RegExp;
        pug: RegExp;
        docs: RegExp;
        code: RegExp;
    };
    readonly loaders: {
        expose: (exposes: any) => {
            loader: string;
            options: {
                exposes: any;
            };
        };
        pcss: {
            loader: string;
        };
        css: ({ isProduction }: {
            isProduction?: boolean;
        }) => {
            loader: string;
            options: {
                importLoaders: number;
                modules: {
                    localIdentName: string;
                    getLocalIdent: (context: any, localIdentName: any, localName?: string, options?: {}) => any;
                };
            };
        };
        rawCss: {
            loader: string;
        };
        svg: {
            loader: string;
            options: {
                svgo: boolean;
                svgoConfig: {
                    plugins: (string | {
                        name: string;
                        params: {
                            overrides: {
                                removeViewBox: boolean;
                                removeUselessDefs: boolean;
                                cleanupIds: {
                                    minify: boolean;
                                    remove: boolean;
                                };
                                collapseGroups: boolean;
                            };
                        };
                    })[];
                };
            };
            type: string;
            issuer: RegExp;
        };
        url: {
            options: {
                limit: number;
                name: string;
            };
            type: string;
        };
        cssExtract: ({ isServer, isHMR }: {
            isHMR?: boolean;
            isServer?: boolean;
        }) => {
            loader: string;
            options: {
                emit: boolean;
            };
        } | undefined;
        style: ({ isHMR }: {
            isHMR?: boolean;
        }) => {
            loader: string;
        } | undefined;
        pug: {
            loader: string;
        };
        resourceUrl: {
            resourceQuery: RegExp;
            type: string;
        };
        babel: {
            loader: string;
            options: {
                cacheDirectory: boolean;
                rootMode: string;
            };
            exclude: any;
        };
        asset: {
            type: string;
        };
    };
}>;
//# sourceMappingURL=react-toolkit.d.ts.map