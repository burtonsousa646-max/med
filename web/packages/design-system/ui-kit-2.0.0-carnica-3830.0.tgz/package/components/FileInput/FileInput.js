import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["label", "caption", "error", "className", "wrapperProps", "wrapperRef", "disabled", "id"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { ControlWrapper } from "../ControlWrapper";
import styles from "./styles.module.css";
import { FileInputField } from "./FileInputField";
var cnFileInput = cnBem('file-input', styles);
var FileInputRender = function FileInputRender(props, ref) {
  var label = props.label,
    caption = props.caption,
    error = props.error,
    className = props.className,
    wrapperProps = props.wrapperProps,
    wrapperRef = props.wrapperRef,
    disabled = props.disabled,
    id = props.id,
    otherProps = _objectWithoutProperties(props, _excluded);
  return /*#__PURE__*/React.createElement(ControlWrapper, _extends({}, wrapperProps, {
    caption: caption,
    captionProps: {
      id: id ? "".concat(id, "-caption") : undefined
    },
    className: cnFileInput(null, [className]),
    disabled: disabled,
    error: error,
    label: label,
    labelProps: {
      htmlFor: id,
      truncate: true,
      rows: 1
    },
    ref: wrapperRef,
    "data-t-id": "components-FileInput"
  }), /*#__PURE__*/React.createElement(FileInputField, _extends({
    "aria-describedby": id ? "".concat(id, "-caption") : undefined,
    "aria-label": "\u041E\u0431\u043B\u0430\u0441\u0442\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0444\u0430\u0439\u043B\u043E\u0432"
  }, otherProps, {
    disabled: disabled,
    id: id,
    ref: ref,
    "data-t-id": "components-FileInput"
  })));
};
export var FileInput = /*#__PURE__*/forwardRef(FileInputRender);