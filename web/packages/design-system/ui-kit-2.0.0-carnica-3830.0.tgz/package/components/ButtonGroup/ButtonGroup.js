import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "color", "items", "convertItem", "priority", "onItemClick", "invert", "disabled", "style"],
  _excluded2 = ["key", "attributes", "ref"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useCallback } from 'react';
import { cnBem } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withRenderCondition } from '@beef/react';
import { useConvertedItems } from "../../hooks/useConvertedItems";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { ButtonGroupItem } from "./ButtonGroupItem";
var cnButtonGroup = cnBem('button-group', styles);
var defaultConvertItem = function defaultConvertItem(item) {
  return item;
};
var ButtonGroupRender = function ButtonGroupRender(props, ref) {
  var className = props.className,
    _props$color = props.color,
    color = _props$color === void 0 ? 'on-bg-primary' : _props$color,
    itemsProp = props.items,
    _props$convertItem = props.convertItem,
    convertItem = _props$convertItem === void 0 ? defaultConvertItem : _props$convertItem,
    priority = props.priority,
    onItemClickProp = props.onItemClick,
    invert = props.invert,
    disabled = props.disabled,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  var items = useConvertedItems({
    items: itemsProp || [],
    convertItem: convertItem,
    withOriginal: true
  });
  var onItemClick = useCallback(function (item) {
    return function (e) {
      var _item$converted$onCli, _item$converted;
      if (item.converted.disabled || disabled) {
        return;
      }
      (_item$converted$onCli = (_item$converted = item.converted).onClick) === null || _item$converted$onCli === void 0 || _item$converted$onCli.call(_item$converted, e);
      onItemClickProp === null || onItemClickProp === void 0 || onItemClickProp(item.original, e);
    };
  }, [onItemClickProp, disabled]);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnButtonGroup({
      color: color,
      invert: invert
    }, [className]),
    ref: ref,
    role: "group",
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty(_defineProperty({}, '--button-group-items-count', items.length), '--button-group-bg', "var(--button-group-bg-".concat(color).concat(invert ? '-invert' : '', ")"))),
    "data-t-id": "components-ButtonGroup"
  }), items.map(function (item) {
    var _item$converted2 = item.converted,
      key = _item$converted2.key,
      attributes = _item$converted2.attributes,
      itemRef = _item$converted2.ref,
      params = _objectWithoutProperties(_item$converted2, _excluded2);
    return /*#__PURE__*/React.createElement(ButtonGroupItem, _extends({}, attributes, params, {
      disabled: params.disabled || disabled,
      invert: invert,
      key: key,
      onClick: onItemClick(item),
      priority: priority,
      ref: itemRef
    }));
  }));
};
export var ButtonGroup = compose(withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref) {
    var items = _ref.items;
    return !!(items !== null && items !== void 0 && items.length);
  }
}), forwardRef)(ButtonGroupRender);