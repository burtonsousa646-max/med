import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "portalProps", "portalClassName", "theme", "focusTrapParams", "portalRef", "children", "onClose", "anchorRef", "disableScroll", "ignoredClickOutsideRefs", "closeOptions"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { memo, useEffect } from 'react';
import { cnBem, forwardRefWithMotion } from '@carnica/utils';
import { AnimatePresence, motion } from 'framer-motion';
import { FocusTrap } from 'focus-trap-react';
import { useBlockScroll, useLowPerformanceDevice } from '@carnica/utils/hooks';
import styles from "./styles.module.css";
import { ThemedPortal } from '..';
import { BottomSheetWindow } from "./BottomSheetWindow";
var cnBottomSheet = cnBem('bottom-sheet', styles);
var BottomSheetRender = forwardRefWithMotion(function (props, ref) {
  var isOpen = props.isOpen,
    portalProps = props.portalProps,
    portalClassName = props.portalClassName,
    theme = props.theme,
    focusTrapParams = props.focusTrapParams,
    portalRef = props.portalRef,
    children = props.children,
    onClose = props.onClose,
    anchorRef = props.anchorRef,
    _props$disableScroll = props.disableScroll,
    disableScroll = _props$disableScroll === void 0 ? true : _props$disableScroll,
    _props$ignoredClickOu = props.ignoredClickOutsideRefs,
    ignoredClickOutsideRefs = _props$ignoredClickOu === void 0 ? [] : _props$ignoredClickOu,
    _props$closeOptions = props.closeOptions,
    closeOptions = _props$closeOptions === void 0 ? {
      button: true,
      overlay: true
    } : _props$closeOptions,
    otherProps = _objectWithoutProperties(props, _excluded);
  useBlockScroll(disableScroll && isOpen);
  var isLowPerformance = useLowPerformanceDevice();

  // Фокусируемся на элементе которое вызывало событие открытия окна
  useEffect(function () {
    return function () {
      var _anchorRef$current;
      return anchorRef === null || anchorRef === void 0 || (_anchorRef$current = anchorRef.current) === null || _anchorRef$current === void 0 ? void 0 : _anchorRef$current.focus();
    };
  }, []);
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait",
    onExitComplete: function onExitComplete() {
      return null;
    },
    "data-t-id": "modules-BottomSheet"
  }, isOpen && /*#__PURE__*/React.createElement(FocusTrap, _extends({
    active: isOpen
  }, focusTrapParams, {
    focusTrapOptions: _objectSpread({
      fallbackFocus: function fallbackFocus() {
        var _document;
        return (_document = document) === null || _document === void 0 ? void 0 : _document.body;
      },
      allowOutsideClick: true,
      preventScroll: true
    }, focusTrapParams === null || focusTrapParams === void 0 ? void 0 : focusTrapParams.focusTrapOptions)
  }), /*#__PURE__*/React.createElement(ThemedPortal, _extends({}, portalProps || {}, {
    "aria-modal": true,
    className: cnBottomSheet(null, [portalClassName]),
    motion: true,
    ref: portalRef,
    role: "dialog",
    theme: theme,
    "data-t-id": "modules-BottomSheet"
  }), /*#__PURE__*/React.createElement(motion.div, {
    animate: {
      opacity: 1
    },
    "aria-hidden": true,
    className: cnBottomSheet('overlay', {
      lowPerformance: isLowPerformance
    }),
    exit: {
      opacity: 0
    },
    initial: {
      opacity: 0
    }
  }), /*#__PURE__*/React.createElement(BottomSheetWindow, _extends({}, otherProps, {
    closeOptions: closeOptions,
    ignoredClickOutsideRefs: ignoredClickOutsideRefs,
    onClose: onClose,
    ref: ref,
    "data-t-id": "modules-BottomSheet"
  }), children))));
});
export var BottomSheet = /*#__PURE__*/memo(BottomSheetRender);