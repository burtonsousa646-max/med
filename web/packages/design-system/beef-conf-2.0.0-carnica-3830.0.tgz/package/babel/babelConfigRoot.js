/* eslint-disable react-hooks/rules-of-hooks */
const {
  configRootResolverSync
} = require('../utils/configResolvers');
const babelConfig = require('./babelConfig');
const {
  detectEnv,
  usePlugin,
  getLinkedModules
} = require('./babelHelpers');
const {
  scopeMatchedExcludes,
  scopeRegExpStr
} = require('../registry');
module.exports = cwd => function babelConfigRoot(api) {
  const {
    modules
  } = detectEnv(api);
  const {
    overrides,
    ...normalBabelConfig
  } = babelConfig(cwd)(api);
  const linkedModuleDirs = getLinkedModules(cwd);
  const isTest = process.env.BABEL_ENV === 'test' || process.env.NODE_ENV === 'test';
  const pckgModulesExcludes = new RegExp(`^(.*[/\\\\]node_modules[/\\\\](?!((${scopeRegExpStr})|debounce|throttleit|swiper|axios|date-fns-new|react-jsx-parser)[/\\\\][^/\\\\]+))`);
  return {
    /**
     * в качестве корня используем - конфиг где-то выше, если он есть, текущую папку,
     * а также все залинкованные пакеты
     */
    babelrcRoots: ['.', configRootResolverSync('babel.config.js', cwd),
    // Позволяет использовать через babel-watch запуск линкованных esm-модулей
    ...linkedModuleDirs.map(({
      link
    }) => link)].filter(Boolean),
    /** отключаем бабель за пределами наших пакетов */
    ignore: isTest ? [pckgModulesExcludes] : [scopeMatchedExcludes],
    /** переводим esm->cjs для jest (только для не линкованных пакетов) */
    overrides: [{
      exclude: linkedModuleDirs.map(({
        link
      }) => link),
      presets: [
      // Добавили для конвертации esm внутри beef в cjs при запуске jest
      usePlugin('@babel/preset-env', {
        modules
      })]
    }, {
      /** обрабатываем файлы проекта, актуально в проектах без монорепозитория */
      ...normalBabelConfig,
      exclude: [/node_modules/]
    }]
  };
};