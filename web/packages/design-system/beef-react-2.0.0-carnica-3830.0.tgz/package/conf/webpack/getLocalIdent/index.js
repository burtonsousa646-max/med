const loaderUtils = require('loader-utils');
const path = require('path');
const {
  allowedLeadingCharacters
} = require('./helpers');
const MAX_ATTEMPTS = 10;
const INITIAL_HASH_LENGTH = 5;
const DEFAULT_CSS_FILENAME = 'styles.pcss';

/**
 * https://www.w3.org/TR/CSS21/syndata.html
 *
 * @param {String} input
 * @returns String
 */
const replaceNonCSSCharacters = (input = '') => {
  const replaceWithAlphabet = match => {
    const charCode = match.charCodeAt(0);
    const index = charCode % allowedLeadingCharacters.length;
    return allowedLeadingCharacters[index];
  };
  return input.replace(/^./, replaceWithAlphabet) // Replace first symbol with alphabetic character
  .replace(/[^A-Za-z0-9-_]+/g, replaceWithAlphabet); // Replace non-css values;
};

// Храним данные о сгенерированных классах в контексте
// Контекст - это ссылка на модуль
// https://github.com/webpack-contrib/css-loader/blob/e27ab5ead47c6bcf8b218dbce52ddd692111e833/src/index.js#L58
// https://github.com/webpack/loader-runner
// в loader runner есть ссылка на _compilation объект,
// который хранит данные на протяжении одной компиляции (в отличие от _compiler)
// В контексте данные хранить не получится самом по себе, так как он сбрасывается для каждого модуля
const getClassNamesDictionaryFromContext = (context = {}) => {
  if (!context._compilation) {
    context._compilation = {};
  }
  if (!context._compilation.__beefClassNames__) {
    context._compilation.__beefClassNames__ = {};
  }
  const {
    __beefClassNames__: classNames
  } = context._compilation;
  return classNames;
};
const getRelativeResourcePath = context => path.posix.relative(context.rootContext, context.resourcePath);

/**
 * Генерирует значимое имя (название папки) вместо стандартного имени файла(styles.pcss)
 */
const getSmartName = filepath => path.basename(filepath) === DEFAULT_CSS_FILENAME ? '[folder]' : '[name]';

/**
 *
 * @param {string} pathName
 * @param {number} hashLength
 * @returns {string}
 */
const getSmartHash = (pathName, hashLength) => replaceNonCSSCharacters(loaderUtils.getHashDigest(pathName, 'md5', 'base64', hashLength));

/**
 * Вызываем `computeFn` `attempts` число раз, пока не результат не будет удовлетворять `checkFn`,
 *   иначе выкидываем ошибку
 * @param maxAttempts
 * @param computeFn
 * @param checkFn
 * @returns {*}
 */
const composeRetryGenerator = (maxAttempts, computeFn, checkFn) => {
  for (let attempts = 0; attempts < maxAttempts; attempts += 1) {
    const value = computeFn(attempts);
    if (checkFn(value)) return value;
  }
  throw new Error('Превышено число попыток');
};

// Проверяем, что имя хэша уникальное в пределах файла
const composeCheckUniqueFn = (classPathsStorage, options) => value => {
  if (classPathsStorage[value] && classPathsStorage[value] !== options.pathName) return false;
  classPathsStorage[value] = options.pathName;
  return true;
};

/**
 * Добавляет в стандартный localIdent два новых placeholder'а:
 * [smart-hash] - минимальный уникальный хэш заданной длины (hashLength)
 * [smart-name] - возвращает имя файла или папки, в зависимости от того стандартное ли имя файла
 *
 * Вероятность коллизии при длине хэша в 5 символов для 1000 css файлов ~ 0.05%
 * Вероятность коллизии случится при длине хэша в 5 символов для 10,000 css файлов ~ 5%
 * https://preshing.com/20110504/hash-collision-probabilities/
 * https://kevingal.com/apps/collision.html
 *
 * TODO: Если по определенному пути и localName уже есть сгенерированный хэш, то можно брать его,
 *   это ускорит генерацию ~в 2 раза (но нужно исключить attempt)
 */
const provideSmartGetLocalIdent = ({
  maxAttempts = MAX_ATTEMPTS,
  hashLength = INITIAL_HASH_LENGTH
} = {}) => (context, localIdentName, localName = '', options = {}) => {
  const relativeResourcePath = getRelativeResourcePath(context);
  const computeHashFn = attempt => getSmartHash(`${relativeResourcePath}:${localName}:${attempt}`, hashLength);
  const classPathsStorage = getClassNamesDictionaryFromContext(context);
  const checkUniqueFn = composeCheckUniqueFn(classPathsStorage, {
    pathName: `${relativeResourcePath}:${localName}`
  });
  try {
    localIdentName = localIdentName.replace(/\[local]/gi, localName).replace(/\[smart-name]/gi, () => getSmartName(context.resourcePath)).replace(/\[smart-hash]/gi, () => composeRetryGenerator(maxAttempts, computeHashFn, checkUniqueFn));
  } catch (err) {
    console.error(`Превышено максимальное число попsыток генерации уникального класса (${MAX_ATTEMPTS}).\n` + `Необходимо увеличить длину хэша 'hashLength(${hashLength})' ` + `или максимальное число попыток maxAttempts(${maxAttempts})`);
    process.exit(-1);
  }

  /**
   * Используем стандартный шаблон localIdentName
   */
  return loaderUtils.interpolateName(context, localIdentName, options);
};
module.exports = {
  provideSmartGetLocalIdent,
  replaceNonCSSCharacters
};