type PartOf<T> = {
    [K in keyof T]?: T[K];
};
type ConfigArgs<T> = [config: PartOf<T>, flag?: boolean];
type MultiConfigArgs<T> = [ConfigArgs<T>, ConfigArgs<T>, ...ConfigArgs<T>[]];
type MixedConfigArgs<T> = ConfigArgs<T> | MultiConfigArgs<T>;
type NoInfer<T> = [T][T extends any ? 0 : never];
export declare const useConfig: (<T>(...args: MixedConfigArgs<NoInfer<T>>) => T | undefined) & {
    replace: <T>(...args: MixedConfigArgs<NoInfer<T>>) => T | undefined;
};
export {};
//# sourceMappingURL=useConfig.d.ts.map