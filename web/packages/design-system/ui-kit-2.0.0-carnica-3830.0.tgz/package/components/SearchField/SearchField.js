import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["ariaLabel", "placeholder", "value", "name", "disabled", "onBlur", "onFocus", "onChange", "onKeyDown", "autoComplete", "autoFocus", "inputRef", "leftIcon", "className", "cancelButton", "onClear", "onCancel", "type", "size", "invert", "style", "color"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { useMemo } from 'react';
import { cnBem, combineRefs, forwardRefWithMotion } from '@carnica/utils';
import { IconCloseRoundStroked, IconSearchOutline } from '@carnica/graphics';
import { Button } from "../Button";
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { useClearButttonVisible } from "./hooks/useClearButttonVisible";
import { generateStyles } from "./utils";
export var cnSearchField = cnBem('search-field', styles);
var hasTruthy = function hasTruthy(option) {
  if (typeof option === 'boolean') {
    return option;
  }
  return Object.keys(option).some(function (key) {
    return option[key];
  });
};
export var SearchField = forwardRefWithMotion(function (props, ref) {
  var ariaLabel = props.ariaLabel,
    placeholder = props.placeholder,
    _props$value = props.value,
    value = _props$value === void 0 ? '' : _props$value,
    name = props.name,
    disabled = props.disabled,
    onBlur = props.onBlur,
    onFocus = props.onFocus,
    onChangeProp = props.onChange,
    onKeyDown = props.onKeyDown,
    _props$autoComplete = props.autoComplete,
    autoComplete = _props$autoComplete === void 0 ? 'off' : _props$autoComplete,
    _props$autoFocus = props.autoFocus,
    autoFocus = _props$autoFocus === void 0 ? false : _props$autoFocus,
    inputRefProp = props.inputRef,
    _props$leftIcon = props.leftIcon,
    Icon = _props$leftIcon === void 0 ? IconSearchOutline : _props$leftIcon,
    className = props.className,
    _props$cancelButton = props.cancelButton,
    cancelButton = _props$cancelButton === void 0 ? {
      showOnFocus: true
    } : _props$cancelButton,
    onClear = props.onClear,
    onCancel = props.onCancel,
    _props$type = props.type,
    type = _props$type === void 0 ? 'search' : _props$type,
    _props$size = props.size,
    size = _props$size === void 0 ? 's' : _props$size,
    invert = props.invert,
    style = props.style,
    _props$color = props.color,
    color = _props$color === void 0 ? 'default-on-bg-primary' : _props$color,
    otherProps = _objectWithoutProperties(props, _excluded);
  var showClearButton = !!onClear && !disabled && !!(value !== null && value !== void 0 && value.length);
  var _useClearButttonVisib = useClearButttonVisible({
      onBlur: onBlur,
      onFocus: onFocus,
      value: value,
      cancelButton: cancelButton
    }),
    isCancelButtonVisible = _useClearButttonVisib.isCancelButtonVisible,
    clearButtonRef = _useClearButttonVisib.clearButtonRef,
    cancelButtonRef = _useClearButttonVisib.cancelButtonRef,
    cancelButtonWidth = _useClearButttonVisib.cancelButtonWidth,
    inputRef = _useClearButttonVisib.inputRef,
    onFocusAction = _useClearButttonVisib.onFocusAction;
  var handleClear = function handleClear(e) {
    var _inputRef$current, _inputRef$current$foc;
    e.stopPropagation();
    onClear === null || onClear === void 0 || onClear('', e);
    (_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 || (_inputRef$current$foc = _inputRef$current.focus) === null || _inputRef$current$foc === void 0 || _inputRef$current$foc.call(_inputRef$current);
  };
  var onChange = function onChange(e) {
    return onChangeProp === null || onChangeProp === void 0 ? void 0 : onChangeProp(e.target.value, e);
  };
  var isCancelButtonAllowed = useMemo(function () {
    return !!onCancel && hasTruthy(cancelButton);
  }, [onCancel, cancelButton]);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnSearchField(null, [className]),
    ref: ref,
    style: _objectSpread(_objectSpread({}, generateStyles(color, invert)), style),
    "data-t-id": "components-SearchField"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnSearchField('wrapper', {
      collapsed: isCancelButtonVisible,
      size: size
    }),
    style: _defineProperty({}, '--search-field-cancel-width', "".concat(cancelButtonWidth, "px")),
    "data-t-id": "components-SearchField"
  }, /*#__PURE__*/React.createElement(Icon, {
    className: cnSearchField('icon'),
    color: invert ? 'tertiary-fake-invert' : 'tertiary',
    size: size
  }), /*#__PURE__*/React.createElement("input", {
    "aria-label": ariaLabel || placeholder || 'Поле поиска',
    autoComplete: autoComplete
    /* eslint-disable-next-line jsx-a11y/no-autofocus */,
    autoFocus: autoFocus,
    className: cnSearchField('input', {
      size: size
    }),
    disabled: disabled,
    name: "search-".concat(name || 'field'),
    onBlur: onFocusAction('blur'),
    onChange: onChange,
    onFocus: onFocusAction('focus'),
    onKeyDown: onKeyDown,
    placeholder: placeholder,
    ref: combineRefs([inputRefProp, inputRef]),
    type: type,
    value: value
  }), showClearButton && /*#__PURE__*/React.createElement(IconCloseRoundStroked, {
    "aria-label": "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443 \u043F\u043E\u0438\u0441\u043A\u0430",
    className: cnSearchField('close'),
    color: invert ? 'tertiary-fake-invert' : 'tertiary',
    onClick: handleClear,
    ref: clearButtonRef,
    size: size,
    tagName: "button",
    type: "button"
  })), isCancelButtonAllowed && /*#__PURE__*/React.createElement(Button, {
    className: cnSearchField('button', {
      visible: isCancelButtonVisible,
      invert: invert
    }),
    disabled: disabled,
    invert: invert,
    mode: "inline",
    onClick: onCancel,
    ref: cancelButtonRef
  }, "\u043E\u0442\u043C\u0435\u043D\u0430"));
});