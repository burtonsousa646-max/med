import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useCallback, useMemo } from 'react';
import { debounce } from '@beef/utils';
import { useSafeState } from "../useSafeState";
/**
 * Возвращает функцию, которая заставляет функциональный компонент перерендериться
 */
export var useForceUpdate = function useForceUpdate() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var _useSafeState = useSafeState(0),
    _useSafeState2 = _slicedToArray(_useSafeState, 2),
    setRnd = _useSafeState2[1];
  var forceUpdate = useCallback(function () {
    return setRnd(Math.random());
  }, [setRnd]);
  return useMemo(function () {
    if (typeof (options === null || options === void 0 ? void 0 : options.debounce) !== 'number') return forceUpdate;
    return debounce(forceUpdate, options.debounce);
  }, [options.debounce, forceUpdate]);
};