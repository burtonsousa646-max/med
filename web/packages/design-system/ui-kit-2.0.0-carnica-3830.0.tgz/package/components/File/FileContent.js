import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { IconCloseRoundStroked } from '@carnica/graphics';
import { cnBem } from '@carnica/utils';
import { Text } from "../Text";
import { Button } from "../Button";
import styles from "./styles.module.css";
import { getSubtitleColor } from "./utils";
import { FileTitle } from "./FileTitle";
var cnFile = cnBem('file', styles);
export var FileContent = function FileContent(_ref) {
  var Icon = _ref.icon,
    title = _ref.title,
    subtitle = _ref.subtitle,
    disabled = _ref.disabled,
    error = _ref.error,
    onRemove = _ref.onRemove,
    tagName = _ref.tagName;
  return /*#__PURE__*/React.createElement(React.Fragment, null, Icon && /*#__PURE__*/React.createElement(Icon, {
    className: cnFile('slot', {
      side: 'left'
    }),
    color: disabled ? 'disabled' : 'tertiary',
    size: "l",
    "data-t-id": "components-File"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnFile('slot', {
      side: 'center'
    })
  }, /*#__PURE__*/React.createElement(FileTitle, {
    disabled: disabled
  }, title), (subtitle || error) && /*#__PURE__*/React.createElement(Text, {
    color: getSubtitleColor(!!error, disabled),
    truncate: true,
    variant: "caption-medium"
  }, error || subtitle)), onRemove && /*#__PURE__*/React.createElement(Button, _extends({
    "aria-label": "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0444\u0430\u0439\u043B",
    className: cnFile('slot', {
      side: 'right'
    }),
    disabled: disabled,
    iconLeft: IconCloseRoundStroked,
    mode: "inline",
    onClick: onRemove,
    onlyIcon: true,
    view: "secondary"
  }, tagName === 'button' ? {
    tagName: 'div',
    role: 'button'
  } : {})));
};