import _extends from "@babel/runtime/helpers/extends";
import _toArray from "@babel/runtime/helpers/toArray";
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import React from 'react';
var _assocPath = function assocPath(object, _ref, value) {
  var _ref2 = _toArray(_ref),
    first = _ref2[0],
    path = _arrayLikeToArray(_ref2).slice(1);
  object[first] = path.length ? _assocPath(object[first] || {}, path, value) : value;
  return object;
};
var unwrapProps = function unwrapProps(props) {
  return Object.keys(props).reduce(function (accum, key) {
    _assocPath(accum, key.split('.'), props[key]);
    return accum;
  }, {});
};
export function withDotSeparatedProps(WrappedComponent, propTypes) {
  var WithWrappedProps = function WithWrappedProps(props) {
    return /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, unwrapProps(props), {
      "data-t-id": "src-enhancers"
    }));
  };
  WithWrappedProps.propTypes = process.env.NODE_ENV !== "production" ? propTypes : {};
  return WithWrappedProps;
}