import React from 'react';
export declare function getContextAtNode<C>(domNode: EventTarget | HTMLElement, Context: React.Context<C>): C;
export declare function findClosestFiberNodeMatch<T>(fiberNode: any, matcher: (fiberNode: any) => T): {
    fiberNode?: any;
    match?: T;
};
export declare function findClosestReactKeyMatching(domNode: Element, matcher: (key: string) => string | undefined): any;
export declare function findDOMParent(component: React.Component): Element;
//# sourceMappingURL=utils.d.ts.map