export function beforeRunHook({ emitCountMap, manifestFileName }: {
    emitCountMap: any;
    manifestFileName: any;
}, _: any, callback: any): void;
export function emitHook({ compiler, emitCountMap, manifestAssetId, manifestFileName, moduleAssets, options }: {
    compiler: any;
    emitCountMap: any;
    manifestAssetId: any;
    manifestFileName: any;
    moduleAssets: any;
    options: any;
}, compilation: any): void;
export function getCompilerHooks(compiler: any): any;
export function normalModuleLoaderHook({ moduleAssets }: {
    moduleAssets: any;
}, loaderContext: any, module: any): void;
//# sourceMappingURL=hooks.d.ts.map