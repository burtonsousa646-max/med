import { UseComponentSize } from './types';
export declare const useComponentSize: UseComponentSize;
//# sourceMappingURL=useComponentSize.d.ts.map