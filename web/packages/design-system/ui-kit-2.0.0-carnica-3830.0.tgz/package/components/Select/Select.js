import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "onChange", "getters", "notFoundLabel", "onListOpen", "loading", "className", "value", "renderValue", "multiple", "disabled", "invert", "convertItem", "id"];
import React, { forwardRef, useEffect, useRef } from 'react';
import { useDidUpdateEffect, useFlag } from '@carnica/utils/hooks';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { convertItemToDefault, dataConverter } from "./utils";
import { SelectField } from "./SelectField";
import { SelectList } from "./SelectList";
var SelectRender = function SelectRender(props, ref) {
  var items = props.items,
    onChange = props.onChange,
    getters = props.getters,
    notFoundLabel = props.notFoundLabel,
    onListOpen = props.onListOpen,
    loading = props.loading,
    className = props.className,
    value = props.value,
    renderValue = props.renderValue,
    multiple = props.multiple,
    disabled = props.disabled,
    invert = props.invert,
    convertItem = props.convertItem,
    id = props.id,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isOpen = _useFlag2[0],
    setIsOpen = _useFlag2[1];
  var wrapperRef = useRef(null);
  var toggleRef = useRef(null);
  useEffect(function () {
    if (disabled) {
      setIsOpen.off();
    }
  }, [disabled]);
  useDidUpdateEffect(function () {
    onListOpen === null || onListOpen === void 0 || onListOpen(isOpen);
  }, [isOpen]);
  var onClose = function onClose() {
    var _toggleRef$current;
    setIsOpen.off();
    (_toggleRef$current = toggleRef.current) === null || _toggleRef$current === void 0 || _toggleRef$current.focus();
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(SelectField, _extends({}, otherProps, {
    "aria-controls": id ? "".concat(id, "-list") : undefined,
    convertItem: convertItemToDefault(getters, convertItem),
    disabled: disabled,
    id: id,
    invert: invert,
    isOpen: isOpen,
    multiple: multiple,
    onClick: setIsOpen.toggle,
    ref: ref,
    renderValue: renderValue,
    toggleRef: toggleRef,
    value: value,
    wrapperRef: wrapperRef,
    "data-t-id": "components-Select"
  })), /*#__PURE__*/React.createElement(SelectList, {
    anchorRef: wrapperRef,
    convertItem: convertItem,
    getters: getters,
    id: id ? "".concat(id, "-list") : undefined,
    isOpen: isOpen,
    items: items,
    loading: loading,
    multiple: multiple,
    notFoundLabel: notFoundLabel,
    onChange: onChange,
    onClickOutside: onClose,
    onClose: onClose,
    value: value
  }));
};
export var Select = compose(withDataConverter(dataConverter), forwardRef)(SelectRender);