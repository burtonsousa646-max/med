export declare const addQueryParam: (urlStr: string, key: string, value: string) => null | string;
//# sourceMappingURL=navigation.d.ts.map