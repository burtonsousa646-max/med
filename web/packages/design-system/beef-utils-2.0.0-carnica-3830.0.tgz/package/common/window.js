export var setWindowFunctions = function setWindowFunctions(functions) {
  var keys = Object.keys(functions || {});
  if (typeof window === 'undefined' || !keys.length) {
    return;
  }
  keys.forEach(function (key) {
    if (!window[key]) window[key] = functions[key];
  });
};