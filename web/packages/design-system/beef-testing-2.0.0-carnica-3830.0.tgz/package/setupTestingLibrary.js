// Extend Jest "expect" functionality with Testing Library assertions.
require('@testing-library/jest-dom');