import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { inheritPropTypes } from "../extra";

/** forwardRef while keeping propTypes and defaultProps */
export var withForwardedRef = function withForwardedRef(WrappedComponent) {
  var Component = /*#__PURE__*/React.forwardRef(function (props, ref) {
    return /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, props, {
      forwardedRef: ref || /*#__PURE__*/React.createRef(),
      "data-t-id": "src-enhancers"
    }));
  });
  return inheritPropTypes(Component, WrappedComponent, {
    omit: ['forwardedRef']
  });
};