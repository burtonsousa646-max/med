import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["direction", "color"];
import React from 'react';
import { IconChevronLeft, IconChevronRight } from '@carnica/graphics';
import { Button } from "../../Button";
import { getButtonView } from "../utils";
export var PagePaginationNavigateButton = function PagePaginationNavigateButton(_ref) {
  var direction = _ref.direction,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'primary' : _ref$color,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var Icon = direction === 'prev' ? IconChevronLeft : IconChevronRight;
  return /*#__PURE__*/React.createElement(Button, _extends({
    "aria-label": "\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043D\u0430 ".concat(direction === 'prev' ? 'предыдущую' : 'следущую', " \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443"),
    "data-change-type": direction === 'prev' ? 'decrement' : 'increment',
    "data-item-type": "navigation",
    iconLeft: Icon,
    onlyIcon: true,
    size: "m",
    view: getButtonView(false, color)
  }, otherProps, {
    "data-t-id": "PagePagination-PagePaginationNavigateButton"
  }));
};