import { DefinePlugin, EnvironmentPlugin } from 'webpack';
/** @type BasePluginOptions & DefinedDefaultMinimizerAndOptions<MinimizerOptions<MinifyOptions>> */
import TerserPlugin from 'terser-webpack-plugin';
import CopyWebpackPlugin from 'copy-webpack-plugin';
import CircularDependencyPlugin from 'circular-dependency-plugin';
import { WebpackManifestPlugin } from 'webpack-manifest-plugin';
import { BeefManifestPlugin } from "../webpack/beefManifestPlugin";
import { BeefCacheBuildDependencyPlugin } from "../webpack/BeefCacheBuildDependencyPlugin";
import { extendPlugin } from "./extend-plugin";
import { scopeIncludes, scopeMatchedExcludes } from "../registry";
import { getCommitHash } from "../utils";

/**
 * Нужно для инференции типов
 */
export { BeefCacheBuildDependencyPlugin, BeefManifestPlugin };
export var baseToolkit = {
  _loaders: {
    babel: require.resolve('babel-loader')
  },
  rules: {
    code: /\.(js|ts)x?$/i
  },
  get loaders() {
    return {
      babel: {
        loader: this._loaders.babel,
        options: {
          cacheDirectory: true,
          rootMode: 'upward-optional'
        },
        exclude: this.options.monorepoExcludes
      },
      asset: {
        type: 'asset'
      }
    };
  },
  plugins: {
    CopyWebpackPlugin: CopyWebpackPlugin,
    CircularDependencyPlugin: extendPlugin(CircularDependencyPlugin, {
      failOnError: {
        cwd: process.cwd(),
        failOnError: true,
        exclude: /node_modules/
      },
      warnOnError: {
        cwd: process.cwd(),
        failOnError: false,
        exclude: /node_modules/
      }
    }),
    WebpackManifestPlugin: WebpackManifestPlugin,
    BeefManifestPlugin: BeefManifestPlugin,
    BeefCacheBuildDependencyPlugin: BeefCacheBuildDependencyPlugin,
    EnvironmentPlugin: EnvironmentPlugin,
    TerserPlugin: extendPlugin(TerserPlugin, {
      eraseComments: {
        extractComments: false,
        terserOptions: {
          format: {
            comments: false
          }
        }
      }
    }),
    DefinePlugin: DefinePlugin
  },
  get options() {
    var version = process.env.CI_COMMIT_SHORT_SHA || getCommitHash();
    return {
      /**
       * Wrapped in capture group for snapshot.managedPaths
       * See: https://webpack.js.org/configuration/other-options/#managedpaths
       */
      monorepoExcludes: scopeMatchedExcludes,
      /**
       * Обратная регулярка, проверяем, что пакеты являются внутренним кодом:
       * используется в @beef/node/conf
       */
      monorepoIncludes: scopeIncludes,
      version: version,
      // eslint-disable-next-line sonarjs/no-nested-template-literals
      filePattern: function filePattern(isProduction) {
        return "static/[name]".concat(isProduction ? ".".concat(version) : '');
      },
      cwd: process.cwd()
    };
  }
};