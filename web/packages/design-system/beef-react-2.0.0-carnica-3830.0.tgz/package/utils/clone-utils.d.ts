import React, { JSX } from 'react';
export declare const componentOnly: <T extends JSX.Element>(fn: (child: T) => any) => (child: T) => T;
export declare const cloneNthChildren: (children: any, depth: number, fn: (elements: any) => any) => React.ReactNode;
//# sourceMappingURL=clone-utils.d.ts.map