const composeConfigValidator = validator => fn => (...args) => {
  const error = validator(...args);
  if (error) {
    console.warn(error);
    process.exit(-1);
  }
  return fn(...args);
};
module.exports = {
  composeConfigValidator
};