import React from 'react';
export declare function populateZones<PKey extends string>(children: React.ReactNode, allowedNames: PKey[]): Record<PKey, React.ReactNode>;
//# sourceMappingURL=utils.d.ts.map