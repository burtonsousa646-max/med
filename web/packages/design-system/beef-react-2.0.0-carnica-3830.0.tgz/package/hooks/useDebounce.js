import { useCallback, useEffect, useRef } from 'react';

/** Функция получения хендлеров для отправки аналитики при клике по карточкам в поиске
 * @param fn {Function} - функция, срабатывание которой нужно ограничить
 * @param time {number} - время в миллисекундах, в течение которого вызовы функции не будут срабатывать
 * @returns {Function} - функцию с задержкой с типизацией оригинальной функции
 */
export var useDebounce = function useDebounce(fn, time) {
  var timeoutRef = useRef(null);
  var fnRef = useRef(fn);
  useEffect(function () {
    fnRef.current = fn;
  }, [fn]);
  useEffect(function () {
    return function () {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [time]);
  return useCallback(function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = window.setTimeout(function () {
      var _fnRef$current;
      timeoutRef.current = null;
      (_fnRef$current = fnRef.current) === null || _fnRef$current === void 0 || _fnRef$current.call.apply(_fnRef$current, [fnRef].concat(args));
    }, time);
  }, [time]);
};