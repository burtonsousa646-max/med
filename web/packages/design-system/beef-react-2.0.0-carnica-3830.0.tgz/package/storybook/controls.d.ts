import type { ArgTypes, Args, InputType } from '@storybook/core/types';
export declare const getPreparedArgs: <T>({ control, defaultValue, name, extraOptions, }: {
    control?: InputType["control"];
    defaultValue: T;
    extraOptions?: InputType;
    name?: string;
}) => {
    _type: T;
    argTypes: ArgTypes;
    args: Args;
};
export declare const select: <T>(name: string, options: T[] | readonly T[], defaultValue: T, extraOptions?: InputType) => {
    _type: T;
    argTypes: ArgTypes;
    args: Args;
};
export declare const multiSelect: <T>(name: string, options: T[] | readonly T[], defaultValue: T[], extraOptions?: InputType) => {
    _type: T[];
    argTypes: ArgTypes;
    args: Args;
};
export declare const radio: <T>(name: string, options: T[] | readonly T[], defaultValue: T, extraOptions?: InputType) => {
    _type: T;
    argTypes: ArgTypes;
    args: Args;
};
export declare const inlineRadio: <T>(name: string, options: T[] | readonly T[], defaultValue: T, extraOptions?: InputType) => {
    _type: T;
    argTypes: ArgTypes;
    args: Args;
};
export declare const check: <T>(name: string, options: T[] | readonly T[], defaultValue: T, extraOptions?: InputType) => {
    _type: T;
    argTypes: ArgTypes;
    args: Args;
};
export declare const inlineCheck: <T>(name: string, options: T[] | readonly T[], defaultValue: T, extraOptions?: InputType) => {
    _type: T;
    argTypes: ArgTypes;
    args: Args;
};
export declare const object: <T>(name: string, defaultValue: T, extraOptions?: InputType) => {
    _type: T;
    argTypes: ArgTypes;
    args: Args;
};
export declare const boolean: (name: string, defaultValue: boolean, extraOptions?: InputType) => {
    _type: boolean;
    argTypes: ArgTypes;
    args: Args;
};
export declare const number: (name: string, defaultValue: number, extraOptions?: InputType) => {
    _type: number;
    argTypes: ArgTypes;
    args: Args;
};
export declare const range: (name: string, defaultValue: number, extraOptions?: InputType) => {
    _type: number;
    argTypes: ArgTypes;
    args: Args;
};
export declare const text: (name: string, defaultValue: string, extraOptions?: InputType) => {
    _type: string;
    argTypes: ArgTypes;
    args: Args;
};
export declare const date: (name: string, defaultValue: Date, extraOptions?: InputType) => {
    _type: string;
    argTypes: ArgTypes;
    args: Args;
};
export declare const color: (name: string, defaultValue: string, extraOptions?: InputType) => {
    _type: string;
    argTypes: ArgTypes;
    args: Args;
};
//# sourceMappingURL=controls.d.ts.map