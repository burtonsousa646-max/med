import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "wrap", "size", "children"];
import React from 'react';
import { cnBem, forwardRefWithMotion } from '@carnica/utils';
import { MotionComponent } from "../../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnAvatarGroup = cnBem('avatar-group-core', styles);
export var AvatarGroupCore = forwardRefWithMotion(function (_ref, ref) {
  var className = _ref.className,
    wrap = _ref.wrap,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    children = _ref.children,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({
    className: cnAvatarGroup({
      wrap: wrap,
      size: size
    }, [className]),
    role: "group",
    tagName: "div"
  }, otherProps, {
    ref: ref,
    "data-t-id": "AvatarGroup-core"
  }), children);
});