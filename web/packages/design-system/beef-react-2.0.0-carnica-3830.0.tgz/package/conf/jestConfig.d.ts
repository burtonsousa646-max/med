declare function _exports(cwd: any, { setupFilesAfterEnv, ...customOptions }?: {
    setupFilesAfterEnv?: never[] | undefined;
}): {
    collectCoverageFrom: string[];
    coverageDirectory: string;
    coveragePathIgnorePatterns: string[];
    coverageReporters: string[];
    moduleFileExtensions: string[];
    moduleNameMapper: {
        '^@carnica/([^\\/]+)/(.*)$': string[];
        '^@beef/([^\\/]+)/(.*)$': string[];
        'swiper/react': string;
        'swiper/core': string;
        'swiper/css': string;
        'swiper/bundle': string;
        'swiper/types': string;
        '^swiper/css/([^\\/]+)/(.*)$': string;
    };
    reporters: (string | (string | {
        outputDirectory: string;
        outputName: string;
    })[])[];
    rootDir: string;
    setupFilesAfterEnv: any[];
    testEnvironment: string;
    testPathIgnorePatterns: string[];
    testRegex: any;
    transform: {
        '\\.(css|pcss|less|scss|sass|png|jpg|ttf|woff|woff2)$': string;
        '\\.(js|ts|jsx|tsx|mjs)$': (string | {
            rootMode: string;
        })[];
        '\\.svg$': string;
    };
    transformIgnorePatterns: string[];
};
export = _exports;
//# sourceMappingURL=jestConfig.d.ts.map