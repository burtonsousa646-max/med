import React from 'react';
export type TagTypes = keyof React.JSX.IntrinsicElements;
export type TagAttributes = React.JSX.IntrinsicElements[TagTypes];
export type TagTypeAttributes<T extends TagTypes> = React.JSX.IntrinsicElements[T];
export type MotionTags = keyof Omit<React.JSX.IntrinsicElements, 'slot' | 'template'> & keyof HTMLElementTagNameMap;
type HtmlTag = keyof HTMLElementTagNameMap;
export type ElementFromTag<Tag extends string> = Tag extends HtmlTag ? HTMLElementTagNameMap[Tag] : HTMLElement;
export {};
//# sourceMappingURL=TagType.d.ts.map