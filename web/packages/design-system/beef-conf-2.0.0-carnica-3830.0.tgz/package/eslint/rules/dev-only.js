module.exports = {
  rules: {
    // devDependencies are totally alright for storybook & tests
    'import/no-extraneous-dependencies': 0,
    // it is okay to use console.log for stories and tests
    'no-console': 0,
    // propType definition in mock components is also an overkill
    'react/prop-types': 0
  }
};