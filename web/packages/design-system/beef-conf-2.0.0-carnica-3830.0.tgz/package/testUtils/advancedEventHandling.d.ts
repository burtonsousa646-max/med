export function injectEventHandling(testNode: any): void;
//# sourceMappingURL=advancedEventHandling.d.ts.map