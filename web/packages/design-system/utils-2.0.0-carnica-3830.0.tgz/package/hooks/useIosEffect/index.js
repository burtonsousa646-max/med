import { useEffect } from 'react';
import { getMobileOS } from '@beef/utils';
export var useIosEffect = function useIosEffect(effect) {
  var deps = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  // eslint-disable-next-line consistent-return
  useEffect(function () {
    if (getMobileOS() === 'ios') {
      return effect();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
};