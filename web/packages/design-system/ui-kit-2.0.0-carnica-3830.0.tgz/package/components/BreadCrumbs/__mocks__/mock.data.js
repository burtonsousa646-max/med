export var items = [{
  label: 'хлебная крошка 1',
  href: '/1'
}, {
  label: 'хлебная крошка 2',
  href: '/2'
}, {
  label: 'хлебная крошка 3',
  href: '/3'
}, {
  label: 'хлебная крошка 4',
  href: '/4'
}];