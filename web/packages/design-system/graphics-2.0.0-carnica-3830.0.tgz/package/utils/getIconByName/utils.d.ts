import type { IconComponentNames } from '../../types/iconNames';
import type { DefineUrlIconParams } from '../defineUrlIcon';
export declare const iconsSpecificSettings: Partial<Record<IconComponentNames, Pick<DefineUrlIconParams, 'defaultSize' | 'ratio'>>>;
export declare const iconNamesMap: Partial<Record<IconComponentNames, string>>;
//# sourceMappingURL=utils.d.ts.map