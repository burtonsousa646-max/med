import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _typeof from "@babel/runtime/helpers/typeof";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
var _excluded = ["text"],
  _excluded2 = ["color", "disabled", "style", "image", "icon", "label", "logo", "badge", "view", "size"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var getColors = function getColors() {
  var colorSettings = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'default-on-bg-primary';
  var disabled = arguments.length > 1 ? arguments[1] : undefined;
  var color = typeof colorSettings === 'string' ? colorSettings : 'default-on-bg-primary';
  var colors = {
    '--avatar-bg': "var(--avatar-v5-bg-".concat(color, ")"),
    '--avatar-icon': "var(--avatar-v5-icon-".concat(color, ")"),
    '--avatar-color': "var(--avatar-v5-color-".concat(color, ")"),
    '--avatar-accent-color': 'var(--avatar-v5-accent-icon-color)'
  };
  if (disabled) {
    return Object.fromEntries(Object.entries(colors).map(function (_ref) {
      var _ref2 = _slicedToArray(_ref, 2),
        key = _ref2[0],
        variable = _ref2[1];
      return [key, "".concat(variable.slice(0, -1), "-disabled)")];
    }));
  }
  if (_typeof(colorSettings) === 'object') {
    colors['--avatar-bg'] = colorSettings.bg || colors['--avatar-bg'];
    colors['--avatar-color'] = colorSettings.content || colors['--avatar-color'];
    colors['--avatar-icon'] = colorSettings.content || colors['--avatar-icon'];
    colors['--avatar-accent-color'] = colorSettings.accent || colors['--avatar-accent-color'];
  }
  return colors;
};
var isIconComponent = function isIconComponent(component) {
  if (_typeof(component) === 'object') {
    var keys = Object.keys(component);
    return keys.includes('render') && !keys.includes('props');
  }
  return typeof component === 'function';
};
var decomposeBadge = function decomposeBadge(badge) {
  if (typeof badge === 'undefined' || badge === null) {
    return undefined;
  }
  if (typeof badge === 'string') {
    return {
      children: badge,
      view: 'text',
      color: 'accent'
    };
  }
  if (typeof badge === 'boolean') {
    return {
      view: 'dot'
    };
  }
  if (isIconComponent(badge)) {
    return {
      view: 'icon',
      color: 'accent',
      icon: badge
    };
  }
  var text = badge.text,
    params = _objectWithoutProperties(badge, _excluded);
  return _objectSpread(_objectSpread({}, params), {}, {
    children: text
  });
};
var detectView = function detectView(props) {
  if (props.image) {
    return 'image';
  }
  if (props.logo) {
    return 'logo';
  }
  if (props.icon) {
    return 'icon';
  }
  return 'text';
};
export var dataConverter = function dataConverter(props) {
  var _props$color = props.color,
    color = _props$color === void 0 ? 'default-on-bg-primary' : _props$color,
    disabled = props.disabled,
    style = props.style,
    image = props.image,
    icon = props.icon,
    label = props.label,
    logo = props.logo,
    badge = props.badge,
    viewProp = props.view,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    otherProps = _objectWithoutProperties(props, _excluded2);
  var view = viewProp || detectView(props);
  return _objectSpread({
    style: _objectSpread(_objectSpread({}, getColors(color, disabled)), style),
    size: size,
    view: view,
    contentParams: {
      icon: icon,
      label: label,
      logo: logo,
      image: image,
      size: size,
      view: view
    },
    badge: decomposeBadge(badge),
    disabled: disabled
  }, otherProps);
};