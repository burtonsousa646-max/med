import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { debounce } from "./timed-functions";
var createArrayBouncer = function createArrayBouncer(arr) {
  return function (item) {
    var allowPush = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    if (allowPush) {
      arr.push(item);
    }
  };
};
export var getCookie = function getCookie(name) {
  if (typeof window === 'undefined') return undefined;
  var matches = document.cookie.match(new RegExp("(?:^|; )".concat(name.replace(/([.$?*|{}()[]\\\/+^])/g, '\\$1'), "=([^;]*)")));
  return matches ? decodeURIComponent(matches[1]) : undefined;
};
export var setCookie = function setCookie(_ref) {
  var domain = _ref.domain,
    maxAge = _ref.maxAge,
    name = _ref.name,
    _ref$path = _ref.path,
    path = _ref$path === void 0 ? '/' : _ref$path,
    _ref$sameSite = _ref.sameSite,
    sameSite = _ref$sameSite === void 0 ? 'lax' : _ref$sameSite,
    _ref$secure = _ref.secure,
    secure = _ref$secure === void 0 ? true : _ref$secure,
    ttl = _ref.ttl,
    _ref$value = _ref.value,
    value = _ref$value === void 0 ? '' : _ref$value;
  if (typeof window !== 'undefined') {
    var _ttl = Number(ttl);
    var _maxAge = Number(maxAge);
    var freshlyBakedCookie = ["".concat(name, "=").concat(value)];
    var cookiePropsBouncer = createArrayBouncer(freshlyBakedCookie);
    cookiePropsBouncer("domain=".concat(domain), Boolean(domain));
    cookiePropsBouncer("path=".concat(path), Boolean(path));
    cookiePropsBouncer("expires=".concat(new Date(new Date().getTime() + _ttl).toUTCString()), !Number.isNaN(_ttl));
    cookiePropsBouncer("max-age=".concat(_maxAge), !Number.isNaN(_maxAge));
    cookiePropsBouncer('secure', secure);
    cookiePropsBouncer("samesite=".concat(sameSite), Boolean(sameSite));
    document.cookie = freshlyBakedCookie.join(';');
  }
};
export var deleteCookie = function deleteCookie(name, props) {
  setCookie(_objectSpread(_objectSpread({}, props), {}, {
    name: name,
    value: '',
    maxAge: -1
  }));
};
var setCookieDebounced = debounce(setCookie);

/**
 * Комбинация getCookie & setCookie, читает куку и обновляет ее время жизни
 * value - задает значение по умолчанию, может быть функцией
 */
export var refreshCookie = function refreshCookie(cookie) {
  var value = getCookie(cookie.name);
  if (typeof value === 'undefined') {
    value = typeof cookie.value === 'function' ? cookie.value() : cookie.value;
    setCookie(_objectSpread(_objectSpread({}, cookie), {}, {
      value: value
    }));
  } else {
    setCookieDebounced(_objectSpread(_objectSpread({}, cookie), {}, {
      value: value
    }));
  }
  return value;
};
export var getRootCookieDomain = function getRootCookieDomain() {
  var path = window.location.hostname.split('.');
  return "".concat(path.length > 2 ? '.' : '').concat(path.slice(-2).join('.'));
};