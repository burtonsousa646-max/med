/**
 * given set of rules should be applied when --fix option is passed,
 * to prevent broken autofix rules
 */
module.exports = {
  rules: {
    // autofix works, but it puts if on same line as closing bracket
    // `} else if (...)` { is converted to `} if () {`
    'no-else-return': 0,
    // Replaces `function Component...` with `var Component...`
    'react/function-component-definition': 0,
    // completely broken fix rule, creates syntax error by replacing `render = () => {}` with `render() { )`
    'react/no-arrow-function-lifecycle': 0
  }
};