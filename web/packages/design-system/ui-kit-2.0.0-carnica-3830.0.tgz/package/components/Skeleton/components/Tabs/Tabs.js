import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["size", "length", "invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnTabs = cnBem('skeleton-tabs', styles);
export var Tabs = function Tabs(_ref) {
  var _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    _ref$length = _ref.length,
    length = _ref$length === void 0 ? 5 : _ref$length,
    invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnTabs({
      size: size
    }, [className])
  }, props, {
    "data-t-id": "components-Tabs"
  }), Array.from({
    length: length
  }).map(function (_, i) {
    return /*#__PURE__*/React.createElement(SkeletonBrick, {
      color: color,
      height: size === 'm' ? 26 : 20,
      invert: invert,
      key: cnTabs('item', {
        i: i
      }),
      width: size === 'm' ? 65 : 60
    });
  }));
};