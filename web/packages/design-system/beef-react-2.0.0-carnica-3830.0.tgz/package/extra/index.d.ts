export { ignoreState } from './ignoreState';
export { inheritPropTypes } from './inheritPropTypes';
//# sourceMappingURL=index.d.ts.map