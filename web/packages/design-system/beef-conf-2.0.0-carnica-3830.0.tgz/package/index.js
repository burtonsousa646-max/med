const {
  isCI
} = require('./utils');
const requireLintStagedConf = isCI ? require('./lintstaged/ci-lintstagedrc') : require('./lintstaged/lintstagedrc');
module.exports = {
  BeefManifestPlugin: require('./webpack/beefManifestPlugin'),
  WebpackFactory: require('./webpack/WebpackFactory'),
  babelConfig: require('./babel/babelConfig'),
  babelConfigRoot: require('./babel/babelConfigRoot'),
  eslintrc: require('./eslint/hybrid.config'),
  lintstagedrc: requireLintStagedConf,
  prettierrc: require('./prettier/prettierrc'),
  resolveWebpackConfig: require('./webpack/resolveConfig'),
  stylelintrc: require('./stylelint/stylelintConfig.json'),
  utils: require('./utils')
};