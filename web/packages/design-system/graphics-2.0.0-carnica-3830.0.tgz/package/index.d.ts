export * from './components/AnimatedIcon';
export * from './components/AnimatedIconProvider';
export * from './components/BaseIcon';
export * from './components/Icon';
export * from './flags';
export * from './logos';
export * from './icons';
export * from './utils/defineAnimatedIcon';
export * from './utils/defineUrlIcon';
export * from './utils/getIconByName';
//# sourceMappingURL=index.d.ts.map