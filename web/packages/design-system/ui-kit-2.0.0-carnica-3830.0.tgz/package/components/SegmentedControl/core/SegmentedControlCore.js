import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["invert", "activeIndex", "disabledIndexes", "disabled", "itemsCount", "className", "style"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithMotion } from '@carnica/utils';
import React from 'react';
import { usePrevious } from '@beef/react';
import { MotionComponent } from "../../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnSegmentedControlCore = cnBem('segmented-control-core', styles);
export var SegmentedControlCore = forwardRefWithMotion(function (props, ref) {
  var invert = props.invert,
    _props$activeIndex = props.activeIndex,
    activeIndex = _props$activeIndex === void 0 ? -1 : _props$activeIndex,
    disabledIndexes = props.disabledIndexes,
    disabled = props.disabled,
    _props$itemsCount = props.itemsCount,
    itemsCount = _props$itemsCount === void 0 ? 0 : _props$itemsCount,
    className = props.className,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  var previousActiveIndex = usePrevious(activeIndex);
  var isActiveElementAreDisabled = disabled || (disabledIndexes === null || disabledIndexes === void 0 ? void 0 : disabledIndexes.includes(activeIndex));
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    "aria-label": "\u041F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u043E\u0442\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0442\u0435\u043D\u0442\u0430",
    className: cnSegmentedControlCore({
      invert: invert,
      withPointer: activeIndex >= 0,
      pointerMovable: previousActiveIndex !== -1 && activeIndex !== -1,
      isActiveElementAreDisabled: isActiveElementAreDisabled
    }, [className]),
    ref: ref,
    role: "listbox",
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty(_defineProperty({}, '--segmented-control-active', "".concat(activeIndex !== -1 ? activeIndex : previousActiveIndex)), '--segmented-control-count', "".concat(itemsCount))),
    "data-t-id": "SegmentedControl-core"
  }));
});