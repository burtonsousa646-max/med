import _typeof from "@babel/runtime/helpers/typeof";
import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
export var AdvancedLogger = /*#__PURE__*/function () {
  function AdvancedLogger() {
    _classCallCheck(this, AdvancedLogger);
    _defineProperty(this, "logs", new Set());
  }
  return _createClass(AdvancedLogger, [{
    key: "uniqueKey",
    value: function uniqueKey(payload, uuid) {
      if (uuid) return uuid;
      if (payload && _typeof(payload) === 'object') return JSON.stringify(payload);
      return payload;
    }
  }, {
    key: "warnOnce",
    value: function warnOnce(payload, uuid) {
      var key = this.uniqueKey(payload, uuid);
      if (this.logs.has(key)) return;
      this.logs.add(key);
      console.warn(payload);
    }
  }, {
    key: "errorOnce",
    value: function errorOnce(payload, uuid) {
      var key = this.uniqueKey(payload, uuid);
      if (this.logs.has(key)) return;
      this.logs.add(key);
      throw new Error(payload);
    }
  }]);
}();