import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["placeholder", "onPaste"];
import React, { forwardRef } from 'react';
import { Input } from "../../Input";
import { withMaskedInput } from "../../../hocs/withMaskedInput";
var params = {
  mask: '+7 000 000 00 00',
  prepare: function prepare(appended, masked) {
    // Убираем пробелы из вставляемого символа
    var char = appended.trim();
    if (masked.value !== '') {
      return char;
    }
    if (char === '') {
      return '';
    }
    if (char === '8' || char === '7') {
      return '7';
    }
    return char;
  }
};
var Phone = withMaskedInput(params, 'tel')(Input);
export var PhoneInput = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var _ref$placeholder = _ref.placeholder,
    placeholder = _ref$placeholder === void 0 ? '+7' : _ref$placeholder,
    onPaste = _ref.onPaste,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var handlePaste = function handlePaste(e) {
    if (e.clipboardData.getData('text').replace(/\D/g, '').length !== 11) {
      onPaste === null || onPaste === void 0 || onPaste(e);
      return;
    }
    e.preventDefault();
    var pasted = e.clipboardData.getData('text');
    // Оставляем только цифры
    var digits = pasted.replace(/\D/g, '');
    // Нормализуем: если начинается с 8 или 7 — убираем первую цифру, оставляем остаток
    var normalized = digits.startsWith('8') || digits.startsWith('7') ? digits.slice(1) : digits;

    // Программно вставляем нормализованное значение
    var input = e.target;
    if (input) {
      var _Object$getOwnPropert;
      // eslint-disable-next-line @typescript-eslint/unbound-method
      var nativeInputValueSetter = (_Object$getOwnPropert = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')) === null || _Object$getOwnPropert === void 0 ? void 0 : _Object$getOwnPropert.set;
      nativeInputValueSetter === null || nativeInputValueSetter === void 0 || nativeInputValueSetter.call(input, normalized);
      input.dispatchEvent(new Event('input', {
        bubbles: true
      }));
    }
    onPaste === null || onPaste === void 0 || onPaste(e);
  };
  return /*#__PURE__*/React.createElement(Phone, _extends({}, otherProps, {
    onPaste: handlePaste,
    placeholder: placeholder,
    ref: ref,
    "data-t-id": "AdvancedInputs-PhoneInput"
  }));
});