import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["groups", "setActiveGroup", "value", "filteredItemsMap", "onChangeGroup", "activeGroup", "isMobile", "className"];
import React, { useCallback, useRef } from 'react';
import { cnBem } from '@carnica/utils';
import { useDragScroll } from '@carnica/utils/hooks';
import { Tabs } from "../../Tabs";
import { useScrollDeviceDetect } from "../../../hooks/useScrollDeviceDetect";
import styles from "./styles.module.css";
import { usePickerContext } from "../PickerContext";
var cnPickerFilters = cnBem('picker-filters', styles);
var getItemAttributes = function getItemAttributes() {
  return {
    className: cnPickerFilters('tab-item')
  };
};
export var PickerTabs = function PickerTabs(_ref) {
  var groups = _ref.groups,
    setActiveGroup = _ref.setActiveGroup,
    value = _ref.value,
    filteredItemsMap = _ref.filteredItemsMap,
    onChangeGroup = _ref.onChangeGroup,
    activeGroup = _ref.activeGroup,
    isMobile = _ref.isMobile,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var tabsRef = useRef(null);
  var _usePickerContext = usePickerContext(),
    setSelectedIndex = _usePickerContext.setSelectedIndex;
  var scrollDevice = useScrollDeviceDetect();
  // Выключаем скролл по нажатию для устройств без мыши, так как там в этом нет необходимости (на мобилках и так работает, а на тачпаде есть горизонтальный скролл)
  useDragScroll(tabsRef, 'horizontal', scrollDevice === 'mouse');
  var handleChangeGroup = useCallback(function (group, e) {
    onChangeGroup === null || onChangeGroup === void 0 || onChangeGroup(group.group, e);
    setActiveGroup(group);
    setSelectedIndex(value ? filteredItemsMap[group.key].findIndex(function (el) {
      return el.converted.key === value.key;
    }) || 0 : 0);
  }, [onChangeGroup, filteredItemsMap]);
  return /*#__PURE__*/React.createElement(Tabs, _extends({}, otherProps, {
    activeTab: activeGroup,
    className: cnPickerFilters('tabs', [className]),
    getItemAttributes: getItemAttributes,
    items: groups,
    onChange: handleChangeGroup,
    ref: tabsRef,
    size: isMobile ? 's' : 'm',
    "data-t-id": "Picker-PickerFilters"
  }));
};