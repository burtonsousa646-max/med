import React from 'react';
import type { ReactProps } from '../types';
import type { ErrorBoundaryProps } from '../components';
export declare function withErrorBoundary<T extends ReactProps>(boundaryProps?: Omit<ErrorBoundaryProps, 'children'>): (WrappedComponent: React.ComponentType<T>) => (props: T) => React.JSX.Element;
//# sourceMappingURL=withErrorBoundary.d.ts.map