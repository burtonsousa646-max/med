declare const requireLintStagedConf: {
    '!({package,tsconfig}.json)*.{js,jsx,ts,tsx,json}': string;
    '*.{ts,tsx}': string;
    '*.md': string;
    '*.pcss': string;
};
export declare let BeefManifestPlugin: typeof import("./webpack/beefManifestPlugin");
export declare let WebpackFactory: typeof import("./webpack/WebpackFactory");
export declare let babelConfig: (configDir: any, custom?: {}) => (api: any) => {
    presets: (false | any[])[];
    plugins: (false | any[])[];
    ignore: any[];
    overrides: {
        test: RegExp;
        sourceType: string;
    }[];
};
export declare let babelConfigRoot: (cwd: any) => (api: any) => {
    babelrcRoots: any[];
    ignore: RegExp[];
    overrides: ({
        exclude: any[];
        presets: (false | any[])[];
    } | {
        exclude: RegExp[];
        presets: (false | any[])[];
        plugins: (false | any[])[];
        ignore: any[];
    })[];
};
export declare let eslintrc: {
    overrides: ({
        overrides: ({
            extends: any[];
            rules: {};
            files: string[];
        } | {
            extends: any[];
            files: string[];
        })[];
        plugins: string[];
        parser: string;
        extends: any[];
        files: string[];
    } | {
        overrides: ({
            extends: any[];
            rules: {};
            files: string[];
        } | {
            extends: any[];
            files: string[];
        })[];
        parser: string;
        extends: any[];
        files: string[];
    } | {
        extends: string[];
        parser: string;
        rules: {
            'jsonc/sort-keys': (string | {
                allowLineSeparatedGroups: boolean;
                caseSensitive: boolean;
                minKeys: number;
                natural: boolean;
            })[];
            'no-irregular-whitespace': string;
        };
        files: string[];
    })[];
    root: boolean;
    plugins: string[];
    env: {
        browser: boolean;
        jest: boolean;
        node: boolean;
        es2020: boolean;
    };
    settings: {
        'import/cache': {
            lifetime: string;
        };
        'import/extensions': string[];
        'import/resolver': {
            'babel-module': {
                babelOptions: {
                    rootMode: string;
                };
            };
            node: {};
            exports: {};
        };
    };
    ignorePatterns: string[];
};
export { requireLintStagedConf as lintstagedrc };
export declare let prettierrc: {
    arrowParens: string;
    bracketSameLine: boolean;
    bracketSpacing: boolean;
    embeddedLanguageFormatting: string;
    experimentalTernaries: boolean;
    jsxSingleQuote: boolean;
    printWidth: number;
    quoteProps: string;
    semi: boolean;
    singleAttributePerLine: boolean;
    singleQuote: boolean;
    tabWidth: number;
    trailingComma: string;
    useTabs: boolean;
};
export declare let resolveWebpackConfig: (cwd?: string) => any;
export declare let stylelintrc: {
    extends: string[];
    plugins: string[];
    rules: {
        "at-rule-no-unknown": (boolean | {
            ignoreAtRules: string[];
        })[];
        "block-no-empty": boolean;
        "color-named": string;
        "custom-property-empty-line-before": string;
        "custom-property-pattern": null;
        "declaration-block-semicolon-newline-before": string;
        "declaration-empty-line-before": null;
        "font-family-name-quotes": string;
        "font-weight-notation": string;
        "function-no-unknown": (boolean | {
            ignoreFunctions: string[];
        })[];
        "function-url-no-scheme-relative": boolean;
        "function-url-quotes": string;
        "import-notation": string;
        "max-empty-lines": number;
        "max-line-length": number;
        "no-duplicate-selectors": boolean;
        "no-empty-source": boolean;
        "number-leading-zero": string;
        "order/order": (string | {
            name: string;
            type: string;
        })[];
        "order/properties-order": {
            noEmptyLineBetween: boolean;
            properties: string[];
        }[];
        "prettier/prettier": (boolean | {
            singleQuote: boolean;
        })[];
        "selector-attribute-quotes": string;
        "selector-class-pattern": string;
        "selector-list-comma-newline-before": string;
        "selector-list-comma-space-after": string;
        "selector-list-comma-space-before": string;
        "selector-max-attribute": number;
        "selector-max-class": number;
        "selector-max-combinators": number;
        "selector-max-compound-selectors": number;
        "selector-max-empty-lines": number;
        "selector-max-id": number;
        "selector-max-type": number;
        "selector-max-universal": number;
        "string-quotes": string;
    };
};
export declare let utils: typeof import("./utils");
//# sourceMappingURL=index.d.ts.map