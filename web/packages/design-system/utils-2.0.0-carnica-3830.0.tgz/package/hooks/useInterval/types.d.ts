import React from 'react';
type UseIntervalParams = {
    onCancel?: VoidFunction;
    onCreate?: VoidFunction;
    onReached?: VoidFunction;
};
type UseIntervalResult = {
    cancelInterval: VoidFunction;
    createInterval: VoidFunction;
    intervalRef: React.RefObject<number | undefined>;
};
export type UseInterval = (interval: number, options?: UseIntervalParams) => UseIntervalResult;
export {};
//# sourceMappingURL=types.d.ts.map