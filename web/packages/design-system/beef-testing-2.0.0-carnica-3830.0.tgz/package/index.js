import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import { setupServer } from 'old-msw/node';
import { convertRoutesToMswHandlers } from "./converter";
import { MockResizeObserver } from "./__mocks__/mockResizeObserver";
import { MockIntersectionObserver } from "./__mocks__/mockIntersectionObserver";
import { mockLottie } from "./__mocks__/mockLottie";
export { convertRoutesToMswHandlers };
var ROUTES_PATH = './server/routes';
var OVERRIDES_PATH = './server/overrides';
export var MockServer = /*#__PURE__*/function () {
  function MockServer() {
    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref$routesPath = _ref.routesPath,
      routesPath = _ref$routesPath === void 0 ? ROUTES_PATH : _ref$routesPath,
      _ref$overridesPath = _ref.overridesPath,
      overridesPath = _ref$overridesPath === void 0 ? OVERRIDES_PATH : _ref$overridesPath,
      options = _ref.options;
    _classCallCheck(this, MockServer);
    _defineProperty(this, "server", void 0);
    _defineProperty(this, "options", void 0);
    _defineProperty(this, "overridesPath", void 0);
    this.overridesPath = overridesPath;
    this.server = setupServer.apply(void 0, _toConsumableArray(convertRoutesToMswHandlers(routesPath)));
    this.options = options;
  }
  return _createClass(MockServer, [{
    key: "composeOverridesPath",
    value: function composeOverridesPath(overridePath) {
      return "".concat(this.overridesPath, "/").concat(overridePath);
    }
  }, {
    key: "listen",
    value: function listen() {
      this.server.listen(this.options);
    }
  }, {
    key: "close",
    value: function close() {
      this.server.close();
    }
  }, {
    key: "reset",
    value: function reset() {
      this.server.resetHandlers();
    }
  }, {
    key: "override",
    value: function override() {
      var _this = this,
        _this$server;
      for (var _len = arguments.length, overridePaths = new Array(_len), _key = 0; _key < _len; _key++) {
        overridePaths[_key] = arguments[_key];
      }
      var handlers = overridePaths.map(function (overridePath) {
        return convertRoutesToMswHandlers(_this.composeOverridesPath(overridePath));
      }).flat();
      (_this$server = this.server).use.apply(_this$server, _toConsumableArray(handlers));
    }
  }]);
}();
export var server = new MockServer({
  options: {
    onUnhandledRequest: 'warn'
  }
});
export { MockResizeObserver };
export { MockIntersectionObserver };
export { mockLottie };