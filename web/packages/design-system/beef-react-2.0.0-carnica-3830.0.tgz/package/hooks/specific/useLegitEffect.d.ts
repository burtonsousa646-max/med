import React from 'react';
export declare function useLegitEffect(fn: () => (() => void) | undefined, dependencies: React.DependencyList, options: {
    useLayoutEffect?: boolean;
}): void;
//# sourceMappingURL=useLegitEffect.d.ts.map