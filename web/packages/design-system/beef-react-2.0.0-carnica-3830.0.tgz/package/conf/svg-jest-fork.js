/* TODO: this is a fork from https://www.npmjs.com/package/svg-jest to fix svg parsing error in jest */
const path = require('path');
function buildModule(functionName, pathname, filename) {
  return `
    const React = require('react');

    const ${functionName} = (props) => {
          return React.createElement('svg', {
            ...props,
          'data-jest-file-name': '${pathname}',
          'data-jest-svg-name': '${filename}',
          'data-testid': '${filename}'
        });
      }

    module.exports = ${functionName};`;
  // ^^^ the only change from the original
}
function createFunctionName(base) {
  const words = base.split(/\W+/);
  return words.reduce((identifer, word) => identifer + word.substr(0, 1).toUpperCase() + word.substr(1), '');
}
function processSvg(contents, filename) {
  const parts = path.parse(filename);
  if (parts.ext.toLowerCase() === '.svg') {
    const functionName = createFunctionName(parts.name);
    return buildModule(functionName, parts.base, parts.name);
  }
  return contents;
}
module.exports = {
  process: processSvg
};