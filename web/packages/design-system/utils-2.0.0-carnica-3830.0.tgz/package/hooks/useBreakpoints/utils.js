import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
export var mapping = function mapping(width, map) {
  var actualPoint;
  var generatedMap = {};
  Object.entries(map).forEach(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 2),
      k = _ref2[0],
      size = _ref2[1];
    var key = k;
    generatedMap[key] = size <= width;
    if ((actualPoint && map[actualPoint] < size || !actualPoint) && size <= width) {
      actualPoint = key;
    }
  });
  return [actualPoint, generatedMap];
};
export var isPointsEqual = function isPointsEqual(a, b) {
  var _a = _slicedToArray(a, 2),
    actualPointA = _a[0],
    mapA = _a[1];
  var _b = _slicedToArray(b, 2),
    actualPointB = _b[0],
    mapB = _b[1];
  if (actualPointA !== actualPointB) return false;
  var keysA = Object.keys(mapA);
  var keysB = Object.keys(mapB);
  if (keysA.length !== keysB.length) return false;
  return keysA.every(function (key) {
    return mapA[key] === mapB[key];
  });
};