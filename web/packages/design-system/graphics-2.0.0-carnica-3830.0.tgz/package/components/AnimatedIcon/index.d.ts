export * from './AnimatedIcon';
//# sourceMappingURL=index.d.ts.map