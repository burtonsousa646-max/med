import { ComponentType } from 'react';
type AnyHoc = <C extends ComponentType<any>>(component: C) => ComponentType<any>;
export declare function allowParamOmit<Params, Generic extends AnyHoc>(hoc: (params?: Params) => Generic): Generic;
export {};
//# sourceMappingURL=allowParamOmit.d.ts.map