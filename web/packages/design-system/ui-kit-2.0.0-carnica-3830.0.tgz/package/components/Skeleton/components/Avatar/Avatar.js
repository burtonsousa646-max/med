import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["size"];
import React from 'react';
import { SkeletonCircle } from "../../Skeleton";
var sizeMap = {
  xl: 64,
  l: 56,
  m: 44,
  s: 32
};
export var Avatar = function Avatar(_ref) {
  var _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'l' : _ref$size,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(SkeletonCircle, _extends({
    diameter: sizeMap[size]
  }, otherProps, {
    "data-t-id": "components-Avatar"
  }));
};