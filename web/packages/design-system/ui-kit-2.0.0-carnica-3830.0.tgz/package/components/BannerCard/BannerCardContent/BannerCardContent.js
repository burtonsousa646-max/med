import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["title", "logo", "invert", "className"];
import { cnBem } from '@carnica/utils';
import React, { forwardRef } from 'react';
import { useIsMobileDimension } from '@carnica/utils/hooks';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnBannerCardContent = cnBem('banner-card-content', styles);
var renderLogo = function renderLogo(Logo, isMobile) {
  if (!Logo) {
    return null;
  }
  if (typeof Logo === 'string') {
    return /*#__PURE__*/React.createElement("img", {
      alt: "\u043B\u043E\u0433\u043E\u0442\u0438\u043F",
      className: cnBannerCardContent('image'),
      src: Logo,
      "data-t-id": "BannerCard-BannerCardContent"
    });
  }
  return /*#__PURE__*/React.createElement(Logo, {
    className: cnBannerCardContent('logo'),
    size: isMobile ? 20 : 32
  });
};
var getLayout = function getLayout(withTitle, withLogo) {
  if (withTitle && withLogo) {
    return 'between';
  }
  if (withTitle) {
    return 'end';
  }
  if (withLogo) {
    return 'start';
  }
  return undefined;
};
export var BannerCardContent = /*#__PURE__*/forwardRef(function (props, ref) {
  var title = props.title,
    logo = props.logo,
    invert = props.invert,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isMobile = useIsMobileDimension();
  if (!title && !logo) {
    return null;
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnBannerCardContent({
      layout: getLayout(!!title, !!logo)
    }, [className]),
    ref: ref
  }, otherProps), renderLogo(logo, isMobile), title && /*#__PURE__*/React.createElement(Text, {
    className: cnBannerCardContent('title'),
    color: invert ? 'white' : 'black',
    rows: 2,
    truncate: true,
    variant: isMobile ? 'body-small' : 'body-large'
  }, title));
});