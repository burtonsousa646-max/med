module.exports = {
  rules: {
    'sonarjs/cognitive-complexity': 'warn',
    'sonarjs/no-duplicate-string': 'off'
  }
};