module.exports = {
  rules: {
    'jsx-a11y/click-events-have-key-events': 0,
    'jsx-a11y/mouse-events-have-key-events': 0,
    'jsx-a11y/anchor-is-valid': 0,
    'jsx-a11y/label-has-associated-control': ['warn', {
      required: {
        some: ['nesting', 'id']
      }
    }],
    // deprecated rule
    'jsx-a11y/label-has-for': 0,
    // caption means subtitles, we do not have the required content for that
    'jsx-a11y/media-has-caption': 0,
    // forcing rule on every single div that has onClick is too much, even for the lord of accessibility
    'jsx-a11y/no-static-element-interactions': 0
  }
};