export * from './Icon';
export type { IconProps, LogoProps } from './types';
//# sourceMappingURL=index.d.ts.map