import type { QRProps } from '../../types';
type Params = {
    size: number;
} & Pick<QRProps, 'cutout' | 'errorCorrectionLevel' | 'rounding' | 'url' | 'viewPortSize'>;
export declare const useQr: ({ url, rounding, errorCorrectionLevel, size, cutout, viewPortSize, }: Params) => {
    cutoutModuleArea: number;
    qrPath: string | null;
    moduleCount: number | undefined;
};
export {};
//# sourceMappingURL=useQr.d.ts.map