import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["actions", "getActionTagName", "getActionAttributes", "getActionDisabled", "getActionLabel", "getActionOnClick", "getActionRef", "getActionIconLeft", "getActionIconRight", "getActionView", "title", "children", "className", "id", "subTitle", "portalProps"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem } from '@carnica/utils';
import React, { forwardRef } from 'react';
import { Modal } from "../Modal";
import styles from "./styles.module.css";
import { composePreparedProps, getActionParams } from "./utils";
import { Title } from "../Title";
import { Button } from "../Button";
var cnDialog = cnBem('dialog', styles);
var getTitleId = function getTitleId(id) {
  if (id) {
    return "dialog-title-".concat(id);
  }
  return 'dialog-title';
};
var DialogRender = function DialogRender(props, ref) {
  var _composePreparedProps = composePreparedProps(props),
    actions = _composePreparedProps.actions,
    getActionTagName = _composePreparedProps.getActionTagName,
    getActionAttributes = _composePreparedProps.getActionAttributes,
    getActionDisabled = _composePreparedProps.getActionDisabled,
    getActionLabel = _composePreparedProps.getActionLabel,
    getActionOnClick = _composePreparedProps.getActionOnClick,
    getActionRef = _composePreparedProps.getActionRef,
    getActionIconLeft = _composePreparedProps.getActionIconLeft,
    getActionIconRight = _composePreparedProps.getActionIconRight,
    getActionView = _composePreparedProps.getActionView,
    title = _composePreparedProps.title,
    children = _composePreparedProps.children,
    className = _composePreparedProps.className,
    id = _composePreparedProps.id,
    subTitle = _composePreparedProps.subTitle,
    portalProps = _composePreparedProps.portalProps,
    otherProps = _objectWithoutProperties(_composePreparedProps, _excluded);
  var getAction = function getAction(action) {
    return getActionParams({
      action: action,
      getActionTagName: getActionTagName,
      getActionAttributes: getActionAttributes,
      getActionDisabled: getActionDisabled,
      getActionLabel: getActionLabel,
      getActionOnClick: getActionOnClick,
      getActionIconLeft: getActionIconLeft,
      getActionIconRight: getActionIconRight,
      getActionRef: getActionRef,
      getActionView: getActionView
    });
  };
  return /*#__PURE__*/React.createElement(Modal, _extends({}, otherProps, {
    className: cnDialog(null, [className]),
    portalProps: _objectSpread(_objectSpread({}, portalProps || {}), {}, {
      'aria-labelledby': getTitleId(id)
    }),
    ref: ref,
    size: "s",
    "data-t-id": "components-Dialog"
  }), title && /*#__PURE__*/React.createElement(Title, {
    align: "left",
    className: cnDialog('title'),
    id: getTitleId(id),
    size: "m",
    subTitle: subTitle,
    title: title
  }), children, actions && /*#__PURE__*/React.createElement("div", {
    className: cnDialog('actions')
  }, actions.map(function (action, index) {
    return /*#__PURE__*/React.createElement(Button, _extends({}, getAction(action), {
      key: cnDialog('action', {
        index: index
      }),
      mode: "default",
      size: "l",
      width: "full"
    }));
  })));
};
export var Dialog = /*#__PURE__*/forwardRef(DialogRender);