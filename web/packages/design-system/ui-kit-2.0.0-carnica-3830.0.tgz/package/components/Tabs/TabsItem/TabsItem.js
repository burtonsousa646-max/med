import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["active", "children", "size", "className", "onClick", "badge"];
import { cnBem } from '@carnica/utils';
import React, { forwardRef } from 'react';
import { Text } from "../../Text";
import { Badge } from "../../Badge";
import styles from "./styles.module.css";
var cnTabsItem = cnBem('tabs-item', styles);
var getVariant = function getVariant(size, active) {
  if (size === 'm') {
    return 'body-medium';
  }
  if (active) {
    return 'body-accent-small';
  }
  return 'body-small';
};
export var TabsItem = /*#__PURE__*/forwardRef(function (props, ref) {
  var active = props.active,
    children = props.children,
    _props$size = props.size,
    size = _props$size === void 0 ? 'm' : _props$size,
    className = props.className,
    onClick = props.onClick,
    badge = props.badge,
    otherProps = _objectWithoutProperties(props, _excluded);
  return /*#__PURE__*/React.createElement("li", {
    className: cnTabsItem(null),
    "data-t-id": "Tabs-TabsItem"
  }, /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    "aria-current": active,
    className: cnTabsItem({
      active: active
    }, [className]),
    color: active ? 'primary' : 'secondary',
    onClick: onClick,
    ref: ref,
    tagName: "button",
    type: "button",
    variant: getVariant(size, active)
  }), children), badge && /*#__PURE__*/React.createElement(Badge, {
    activated: true,
    className: cnTabsItem('badge'),
    type: "dot"
  }));
});