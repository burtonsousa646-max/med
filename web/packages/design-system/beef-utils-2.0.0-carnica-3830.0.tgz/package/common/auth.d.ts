export type TUser = Partial<{
    isConvergent: boolean;
    isMobile: boolean;
}>;
export declare const LOGIN_TYPES: {
    mobile: string;
    mobileConvergence: string;
    login: string;
    b2b: string;
    unknown: string;
};
export declare const LOGIN_TYPES_ANALYTICS: {
    mobile: string;
    fttb: string;
    fmc: string;
    none: string;
};
export declare const getAccountType: (user: TUser) => string;
//# sourceMappingURL=auth.d.ts.map