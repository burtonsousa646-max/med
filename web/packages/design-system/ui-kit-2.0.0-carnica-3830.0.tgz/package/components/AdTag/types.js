export var adTagPropSize = ['s', 'm', 'l'];
export var adTagPropBackground = ['light', 'dark'];