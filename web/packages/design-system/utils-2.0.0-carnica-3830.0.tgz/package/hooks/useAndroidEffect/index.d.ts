import React from 'react';
type AndroidDeviceEffectParams = {
    isInstalledApp: boolean | null;
};
type EffectCallback = (params: AndroidDeviceEffectParams) => (() => void) | void;
type UseAndroidDeviceOptions = {
    waitInstalledAppStatus?: boolean;
};
export declare const useAndroidEffect: (effect: EffectCallback, options?: UseAndroidDeviceOptions, deps?: React.DependencyList) => void;
export {};
//# sourceMappingURL=index.d.ts.map