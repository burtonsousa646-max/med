declare let _extends: any[];
export { _extends as extends };
//# sourceMappingURL=test-only.d.ts.map