import React from 'react';
import { Fiber } from '@beef/react/internals';
type IProps = {
    children?: ((fiber: Fiber) => React.ReactNode) | React.ReactNode;
};
export declare class FiberAccess extends React.Component<IProps> {
    private _fiber?;
    get fiber(): Fiber;
    render(): any;
}
export {};
//# sourceMappingURL=FiberAccess.d.ts.map