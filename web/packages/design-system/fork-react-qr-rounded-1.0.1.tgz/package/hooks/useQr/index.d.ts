export * from './useQr';
//# sourceMappingURL=index.d.ts.map