export {};
//# sourceMappingURL=setupMockServer.d.ts.map