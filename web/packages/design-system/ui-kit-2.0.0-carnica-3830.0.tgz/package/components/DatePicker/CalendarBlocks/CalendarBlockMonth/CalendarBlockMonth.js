import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["date", "label"];
import React, { useCallback } from 'react';
import { cnBem } from '@carnica/utils';
import { formatDate, isSameMonth } from 'date-fns-new';
import { useDatePeriodList } from "../../hooks/useDatePeriodList";
import { useCalendarGridKeyboardHandler } from "../../hooks/useCalendarGridKeyboardHandler";
import { Cell } from "../../Cell";
import styles from "./styles.module.css";
import { Grid } from "../../Grid";
var cnCalendarBlockMonth = cnBem('month-block', styles);
export var CalendarBlockMonth = function CalendarBlockMonth(props) {
  var currentVisibleDate = props.currentVisibleDate,
    minDate = props.minDate,
    maxDate = props.maxDate,
    locale = props.locale,
    value = props.value,
    disableDates = props.disableDates,
    onChange = props.onChange,
    setCurrentVisibleDate = props.setCurrentVisibleDate,
    isComposed = props.isComposed,
    isAnimationFinished = props.isAnimationFinished;
  var handleChange = useCallback(function (date, e) {
    var sameMonth = date && value && isSameMonth(value, date);
    onChange === null || onChange === void 0 || onChange(sameMonth ? null : date, e);
  }, [onChange, value]);
  var months = useDatePeriodList({
    onChange: handleChange,
    type: 'month',
    locale: locale,
    currentVisibleDate: currentVisibleDate,
    disableDates: disableDates,
    maxDate: maxDate,
    minDate: minDate,
    value: value
  });
  var _useCalendarGridKeybo = useCalendarGridKeyboardHandler({
      items: months,
      value: value,
      currentVisibleDate: currentVisibleDate,
      setCurrentVisibleDate: setCurrentVisibleDate,
      isComposed: isComposed,
      type: 'month',
      isAnimationFinished: isAnimationFinished,
      disableDates: disableDates,
      maxDate: maxDate,
      minDate: minDate
    }),
    refs = _useCalendarGridKeybo.refs,
    onKeyDownByIndex = _useCalendarGridKeybo.onKeyDownByIndex;
  return /*#__PURE__*/React.createElement(Grid, {
    className: cnCalendarBlockMonth('list'),
    type: "month",
    "data-t-id": "CalendarBlocks-CalendarBlockMonth"
  }, months.map(function (item, i) {
    var date = item.date,
      label = item.label,
      params = _objectWithoutProperties(item, _excluded);
    return /*#__PURE__*/React.createElement(Cell, _extends({
      className: cnCalendarBlockMonth('month'),
      "data-t-date": formatDate(date, 'yyyy-MM'),
      key: date.toDateString(),
      onKeyDown: onKeyDownByIndex(i, item),
      ref: refs[i],
      rootProps: {
        className: cnCalendarBlockMonth('cell')
      }
    }, params), label);
  }));
};