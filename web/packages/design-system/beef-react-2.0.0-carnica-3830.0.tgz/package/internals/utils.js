import { getDomNodeFromFiber, getFiberNodeFromClassComponent, getFiberNodeFromDOM, getFiberNodeParent, getFiberNodeType, getFiberProp, isDomFiberNode, isRootFiberNode } from "./fiber";
export function getContextAtNode(domNode, Context) {
  var contextNode = findClosestFiberNodeMatch(getFiberNodeFromDOM(domNode), function (checkNode) {
    return getFiberNodeType(checkNode) === Context.Provider;
  }).fiberNode;
  return contextNode ? getFiberProp(contextNode, 'value') : null;
}
export function findClosestFiberNodeMatch(fiberNode, matcher) {
  while (fiberNode) {
    var match = matcher(fiberNode);
    if (match) return {
      fiberNode: fiberNode,
      match: match
    };
    fiberNode = getFiberNodeParent(fiberNode);
  }
  return {};
}
export function findClosestReactKeyMatching(domNode, matcher) {
  return findClosestFiberNodeMatch(getFiberNodeFromDOM(domNode), function (node) {
    return node.key && matcher(node.key);
  }).match;
}
export function findDOMParent(component) {
  return getDomNodeFromFiber(findClosestFiberNodeMatch(getFiberNodeFromClassComponent(component), function (checkNode) {
    return isDomFiberNode(checkNode) || isRootFiberNode(checkNode);
  }).fiberNode);
}