var setRef = function setRef(ref, value) {
  if (typeof ref === 'function') {
    ref(value);
    return;
  }
  if (ref) {
    ref.current = value;
  }
};
export var combineRefs = function combineRefs(refs) {
  if (!refs.length) {
    return null;
  }
  return function (refValue) {
    refs.forEach(function (ref) {
      setRef(ref, refValue);
    });
  };
};