import _typeof from "@babel/runtime/helpers/typeof";
import React from 'react';

/**
 * Оборачивает функцией только на component-узлы. Пропуская примитивы как есть.
 * Полезно при вызове cloneElement
 */
export var componentOnly = function componentOnly(fn) {
  return function (child) {
    if (!child || _typeof(child) !== 'object') return child;
    return fn(child);
  };
};

/**
 * Moves cloneElement to a new level, by cloning children of children (nth) instead of direct ones
 * Only works with 'children' field
 */
var _cloneNthChildren = function cloneNthChildren(children, depth, fn) {
  if (depth === 0) return fn(children);
  return children && React.Children.map(children, componentOnly(function (child) {
    return /*#__PURE__*/React.cloneElement(child, undefined, _cloneNthChildren(child.props.children, depth - 1, fn));
  }));
};
export { _cloneNthChildren as cloneNthChildren };