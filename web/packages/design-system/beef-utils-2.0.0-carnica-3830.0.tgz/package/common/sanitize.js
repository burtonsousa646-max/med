export var sanitize = function sanitize(string) {
  var replaceValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  var regex = /<([^>]+)>/gi;
  return string.replace(regex, replaceValue);
};
var patternScript = '(<\\s*script\\b|<\\/\\s*script\\s*>|javascript:|data:text\\/html|window\\.eval|eval\\s*\\(|Function\\s*\\(|document\\.cookie|document\\.write|onerror\\s*=|onload\\s*=|alert\\s*\\(|prompt\\s*\\(|confirm\\s*\\(|<\\s*iframe\\b|<\\s*img\\b[^>]*on\\w+\\s*=)';
// eslint-disable-next-line no-useless-escape
var combinedPattern = "(<([^>()[\\\\]+)>|[/<>|?!()\\\\\"']|".concat(patternScript, ")");
var DANGEROUS_CHECK_REGEX = new RegExp(patternScript, 'i');

// Позволяет писать буквы и цифры, очищает от HTML тегов. Запрещен ввод вредоностного кода для ИБ.
var DANGEROUS_CHARS_REGEX = new RegExp(combinedPattern, 'gi');
export var sanitizeSearch = function sanitizeSearch(string) {
  var replaceValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  return string.replace(DANGEROUS_CHARS_REGEX, replaceValue);
};
export var checkDangerousChars = function checkDangerousChars(value, onDangerous) {
  var isDangerous = DANGEROUS_CHECK_REGEX.test(value || '');
  if (isDangerous) {
    onDangerous === null || onDangerous === void 0 || onDangerous();
  }
  return isDangerous;
};