import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["onChange", "date", "className", "onClick", "value"];
import React from 'react';
import { AnimatedIcon, IconChevronDown } from '@carnica/graphics';
import { cnBem } from '@carnica/utils';
import { motion } from 'framer-motion';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnModeToggle = cnBem('toggle', styles);
export var ModeToggle = function ModeToggle(_ref) {
  var onChange = _ref.onChange,
    date = _ref.date,
    className = _ref.className,
    onClick = _ref.onClick,
    _ref$value = _ref.value,
    value = _ref$value === void 0 ? 'date' : _ref$value,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var handleClick = function handleClick(e) {
    onClick === null || onClick === void 0 || onClick(e);
    onChange === null || onChange === void 0 || onChange(value === 'date' ? 'year' : 'date', e);
  };
  return /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    "aria-label": "\u041F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043D\u0430 \u0432\u044B\u0431\u043E\u0440 ".concat(value === 'date' ? 'года' : 'даты'),
    className: cnModeToggle(null, [className]),
    color: "primary-fake-invert",
    onClick: handleClick,
    tagName: "button",
    type: "button",
    variant: "headline-small",
    "data-t-id": "DatePicker-ModeToggle"
  }), /*#__PURE__*/React.createElement(motion.span, {
    animate: {
      width: value === 'date' ? 54 : 150
    },
    transition: {
      ease: 'easeOut',
      duration: 0.3
    }
  }, value === 'date' ? date.getFullYear() : 'выберите год'), /*#__PURE__*/React.createElement(AnimatedIcon, {
    activeIndex: value === 'date' ? 0 : 1,
    className: cnModeToggle('icon'),
    color: "primary-invert",
    icons: [IconChevronDown],
    rotations: [0, 180],
    size: "m",
    "data-t-id": "DatePicker-ModeToggle"
  }));
};