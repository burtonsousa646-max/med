export * from './useResizeObserved';
//# sourceMappingURL=index.d.ts.map