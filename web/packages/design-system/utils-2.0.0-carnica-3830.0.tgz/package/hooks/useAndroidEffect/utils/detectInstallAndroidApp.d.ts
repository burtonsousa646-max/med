export declare const detectInstalledAndroidApp: (timeout: number, setIsInstalledApp: (value: boolean) => void) => (() => void) | void;
//# sourceMappingURL=detectInstallAndroidApp.d.ts.map