import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["style", "width", "color", "invert", "height", "tagName", "className"],
  _excluded2 = ["className", "invert", "color"],
  _excluded3 = ["className", "color", "invert", "diameter"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React from 'react';
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import { useBreakpoints } from '@carnica/utils/hooks';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { getSize } from "./utils";
var cnSkeleton = cnBem('skeleton', styles);
var Skeleton = forwardRefWithMotionTag(function (_ref, ref) {
  var style = _ref.style,
    _ref$width = _ref.width,
    width = _ref$width === void 0 ? '100%' : _ref$width,
    _ref$color = _ref.color,
    color = _ref$color === void 0 ? 'default' : _ref$color,
    invert = _ref.invert,
    _ref$height = _ref.height,
    height = _ref$height === void 0 ? 16 : _ref$height,
    _ref$tagName = _ref.tagName,
    tagName = _ref$tagName === void 0 ? 'span' : _ref$tagName,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  var _useBreakpoints = useBreakpoints(),
    _useBreakpoints2 = _slicedToArray(_useBreakpoints, 1),
    breakpoint = _useBreakpoints2[0];
  var dimension = breakpoint || 'desktop';
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, props, {
    "aria-hidden": true,
    className: cnSkeleton({
      invert: invert,
      color: color
    }, [className]),
    ref: ref,
    role: "presentation",
    style: _objectSpread(_defineProperty(_defineProperty({}, '--skeleton-width', getSize(width, dimension)), '--skeleton-height', getSize(height, dimension)), style),
    tagName: tagName,
    "data-t-id": "components-Skeleton"
  }));
});
export var SkeletonBrick = forwardRefWithMotionTag(function (_ref2, ref) {
  var className = _ref2.className,
    invert = _ref2.invert,
    color = _ref2.color,
    props = _objectWithoutProperties(_ref2, _excluded2);
  return /*#__PURE__*/React.createElement(Skeleton, _extends({}, props, {
    className: cnSkeleton({
      invert: invert,
      color: color,
      view: 'brick'
    }, [className]),
    ref: ref
  }));
});
export var SkeletonCircle = forwardRefWithMotionTag(function (_ref3, ref) {
  var className = _ref3.className,
    color = _ref3.color,
    invert = _ref3.invert,
    _ref3$diameter = _ref3.diameter,
    diameter = _ref3$diameter === void 0 ? 32 : _ref3$diameter,
    props = _objectWithoutProperties(_ref3, _excluded3);
  return /*#__PURE__*/React.createElement(Skeleton, _extends({}, props, {
    className: cnSkeleton({
      invert: invert,
      color: color,
      view: 'circle'
    }, [className]),
    height: diameter,
    ref: ref,
    width: diameter
  }));
});