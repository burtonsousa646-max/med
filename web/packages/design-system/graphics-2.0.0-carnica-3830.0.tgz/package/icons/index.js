import { baseServerUrl } from "../utils/constant";
import { defineUrlIcon } from "../utils/defineUrlIcon";
export var IconAiSearch = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconAiSearch.svg")
});
export var IconArchiveFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArchiveFilled.svg")
});
export var IconArchiveOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArchiveOutline.svg")
});
export var IconArrowsDown = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsDown.svg")
});
export var IconArrowsDownLeft = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsDownLeft.svg")
});
export var IconArrowsDownRight = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsDownRight.svg")
});
export var IconArrowsLeft = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsLeft.svg")
});
export var IconArrowsRight = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsRight.svg")
});
export var IconArrowsUp = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsUp.svg")
});
export var IconArrowsUpLeft = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsUpLeft.svg")
});
export var IconArrowsUpRight = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconArrowsUpRight.svg")
});
export var IconAutoPayFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconAutoPayFilled.svg")
});
export var IconAutoPayOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconAutoPayOutline.svg")
});
export var IconBagFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBagFilled.svg")
});
export var IconBagOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBagOutline.svg")
});
export var IconBanRoundFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBanRoundFilled.svg")
});
export var IconBanRoundOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBanRoundOutline.svg")
});
export var IconBankFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBankFilled.svg")
});
export var IconBankOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBankOutline.svg")
});
export var IconBasketFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBasketFilled.svg")
});
export var IconBasketOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBasketOutline.svg")
});
export var IconBellFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBellFilled.svg")
});
export var IconBellOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBellOutline.svg")
});
export var IconBookFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBookFilled.svg")
});
export var IconBookOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBookOutline.svg")
});
export var IconBookmarkFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBookmarkFilled.svg")
});
export var IconBookmarkOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBookmarkOutline.svg")
});
export var IconBrokenHeartFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBrokenHeartFilled.svg")
});
export var IconBrokenHeartOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBrokenHeartOutline.svg")
});
export var IconBurgerMenu = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBurgerMenu.svg")
});
export var IconBusFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBusFilled.svg")
});
export var IconBusOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconBusOutline.svg")
});
export var IconCalculatorFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCalculatorFilled.svg")
});
export var IconCalculatorOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCalculatorOutline.svg")
});
export var IconCalendarFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCalendarFilled.svg")
});
export var IconCalendarOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCalendarOutline.svg")
});
export var IconCallSilentFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallSilentFilled.svg")
});
export var IconCallSilentOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallSilentOutline.svg")
});
export var IconCallingFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOnFilled.svg")
});
export var IconCallingFilled1 = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOffFilled.svg")
});
export var IconCallingOffFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOffFilled.svg")
});
export var IconCallingOffOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOffOutline.svg")
});
export var IconCallingOnCrossedFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOnCrossedFilled.svg")
});
export var IconCallingOnCrossedOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOnCrossedOutline.svg")
});
export var IconCallingOnFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOnFilled.svg")
});
export var IconCallingOnOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOnOutline.svg")
});
export var IconCallingOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOnOutline.svg")
});
export var IconCallingOutline1 = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCallingOffOutline.svg")
});
export var IconCameraFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCameraFilled.svg")
});
export var IconCameraOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCameraOutline.svg")
});
export var IconCarFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCarFilled.svg")
});
export var IconCarOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCarOutline.svg")
});
export var IconCardFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCardFilled.svg")
});
export var IconCardOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCardOutline.svg")
});
export var IconCaseFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCaseFilled.svg")
});
export var IconCaseOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCaseOutline.svg")
});
export var IconCashFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCashFilled.svg")
});
export var IconCashOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCashOutline.svg")
});
export var IconChartAltFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChartAltFilled.svg")
});
export var IconChartAltOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChartAltOutline.svg")
});
export var IconChartFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChartFilled.svg")
});
export var IconChartOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChartOutline.svg")
});
export var IconChatAddMessageFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChatAddMessageFilled.svg")
});
export var IconChatAddMessageOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChatAddMessageOutline.svg")
});
export var IconChatMessageFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChatMessageFilled.svg")
});
export var IconChatMessageOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChatMessageOutline.svg")
});
export var IconChatPlusMessageFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChatPlusMessageFilled.svg")
});
export var IconChatPlusMessageOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChatPlusMessageOutline.svg")
});
export var IconCheckFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckFilled.svg")
});
export var IconCheckMarkCheck = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckMarkCheck.svg")
});
export var IconCheckMarkDoubleCheck = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckMarkDoubleCheck.svg")
});
export var IconCheckOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckOutline.svg")
});
export var IconCheckRoundFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckRoundFilled.svg")
});
export var IconCheckRoundOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckRoundOutline.svg")
});
export var IconCheckShieldFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckShieldFilled.svg")
});
export var IconCheckShieldOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckShieldOutline.svg")
});
export var IconCheckSquareFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckSquareFilled.svg")
});
export var IconCheckSquareOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCheckSquareOutline.svg")
});
export var IconChevronDown = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChevronDown.svg")
});
export var IconChevronLeft = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChevronLeft.svg")
});
export var IconChevronRight = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChevronRight.svg")
});
export var IconChevronUp = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconChevronUp.svg")
});
export var IconCloseRoundFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloseRoundFilled.svg")
});
export var IconCloseRoundOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloseRoundOutline.svg")
});
export var IconCloseRoundStroked = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloseRoundStroked.svg")
});
export var IconCloseShieldFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloseShieldFilled.svg")
});
export var IconCloseShieldOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloseShieldOutline.svg")
});
export var IconCloseSquareFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloseSquareFilled.svg")
});
export var IconCloseSquareOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloseSquareOutline.svg")
});
export var IconCloudFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloudFilled.svg")
});
export var IconCloudOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCloudOutline.svg")
});
export var IconCoinsFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCoinsFilled.svg")
});
export var IconCoinsOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCoinsOutline.svg")
});
export var IconCollapse = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCollapse.svg")
});
export var IconCompasFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCompasFilled.svg")
});
export var IconCompasOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCompasOutline.svg")
});
export var IconConnection = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconConnection.svg")
});
export var IconCopyFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCopyFilled.svg")
});
export var IconCopyOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCopyOutline.svg")
});
export var IconCouponFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCouponFilled.svg")
});
export var IconCouponOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCouponOutline.svg")
});
export var IconCyrillicACapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicACapital.svg")
});
export var IconCyrillicASmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicASmall.svg")
});
export var IconCyrillicBCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicBCapital.svg")
});
export var IconCyrillicBSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicBSmall.svg")
});
export var IconCyrillicCCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicCCapital.svg")
});
export var IconCyrillicCSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicCSmall.svg")
});
export var IconCyrillicChCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicChCapital.svg")
});
export var IconCyrillicChSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicChSmall.svg")
});
export var IconCyrillicDCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicDCapital.svg")
});
export var IconCyrillicDSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicDSmall.svg")
});
export var IconCyrillicECapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicECapital.svg")
});
export var IconCyrillicESmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicESmall.svg")
});
export var IconCyrillicFCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicFCapital.svg")
});
export var IconCyrillicFSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicFSmall.svg")
});
export var IconCyrillicGCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicGCapital.svg")
});
export var IconCyrillicGSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicGSmall.svg")
});
export var IconCyrillicICapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicICapital.svg")
});
export var IconCyrillicISmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicISmall.svg")
});
export var IconCyrillicKCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicKCapital.svg")
});
export var IconCyrillicKSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicKSmall.svg")
});
export var IconCyrillicLCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicLCapital.svg")
});
export var IconCyrillicLSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicLSmall.svg")
});
export var IconCyrillicMCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicMCapital.svg")
});
export var IconCyrillicMSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicMSmall.svg")
});
export var IconCyrillicNCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicNCapital.svg")
});
export var IconCyrillicNSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicNSmall.svg")
});
export var IconCyrillicOCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicOCapital.svg")
});
export var IconCyrillicOSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicOSmall.svg")
});
export var IconCyrillicPCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicPCapital.svg")
});
export var IconCyrillicPSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicPSmall.svg")
});
export var IconCyrillicRCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicRCapital.svg")
});
export var IconCyrillicRSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicRSmall.svg")
});
export var IconCyrillicSCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicSCapital.svg")
});
export var IconCyrillicSSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicSSmall.svg")
});
export var IconCyrillicShCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicShCapital.svg")
});
export var IconCyrillicShSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicShSmall.svg")
});
export var IconCyrillicShchCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicShchCapital.svg")
});
export var IconCyrillicShchSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicShchSmall.svg")
});
export var IconCyrillicTCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicTCapital.svg")
});
export var IconCyrillicTSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicTSmall.svg")
});
export var IconCyrillicUCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicUCapital.svg")
});
export var IconCyrillicUSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicUSmall.svg")
});
export var IconCyrillicVCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicVCapital.svg")
});
export var IconCyrillicVSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicVSmall.svg")
});
export var IconCyrillicXCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicXCapital.svg")
});
export var IconCyrillicXSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicXSmall.svg")
});
export var IconCyrillicYaCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicYaCapital.svg")
});
export var IconCyrillicYaSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicYaSmall.svg")
});
export var IconCyrillicYeCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicYeCapital.svg")
});
export var IconCyrillicYeSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicYeSmall.svg")
});
export var IconCyrillicYuCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicYuCapital.svg")
});
export var IconCyrillicYuSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicYuSmall.svg")
});
export var IconCyrillicZCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicZCapital.svg")
});
export var IconCyrillicZSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicZSmall.svg")
});
export var IconCyrillicZhCapital = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicZhCapital.svg")
});
export var IconCyrillicZhSmall = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconCyrillicZhSmall.svg")
});
export var IconDangerFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDangerFilled.svg")
});
export var IconDangerOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDangerOutline.svg")
});
export var IconDeskCrossedFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDeskCrossedFilled.svg")
});
export var IconDeskCrossedOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDeskCrossedOutline.svg")
});
export var IconDeskFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDeskFilled.svg")
});
export var IconDeskOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDeskOutline.svg")
});
export var IconDigitalRuble = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDigitalRuble.svg")
});
export var IconDocFillFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDocFillFilled.svg")
});
export var IconDocFillOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDocFillOutline.svg")
});
export var IconDocFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDocFilled.svg")
});
export var IconDocOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDocOutline.svg")
});
export var IconDocxFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDocxFilled.svg")
});
export var IconDocxOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDocxOutline.svg")
});
export var IconDotsMessage2Filled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDotsMessage2Filled.svg")
});
export var IconDotsMessage2Outline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDotsMessage2Outline.svg")
});
export var IconDotsMessageFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDotsMessageFilled.svg")
});
export var IconDotsMessageOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDotsMessageOutline.svg")
});
export var IconDotsRoundFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDotsRoundFilled.svg")
});
export var IconDotsRoundOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDotsRoundOutline.svg")
});
export var IconDotsRoundStroked = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDotsRoundStroked.svg")
});
export var IconDoubleRightArrowFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDoubleRightArrowFilled.svg")
});
export var IconDoubleRightArrowOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconDoubleRightArrowOutline.svg")
});
export var IconEditPencilFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEditPencilFilled.svg")
});
export var IconEditPencilOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEditPencilOutline.svg")
});
export var IconEsimFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEsimFilled.svg")
});
export var IconEsimOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEsimOutline.svg")
});
export var IconExpand = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconExpand.svg")
});
export var IconExportFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconExportFilled.svg")
});
export var IconExportOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconExportOutline.svg")
});
export var IconEyeCloseFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEyeCloseFilled.svg")
});
export var IconEyeCloseOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEyeCloseOutline.svg")
});
export var IconEyeOpenFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEyeOpenFilled.svg")
});
export var IconEyeOpenOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconEyeOpenOutline.svg")
});
export var IconFaceIDFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFaceIDFilled.svg")
});
export var IconFaceIDOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFaceIDOutline.svg")
});
export var IconFileDocFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileDocFilled.svg")
});
export var IconFileDocOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileDocOutline.svg")
});
export var IconFileDocxFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileDocxFilled.svg")
});
export var IconFileDocxOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileDocxOutline.svg")
});
export var IconFileEmptyFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileEmptyFilled.svg")
});
export var IconFileEmptyOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileEmptyOutline.svg")
});
export var IconFileFillFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileFillFilled.svg")
});
export var IconFileFillOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileFillOutline.svg")
});
export var IconFileImgFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileImgFilled.svg")
});
export var IconFileImgOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileImgOutline.svg")
});
export var IconFileJpegFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileJpegFilled.svg")
});
export var IconFileJpegOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileJpegOutline.svg")
});
export var IconFileJpgFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileJpgFilled.svg")
});
export var IconFileJpgOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFileJpgOutline.svg")
});
export var IconFilePdfFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFilePdfFilled.svg")
});
export var IconFilePdfOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFilePdfOutline.svg")
});
export var IconFilePngFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFilePngFilled.svg")
});
export var IconFilePngOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFilePngOutline.svg")
});
export var IconFingerprintFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFingerprintFilled.svg")
});
export var IconFingerprintStroked = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFingerprintStroked.svg")
});
export var IconFireFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFireFilled.svg")
});
export var IconFireOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFireOutline.svg")
});
export var IconFlagFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFlagFilled.svg")
});
export var IconFlagOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFlagOutline.svg")
});
export var IconFourSquareFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFourSquareFilled.svg")
});
export var IconFourSquareOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconFourSquareOutline.svg")
});
export var IconGadget = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconGadget.svg")
});
export var IconGamepadFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconGamepadFilled.svg")
});
export var IconGamepadOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconGamepadOutline.svg")
});
export var IconGiftFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconGiftFilled.svg")
});
export var IconGiftOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconGiftOutline.svg")
});
export var IconGlobeFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconGlobeFilled.svg")
});
export var IconGlobeOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconGlobeOutline.svg")
});
export var IconHeadphonesFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHeadphonesFilled.svg")
});
export var IconHeadphonesOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHeadphonesOutline.svg")
});
export var IconHeartFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHeartFilled.svg")
});
export var IconHeartOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHeartOutline.svg")
});
export var IconHomeFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHomeFilled.svg")
});
export var IconHomeOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHomeOutline.svg")
});
export var IconHoneyCombFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHoneyCombFilled.svg")
});
export var IconHoneyCombOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHoneyCombOutline.svg")
});
export var IconHoneyCombStyled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHoneyCombStyled.svg"),
  multiColor: false
});
export var IconHoneycombsFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHoneycombsFilled.svg")
});
export var IconHoneycombsOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHoneycombsOutline.svg")
});
export var IconHotelFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHotelFilled.svg")
});
export var IconHotelOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconHotelOutline.svg")
});
export var IconIPhoneFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconIPhoneFilled.svg")
});
export var IconIPhoneOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconIPhoneOutline.svg")
});
export var IconImageBoxFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconImageBoxFilled.svg")
});
export var IconImageBoxOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconImageBoxOutline.svg")
});
export var IconImgFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconImgFilled.svg")
});
export var IconImgOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconImgOutline.svg")
});
export var IconImportFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconImportFilled.svg")
});
export var IconImportOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconImportOutline.svg")
});
export var IconInfinite = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconInfinite.svg")
});
export var IconInfoFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconInfoFilled.svg")
});
export var IconInfoOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconInfoOutline.svg")
});
export var IconJpegFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconJpegFilled.svg")
});
export var IconJpegOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconJpegOutline.svg")
});
export var IconJpgFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconJpgFilled.svg")
});
export var IconJpgOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconJpgOutline.svg")
});
export var IconKeySquareFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconKeySquareFilled.svg")
});
export var IconKeySquareOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconKeySquareOutline.svg")
});
export var IconKeyboardFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconKeyboardFilled.svg")
});
export var IconKeyboardOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconKeyboardOutline.svg")
});
export var IconLableFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLableFilled.svg")
});
export var IconLableOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLableOutline.svg")
});
export var IconLayersFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLayersFilled.svg")
});
export var IconLayersOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLayersOutline.svg")
});
export var IconLeftArrowFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLeftArrowFilled.svg")
});
export var IconLeftArrowOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLeftArrowOutline.svg")
});
export var IconLightningCrossedOutFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLightningCrossedOutFilled.svg")
});
export var IconLightningCrossedOutOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLightningCrossedOutOutline.svg")
});
export var IconLightningFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLightningFilled.svg")
});
export var IconLightningOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLightningOutline.svg")
});
export var IconLoading = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLoading.svg")
});
export var IconLockCheckFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockCheckFilled.svg")
});
export var IconLockCheckOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockCheckOutline.svg")
});
export var IconLockCloseFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockCloseFilled.svg")
});
export var IconLockCloseOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockCloseOutline.svg")
});
export var IconLockFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockFilled.svg")
});
export var IconLockOpenFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockOpenFilled.svg")
});
export var IconLockOpenOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockOpenOutline.svg")
});
export var IconLockOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLockOutline.svg")
});
export var IconLoginFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLoginFilled.svg")
});
export var IconLoginOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLoginOutline.svg")
});
export var IconLogoutFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLogoutFilled.svg")
});
export var IconLogoutOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconLogoutOutline.svg")
});
export var IconMailNewFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMailNewFilled.svg")
});
export var IconMailNewOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMailNewOutline.svg")
});
export var IconMailOpenFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMailOpenFilled.svg")
});
export var IconMailOpenOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMailOpenOutline.svg")
});
export var IconMapPinBigFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMapPinBigFilled.svg")
});
export var IconMapPinBigOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMapPinBigOutline.svg")
});
export var IconMapPinSmallFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMapPinSmallFilled.svg")
});
export var IconMapPinSmallOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMapPinSmallOutline.svg")
});
export var IconMarkFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMarkFilled.svg")
});
export var IconMarkOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMarkOutline.svg")
});
export var IconMicCrossedFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMicCrossedFilled.svg")
});
export var IconMicCrossedOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMicCrossedOutline.svg")
});
export var IconMicFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMicFilled.svg")
});
export var IconMicMuteFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMicMuteFilled.svg")
});
export var IconMicMuteOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMicMuteOutline.svg")
});
export var IconMicOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMicOutline.svg")
});
export var IconMinusRoundFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMinusRoundFilled.svg")
});
export var IconMinusRoundOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMinusRoundOutline.svg")
});
export var IconMinusRoundStroked = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMinusRoundStroked.svg")
});
export var IconMinusSquareFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMinusSquareFilled.svg")
});
export var IconMinusSquareOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMinusSquareOutline.svg")
});
export var IconMoonFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMoonFilled.svg")
});
export var IconMoonOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconMoonOutline.svg")
});
export var IconNotebookFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconNotebookFilled.svg")
});
export var IconNotebookOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconNotebookOutline.svg")
});
export var IconOrangeFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconOrangeFilled.svg")
});
export var IconOrangeStyled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconOrangeStyled.svg"),
  multiColor: false
});
export var IconPaperclip = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPaperclip.svg")
});
export var IconPassportFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPassportFilled.svg")
});
export var IconPassportOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPassportOutline.svg")
});
export var IconPdfFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPdfFilled.svg")
});
export var IconPdfOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPdfOutline.svg")
});
export var IconPercent = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPercent.svg")
});
export var IconPhoneCallInFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneCallInFilled.svg")
});
export var IconPhoneCallInOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneCallInOutline.svg")
});
export var IconPhoneCallOutFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneCallOutFilled.svg")
});
export var IconPhoneCallOutOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneCallOutOutline.svg")
});
export var IconPhoneCallTransferFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneCallTransferFilled.svg")
});
export var IconPhoneCallTransferOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneCallTransferOutline.svg")
});
export var IconPhoneFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneFilled.svg")
});
export var IconPhoneOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPhoneOutline.svg")
});
export var IconPieChartFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPieChartFilled.svg")
});
export var IconPieChartOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPieChartOutline.svg")
});
export var IconPinFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPinFilled.svg")
});
export var IconPinOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPinOutline.svg")
});
export var IconPlaneFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlaneFilled.svg")
});
export var IconPlaneOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlaneOutline.svg")
});
export var IconPlayFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlayFilled.svg")
});
export var IconPlayOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlayOutline.svg")
});
export var IconPlusRoundFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlusRoundFilled.svg")
});
export var IconPlusRoundOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlusRoundOutline.svg")
});
export var IconPlusRoundStroked = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlusRoundStroked.svg")
});
export var IconPlusSquareFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlusSquareFilled.svg")
});
export var IconPlusSquareOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPlusSquareOutline.svg")
});
export var IconPngFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPngFilled.svg")
});
export var IconPngOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPngOutline.svg")
});
export var IconPowerFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPowerFilled.svg")
});
export var IconPowerOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPowerOutline.svg")
});
export var IconPumpFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPumpFilled.svg")
});
export var IconPumpOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconPumpOutline.svg")
});
export var IconQuestionFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconQuestionFilled.svg")
});
export var IconQuestionMessage3Filled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconQuestionMessage3Filled.svg")
});
export var IconQuestionMessage3Outline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconQuestionMessage3Outline.svg")
});
export var IconQuestionMessageFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconQuestionMessageFilled.svg")
});
export var IconQuestionMessageOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconQuestionMessageOutline.svg")
});
export var IconQuestionOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconQuestionOutline.svg")
});
export var IconRainFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRainFilled.svg")
});
export var IconRainOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRainOutline.svg")
});
export var IconRefresh = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRefresh.svg")
});
export var IconRightArrowFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRightArrowFilled.svg")
});
export var IconRightArrowOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRightArrowOutline.svg")
});
export var IconRobotCrossedFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRobotCrossedFilled.svg")
});
export var IconRobotCrossedOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRobotCrossedOutline.svg")
});
export var IconRobotFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRobotFilled.svg")
});
export var IconRobotOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRobotOutline.svg")
});
export var IconRouterFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRouterFilled.svg")
});
export var IconRouterOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconRouterOutline.svg")
});
export var IconSaleCouponFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSaleCouponFilled.svg")
});
export var IconSaleCouponOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSaleCouponOutline.svg")
});
export var IconScannerQrFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconScannerQrFilled.svg")
});
export var IconScannerQrOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconScannerQrOutline.svg")
});
export var IconScreenMenu2Filled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconScreenMenu2Filled.svg")
});
export var IconScreenMenu2Outline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconScreenMenu2Outline.svg")
});
export var IconScreenMenuFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconScreenMenuFilled.svg")
});
export var IconScreenMenuOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconScreenMenuOutline.svg")
});
export var IconSearchFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSearchFilled.svg")
});
export var IconSearchOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSearchOutline.svg")
});
export var IconSendFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSendFilled.svg")
});
export var IconSendOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSendOutline.svg")
});
export var IconSettings = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSettings.svg")
});
export var IconSettingsFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSettingsFilled.svg")
});
export var IconSettingsOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSettingsOutline.svg")
});
export var IconShareFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconShareFilled.svg")
});
export var IconShareOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconShareOutline.svg")
});
export var IconShieldFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconShieldFilled.svg")
});
export var IconShieldOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconShieldOutline.svg")
});
export var IconShoppingBagFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconShoppingBagFilled.svg")
});
export var IconShoppingBagOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconShoppingBagOutline.svg")
});
export var IconSimFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSimFilled.svg")
});
export var IconSimOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSimOutline.svg")
});
export var IconSoundFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSoundFilled.svg")
});
export var IconSoundOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSoundOutline.svg")
});
export var IconSpeedFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSpeedFilled.svg")
});
export var IconSpeedOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSpeedOutline.svg")
});
export var IconStarAutoPayFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStarAutoPayFilled.svg")
});
export var IconStarAutoPayOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStarAutoPayOutline.svg")
});
export var IconStarFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStarFilled.svg")
});
export var IconStarHalfFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStarHalfFilled.svg")
});
export var IconStarOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStarOutline.svg")
});
export var IconStopAndPlayFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStopAndPlayFilled.svg")
});
export var IconStopAndPlayOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStopAndPlayOutline.svg")
});
export var IconStopFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStopFilled.svg")
});
export var IconStopOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStopOutline.svg")
});
export var IconStudyFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStudyFilled.svg")
});
export var IconStudyOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconStudyOutline.svg")
});
export var IconSunFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSunFilled.svg")
});
export var IconSunOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSunOutline.svg")
});
export var IconSwap = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconSwap.svg")
});
export var IconTabletFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTabletFilled.svg")
});
export var IconTabletOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTabletOutline.svg")
});
export var IconTimeFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTimeFilled.svg")
});
export var IconTimeOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTimeOutline.svg")
});
export var IconToolFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconToolFilled.svg")
});
export var IconToolOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconToolOutline.svg")
});
export var IconTrainFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTrainFilled.svg")
});
export var IconTrainOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTrainOutline.svg")
});
export var IconTrashFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTrashFilled.svg")
});
export var IconTrashOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTrashOutline.svg")
});
export var IconTvFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTvFilled.svg")
});
export var IconTvOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconTvOutline.svg")
});
export var IconUserAddFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconUserAddFilled.svg")
});
export var IconUserAddOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconUserAddOutline.svg")
});
export var IconUserFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconUserFilled.svg")
});
export var IconUserOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconUserOutline.svg")
});
export var IconUsersGroupFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconUsersGroupFilled.svg")
});
export var IconUsersGroupOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconUsersGroupOutline.svg")
});
export var IconVideoFileFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVideoFileFilled.svg")
});
export var IconVideoFileOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVideoFileOutline.svg")
});
export var IconVideoFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVideoFilled.svg")
});
export var IconVideoOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVideoOutline.svg")
});
export var IconVolumeOffFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVolumeOffFilled.svg")
});
export var IconVolumeOffOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVolumeOffOutline.svg")
});
export var IconVolumeUpFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVolumeUpFilled.svg")
});
export var IconVolumeUpOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconVolumeUpOutline.svg")
});
export var IconWalletFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWalletFilled.svg")
});
export var IconWalletOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWalletOutline.svg")
});
export var IconWatchFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWatchFilled.svg")
});
export var IconWatchOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWatchOutline.svg")
});
export var IconWifi2Filled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWifi2Filled.svg")
});
export var IconWifi2Outline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWifi2Outline.svg")
});
export var IconWifiFilled = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWifiFilled.svg")
});
export var IconWifiOutline = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconWifiOutline.svg")
});
export var IconX5PointsReceived = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconX5PointsReceived.svg"),
  multiColor: false
});
export var IconX5PointsSpent = defineUrlIcon({
  url: "".concat(baseServerUrl, "/icons/IconX5PointsSpent.svg"),
  multiColor: false
});