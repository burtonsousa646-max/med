export type { IconComponent, IconPropColor, IconPropSize, LogoComponent } from './IconComponent';
export * from './componentTypes';
export * from './iconNames';
//# sourceMappingURL=index.d.ts.map