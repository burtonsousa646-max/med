import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["getters", "convertButton", "buttons", "className", "shouldRender"],
  _excluded2 = ["attributes", "icon", "label", "ref"];
import { cnBem } from '@carnica/utils';
import React from 'react';
import { withRenderCondition } from '@beef/react';
import { IconInfoOutline } from '@carnica/graphics';
import { Button } from "../../Button";
import { useConvertedItems } from "../../../hooks/useConvertedItems";
import styles from "./styles.module.css";
var cnStatusViewButtons = cnBem('status-view-buttons', styles);
var buttonKeys = ['attributes', 'disabled', 'icon', 'label', 'onClick', 'ref', 'tagName'];
var StatusViewButtonsRender = function StatusViewButtonsRender(_ref) {
  var getters = _ref.getters,
    convertButton = _ref.convertButton,
    _ref$buttons = _ref.buttons,
    buttons = _ref$buttons === void 0 ? [] : _ref$buttons,
    className = _ref.className,
    shouldRender = _ref.shouldRender,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var items = useConvertedItems({
    items: buttons,
    convertItem: convertButton,
    keys: buttonKeys,
    prefix: 'button',
    getters: getters
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnStatusViewButtons(null, [className])
  }, otherProps, {
    "data-t-id": "StatusView-StatusViewButtons"
  }), items.map(function (_ref2, i) {
    var attributes = _ref2.attributes,
      _ref2$icon = _ref2.icon,
      icon = _ref2$icon === void 0 ? IconInfoOutline : _ref2$icon,
      label = _ref2.label,
      ref = _ref2.ref,
      params = _objectWithoutProperties(_ref2, _excluded2);
    return /*#__PURE__*/React.createElement(Button, _extends({}, attributes, params, {
      iconLeft: icon,
      key: cnStatusViewButtons('item', {
        i: i
      }),
      mode: "grid",
      ref: ref,
      size: "l",
      view: i === 0 ? 'primary' : 'secondary-on-primary'
    }), label);
  }));
};
export var StatusViewButtons = withRenderCondition({
  shouldRenderFn: function shouldRenderFn(_ref3) {
    var buttons = _ref3.buttons;
    return !!(buttons !== null && buttons !== void 0 && buttons.length);
  }
})(StatusViewButtonsRender);