import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import { getMixinsList } from "./getMixinsList";
import { getModificatorsList } from "./getModificatorsList";
import { bemPreset } from "./preset";
export var getClassList = function getClassList(b, e, modificators, mix) {
  var entityName = e ? bemPreset.b + b + bemPreset.e + e : bemPreset.b + b;
  var list = [entityName];
  if (modificators) {
    var modPrefix = "".concat(entityName).concat(bemPreset.m);
    list.push.apply(list, _toConsumableArray(getModificatorsList(modPrefix, modificators)));
  }
  if (mix !== undefined) {
    list.push.apply(list, _toConsumableArray(getMixinsList(entityName, mix)));
  }
  return list;
};