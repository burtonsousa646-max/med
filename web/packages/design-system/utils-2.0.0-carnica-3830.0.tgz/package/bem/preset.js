export var bemPreset = {
  b: '',
  e: '__',
  m: '_'
};