import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["badgeOptions", "badgeWrapperOptions"],
  _excluded2 = ["className"];
/* eslint-disable @typescript-eslint/comma-dangle */
import React, { forwardRef } from 'react';
export var defineHOC = function defineHOC(Wrapper) {
  return function (WrappedComponent) {
    return /*#__PURE__*/forwardRef(function (_ref, ref) {
      var badgeOptions = _ref.badgeOptions,
        _ref$badgeWrapperOpti = _ref.badgeWrapperOptions,
        badgeWrapperOptions = _ref$badgeWrapperOpti === void 0 ? {} : _ref$badgeWrapperOpti,
        otherProps = _objectWithoutProperties(_ref, _excluded);
      var Component = WrappedComponent;
      if (!badgeOptions) {
        return /*#__PURE__*/React.createElement(Component, _extends({}, otherProps, {
          ref: ref,
          "data-t-id": "hocs-withBadge"
        }));
      }
      var className = badgeOptions.className,
        badgeParams = _objectWithoutProperties(badgeOptions, _excluded2);
      return /*#__PURE__*/React.createElement(Wrapper, _extends({}, badgeParams, {
        badgeClassName: className
      }, badgeWrapperOptions), /*#__PURE__*/React.createElement(Component, _extends({}, otherProps, {
        ref: ref,
        "data-t-id": "hocs-withBadge"
      })));
    });
  };
};