export type ClassNameList = Array<string | undefined> | string;
export type NoStrictEntityMods = Record<string, boolean | number | string | undefined>;
export interface ClassNameFormatter {
    (): string;
    (mods?: NoStrictEntityMods | null, mix?: ClassNameList): string;
    (elemName: string, elemMix?: ClassNameList): string;
    (elemName: string, elemMods?: NoStrictEntityMods | null, elemMix?: ClassNameList): string;
}
//# sourceMappingURL=types.d.ts.map