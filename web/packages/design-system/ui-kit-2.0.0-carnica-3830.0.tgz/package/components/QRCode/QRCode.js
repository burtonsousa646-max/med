import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
var _excluded = ["children", "image", "className", "size", "imageProps", "scale"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { QR } from '@carnica/fork-react-qr-rounded';
import { withDataConverter } from '@beef/react';
import { Text } from "../Text";
import styles from "./styles.module.css";
import { dataConverter, getLogoSize } from "./utils";
var cnQRCode = cnBem('qrcode', styles);
var renderContent = function renderContent(params) {
  var Image = params.image,
    imageProps = params.imageProps,
    children = params.children,
    size = params.size,
    scale = params.scale;
  if (typeof Image === 'string') {
    var props = imageProps || {};
    return /*#__PURE__*/React.createElement("img", _extends({}, props, {
      alt: props.alt || 'изображение для QR-кода',
      className: cnQRCode('image', [props === null || props === void 0 ? void 0 : props.className]),
      src: Image,
      style: _objectSpread(_objectSpread({}, props.style), {}, _defineProperty({}, '--qr-image-size', "".concat(getLogoSize(size) * scale, "px"))),
      "data-t-id": "components-QRCode"
    }));
  }
  if (Image) {
    return /*#__PURE__*/React.createElement(Image, _extends({}, imageProps || {}, {
      className: cnQRCode('icon', [imageProps === null || imageProps === void 0 ? void 0 : imageProps.className]),
      size: getLogoSize(size) * scale
    }));
  }
  return /*#__PURE__*/React.createElement(Text, {
    align: "center",
    lineHeight: "1em",
    size: 20 * scale
  }, children);
};
var QRCodeRender = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var children = _ref.children,
    image = _ref.image,
    className = _ref.className,
    size = _ref.size,
    imageProps = _ref.imageProps,
    scale = _ref.scale,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(QR, _extends({}, otherProps, {
    className: cnQRCode(null, [className]),
    cutoutElement: /*#__PURE__*/React.createElement("div", {
      className: cnQRCode('container')
    }, renderContent({
      image: image,
      imageProps: imageProps,
      children: children,
      size: size,
      scale: scale
    })),
    ref: ref,
    size: size,
    style: _objectSpread(_defineProperty(_defineProperty({}, '--qr-code-size', "".concat(size, "px")), '--qr-icon-size', "".concat(getLogoSize(size), "px")), otherProps.style)
  }));
});
export var QRCode = withDataConverter(dataConverter)(QRCodeRender);