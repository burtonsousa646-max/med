import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useEffect, useRef, useState } from 'react';

// NOTE: Referrence
// Author Dan Abramov
export function useInterval(callback, delay) {
  var savedCallback = useRef(null);
  var _useState = useState(0),
    _useState2 = _slicedToArray(_useState, 2),
    _id = _useState2[0],
    setId = _useState2[1];
  useEffect(function () {
    savedCallback.current = callback;
  }, [callback]);
  useEffect(function () {
    var tick = function tick() {
      var _savedCallback$curren;
      savedCallback === null || savedCallback === void 0 || (_savedCallback$curren = savedCallback.current) === null || _savedCallback$curren === void 0 || _savedCallback$curren.call(savedCallback);
    };
    if (delay === null) {
      var id = setInterval(tick, delay);
      setId(id);
      return function () {
        clearInterval(id);
      };
    }
    return function () {};
  }, [callback, delay]);
  return function () {
    return clearInterval(_id);
  };
}