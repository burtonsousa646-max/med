import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useEffect, useState } from 'react';
import { getMobileOS } from '@beef/utils';
export var useMobileOS = function useMobileOS() {
  var _useState = useState(null),
    _useState2 = _slicedToArray(_useState, 2),
    os = _useState2[0],
    setOS = _useState2[1];
  useEffect(function () {
    setOS(getMobileOS());
  }, []);
  return os;
};