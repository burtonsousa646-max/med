import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["isOpen", "theme", "portalClassName", "portalRef", "disableScroll", "portalProps", "anchorRef", "focusTrapParams", "onClose", "closeOptions"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useEffect, useRef } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { DIMENSION_TYPE, useBlockScroll, useBreakpoints, useKeys, useLowPerformanceDevice } from '@carnica/utils/hooks';
import { EKeyCodes } from '@carnica/utils/types';
import { AnimatePresence, motion } from 'framer-motion';
import { FocusTrap } from 'focus-trap-react';
import { ThemedPortal } from "../../modules/ThemedPortal";
import { BottomSheet } from "../../modules/BottomSheet";
import styles from "./styles.module.css";
import { ModalContent } from "./ModalContent";
var cnModal = cnBem('modal', styles);
var defaultCloseOptions = {
  overlay: true,
  button: true,
  escape: true
};
export var Modal = /*#__PURE__*/forwardRef(function (props, ref) {
  var isOpen = props.isOpen,
    theme = props.theme,
    portalClassName = props.portalClassName,
    portalRef = props.portalRef,
    _props$disableScroll = props.disableScroll,
    disableScroll = _props$disableScroll === void 0 ? true : _props$disableScroll,
    portalProps = props.portalProps,
    anchorRef = props.anchorRef,
    focusTrapParams = props.focusTrapParams,
    onClose = props.onClose,
    _props$closeOptions = props.closeOptions,
    closeOptions = _props$closeOptions === void 0 ? defaultCloseOptions : _props$closeOptions,
    otherProps = _objectWithoutProperties(props, _excluded);
  var containerRef = useRef(null);
  var _useBreakpoints = useBreakpoints(),
    _useBreakpoints2 = _slicedToArray(_useBreakpoints, 1),
    dimension = _useBreakpoints2[0];
  var isLowPerformance = useLowPerformanceDevice();
  useKeys(_defineProperty({}, EKeyCodes.Escape, function (e) {
    return isOpen && closeOptions.escape && (onClose === null || onClose === void 0 ? void 0 : onClose(e));
  }));
  useBlockScroll(disableScroll && isOpen);
  var isMobile = dimension === DIMENSION_TYPE.MOBILE;

  // Фокусируемся на элементе которое вызывало событие открытия окна
  useEffect(function () {
    return function () {
      if (isOpen) {
        var _anchorRef$current;
        anchorRef === null || anchorRef === void 0 || (_anchorRef$current = anchorRef.current) === null || _anchorRef$current === void 0 || _anchorRef$current.focus();
      }
    };
  }, [isOpen]);

  // Необходимо для того чтобы не скакала модалка при открытии
  if (!dimension) {
    return null;
  }
  if (isMobile) {
    return /*#__PURE__*/React.createElement(BottomSheet, _extends({}, props, {
      "data-t-id": "components-Modal"
    }), otherProps.children);
  }
  return /*#__PURE__*/React.createElement(AnimatePresence, {
    custom: isOpen,
    initial: false,
    mode: "wait"
  }, isOpen && /*#__PURE__*/React.createElement(FocusTrap, _extends({
    active: isOpen
  }, focusTrapParams, {
    focusTrapOptions: _objectSpread({
      fallbackFocus: function fallbackFocus() {
        var _document;
        return (_document = document) === null || _document === void 0 ? void 0 : _document.body;
      },
      allowOutsideClick: true,
      preventScroll: true
    }, focusTrapParams === null || focusTrapParams === void 0 ? void 0 : focusTrapParams.focusTrapOptions)
  }), /*#__PURE__*/React.createElement(ThemedPortal, _extends({}, portalProps || {}, {
    "aria-modal": true,
    className: cnModal(null, [portalClassName]),
    motion: true,
    ref: combineRefs([portalRef, containerRef]),
    role: "dialog",
    theme: theme,
    "data-t-id": "components-Modal"
  }), /*#__PURE__*/React.createElement(motion.div, {
    animate: {
      opacity: 1
    },
    "aria-hidden": true,
    className: cnModal('overlay', {
      lowPerformance: isLowPerformance
    }),
    exit: {
      opacity: 0
    },
    initial: {
      opacity: 0
    },
    role: "presentation"
  }), /*#__PURE__*/React.createElement(ModalContent, _extends({
    closeOptions: closeOptions,
    containerRef: containerRef,
    isOpen: isOpen,
    onClose: onClose,
    ref: ref
  }, otherProps, {
    "data-t-id": "components-Modal"
  })))));
});