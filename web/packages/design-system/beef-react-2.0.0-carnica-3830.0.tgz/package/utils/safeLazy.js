import React from 'react';
import { ErrorBoundary } from "../components/ErrorBoundary";
var DefaultFallback = /*#__PURE__*/React.createElement("div", {
  id: "default-fallback",
  "data-t-id": "src-utils"
});
var onError = function onError(e, i) {
  console.error('SafeLazy ErrorBoundary Fired');
  // eslint-disable-next-line no-console
  console.dir(e);
  // eslint-disable-next-line no-console
  console.dir(i);
};

/**
 * You shouldn't use React.lazy for initial render
 * Only for deferred render (modals, async content, async vendor modules)
 * NEVER pass falsy value for the serverSideFire parameter
 * Only in EMERGENCY cases use during initial rendering (including server side rendering) serverSideFire parameter as falsy
 * But most likely you will be FIRED
 */
export function safeLazy(dynamicImport) {
  var fallback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : DefaultFallback;
  var serverSideFire = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  // Client Side
  if (typeof window !== 'undefined') {
    return function (props) {
      var Component = React.useRef(/*#__PURE__*/React.lazy(dynamicImport)).current;
      return /*#__PURE__*/React.createElement(ErrorBoundary, {
        fallback: fallback,
        onError: onError
      }, /*#__PURE__*/React.createElement(React.Suspense, {
        fallback: fallback
      }, /*#__PURE__*/React.createElement(Component, props)));
    };
  }

  // Server Side
  return function () {
    if (serverSideFire) {
      throw Error("You shouldn't use React.lazy for initial render. Only for deferred render (modals, async content, async vendor modules)");
    }
    return fallback;
  };
}