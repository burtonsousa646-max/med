import { isValidElementType } from 'react-is';

/**
 * Wraps parametrized HOC function allowing to call it both with param, or without it, as follows:
 * - HOC(params)(WrappedComponent)
 * - HOC(WrappedComponents)
 *
 * WARNING: функция под удаление, вместо ее вызова лучше напрямую экспортировать версии без параметров и с параметрами
 */

export function allowParamOmit(hoc) {
  return function (arg) {
    return isValidElementType(arg) ? hoc()(arg) : hoc(arg);
  };
}