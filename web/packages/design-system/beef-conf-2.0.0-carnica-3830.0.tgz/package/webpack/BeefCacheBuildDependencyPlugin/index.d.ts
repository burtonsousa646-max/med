export class BeefCacheBuildDependencyPlugin {
    constructor(options?: {});
    options: {};
    apply(compiler: any): void;
}
//# sourceMappingURL=index.d.ts.map