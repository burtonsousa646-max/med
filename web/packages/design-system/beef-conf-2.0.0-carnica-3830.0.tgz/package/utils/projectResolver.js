const fs = require('fs');
const path = require('path');
const {
  configRootResolverSync
} = require('./configResolvers');

/**
 * Smart project resolver, returns list of all references tsconfigs according to tsc algorithms
 * @param cwd
 */
const resolveProjectReferences = cwd => {
  const projectRoot = configRootResolverSync('lerna.json', cwd) || configRootResolverSync('tsconfig.json', cwd);
  const rootTsConfig = path.resolve(projectRoot, './tsconfig.json');
  const json = JSON.parse(fs.readFileSync(rootTsConfig).toString());
  if (json.references) {
    return [path.resolve(projectRoot, 'tsconfig.json'), ...json.references.map(ref => path.resolve(projectRoot, ref.path, 'tsconfig.json'))];
  }
  return [rootTsConfig];
};
module.exports = {
  resolveProjectReferences
};