import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { canUseDom } from "./canUseDom";
var APPEND_ORDER = 'data-carnica-order';
var APPEND_PRIORITY = 'data-carnica-priority';
var MARK_KEY = 'carnica-util-key';
var containerCache = new Map();
var getMark = function getMark(mark) {
  if (mark) {
    return mark.startsWith('data-') ? mark : "data-".concat(mark);
  }
  return MARK_KEY;
};
var getContainer = function getContainer(option) {
  if (option.attachTo) {
    return option.attachTo;
  }
  var head = document.querySelector('head');
  return head || document.body;
};
var getOrder = function getOrder(prepend) {
  if (prepend === 'queue') {
    return 'prependQueue';
  }
  return prepend ? 'prepend' : 'append';
};
var findStyles = function findStyles(container) {
  return Array.from((containerCache.get(container) || container).children).filter(function (node) {
    return node.tagName === 'STYLE';
  });
};
export var injectCSS = function injectCSS(css) {
  var option = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (!canUseDom()) {
    return null;
  }
  var csp = option.csp,
    prepend = option.prepend,
    _option$priority = option.priority,
    priority = _option$priority === void 0 ? 0 : _option$priority;
  var mergedOrder = getOrder(prepend);
  var isPrependQueue = mergedOrder === 'prependQueue';
  var styleNode = document.createElement('style');
  styleNode.setAttribute(APPEND_ORDER, mergedOrder);
  if (isPrependQueue && priority) {
    styleNode.setAttribute(APPEND_PRIORITY, "".concat(priority));
  }
  if (csp !== null && csp !== void 0 && csp.nonce) {
    styleNode.nonce = csp === null || csp === void 0 ? void 0 : csp.nonce;
  }
  styleNode.innerHTML = css;
  var container = getContainer(option);
  var firstChild = container.firstChild;
  if (!prepend) {
    container.appendChild(styleNode);
    return styleNode;
  }
  if (isPrependQueue) {
    var existStyle = (option.styles || findStyles(container)).filter(function (node) {
      // Ignore style which not injected by rc-util with prepend
      if (!['prepend', 'prependQueue'].includes(node.getAttribute(APPEND_ORDER))) {
        return false;
      }

      // Ignore style which priority less then new style
      var nodePriority = Number(node.getAttribute(APPEND_PRIORITY) || 0);
      return priority >= nodePriority;
    });
    if (existStyle.length) {
      container.insertBefore(styleNode, existStyle[existStyle.length - 1].nextSibling);
      return styleNode;
    }
  }

  // Use `insertBefore` as `prepend`
  container.insertBefore(styleNode, firstChild);
  return styleNode;
};
var findExistNode = function findExistNode(key) {
  var option = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var styles = option.styles;
  styles || (styles = findStyles(getContainer(option)));
  return styles.find(function (node) {
    return node.getAttribute(getMark(option === null || option === void 0 ? void 0 : option.mark)) === key;
  });
};
export default function contains(root, n) {
  if (!root) {
    return false;
  }

  // Use native if support
  if (root.contains) {
    return root.contains(n || null);
  }

  // `document.contains` not support with IE11
  var node = n;
  while (node) {
    if (node === root) {
      return true;
    }
    node = node.parentNode;
  }
  return false;
}
var syncRealContainer = function syncRealContainer(container, option) {
  var cachedRealContainer = containerCache.get(container);

  // Find real container when not cached or cached container removed
  if (!cachedRealContainer || !contains(document, cachedRealContainer)) {
    var placeholderStyle = injectCSS('', option);
    if (!(placeholderStyle !== null && placeholderStyle !== void 0 && placeholderStyle.parentNode)) {
      return;
    }
    containerCache.set(container, placeholderStyle.parentNode);
    container.removeChild(placeholderStyle);
  }
};
export var removeCSS = function removeCSS(key) {
  var option = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var existNode = findExistNode(key, option);
  if (existNode) {
    var _getContainer;
    (_getContainer = getContainer(option)) === null || _getContainer === void 0 || _getContainer.removeChild(existNode);
  }
};
export var updateCSS = function updateCSS(css, key) {
  var originOption = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var container = getContainer(originOption);
  var styles = findStyles(container);
  var option = _objectSpread(_objectSpread({}, originOption), {}, {
    styles: styles
  });

  // Sync real parent
  syncRealContainer(container, option);
  var existNode = findExistNode(key, option);
  if (existNode) {
    var _option$csp, _option$csp2;
    if ((_option$csp = option.csp) !== null && _option$csp !== void 0 && _option$csp.nonce && existNode.nonce !== ((_option$csp2 = option.csp) === null || _option$csp2 === void 0 ? void 0 : _option$csp2.nonce)) {
      var _option$csp3;
      existNode.nonce = (_option$csp3 = option.csp) === null || _option$csp3 === void 0 ? void 0 : _option$csp3.nonce;
    }
    if (existNode.innerHTML !== css) {
      existNode.innerHTML = css;
    }
    return existNode;
  }
  var newNode = injectCSS(css, option);
  newNode === null || newNode === void 0 || newNode.setAttribute(getMark(option.mark), key);
  return newNode;
};