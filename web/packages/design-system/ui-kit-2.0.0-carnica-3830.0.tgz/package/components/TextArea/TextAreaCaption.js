import React from 'react';
import { cnBem } from '@carnica/utils';
import { withRenderFlag } from '@beef/react';
import styles from "./styles.module.css";
var cnTextArea = cnBem('textarea', styles);
var TextAreaCaptionRender = function TextAreaCaptionRender(_ref) {
  var caption = _ref.caption,
    maxLength = _ref.maxLength,
    value = _ref.value,
    withLengthCounter = _ref.withLengthCounter;
  if (withLengthCounter && maxLength) {
    return /*#__PURE__*/React.createElement("div", {
      className: cnTextArea('caption'),
      "data-t-id": "components-TextArea"
    }, /*#__PURE__*/React.createElement("span", null, caption), /*#__PURE__*/React.createElement("span", null, "".concat((value === null || value === void 0 ? void 0 : value.length) || 0, "/").concat(maxLength)));
  }
  return caption || null;
};
export var TextAreaCaption = withRenderFlag(TextAreaCaptionRender);