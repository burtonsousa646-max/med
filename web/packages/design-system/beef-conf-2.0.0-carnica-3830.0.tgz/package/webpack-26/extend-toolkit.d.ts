import type { WebpackBuilderUtils } from './types';
export type IsObject<T> = T extends object ? T extends ((...args: any[]) => any) | readonly any[] ? false : true : false;
export type MergeObjectValues<A, B> = {
    [K in keyof A | keyof B]: K extends keyof B ? B[K] : K extends keyof A ? A[K] : never;
};
export type MergeValue<A, B> = IsObject<A> extends true ? IsObject<B> extends true ? MergeObjectValues<A, B> : B : B;
export type MergeBuilders<A extends object, B extends object> = {
    [K in keyof A | keyof B]: K extends keyof B ? K extends keyof A ? MergeValue<A[K], B[K]> : B[K] : K extends keyof A ? A[K] : never;
};
export declare function extendToolkit<I extends Partial<WebpackBuilderUtils>, O extends Partial<WebpackBuilderUtils>>(base: I, factory: (base: I) => O): MergeBuilders<I, O>;
//# sourceMappingURL=extend-toolkit.d.ts.map