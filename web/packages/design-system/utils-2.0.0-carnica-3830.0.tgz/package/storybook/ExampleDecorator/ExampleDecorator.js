import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
var _excluded = ["children", "className", "direction", "background", "themeVersion", "withoutControls"];
import React, { useState } from 'react';
import { cnBem } from "../../bem";
import styles from "./styles.module.css";
import { ThemeProvider, useThemeContext } from "./ThemeProvider";
import themeV1 from "./ThemeProvider/themeV1.module.css";
import themeV2 from "./ThemeProvider/themeV2.module.css";
import { themeItems, versionItems } from "./utils";
import { Toggler } from "./Toggle";
var cnExample = cnBem('example', styles);
var ThemeToggle = function ThemeToggle() {
  var _useThemeContext = useThemeContext(),
    _useThemeContext2 = _slicedToArray(_useThemeContext, 2),
    theme = _useThemeContext2[0],
    setTheme = _useThemeContext2[1];
  return /*#__PURE__*/React.createElement(Toggler, {
    items: themeItems,
    onChange: setTheme,
    value: theme,
    "data-t-id": "storybook-ExampleDecorator"
  });
};
var getThemeStyles = function getThemeStyles(version) {
  if (version === 'v1') {
    return {
      light: themeV1,
      dark: themeV1
    };
  }
  return {
    light: themeV2,
    dark: themeV2
  };
};
export var ExampleDecorator = function ExampleDecorator(_ref) {
  var children = _ref.children,
    className = _ref.className,
    direction = _ref.direction,
    _ref$background = _ref.background,
    background = _ref$background === void 0 ? 'primary' : _ref$background,
    themeVersion = _ref.themeVersion,
    withoutControls = _ref.withoutControls,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var _useState = useState(themeVersion !== null && themeVersion !== void 0 ? themeVersion : 'v2'),
    _useState2 = _slicedToArray(_useState, 2),
    version = _useState2[0],
    setVersion = _useState2[1];
  return /*#__PURE__*/React.createElement(ThemeProvider, {
    className: cnExample({
      background: background,
      version: version
    }, ['sb-unstyled']),
    themeStyles: getThemeStyles(version)
  }, function (theme) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, !withoutControls && /*#__PURE__*/React.createElement("div", {
      className: cnExample('top')
    }, /*#__PURE__*/React.createElement(ThemeToggle, null), !themeVersion && /*#__PURE__*/React.createElement(Toggler, {
      items: versionItems,
      onChange: setVersion,
      value: version
    })), /*#__PURE__*/React.createElement("div", _extends({
      className: cnExample('container', {
        direction: direction
      }, [className])
    }, otherProps), typeof children === 'function' ? children(theme, version) : children), /*#__PURE__*/React.createElement("div", {
      className: cnExample('bg')
    }));
  });
};