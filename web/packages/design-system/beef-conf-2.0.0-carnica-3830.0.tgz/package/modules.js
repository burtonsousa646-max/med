/** re-export modules so that they can be used in other packages with local dependencies */
module.exports.webpack = require('webpack');