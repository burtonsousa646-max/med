import { useResizeObserved } from "../useResizeObserved";
import { getElementSize } from "./helpers";
export var useComponentSize = function useComponentSize(ref, deps) {
  return useResizeObserved([ref], getElementSize, deps)[0];
};