import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["title", "subtitle", "icon", "deleteMode", "onRemove", "error", "loading", "view", "className", "disabled"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import React, { useCallback, useRef } from 'react';
import { useFlag } from '@carnica/utils/hooks';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { FileContent } from "./FileContent";
import { FileDelete } from "./FileDelete";
var cnFile = cnBem('file', styles);
var DEFAULT_TIME = 5; // время в секундах для отмены удаления

export var File = forwardRefWithMotionTag(function (props, ref) {
  var title = props.title,
    subtitle = props.subtitle,
    icon = props.icon,
    _props$deleteMode = props.deleteMode,
    deleteMode = _props$deleteMode === void 0 ? 'undoable' : _props$deleteMode,
    onRemove = props.onRemove,
    error = props.error,
    loading = props.loading,
    _props$view = props.view,
    view = _props$view === void 0 ? 'primary' : _props$view,
    className = props.className,
    disabled = props.disabled,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(false),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isRemoveView = _useFlag2[0],
    setIsRemoveView = _useFlag2[1];
  var timerRef = useRef(null);
  var handleRemove = useCallback(function (e) {
    if (deleteMode === 'undoable') {
      setIsRemoveView.on();
      timerRef.current = setTimeout(function () {
        return onRemove === null || onRemove === void 0 ? void 0 : onRemove(e);
      }, DEFAULT_TIME * 1000 + 300);
    } else {
      onRemove === null || onRemove === void 0 || onRemove(e);
    }
  }, [onRemove, deleteMode]);
  var onCancel = function onCancel() {
    setIsRemoveView.off();
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
  };
  var showLoader = typeof loading === 'number' ? loading >= 0 : !!loading;
  var ariaParams = isRemoveView ? {
    role: 'status',
    'aria-live': 'assertive',
    'aria-atomic': true,
    'aria-label': 'Подтверждение удаления'
  } : {
    'aria-busy': Boolean(loading)
  };
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, ariaParams, otherProps, otherProps.tagName === 'button' ? {
    disabled: disabled
  } : {}, {
    className: cnFile({
      view: view,
      error: !!error
    }, [className]),
    ref: ref,
    style: _objectSpread(_objectSpread({}, otherProps.style), {}, _defineProperty({}, '--file-loader-progress', typeof loading === 'number' ? Math.max(Math.min(100, loading), 0) : 0)),
    "data-t-id": "components-File"
  }), showLoader && !isRemoveView && /*#__PURE__*/React.createElement("div", {
    "aria-label": "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0444\u0430\u0439\u043B\u0430 ".concat(typeof title === 'string' ? title : ''),
    "aria-live": "polite",
    "aria-valuemax": 100,
    "aria-valuemin": 0,
    "aria-valuenow": typeof loading === 'number' ? loading : undefined,
    className: cnFile('loader', {
      mode: typeof loading === 'number' ? 'percent' : 'infinite'
    }),
    role: "progressbar"
  }), isRemoveView ? /*#__PURE__*/React.createElement(FileDelete, {
    onCancel: onCancel,
    seconds: DEFAULT_TIME,
    tagName: otherProps.tagName
  }) : /*#__PURE__*/React.createElement(FileContent, {
    disabled: disabled,
    error: error,
    icon: icon,
    onRemove: handleRemove,
    subtitle: subtitle,
    tagName: otherProps.tagName,
    title: title
  }));
});