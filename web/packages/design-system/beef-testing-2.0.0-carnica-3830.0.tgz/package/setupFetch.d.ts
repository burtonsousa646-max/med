export {};
//# sourceMappingURL=setupFetch.d.ts.map