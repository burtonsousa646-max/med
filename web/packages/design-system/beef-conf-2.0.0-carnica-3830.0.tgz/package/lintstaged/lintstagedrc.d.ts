declare const _exports: {
    '!({package,tsconfig}.json)*.{js,jsx,ts,tsx,json}': string;
    '*.{ts,tsx}': string;
    '*.md': string;
    '*.pcss': string;
};
export = _exports;
//# sourceMappingURL=lintstagedrc.d.ts.map