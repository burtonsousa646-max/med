import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "loading", "hasItems", "children"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { Spinner } from "../../Spinner";
import { MotionComponent } from "../../../modules/MotionComponent";
import styles from "./styles.module.css";
var cnActionSheetWrapper = cnBem('action-sheet--wrapper', styles);
var ActionSheetWrapperRender = function ActionSheetWrapperRender(_ref, ref) {
  var className = _ref.className,
    loading = _ref.loading,
    hasItems = _ref.hasItems,
    children = _ref.children,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnActionSheetWrapper({
      loading: loading,
      hasItems: hasItems
    }, [className]),
    ref: ref,
    "data-t-id": "ActionSheet-ActionSheetWrapper"
  }), loading ? /*#__PURE__*/React.createElement("div", {
    className: cnActionSheetWrapper('loader')
  }, /*#__PURE__*/React.createElement(Spinner, {
    "aria-label": "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0441\u043F\u0438\u0441\u043A\u0430",
    view: "yellow-white"
  })) : children);
};
export var ActionSheetWrapper = /*#__PURE__*/forwardRef(ActionSheetWrapperRender);