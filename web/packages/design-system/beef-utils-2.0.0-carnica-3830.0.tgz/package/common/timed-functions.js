import _typeof from "@babel/runtime/helpers/typeof";
/**
 * Стандартные популярные реализации throttle/debounce
 * Обвешанные гардами на случай неправильного вызова (на время миграции)
 */

import debounceOriginal from 'debounce';
import throttleOriginal from 'throttleit';
var isNum = function isNum(val) {
  return typeof val === 'number';
};
var isNumOrUndefined = function isNumOrUndefined(val) {
  return isNum(val) || typeof val === 'undefined';
};
var isFun = function isFun(val) {
  return typeof val === 'function';
};
var isDelayObject = function isDelayObject(val) {
  return _typeof(val) === 'object' && val !== null && 'delay' in val;
};
export function debounce(f, interval, options) {
  if (isNumOrUndefined(f) && isFun(interval)) {
    console.error('@Deprecated Обнаружен старый формат вызова debounce(50, fn). Используйте debounce(fn, 50)');
    return debounceOriginal(interval, f, options);
  }
  if (!isFun(f) || !isNumOrUndefined(interval)) {
    console.error('Неизвестный формат вызова debounce. Используйте debounce(fn, 50?, options?)');
  }
  return debounceOriginal(f, interval, options);
}
export function throttle(f, interval) {
  if (isFun(interval)) {
    if (isDelayObject(f)) {
      console.error('@Deprecated Обнаружен старый формат вызова throttle({ delay: 50 }, fn). Используйте throttle(fn, 50)');
      return throttleOriginal(interval, f.delay);
    }
    if (isNum(f)) {
      console.error('@Deprecated Обнаружен старый формат вызова throttle(50, fn). Используйте throttle(fn, 50)');
      return throttleOriginal(interval, f);
    }
    return throttleOriginal(f, interval);
  }
  if (!isFun(f) || !isNum(interval)) {
    console.error('Неизвестный формат вызова throttle. Используйте throttle(fn, 50)');
  }
  return throttleOriginal(f, interval);
}