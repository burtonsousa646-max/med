/* eslint-disable react-hooks/rules-of-hooks */
const {
  getResolveAliases,
  usePlugin,
  detectEnv,
  getLinkedModules
} = require('./babelHelpers');
const {
  browsers,
  isModuleAvailable,
  resolveSymlinkedModuleDir
} = require('../utils');
module.exports = (configDir, custom = {}) => function babelConfig(api) {
  const cwd = resolveSymlinkedModuleDir(configDir);
  const {
    ignore = [],
    ...restCustomOptions
  } = custom;
  const {
    isProduction,
    isNode,
    isHMR,
    isPublish,
    modules
  } = detectEnv(api);
  api.cache(true);
  return {
    presets: [usePlugin('@babel/preset-env', {
      /**
       * По умолчанию env использует modules: 'auto'
       * Так и должно остаться - в этом случае вызывающий инструмент сам определяет необходимый формат
       */
      modules,
      targets: isNode ? {
        node: 'current'
      } : {
        browsers
      }
    }), usePlugin('@babel/preset-typescript', {
      allExtensions: true,
      isTSX: true,
      allowDeclareFields: true
    }), usePlugin('@babel/preset-react')].filter(Boolean),
    plugins: [usePlugin('babel-plugin-module-resolver', {
      cwd,
      extensions: ['.js', '.jsx', '.ts', '.tsx'],
      alias: getResolveAliases(cwd)
    }), usePlugin('babel-plugin-module-rewrite', {
      cwd,
      linkedModuleDirs: getLinkedModules(cwd),
      replaceFunc: require.resolve('./module-rewrite.js')
    }),
    /**
     * NOTE: В прошлом по какой-то причине плагин отключался для не nodejs проектов.
     * В результате при попытке опубликовать пакеты с декораторами, они не преобразовывались
     * В связи с этим пришлось снова активировать их для всех сборок
     */
    usePlugin('babel-plugin-transform-typescript-metadata'), usePlugin('@babel/plugin-proposal-decorators', {
      version: 'legacy'
    }), usePlugin('@babel/plugin-transform-class-properties'), usePlugin('@babel/plugin-transform-runtime', {
      helpers: true,
      regenerator: !isNode
    }), usePlugin('babel-plugin-const-enum', undefined, !isNode), /** Оба transform-плагина включены одновременно для web и для node с целью поддержки гибридной кодовой базы */
    usePlugin('babel-plugin-transform-react-remove-prop-types', {
      mode: 'wrap'
    }, isProduction), usePlugin('react-refresh/babel', undefined, isModuleAvailable('react-refresh/babel') && !isNode && isHMR), usePlugin('babel-plugin-react-generate-property', {
      customProperty: 'data-t-id',
      customSeparator: '-',
      omitFileName: true,
      dirLevel: 2,
      ignoreNodeNames: true,
      firstChildOnly: true
    }), usePlugin('babel-plugin-transform-rename-import', {
      original: '^(.+?)\\.pcss$',
      replacement: '$1.module.css'
    }, isPublish)].filter(Boolean),
    ignore: [/\/core-js/, ...ignore],
    /**
     * Only applied to .js due to super special case:
     * When a .ts file only uses `export type` directives, the file is considered commonjs
     */
    overrides: [{
      test: /.js$/,
      /** lets babel detect if file is cjs or ts */
      sourceType: 'unambiguous'
    }],
    ...restCustomOptions
  };
};