export = FriendlyErrorOverlayWebpackPlugin;
declare class FriendlyErrorOverlayWebpackPlugin {
    constructor({ errorFilters }?: {});
    options: {
        errorFilters: any[];
    };
    apply(compiler: any): void;
}
//# sourceMappingURL=index.d.ts.map