export var getElementSize = function getElementSize(el) {
  if (!el) {
    return {
      width: 0,
      height: 0
    };
  }
  var _el$getBoundingClient = el.getBoundingClientRect(),
    width = _el$getBoundingClient.width,
    height = _el$getBoundingClient.height;
  return {
    width: width,
    height: height
  };
};