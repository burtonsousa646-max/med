export declare let parser: string;
declare let _extends: any[];
export { _extends as extends };
//# sourceMappingURL=js-recommended.d.ts.map