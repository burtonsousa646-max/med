import React from 'react';
export declare const withClientRendering: <C extends React.ComponentType<any>>(component: C) => React.FC<React.ComponentProps<C> & {}>;
//# sourceMappingURL=withClientRendering.d.ts.map