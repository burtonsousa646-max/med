module.exports = {
  plugins: ['import', 'jsx-a11y', 'perfectionist', 'prettier', 'react', 'react-hooks', 'testing-library', 'sonarjs', '@typescript-eslint'],
  env: {
    browser: true,
    jest: true,
    node: true,
    es2020: true
  },
  settings: {
    // Should be careful with import/cache, it speeds eslint up 1.5-2 times,
    //   but may cause side effects on the way, especially with automated eslint_d runners
    'import/cache': {
      lifetime: 'Infinity'
    },
    'import/extensions': ['.js', '.mjs', '.jsx', '.ts', '.tsx', '.d.ts'],
    'import/resolver': {
      'babel-module': {
        babelOptions: {
          rootMode: 'upward-optional'
        }
      },
      node: {},
      exports: {}
    }
  },
  ignorePatterns: ['**/node_modules/**', '**/dist/**', '!**/.storybook/**/*', 'package.json', 'tsconfig.json']
};