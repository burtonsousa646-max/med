import React from 'react';
export type UseComponentSizePropSize = Pick<DOMRect, 'height' | 'width'>;
export type UseComponentSize = (ref: React.RefObject<HTMLElement | SVGGraphicsElement | null>, deps?: unknown[]) => UseComponentSizePropSize;
//# sourceMappingURL=types.d.ts.map