export function resolveSymlinkedModuleDir(sourcePath: any, cwd?: string): string | null | undefined;
export function createRequireLinked(sourcePath: any): NodeJS.Require;
//# sourceMappingURL=resolveSymlinked.d.ts.map