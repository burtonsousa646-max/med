const inquirer = require('inquirer');
const promptConfirmation = message => {
  return inquirer.prompt([{
    type: 'expand',
    name: 'confirm',
    message,
    default: 2,
    choices: [{
      key: 'y',
      name: 'Yes',
      value: true
    }, {
      key: 'n',
      name: 'No',
      value: false
    }]
  }]).then(answers => {
    return answers.confirm;
  });
};
const promptSelectOne = (message, choices) => {
  return inquirer.prompt([{
    type: 'list',
    name: 'prompt',
    message,
    choices,
    pageSize: choices?.length
  }]).then(answers => {
    return answers.prompt;
  });
};
module.exports = {
  promptSelectOne,
  promptConfirmation
};