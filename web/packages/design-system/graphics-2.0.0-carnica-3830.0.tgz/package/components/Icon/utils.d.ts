import { MotionTagProps, MotionTags } from '@carnica/utils/types';
import { IconMainProps } from './types';
export declare const getColor: (color: string) => string;
type Result = Omit<MotionTagProps<IconMainProps & {
    mode: 'background' | 'mask';
}, MotionTags, 'span', false>, 'color' | 'customColor' | 'multiColor' | 'ratio' | 'size'>;
export declare const dataConverter: ({ multiColor, size, style, ratio, customColor, color, className, tagName, ...otherProps }: MotionTagProps<IconMainProps, MotionTags, "span", false>) => Result;
export {};
//# sourceMappingURL=utils.d.ts.map