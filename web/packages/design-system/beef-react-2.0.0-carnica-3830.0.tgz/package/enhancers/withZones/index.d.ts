import { TWithZonesLayoutType, TWithZonesReturnType } from '@beef/react/types';
export declare function withZones<PKey extends string>(allowedNames: PKey[]): <PProps extends Record<string, unknown>>(WrappedComponent: TWithZonesLayoutType<PKey, PProps>) => TWithZonesReturnType<PKey, PProps>;
//# sourceMappingURL=index.d.ts.map