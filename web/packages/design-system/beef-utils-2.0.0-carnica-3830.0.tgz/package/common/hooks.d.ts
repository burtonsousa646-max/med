import { RefObject } from 'react';
export declare const useOnScreen: (ref: RefObject<HTMLDivElement | null>) => boolean;
export declare const useOnScreenEffect: (callback: () => void, dependencies?: never[]) => RefObject<any>;
//# sourceMappingURL=hooks.d.ts.map