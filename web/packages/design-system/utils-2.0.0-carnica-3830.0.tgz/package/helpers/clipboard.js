export var canUseShare = function canUseShare() {
  return typeof window !== 'undefined' && 'share' in navigator;
};
export var canUseClipboard = function canUseClipboard() {
  return typeof window !== 'undefined' && 'clipboard' in navigator;
};
export var shareData = function shareData(data) {
  if (canUseShare()) {
    navigator.share(data).catch(function (err) {
      return console.error(err);
    });
  }
};
export var clipboardData = function clipboardData(_ref) {
  var text = _ref.text,
    onFinally = _ref.onFinally,
    _ref$interval = _ref.interval,
    interval = _ref$interval === void 0 ? 2000 : _ref$interval;
  if (canUseClipboard()) {
    navigator.clipboard.writeText(text).then(function () {
      onFinally(true);
      var intervalAlert = setTimeout(function () {
        onFinally(false);
        clearInterval(intervalAlert);
      }, interval);
    }).catch(function (err) {
      return console.error(err);
    });
  }
};