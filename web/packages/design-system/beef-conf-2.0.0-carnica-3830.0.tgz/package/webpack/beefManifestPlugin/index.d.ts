import { getCompilerHooks } from "./hooks";
export class BeefManifestPlugin {
    constructor(opts: any);
    options: any;
    apply(compiler: any): void;
}
export { getCompilerHooks };
//# sourceMappingURL=index.d.ts.map