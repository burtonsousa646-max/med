import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["method", "originalResponse", "responseType", "timeout", "withCredentials"],
  _excluded2 = ["headers", "originalResponse", "skipWaffleInterceptor"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import axios from 'axios';
import { createWaffleInterceptor } from "./interceptors";
export function axiosBaseRequest(_ref) {
  var _ref$method = _ref.method,
    method = _ref$method === void 0 ? 'get' : _ref$method,
    _ref$originalResponse = _ref.originalResponse,
    originalResponse = _ref$originalResponse === void 0 ? false : _ref$originalResponse,
    _ref$responseType = _ref.responseType,
    responseType = _ref$responseType === void 0 ? 'json' : _ref$responseType,
    _ref$timeout = _ref.timeout,
    timeout = _ref$timeout === void 0 ? 40000 : _ref$timeout,
    _ref$withCredentials = _ref.withCredentials,
    withCredentials = _ref$withCredentials === void 0 ? true : _ref$withCredentials,
    config = _objectWithoutProperties(_ref, _excluded);
  var response = axios(_objectSpread({
    method: method,
    responseType: responseType,
    timeout: timeout,
    withCredentials: withCredentials
  }, config)).catch(createWaffleInterceptor());
  return originalResponse ? response : response.then(function (_ref2) {
    var data = _ref2.data;
    return data;
  });
}

/**
 * Обертка добавляет в запрос хидер X-Requested-With: XMLHttpRequest
 * Нужно для того, чтобы b2c-бэк воспринимал реквест как ajax
 * Иначе возможны баги в АЗ при обращении с другой витрины
 */

export function axiosBeelineRequest(_ref3) {
  var headers = _ref3.headers,
    _ref3$originalRespons = _ref3.originalResponse,
    originalResponse = _ref3$originalRespons === void 0 ? false : _ref3$originalRespons,
    _ref3$skipWaffleInter = _ref3.skipWaffleInterceptor,
    skipWaffleInterceptor = _ref3$skipWaffleInter === void 0 ? false : _ref3$skipWaffleInter,
    config = _objectWithoutProperties(_ref3, _excluded2);
  /** Позволяет автоматически определить какой тип подставить, так как тип меняется в зависимости от флажка */
  originalResponse = originalResponse;
  return axiosBaseRequest(_objectSpread(_objectSpread({}, config), {}, {
    originalResponse: originalResponse,
    skipWaffleInterceptor: skipWaffleInterceptor,
    headers: _objectSpread(_objectSpread({}, headers), {}, {
      'X-Requested-With': 'XMLHttpRequest'
    })
  }));
}