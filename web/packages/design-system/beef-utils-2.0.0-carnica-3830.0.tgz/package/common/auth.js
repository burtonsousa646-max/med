export var LOGIN_TYPES = {
  mobile: 'mobile',
  mobileConvergence: 'mobileConvergence',
  login: 'login',
  b2b: 'b2b',
  unknown: 'unknown'
};
export var LOGIN_TYPES_ANALYTICS = {
  mobile: 'mobile',
  // Мобильная связь
  fttb: 'fttb',
  // ШПД
  fmc: 'fmc',
  // Конвергент
  none: 'none' // Если пользователь не авторизован
};
export var getAccountType = function getAccountType(user) {
  if (!user) return LOGIN_TYPES_ANALYTICS.none;
  var isMobile = user.isMobile,
    isConvergent = user.isConvergent;
  if (isConvergent) {
    return LOGIN_TYPES_ANALYTICS.fmc;
  }
  if (isMobile) {
    return LOGIN_TYPES_ANALYTICS.mobile;
  }
  return LOGIN_TYPES_ANALYTICS.fttb;
};