const {
  resolvePlugin,
  isFixMode
} = require('../utils');
module.exports = {
  extends: ['plugin:testing-library/react', ...[isFixMode ? '../rules/autofix-broken' : null].filter(Boolean).map(resolvePlugin)]
};