import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
var _excluded = ["date", "label"];
import React, { useRef } from 'react';
import { cnBem } from '@carnica/utils';
import { useComponentSize } from '@carnica/utils/hooks';
import { motion } from 'framer-motion';
import { useCalendarGridKeyboardHandler } from "../../hooks/useCalendarGridKeyboardHandler";
import { useYearsScroll } from "../../hooks/useYearsScroll";
import { Cell } from "../../Cell";
import styles from "./styles.module.css";
import { Grid } from "../../Grid";
import { useDatePeriodList } from "../../hooks/useDatePeriodList";
var cnCalendarBlockYear = cnBem('years-block', styles);
export var CalendarBlockYear = function CalendarBlockYear(props) {
  var currentVisibleDate = props.currentVisibleDate,
    setCurrentVisibleDate = props.setCurrentVisibleDate,
    minDate = props.minDate,
    maxDate = props.maxDate,
    locale = props.locale,
    value = props.value,
    isComposed = props.isComposed,
    isAnimationFinished = props.isAnimationFinished,
    disableDates = props.disableDates,
    changeMode = props.changeMode;
  var containerRef = useRef(null);
  var _useComponentSize = useComponentSize(containerRef),
    height = _useComponentSize.height;
  var onKeyDown = function onKeyDown(e) {
    if (e.code === 'Escape') {
      changeMode === null || changeMode === void 0 || changeMode();
    }
  };
  var onYearChoose = function onYearChoose(date) {
    if (!date) {
      return;
    }
    setCurrentVisibleDate === null || setCurrentVisibleDate === void 0 || setCurrentVisibleDate(date);
    changeMode === null || changeMode === void 0 || changeMode();
  };
  var years = useDatePeriodList({
    onChange: onYearChoose,
    type: 'years',
    locale: locale,
    currentVisibleDate: currentVisibleDate,
    disableDates: disableDates,
    maxDate: maxDate,
    minDate: minDate,
    value: value
  });
  var _useCalendarGridKeybo = useCalendarGridKeyboardHandler({
      items: years,
      value: value,
      currentVisibleDate: currentVisibleDate,
      isComposed: isComposed,
      type: 'year',
      isAnimationFinished: isAnimationFinished,
      setCurrentVisibleDate: setCurrentVisibleDate,
      disableDates: disableDates,
      maxDate: maxDate,
      minDate: minDate
    }),
    refs = _useCalendarGridKeybo.refs,
    onKeyDownByIndex = _useCalendarGridKeybo.onKeyDownByIndex;
  useYearsScroll({
    containerRef: containerRef,
    currentVisibleDate: currentVisibleDate,
    isActive: true,
    refs: refs
  });
  return /*#__PURE__*/React.createElement(motion.div, {
    className: cnCalendarBlockYear(),
    onKeyDown: onKeyDown,
    ref: containerRef,
    style: _defineProperty({}, '--wrapper-size', "".concat(height || 370, "px"))
  }, /*#__PURE__*/React.createElement(Grid, {
    className: cnCalendarBlockYear('list'),
    type: "years",
    "data-t-id": "CalendarBlocks-CalendarBlockYear"
  }, years.map(function (item, i) {
    var date = item.date,
      label = item.label,
      params = _objectWithoutProperties(item, _excluded);
    return /*#__PURE__*/React.createElement(Cell, _extends({
      "aria-label": "".concat(label, " \u0433\u043E\u0434"),
      "data-t-date": date.getFullYear(),
      key: date.toDateString(),
      onKeyDown: onKeyDownByIndex(i, item),
      ref: refs[i],
      rootProps: {
        className: cnCalendarBlockYear('year')
      }
    }, params), label);
  })));
};