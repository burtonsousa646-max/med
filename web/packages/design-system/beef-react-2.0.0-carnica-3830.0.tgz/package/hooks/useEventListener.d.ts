import React from 'react';
type TConfig = {
    mode?: AddEventListenerOptions | boolean;
    useLayoutEffect?: boolean;
};
type TDOMEntity = HTMLElement | typeof document | typeof globalThis | typeof window;
export type GenericEventHandler<K extends keyof DocumentEventMap | keyof HTMLElementEventMap | keyof WindowEventMap> = (ev: K extends keyof HTMLElementEventMap ? HTMLElementEventMap[K] : K extends keyof WindowEventMap ? WindowEventMap[K] : K extends keyof DocumentEventMap ? DocumentEventMap[K] : Event) => void;
export declare function useEventListener<K extends keyof DocumentEventMap | keyof HTMLElementEventMap | keyof WindowEventMap>(eventName: K, handler: GenericEventHandler<K>, domTarget?: React.RefObject<HTMLElement | null> | TDOMEntity | null, { mode, useLayoutEffect }?: TConfig): void;
export {};
//# sourceMappingURL=useEventListener.d.ts.map