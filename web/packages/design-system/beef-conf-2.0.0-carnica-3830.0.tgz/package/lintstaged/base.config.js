const {
  getTsCheckEslintConfigPath
} = require('../eslint/utils');
module.exports = (fix = false) => {
  const lintFixOption = fix ? '--fix' : '';
  const prettierFixOption = fix ? '--write' : '';
  const tsCheckConfig = getTsCheckEslintConfigPath();
  return {
    '!({package,tsconfig}.json)*.{js,jsx,ts,tsx,json}': `eslint ${lintFixOption}`,
    '*.{ts,tsx}': `eslint ${lintFixOption} --no-eslintrc --config ${tsCheckConfig}`,
    '*.md': `prettier ${prettierFixOption}`,
    '*.pcss': `stylelint ${lintFixOption}`
  };
};