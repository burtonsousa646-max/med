/**
 * Some exceptions are marked as silent
 * Such as user made custom-exceptions that are handled manually via error-boundaries
 * @param error
 * @returns {boolean} a single true value ignores the error
 */
module.exports = ({
  error
}) => !!error.silent;