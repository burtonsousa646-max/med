import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import React, { createContext, useContext, useMemo, useState } from 'react';
var PickerContext = /*#__PURE__*/createContext({
  selectedIndex: 0,
  setSelectedIndex: function setSelectedIndex() {},
  activeIndex: 0,
  setActiveIndex: function setActiveIndex() {},
  portalRef: {
    current: null
  }
});
export var PickerProvider = function PickerProvider(_ref) {
  var children = _ref.children,
    portalRef = _ref.portalRef,
    _ref$defaultIndex = _ref.defaultIndex,
    defaultIndex = _ref$defaultIndex === void 0 ? 0 : _ref$defaultIndex,
    onClose = _ref.onClose;
  var _useState = useState(defaultIndex),
    _useState2 = _slicedToArray(_useState, 2),
    selectedIndex = _useState2[0],
    setSelectedIndex = _useState2[1];
  var _useState3 = useState(defaultIndex),
    _useState4 = _slicedToArray(_useState3, 2),
    activeIndex = _useState4[0],
    setActiveIndex = _useState4[1];
  var value = useMemo(function () {
    return {
      selectedIndex: selectedIndex,
      setSelectedIndex: setSelectedIndex,
      portalRef: portalRef,
      onClose: onClose,
      activeIndex: activeIndex,
      setActiveIndex: setActiveIndex
    };
  }, [selectedIndex, onClose, activeIndex]);
  return /*#__PURE__*/React.createElement(PickerContext.Provider, {
    value: value
  }, children);
};
export var usePickerContext = function usePickerContext() {
  return useContext(PickerContext);
};