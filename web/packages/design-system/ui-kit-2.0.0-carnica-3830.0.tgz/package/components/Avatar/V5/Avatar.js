import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "contentParams", "size", "view", "badge", "badgeClassName"];
import { cnBem } from '@carnica/utils';
import React, { forwardRef } from 'react';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { MotionComponent } from "../../../modules/MotionComponent";
import { Badge } from "../../Badge/V3";
import styles from "./styles.module.css";
import { AvatarContent } from "./AvatarContent";
import { badgeSizeMap, dataConverter } from "./utils";
var cnAvatar = cnBem('avatar-v5', styles);
var AvatarRender = function AvatarRender(_ref, ref) {
  var className = _ref.className,
    contentParams = _ref.contentParams,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    view = _ref.view,
    badge = _ref.badge,
    badgeClassName = _ref.badgeClassName,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnAvatar({
      size: size,
      disabled: otherProps.disabled,
      view: view
    }, [className]),
    ref: ref,
    "data-t-id": "Avatar-V5"
  }), /*#__PURE__*/React.createElement(AvatarContent, _extends({}, contentParams, {
    "data-t-id": "Avatar-V5"
  })), badge && /*#__PURE__*/React.createElement(Badge, _extends({
    className: cnAvatar('badge'),
    size: badgeSizeMap[size]
  }, badge)));
};
export var Avatar = compose(withDataConverter(dataConverter), forwardRef)(AvatarRender);