import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["color", "type", "disabled", "label", "size", "className", "style"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { Text } from "../../Text";
import styles from "./styles.module.css";
import { getColor, getTextSettings } from "./utils";
var cnCellText = cnBem('cell-text', styles);
export var CellText = /*#__PURE__*/forwardRef(function (props, ref) {
  var _ = props.color,
    type = props.type,
    disabled = props.disabled,
    label = props.label,
    _props$size = props.size,
    size = _props$size === void 0 ? 's' : _props$size,
    className = props.className,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  if (!label) {
    return null;
  }
  var _getTextSettings = getTextSettings(label),
    text = _getTextSettings.text,
    truncate = _getTextSettings.truncate,
    rows = _getTextSettings.rows,
    color = _getTextSettings.color;
  return /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    className: cnCellText(null, [className]),
    ref: ref,
    rows: rows,
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty({}, '--cell-text-color', getColor({
      disabled: disabled,
      type: type,
      color: color
    }))),
    tagName: "span",
    truncate: truncate,
    variant: size === 's' ? 'body-small' : 'body-large',
    "data-t-id": "Cell-CellText"
  }), text);
});