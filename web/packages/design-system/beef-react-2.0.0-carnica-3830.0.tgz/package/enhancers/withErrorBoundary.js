import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { ErrorBoundary } from "../components";
export function withErrorBoundary(boundaryProps) {
  return function (WrappedComponent) {
    return function (props) {
      return /*#__PURE__*/React.createElement(ErrorBoundary, _extends({}, boundaryProps, {
        "data-t-id": "src-enhancers"
      }), /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, props, {
        "data-t-id": "src-enhancers"
      })));
    };
  };
}