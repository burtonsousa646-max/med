export declare const useMobileOS: () => null | string;
//# sourceMappingURL=useMobileOS.d.ts.map