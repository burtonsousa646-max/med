export * from './BaseIcon';
//# sourceMappingURL=index.d.ts.map