import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "title", "subTitle", "shouldRender", "shouldTitleRender", "shouldCounterRedner", "steps", "activeStep"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import { withDataConverter, withRenderCondition } from '@beef/react';
import { compose } from '@beef/utils';
import { Text } from "../Text";
import styles from "./styles.module.css";
import { ProgressStepBarAnimatedContent } from "./ProgressStepBarAnimatedContent";
var cnProgressStepBar = cnBem('progress-step-bar', styles);
var Counter = function Counter(_ref) {
  var activeStep = _ref.activeStep,
    steps = _ref.steps;
  return /*#__PURE__*/React.createElement(React.Fragment, null, 'шаг ', /*#__PURE__*/React.createElement(ProgressStepBarAnimatedContent, {
    animationKey: activeStep,
    "data-t-id": "components-ProgressStepBar"
  }, activeStep), ' из ', /*#__PURE__*/React.createElement(ProgressStepBarAnimatedContent, {
    animationKey: steps
  }, steps));
};
var getAnimationKey = function getAnimationKey(content) {
  if (typeof content === 'bigint' || typeof content === 'string' || typeof content === 'number') {
    return content;
  }
  return undefined;
};
var ProgressStepBarContentRender = /*#__PURE__*/forwardRef(function (_ref2, ref) {
  var className = _ref2.className,
    title = _ref2.title,
    subTitle = _ref2.subTitle,
    shouldRender = _ref2.shouldRender,
    shouldTitleRender = _ref2.shouldTitleRender,
    shouldCounterRedner = _ref2.shouldCounterRedner,
    steps = _ref2.steps,
    activeStep = _ref2.activeStep,
    otherProps = _objectWithoutProperties(_ref2, _excluded);
  return /*#__PURE__*/React.createElement(Text, _extends({}, otherProps, {
    className: cnProgressStepBar('title', [className]),
    color: "primary",
    ref: ref,
    truncate: true,
    variant: "body-small"
  }), shouldTitleRender && /*#__PURE__*/React.createElement(ProgressStepBarAnimatedContent, {
    animationKey: getAnimationKey(title)
  }, title), shouldCounterRedner && /*#__PURE__*/React.createElement(Counter, {
    activeStep: activeStep,
    steps: steps
  }), subTitle && title !== null && /*#__PURE__*/React.createElement("span", {
    className: cnProgressStepBar('dot')
  }, "\u2022"), subTitle && /*#__PURE__*/React.createElement(ProgressStepBarAnimatedContent, {
    animationKey: getAnimationKey(subTitle),
    className: cnProgressStepBar('subTitle')
  }, subTitle));
});
export var ProgressStepBarContent = compose(withDataConverter(function (props) {
  return _objectSpread(_objectSpread({}, props), {}, {
    shouldTitleRender: Boolean(props.title),
    shouldCounterRedner: Boolean(props.title !== null && !props.title)
  });
}), withRenderCondition({
  shouldRenderFn: function shouldRenderFn(props) {
    return Boolean(props.shouldTitleRender || props.shouldCounterRedner || props.subTitle);
  }
}))(ProgressStepBarContentRender);