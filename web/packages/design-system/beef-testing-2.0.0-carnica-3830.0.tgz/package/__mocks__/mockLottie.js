export var mockLottie = {
  loadAnimation: jest.fn(function () {
    return {
      playSegments: jest.fn(),
      setSegment: jest.fn(),
      goToAndStop: jest.fn(),
      resetSegments: jest.fn(),
      destroy: jest.fn(),
      currentRawFrame: 0,
      totalFrames: 150
    };
  })
};

// Пример использования. Использовать перед describe
// jest.mock('lottie-web', () => mockLottie);