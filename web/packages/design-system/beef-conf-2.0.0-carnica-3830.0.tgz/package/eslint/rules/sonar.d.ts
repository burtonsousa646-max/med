export let rules: {
    'sonarjs/cognitive-complexity': string;
    'sonarjs/no-duplicate-string': string;
};
//# sourceMappingURL=sonar.d.ts.map