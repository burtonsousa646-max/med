import { map } from "./helpers";
/**
 * Позволяет задавать пресеты конфигураций для плагинов
 * @param Plugin
 * @param presets
 */
export function extendPlugin(Plugin, presets) {
  return Object.assign(Plugin, map(presets, function (opts) {
    return typeof opts === 'function' ? function () {
      return new Plugin(opts.apply(void 0, arguments));
    } :
    // FIXME: нужно отслеживать, что Plugin - undefined и выкидывать ошибку на уровень выше
    new Plugin(opts);
  }));
}