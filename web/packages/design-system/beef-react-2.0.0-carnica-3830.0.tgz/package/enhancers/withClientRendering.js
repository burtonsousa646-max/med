import { allowParamOmit } from "./allowParamOmit";
import { withRenderCondition } from "./withRenderFlag";
var shouldRenderFn = function shouldRenderFn() {
  return typeof window !== 'undefined' && !!window.document && !!document.createElement;
};
export var withClientRendering = allowParamOmit(function () {
  var fallback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  return withRenderCondition({
    fallback: fallback,
    shouldRenderFn: shouldRenderFn
  });
});