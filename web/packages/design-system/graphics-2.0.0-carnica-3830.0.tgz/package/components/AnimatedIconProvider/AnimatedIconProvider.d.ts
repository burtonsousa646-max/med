import React from 'react';
type AnimatedIconProviderProps = {
    activeIndex?: number;
    children?: React.ReactNode;
};
export declare const AnimatedIconContext: React.Context<number>;
export declare const AnimatedIconProvider: (props: AnimatedIconProviderProps) => React.JSX.Element;
export {};
//# sourceMappingURL=AnimatedIconProvider.d.ts.map