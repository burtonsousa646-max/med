export var detectInstalledAndroidApp = function detectInstalledAndroidApp(timeout, setIsInstalledApp) {
  var timerId;
  var handleBeforeInstallPrompt = function handleBeforeInstallPrompt(event) {
    event.preventDefault();
    clearTimeout(timerId);
    setIsInstalledApp(false);
  };
  window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  timerId = setTimeout(function () {
    setIsInstalledApp(true);
  }, window.beforeinstallpromptTimeout || timeout);
  return function () {
    clearTimeout(timerId);
    window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  };
};