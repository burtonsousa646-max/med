export type ForceUpdateOptions = {
    debounce?: number;
};
export declare const useForceUpdate: (options?: ForceUpdateOptions) => (() => void);
//# sourceMappingURL=useForceUpdate.d.ts.map