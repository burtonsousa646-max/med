export function resolveProjectReferences(cwd: any): any[];
//# sourceMappingURL=projectResolver.d.ts.map