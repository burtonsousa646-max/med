import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { passAsIs } from '@beef/utils';
/**
 * Полностью автоматическая функция для превращения Wrapper -> Hoc
 * Параметры контейнера становятся статическими опциями HOC'а
 */
export var hocify = function hocify(ContainerComponent) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$enhanceOpts = _ref.enhanceOpts,
    enhanceOpts = _ref$enhanceOpts === void 0 ? passAsIs : _ref$enhanceOpts,
    _ref$enhanceProps = _ref.enhanceProps,
    enhanceProps = _ref$enhanceProps === void 0 ? passAsIs : _ref$enhanceProps;
  return function (opts) {
    return hocifyManually(function (WrappedComponent) {
      return function (props) {
        return /*#__PURE__*/React.createElement(ContainerComponent, _extends({}, enhanceOpts(opts, props), {
          "data-t-id": "src-utils"
        }), /*#__PURE__*/React.createElement(WrappedComponent, _extends({}, enhanceProps(props, opts), {
          "data-t-id": "src-utils"
        })));
      };
    });
  };
};

/**
 * Полуавтоматическая функция для превращения Wrapper -> Hoc
 * Упрощает типизацию и установку статических полей
 */
export var hocifyManually = function hocifyManually(fn) {
  return function (WrappedComponent) {
    var HocifiedComponent = fn(WrappedComponent);
    HocifiedComponent.propTypes = WrappedComponent.propTypes;
    return HocifiedComponent;
  };
};