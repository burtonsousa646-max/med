export * from './MotionComponent';
//# sourceMappingURL=index.d.ts.map