import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "notFoundLabel", "loading", "multiple", "convertItem", "renderListAsMotion", "getters"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useCallback, useEffect } from 'react';
import { cnBem, combineRefs } from '@carnica/utils';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { Text } from "../Text";
import { List } from "../../modules/List";
import { Checkbox } from "../Checkbox";
import { useConvertedItems } from "../../hooks/useConvertedItems";
import styles from "./styles.module.css";
import { dataConverter, itemKeys } from "./utils";
import { ActionSheetWrapper } from "./ActionSheetWrapper";
import { useActionSheetKeyboardHandler } from "./hooks/useActionSheetKeyboardHandler";
import { ActionSheetPopover } from "./ActionSheetPopover";
import { useActionSheetPopoverContext } from "./ActionSheetPopover/context";
import { useActionSheetItemAnimation } from "./hooks/useActionSheetItemAnimation";
var cnActionSheet = cnBem('action-sheet', styles);
var ActionSheetRender = function ActionSheetRender(props, ref) {
  var itemsProp = props.items,
    _props$notFoundLabel = props.notFoundLabel,
    notFoundLabel = _props$notFoundLabel === void 0 ? 'Ничего не найдено 😔' : _props$notFoundLabel,
    loading = props.loading,
    multiple = props.multiple,
    convertItem = props.convertItem,
    renderListAsMotion = props.renderListAsMotion,
    getters = props.getters,
    otherProps = _objectWithoutProperties(props, _excluded);
  var items = useConvertedItems({
    items: itemsProp || [],
    getters: getters,
    convertItem: convertItem,
    keys: itemKeys
  });
  var _useActionSheetPopove = useActionSheetPopoverContext(),
    changeLoading = _useActionSheetPopove.changeLoading,
    popoverRef = _useActionSheetPopove.popoverRef;
  var _useActionSheetKeyboa = useActionSheetKeyboardHandler({
      items: items,
      multiple: multiple
    }),
    itemRefs = _useActionSheetKeyboa.itemRefs,
    onKeyDownByItem = _useActionSheetKeyboa.onKeyDownByItem;
  useActionSheetItemAnimation({
    items: items,
    loading: loading,
    itemRefs: itemRefs
  });
  var getRef = function getRef(item) {
    return combineRefs([item.ref, itemRefs[item.key]]);
  };
  var getAttributes = useCallback(function (item) {
    var _item$attributes;
    return _objectSpread(_objectSpread({}, item.attributes), {}, {
      className: cnActionSheet('item', {
        initialItemHidden: !loading && !!(popoverRef !== null && popoverRef !== void 0 && popoverRef.current)
      }, [(_item$attributes = item.attributes) === null || _item$attributes === void 0 ? void 0 : _item$attributes.className]),
      onKeyDown: function onKeyDown(e) {
        var _item$attributes2, _item$attributes2$onK;
        (_item$attributes2 = item.attributes) === null || _item$attributes2 === void 0 || (_item$attributes2$onK = _item$attributes2.onKeyDown) === null || _item$attributes2$onK === void 0 || _item$attributes2$onK.call(_item$attributes2, e);
        onKeyDownByItem(item)(e);
      }
    });
  }, [onKeyDownByItem, loading]);
  var getItemRightSide = useCallback(function (item) {
    if (!multiple) {
      return null;
    }
    return /*#__PURE__*/React.createElement(Checkbox, {
      "aria-hidden": true,
      checked: item.checked,
      disabled: item.disabled,
      tabIndex: -1,
      "data-t-id": "components-ActionSheet"
    });
  }, [multiple]);
  var convertListItem = useCallback(function (item) {
    return _objectSpread(_objectSpread({}, item), {}, {
      ref: getRef(item),
      attributes: getAttributes(item),
      rightSide: getItemRightSide(item)
    });
  }, [getItemRightSide, getAttributes]);
  useEffect(function () {
    return changeLoading(!!loading);
  }, [loading]);
  if (loading || !(items !== null && items !== void 0 && items.length)) {
    return /*#__PURE__*/React.createElement(ActionSheetWrapper, _extends({}, otherProps, {
      loading: loading,
      ref: ref
    }), !loading && /*#__PURE__*/React.createElement(Text, {
      align: "center",
      "aria-label": notFoundLabel,
      className: cnActionSheet('not-found'),
      color: "secondary-fake-invert",
      role: "alertdialog",
      variant: "body-small"
    }, notFoundLabel));
  }
  return /*#__PURE__*/React.createElement(ActionSheetWrapper, _extends({}, otherProps, {
    hasItems: true,
    ref: ref
  }), /*#__PURE__*/React.createElement(List, _extends({}, getters, {
    "aria-label": "\u0421\u043F\u0438\u0441\u043E\u043A \u043E\u043F\u0446\u0438\u0439",
    convertItem: convertListItem,
    invert: true,
    items: items,
    motion: renderListAsMotion,
    "data-t-id": "components-ActionSheet"
  })));
};
export var ActionSheet = compose(withDataConverter(dataConverter), forwardRef)(ActionSheetRender);
ActionSheet.Popover = ActionSheetPopover;