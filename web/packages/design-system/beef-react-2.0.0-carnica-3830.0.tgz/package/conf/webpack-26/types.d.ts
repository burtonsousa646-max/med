import { BasePluginOptions, CssNanoOptionsExtended, DefinedDefaultMinimizerAndOptions } from 'css-minimizer-webpack-plugin';
import type CssMinimizerPlugin from 'css-minimizer-webpack-plugin';
import type { TransformOptions } from 'esbuild';
export type BuildEnv = {
    [key: `is${string}`]: boolean | undefined;
    isHMR?: boolean;
    isProduction?: boolean;
    isServer?: boolean;
};
export type CssMinimizerPluginEsbuild = CssMinimizerPlugin & (new (options?: BasePluginOptions & DefinedDefaultMinimizerAndOptions<TransformOptions>) => any);
export type CssMinimizerPluginCssNano = CssMinimizerPlugin & (new (options?: BasePluginOptions & DefinedDefaultMinimizerAndOptions<CssNanoOptionsExtended>) => any);
//# sourceMappingURL=types.d.ts.map