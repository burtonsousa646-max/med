import { RuleSetRule } from 'webpack';
export type Rule = RegExp | string;
export type RuleUse = Extract<RuleSetRule, object>;
export type RuleSetFull = '' | '...' | 0 | RuleSetRule | false | null | undefined;
export type RuleSetFullExt = RuleSetFull | symbol;
export type UseRule<T extends Rule | Rule[] = Rule | Rule[], R extends RuleSetFullExt = RuleSetFullExt> = {
    (rule: T, use: (RuleUse | undefined)[] | RuleUse, extra?: Record<string, any>, flag?: boolean): R;
    (rule: T, use: (RuleUse | undefined)[] | RuleUse, flag?: boolean): R;
};
export declare const useRule: UseRule<any, any> & {
    replace: UseRule<Rule, RuleSetFull>;
    exclude: (rule: Rule, flag?: boolean) => symbol | undefined;
};
//# sourceMappingURL=useRule.d.ts.map