import * as Components from "./components";
export var Skeleton = Components;
export { SkeletonBrick, SkeletonCircle } from "./Skeleton";