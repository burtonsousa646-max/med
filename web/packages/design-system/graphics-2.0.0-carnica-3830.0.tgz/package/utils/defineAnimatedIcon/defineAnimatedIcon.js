import _extends from "@babel/runtime/helpers/extends";
import React, { forwardRef, useContext } from 'react';
import { AnimatedIcon } from "../../components/AnimatedIcon";
import { AnimatedIconContext } from "../../components/AnimatedIconProvider";
export var defineAnimatedIcon = function defineAnimatedIcon(params) {
  return /*#__PURE__*/forwardRef(function (props, ref) {
    var activeIndex = useContext(AnimatedIconContext);
    return /*#__PURE__*/React.createElement(AnimatedIcon, _extends({}, params, props, {
      activeIndex: activeIndex,
      ref: ref,
      "data-t-id": "utils-defineAnimatedIcon"
    }));
  });
};