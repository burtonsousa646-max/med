import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["disabled", "error", "isOpen", "onClick", "leftSide", "placeholder", "value", "className", "wrapperRef", "multiple", "withMobileOffset", "renderValue", "invert", "toggleRef", "onClear", "convertItem"];
import React, { forwardRef, useMemo } from 'react';
import { cnBem } from '@carnica/utils';
import { AnimatedIcon, IconChevronDown, IconCloseRoundStroked } from '@carnica/graphics';
import { ControlWrapper } from "../../ControlWrapper";
import { Text } from "../../Text";
import { IconWrapper } from "../../../modules/IconWrapper";
import styles from "./styles.module.css";
import { getIconColor, getTextColor, isMultipleParams } from "./utils";
var cnSelectField = cnBem('select-field', styles);
var getDefaultAriaLabel = function getDefaultAriaLabel(multiple, hasLabel) {
  if (hasLabel) {
    return undefined;
  }
  return "\u041F\u043E\u043B\u0435 \u0432\u044B\u0431\u043E\u0440\u0430 ".concat(multiple ? 'вариантов' : 'варианта');
};
export var SelectField = /*#__PURE__*/forwardRef(function (props, ref) {
  var _props$value;
  var disabled = props.disabled,
    error = props.error,
    isOpen = props.isOpen,
    onClick = props.onClick,
    Icon = props.leftSide,
    placeholder = props.placeholder,
    value = props.value,
    className = props.className,
    wrapperRef = props.wrapperRef,
    multiple = props.multiple,
    withMobileOffset = props.withMobileOffset,
    renderValue = props.renderValue,
    invert = props.invert,
    toggleRef = props.toggleRef,
    onClear = props.onClear,
    convertItem = props.convertItem,
    otherProps = _objectWithoutProperties(props, _excluded);
  var isValueDefined = isMultipleParams(props) ? !!((_props$value = props.value) !== null && _props$value !== void 0 && _props$value.length) : !!value;
  var withClearButton = isValueDefined && !disabled && !!onClear;
  var valueContent = useMemo(function () {
    var _props$value2;
    if (!value) {
      return undefined;
    }
    if (renderValue) {
      return renderValue(value);
    }
    return isMultipleParams(props) ? (_props$value2 = props.value) === null || _props$value2 === void 0 ? void 0 : _props$value2.map(function (item) {
      return convertItem(item).label;
    }).join(', ') : convertItem(value).label;
  }, [value]);
  var handleChange = function handleChange(e) {
    if (isMultipleParams(props)) {
      var _props$onClear;
      (_props$onClear = props.onClear) === null || _props$onClear === void 0 || _props$onClear.call(props, [], e);
    } else {
      var _props$onClear2;
      (_props$onClear2 = props.onClear) === null || _props$onClear2 === void 0 || _props$onClear2.call(props, undefined, e);
    }
  };
  return /*#__PURE__*/React.createElement(ControlWrapper, _extends({
    "aria-expanded": isOpen,
    "aria-haspopup": true,
    "aria-label": getDefaultAriaLabel(multiple, !!otherProps.label),
    className: cnSelectField({
      disabled: disabled,
      error: !!error
    }, [className]),
    disabled: disabled,
    error: error,
    invert: invert,
    onClick: disabled ? undefined : onClick,
    ref: ref,
    role: "combobox",
    withMobileOffset: withMobileOffset
  }, otherProps, {
    "data-t-id": "Select-SelectField"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnSelectField('wrapper', {
      isOpen: isOpen,
      disabled: disabled,
      invert: invert
    }),
    ref: wrapperRef,
    "data-t-id": "Select-SelectField"
  }, Icon && /*#__PURE__*/React.createElement(IconWrapper, {
    className: cnSelectField('side', {
      position: 'left'
    }),
    color: getIconColor({
      disabled: disabled,
      invert: invert
    }),
    disabled: disabled,
    icon: Icon,
    size: "m"
  }), /*#__PURE__*/React.createElement(Text, {
    className: cnSelectField('value', {
      empty: !valueContent
    }),
    color: getTextColor(valueContent, error, disabled, invert),
    variant: "body-large"
  }, valueContent || placeholder), withClearButton && /*#__PURE__*/React.createElement(IconCloseRoundStroked, {
    "aria-label": "\u043E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u043F\u043E\u043B\u0435",
    className: cnSelectField('close'),
    color: invert ? 'tertiary-fake-invert' : 'tertiary',
    onClick: handleChange,
    size: "m",
    tagName: "button",
    type: "button"
  }), /*#__PURE__*/React.createElement(AnimatedIcon, {
    activeIndex: Number(isOpen),
    "aria-label": isOpen ? 'Закрыть список' : 'Открыть список',
    className: cnSelectField('side', {
      position: 'right'
    }),
    color: getIconColor({
      disabled: disabled,
      invert: invert
    }),
    disabled: disabled,
    icons: [IconChevronDown],
    ref: toggleRef,
    rotations: [0, 180],
    tagName: "button",
    type: "button"
  })));
});