export declare const useInitial: <T>(value: T) => T | undefined;
//# sourceMappingURL=useInitial.d.ts.map