import type { IconComponentNames } from '../../../types/iconNames';
export declare const mockData: IconComponentNames[];
//# sourceMappingURL=mock.data.d.ts.map