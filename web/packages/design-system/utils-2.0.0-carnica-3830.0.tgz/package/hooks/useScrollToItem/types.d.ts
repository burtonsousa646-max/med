import React from 'react';
export type UseScrollToItemParams = {
    containeRef: React.RefObject<HTMLElement | null>;
    direction?: 'horizontal' | 'vertical';
    itemRefs: Array<React.RefObject<HTMLElement | null>>;
    resultAlign?: 'center' | 'end' | 'start';
};
//# sourceMappingURL=types.d.ts.map