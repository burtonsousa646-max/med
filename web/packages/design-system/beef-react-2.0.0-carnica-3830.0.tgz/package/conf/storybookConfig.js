const path = require('path');
const {
  composeConfigValidator
} = require('@beef/conf/utils');
const remarkSlug = require('remark-slug');
const remarkExternalLinks = require('remark-external-links');
const {
  WebpackFactory,
  webpack
} = require('./webpack');

// Exclude plugins not required for storybook
const {
  config: customConfig
} = new WebpackFactory({
  excludePlugins: [webpack.plugins.HtmlWebpackPlugin, webpack.plugins.WebpackManifestPlugin]
});
const [cGreen, cRed, cReset] = ['\x1b[32m', '\x1b[31m', '\x1b[0m'];
const BadConfigurationError = ['Bad configuration. Config function call missing:', ` > require(${cGreen}'@beef/react/conf'${cReset}).storybookConfig${cRed}()${cReset};`, ''].join('\r\n');
const validateStorybookConfig = composeConfigValidator(({
  _version
} = {}) => _version ? BadConfigurationError : null);
const isPatternLikeRule = patterns => rule => {
  if (!rule || !rule.test) return false;
  const s = rule.test.toString();
  return patterns.some(pattern => s.includes(pattern));
};
const excludePatterns = (rules, patterns) => (rules || []).filter(rule => !isPatternLikeRule(patterns)(rule));

/**
 * NOTE: Webpack@^5+ must be listed in [dev]Dependencies of the repository
 */
module.exports = (...args) => validateStorybookConfig(({
  extraAddons = [],
  extraEntries = [],
  cwd = process.cwd(),
  rootDir = './src',
  rootConfig = './.storybook'
} = {}) => ({
  framework: '@storybook/react-webpack5',
  stories: [path.resolve(cwd, rootDir, '**/*.(stories.@(js|jsx|ts|tsx)|mdx)'), path.resolve(cwd, rootDir, '**/*.mdx')],
  // @storybook/addon-essentials already include a large selection of addons
  // See: https://storybook.js.org/addons/tag/essentials
  addons: ['@storybook/addon-essentials', '@storybook/addon-links', '@storybook/addon-mdx-gfm', ...extraAddons],
  staticDirs: [path.resolve(cwd, `${rootConfig}/static`),
  // Необходимо для ServiceWorker'ов аддона msw-storybook-addon
  path.resolve(cwd, `.storybook-public`)],
  docs: {
    defaultName: 'Документация',
    autodocs: 'tag',
    mdxPluginOptions: {
      mdxCompileOptions: {
        remarkPlugins: [remarkSlug, remarkExternalLinks]
      }
    }
  },
  webpackFinal: async config => {
    // выкидываем пересекающиеся CSS-правила из конфига, так как они могут ломать цепочку обработчиков storybook'a
    const sanitizedCustomRules = excludePatterns(customConfig.module?.rules, ['\\.css']);
    const next = {
      ...config,
      module: {
        ...config.module,
        rules: [...sanitizedCustomRules, ...excludePatterns(config.module.rules, ['svg']) // правила SB (MDX, assets и пр.), вырезаем обработчик svg, так как он конфликтует с нашим обработчиком из WebpackFactory
        ]
      },
      watchOptions: {
        ...config.watchOptions,
        ignored: ['**/node_modules/**', '**/dist/**', '**/.git/**', '**/.cache/**']
      },
      plugins: [...customConfig.plugins, ...config.plugins].filter(Boolean)
    };

    // Обработка на случай если энтрисы сторибука вместо массива окажутся функцией
    if (Array.isArray(config.entry)) {
      next.entry = [...config.entry, ...extraEntries];
    } else if (typeof config.entry === 'function') {
      next.entry = async () => {
        const base = await config.entry();
        return Array.isArray(base) ? [...base, ...extraEntries] : base;
      };
    }
    return next;
  }
}))(...args);