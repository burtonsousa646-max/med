export declare function useSafeState<T>(initialState: T): readonly [T, (val: T) => void];
//# sourceMappingURL=useSafeState.d.ts.map