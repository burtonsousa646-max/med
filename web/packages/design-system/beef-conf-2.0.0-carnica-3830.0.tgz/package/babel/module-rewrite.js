const {
  createRequire
} = require('module');
const path = require('path');
const createSafeRequire = cwd => {
  const requireLocal = createRequire(`${cwd}/package.json`);
  const originalResolve = requireLocal.resolve.bind(requireLocal);
  return Object.assign(requireLocal, {
    resolve: resolvePath => {
      try {
        return originalResolve(resolvePath);
      } catch (err) {
        // Module is missing in the original repository
        return undefined;
      }
    }
  });
};
const isModulePath = checkPath => checkPath.indexOf('./') !== 0;

/**
 * Если модуль, откуда файл импортируется залинкован (yarn link), то
 * - строим путь относительно основного репозитория
 * - если там нет аналогичного пакета, то возвращаем тот, что есть
 */
const replaceImport = (originalPath, callingFileName, options) => {
  const linkedCallPaths = options.linkedModuleDirs.map(({
    source
  }) => source);
  if (!linkedCallPaths.length) return originalPath;
  const linkedCallPathRegex = new RegExp(`^(${linkedCallPaths.join('|')})`);
  const requireLocal = createSafeRequire(options.cwd);
  if (isModulePath(originalPath) && linkedCallPathRegex.test(callingFileName)) {
    const resolvedPath = requireLocal.resolve(originalPath);
    if (resolvedPath) {
      const match = options.linkedModuleDirs.find(item => resolvedPath.indexOf(item.source) !== -1);
      if (match) {
        return path.join(match.link, path.relative(match.source, resolvedPath));
      }
    }
    return resolvedPath;
  }
  return originalPath;
};
module.exports = replaceImport;