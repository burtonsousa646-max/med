import PropTypes from 'prop-types';
export declare const CustomPropTypes: {
    component: PropTypes.Requireable<PropTypes.ReactComponentLike>;
    id: PropTypes.Requireable<NonNullable<string | number | null | undefined>>;
    newRef: PropTypes.Requireable<PropTypes.InferProps<{
        current: PropTypes.Requireable<any>;
    }>>;
    ref: PropTypes.Requireable<NonNullable<((...args: any[]) => any) | PropTypes.InferProps<{
        current: PropTypes.Requireable<any>;
    }> | null | undefined>>;
    options: PropTypes.Requireable<(PropTypes.InferProps<{
        label: PropTypes.Requireable<string>;
        value: PropTypes.Requireable<any>;
    }> | null | undefined)[]>;
    oneOfValues: (obj: Record<string, string>) => ReturnType<typeof PropTypes.oneOf>;
};
//# sourceMappingURL=index.d.ts.map