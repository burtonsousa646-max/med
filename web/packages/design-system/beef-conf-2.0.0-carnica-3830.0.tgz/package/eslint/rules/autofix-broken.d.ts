export let rules: {
    'no-else-return': number;
    'react/function-component-definition': number;
    'react/no-arrow-function-lifecycle': number;
};
//# sourceMappingURL=autofix-broken.d.ts.map