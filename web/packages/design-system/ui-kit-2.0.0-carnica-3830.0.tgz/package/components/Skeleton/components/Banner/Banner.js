import _extends from "@babel/runtime/helpers/extends";
import React from 'react';
import { SkeletonBrick } from "../../Skeleton";
var sizeMap = {
  width: {
    desktop: 'min(100%, 960px)',
    mobile: '100%'
  },
  height: {
    mobile: 540,
    desktop: 444
  }
};
export var Banner = function Banner(props) {
  return /*#__PURE__*/React.createElement(SkeletonBrick, _extends({}, props, sizeMap, {
    "data-t-id": "components-Banner"
  }));
};