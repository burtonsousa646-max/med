const WebpackCacheOptionsApply = require('./WebpackOptionsApply');
class BeefCacheBuildDependencyPlugin {
  constructor(options = {}) {
    this.options = options;
  }
  apply(compiler) {
    /** Пробегаем по всем stage'ам processAssets */
    compiler.hooks.afterEnvironment.tap(this.constructor.name, () => {
      new WebpackCacheOptionsApply(this.options).process(compiler.options, compiler);
    });
  }
}
module.exports = {
  BeefCacheBuildDependencyPlugin
};