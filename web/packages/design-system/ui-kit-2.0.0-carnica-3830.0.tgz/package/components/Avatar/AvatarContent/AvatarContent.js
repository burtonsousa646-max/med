import React from 'react';
import { cnBem } from '@carnica/utils';
import { Text } from "../../Text";
import { avatarSizeMap, getInitialsForName, iconSizeMap, textSizeMap } from "../utils";
import styles from "../styles.module.css";
var cnAvatar = cnBem('avatar', styles);
export var AvatarContent = function AvatarContent(_ref) {
  var image = _ref.image,
    name = _ref.name,
    Icon = _ref.icon,
    Logo = _ref.logo,
    disabled = _ref.disabled,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size;
  if (image) {
    return /*#__PURE__*/React.createElement("img", {
      alt: name !== null && name !== void 0 ? name : 'Аватар',
      className: cnAvatar('image'),
      src: image,
      "data-t-id": "Avatar-AvatarContent"
    });
  }
  if (Icon) {
    return /*#__PURE__*/React.createElement(Icon, {
      className: cnAvatar('icon'),
      size: iconSizeMap[size]
    });
  }
  if (Logo) {
    return /*#__PURE__*/React.createElement(Logo, {
      className: cnAvatar('logo'),
      height: "".concat(avatarSizeMap[size], "px"),
      size: avatarSizeMap[size],
      width: "".concat(avatarSizeMap[size], "px")
    });
  }
  return /*#__PURE__*/React.createElement(Text, {
    align: "center",
    className: cnAvatar('name'),
    color: disabled ? 'tertiary' : undefined,
    variant: textSizeMap[size]
  }, getInitialsForName(name));
};