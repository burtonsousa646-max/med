import type { BaseIconComponent } from './types';
export declare const BaseIcon: BaseIconComponent;
//# sourceMappingURL=BaseIcon.d.ts.map