import React from 'react';
import type { ThemeProviderBaseThemes, ThemeProviderProps } from './types';
type ThemeContextOptions = Required<Pick<ThemeProviderProps, 'baseName' | 'initialTheme' | 'themeStyles'>>;
type ThemeContextType = [
    ThemeProviderBaseThemes,
    (val: ThemeProviderBaseThemes) => void,
    ThemeContextOptions
];
export declare const useThemeContext: () => ThemeContextType;
export declare const ThemeProvider: React.FC<ThemeProviderProps>;
export {};
//# sourceMappingURL=ThemeProvider.d.ts.map