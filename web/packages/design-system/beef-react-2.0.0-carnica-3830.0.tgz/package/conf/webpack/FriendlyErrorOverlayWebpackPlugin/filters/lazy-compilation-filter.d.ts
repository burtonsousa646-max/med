declare function _exports({ error, stackFrames }: {
    error: any;
    stackFrames: any;
}): any;
export = _exports;
//# sourceMappingURL=lazy-compilation-filter.d.ts.map