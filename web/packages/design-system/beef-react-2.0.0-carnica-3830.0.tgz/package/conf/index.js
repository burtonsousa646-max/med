const {
  resolveWebpackConfig
} = require('@beef/conf');
const {
  WebpackFactory,
  webpack
} = require('./webpack');
const {
  errorFilters
} = require('./webpack/utils');
module.exports = {
  WebpackFactory,
  errorFilters,
  webpack,
  resolveWebpackConfig,
  postcssConfig: require('./postcssConfig'),
  storybookConfig: require('./storybookConfig'),
  jestConfig: require('./jestConfig')
};