import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "disabled", "className"];
import React, { useEffect, useRef } from 'react';
import { cnBem } from '@carnica/utils';
import { useComponentSize, useFlag } from '@carnica/utils/hooks';
import { withTooltip } from "../../hocs/withTooltip";
import { Text } from "../Text";
import { splitFileName } from "./utils";
import styles from "./styles.module.css";
var cnFile = cnBem('file', styles);
var TextWithTooltip = withTooltip({
  direction: 'upCenter',
  possibleDirections: ['upCenter', 'downCenter']
})(Text);
export var FileTitle = function FileTitle(_ref) {
  var children = _ref.children,
    disabled = _ref.disabled,
    className = _ref.className,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var titleRef = useRef(null);
  var titleSize = useComponentSize(titleRef);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    hasTooltip = _useFlag2[0],
    setHasTooltip = _useFlag2[1];
  useEffect(function () {
    var timeout = setTimeout(function () {
      setHasTooltip.set(Boolean(titleRef.current && titleRef.current.offsetWidth < titleRef.current.scrollWidth));
    }, 100);
    return function () {
      clearTimeout(timeout);
    };
  }, [titleSize.width, children]);
  var Title = hasTooltip ? TextWithTooltip : Text;
  var splitedTitle = splitFileName(children);
  if (!splitedTitle) {
    return null;
  }
  return /*#__PURE__*/React.createElement(Title, _extends({}, otherProps, {
    className: cnFile('title', {
      hidden: !hasTooltip
    }, [className]),
    color: disabled ? 'disabled' : 'primary',
    variant: "body-accent-small"
  }, hasTooltip ? {
    tooltipProps: {
      tooltipContent: children
    }
  } : {}, {
    "data-t-id": "components-File"
  }), hasTooltip && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: cnFile('start-row')
  }, splitedTitle.start), splitedTitle.end), /*#__PURE__*/React.createElement("span", {
    className: cnFile('detect-row', {
      hidden: hasTooltip
    }),
    ref: titleRef
  }, children));
};