import { useEffect, useRef } from 'react';
export var useInterval = function useInterval(interval, options) {
  var _ref = options !== null && options !== void 0 ? options : {},
    onCreate = _ref.onCreate,
    onCancel = _ref.onCancel,
    _ref$onReached = _ref.onReached,
    onReached = _ref$onReached === void 0 ? function () {} : _ref$onReached;
  var intervalRef = useRef(undefined);
  var cancelInterval = function cancelInterval() {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = undefined;
      onCancel === null || onCancel === void 0 || onCancel();
    }
  };
  var createInterval = function createInterval() {
    onCreate === null || onCreate === void 0 || onCreate();
    intervalRef.current = setInterval(onReached, interval);
  };
  useEffect(function () {
    cancelInterval();
    return function () {
      return clearInterval(intervalRef.current);
    };
  }, []);
  return {
    intervalRef: intervalRef,
    createInterval: createInterval,
    cancelInterval: cancelInterval
  };
};