export let arrowParens: string;
export let bracketSameLine: boolean;
export let bracketSpacing: boolean;
export let embeddedLanguageFormatting: string;
export let experimentalTernaries: boolean;
export let jsxSingleQuote: boolean;
export let printWidth: number;
export let quoteProps: string;
export let semi: boolean;
export let singleAttributePerLine: boolean;
export let singleQuote: boolean;
export let tabWidth: number;
export let trailingComma: string;
export let useTabs: boolean;
//# sourceMappingURL=prettierrc.d.ts.map