export function promptSelectOne(message: any, choices: any): any;
export function promptConfirmation(message: any): any;
//# sourceMappingURL=promts.d.ts.map