import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["multiColor", "defaultSize"],
  _excluded2 = ["color", "customColor", "size"];
import React, { forwardRef } from 'react';
import { Icon } from "../../components/Icon";
export var defineUrlIcon = function defineUrlIcon(_ref) {
  var _ref$multiColor = _ref.multiColor,
    multiColor = _ref$multiColor === void 0 ? true : _ref$multiColor,
    defaultSize = _ref.defaultSize,
    params = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/forwardRef(function (_ref2, ref) {
    var color = _ref2.color,
      customColor = _ref2.customColor,
      size = _ref2.size,
      props = _objectWithoutProperties(_ref2, _excluded2);
    return /*#__PURE__*/React.createElement(Icon, _extends({}, props, params, multiColor ? {
      color: color,
      multiColor: true,
      customColor: customColor
    } : {
      multiColor: false
    }, {
      ref: ref,
      size: size || defaultSize || 'm',
      "data-t-id": "utils-defineUrlIcon"
    }));
  });
};