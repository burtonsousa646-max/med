export var DIMENSION_TYPE = /*#__PURE__*/function (DIMENSION_TYPE) {
  DIMENSION_TYPE["MOBILE"] = "mobile";
  DIMENSION_TYPE["TABLET"] = "tablet";
  DIMENSION_TYPE["DESKTOP"] = "desktop";
  return DIMENSION_TYPE;
}({});