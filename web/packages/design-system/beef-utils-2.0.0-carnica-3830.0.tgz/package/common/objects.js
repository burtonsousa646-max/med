import _typeof from "@babel/runtime/helpers/typeof";
import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 * A `list.map` for objects
 */

import { isNullOrUndefined } from "./atomic";
export function map(obj, fn) {
  return Object.keys(obj).reduce(function (result, key) {
    result[key] = fn(obj[key], key);
    return result;
  }, {});
}
export function mapKeys(obj, fn) {
  return Object.keys(obj).reduce(function (result, key) {
    result[fn(key, obj[key])] = obj[key];
    return result;
  }, {});
}

/**
 * A list.forEach for objects
 */
export function forEach(obj, fn) {
  return Object.keys(obj).forEach(function (key) {
    fn(obj[key], key);
  });
}

/**
 * A `list.reduce` for objects
 */
export function reduce(obj, fn, initialState) {
  return Object.keys(obj).reduce(function (result, key) {
    return fn(result, obj[key], key);
  }, initialState);
}

/**
 * A `list.filter` for objects
 */
export function filter(obj, fn) {
  return Object.keys(obj).reduce(function (result, key) {
    if (fn(obj[key], key)) result[key] = obj[key];
    return result;
  }, {});
}
export function take(fields, obj) {
  return fields.reduce(function (accum, key) {
    return _objectSpread(_objectSpread({}, accum), {}, _defineProperty({}, key, obj[key]));
  }, {});
}
export var flatten = function flatten(arrayOfArrays) {
  var _ref;
  return (_ref = []).concat.apply(_ref, _toConsumableArray(arrayOfArrays));
};
export var distinct = function distinct(arrayWithDuplicates) {
  return Array.from(new Set(arrayWithDuplicates));
};
export var filterDefined = function filterDefined(obj) {
  return filter(obj, function (val) {
    return typeof val !== 'undefined';
  });
};
export var filterValuable = function filterValuable(obj) {
  return filter(obj, function (val) {
    return !isNullOrUndefined(val);
  });
};
export var convertListToObjectBy = function convertListToObjectBy(field) {
  return function (list) {
    return list.reduce(function (result, item, index) {
      result[typeof field === 'function' ? field(item, index) : item[field]] = item;
      return result;
    }, {});
  };
};
export var objectHasValue = function objectHasValue(obj, value) {
  return Object.keys(obj).some(function (key) {
    return obj[key] === value;
  });
};
export { compose } from 'redux';

/**
 * Stolen from react-redux to avoid warning caused by old version of react-redux
 * FIXME: After migrating to new react-redux replace with
 * export { shallowEqual } from 'react-redux';
 */
export var shallowEqual = function shallowEqual(objA, objB) {
  var is = function is(x, y) {
    if (x === y) {
      return x !== 0 || y !== 0 || 1 / x === 1 / y;
    }
    // eslint-disable-next-line no-self-compare
    return x !== x && y !== y;
  };
  if (is(objA, objB)) return true;
  if (_typeof(objA) !== 'object' || objA === null || _typeof(objB) !== 'object' || objB === null) {
    return false;
  }
  var keysA = Object.keys(objA);
  var keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  for (var i = 0; i < keysA.length; i += 1) {
    if (!Object.prototype.hasOwnProperty.call(objB, keysA[i]) || !is(objA[keysA[i]], objB[keysA[i]])) {
      return false;
    }
  }
  return true;
};