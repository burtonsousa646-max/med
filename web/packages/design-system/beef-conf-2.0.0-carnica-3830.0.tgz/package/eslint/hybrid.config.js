const settings = require('./configs/settings');
const jsConfig = require('./configs/js-recommended');
const tsConfig = require('./configs/ts-recommended');
const devConfig = require('./configs/dev-only');
const testConfig = require('./configs/test-only');
const jsonConfig = require('./configs/json-recommended');
module.exports = {
  ...settings,
  overrides: [{
    files: ['**/*{.ts,.tsx}'],
    ...tsConfig,
    overrides: [{
      // tsx? stories on top of tsx? config
      files: ['**/*.stories{.ts,.tsx}', '**/stories/**/*{.ts,.tsx}', '**/__stories__/**/*{.ts,.tsx}'],
      ...devConfig
    }, {
      files: ['**/__tests__/**/*{.ts,.tsx}', '**/*{.spec,.test}{.ts,.tsx}'],
      ...testConfig
    }]
  }, {
    files: ['**/*{.js,.jsx}'],
    ...jsConfig,
    overrides: [{
      // jsx? stories on top of jsx? config
      files: ['**/*.stories{.js,.jsx}', '**/stories/**/*{.js,.jsx}', '**/__stories__/**/*{.js,.jsx}'],
      ...devConfig
    }, {
      files: ['**/__tests__/**/*{.js,.jsx}', '**/*{.spec,.test}{.js,.jsx}'],
      ...testConfig
    }]
  }, {
    files: ['*.json'],
    ...jsonConfig
  }],
  root: true
};