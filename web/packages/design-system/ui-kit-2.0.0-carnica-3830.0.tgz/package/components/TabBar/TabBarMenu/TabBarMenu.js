import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["items", "position", "getters", "convertMenu", "onMenuClick", "onMenuButtonClick", "invert", "className", "closeMenuOnScroll"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { useEffect } from 'react';
import { useFlag } from '@carnica/utils/hooks';
import { cnBem } from '@carnica/utils';
import { AnimatedIconProvider, IconCloseRoundStroked, defineAnimatedIcon } from '@carnica/graphics';
import { Menu } from "../../Menu";
import { Button } from "../../Button";
import { useConvertedItems } from "../../../hooks/useConvertedItems";
import styles from "./styles.module.css";
import { useMenuNavigation } from "../hooks/useMenuNavigation";
import { menuItemKeys } from "./utils";
var cnTabBarMenu = cnBem('tabbar-menu', styles);
var Icon = defineAnimatedIcon({
  icons: [IconCloseRoundStroked],
  rotations: [45, 180],
  transition: 300
});
export var TabBarMenu = function TabBarMenu(props) {
  var itemsProp = props.items,
    position = props.position,
    getters = props.getters,
    convertMenu = props.convertMenu,
    onMenuClick = props.onMenuClick,
    onMenuButtonClick = props.onMenuButtonClick,
    invert = props.invert,
    className = props.className,
    closeMenuOnScroll = props.closeMenuOnScroll,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isOpen = _useFlag2[0],
    setIsOpen = _useFlag2[1];
  var items = useConvertedItems({
    items: itemsProp || [],
    convertItem: convertMenu,
    getters: getters,
    keys: menuItemKeys,
    prefix: 'menu',
    withOriginal: true
  });
  var _useMenuNavigation = useMenuNavigation({
      isOpen: isOpen,
      closeMenu: setIsOpen.off,
      items: items
    }),
    getItemAttributes = _useMenuNavigation.getItemAttributes,
    getItemRef = _useMenuNavigation.getItemRef,
    buttonRef = _useMenuNavigation.buttonRef;
  useEffect(function () {
    if (closeMenuOnScroll) {
      window.addEventListener('scroll', setIsOpen.off);
    }
    return function () {
      return window.removeEventListener('scroll', setIsOpen.off);
    };
  }, [closeMenuOnScroll]);
  var handleMenuButtonClick = function handleMenuButtonClick(e) {
    onMenuButtonClick === null || onMenuButtonClick === void 0 || onMenuButtonClick(e);
    setIsOpen.toggle();
  };
  if (!items.length) {
    return null;
  }
  var onClose = function onClose() {
    var _buttonRef$current;
    setIsOpen.off();
    (_buttonRef$current = buttonRef.current) === null || _buttonRef$current === void 0 || _buttonRef$current.focus();
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, position === 'fixed' && /*#__PURE__*/React.createElement("div", {
    "aria-hidden": true,
    className: cnTabBarMenu('overlay', {
      isOpen: isOpen
    }),
    "data-t-id": "TabBar-TabBarMenu"
  }), /*#__PURE__*/React.createElement("div", {
    className: cnTabBarMenu('wrapper', {
      position: position
    })
  }, /*#__PURE__*/React.createElement(AnimatedIconProvider, {
    activeIndex: isOpen ? 1 : 0
  }, /*#__PURE__*/React.createElement(Button, {
    "aria-expanded": isOpen,
    "aria-haspopup": true,
    "aria-label": isOpen ? 'закрыть меню' : 'открыть меню',
    className: cnTabBarMenu({
      isOpen: isOpen
    }, [className]),
    iconLeft: Icon,
    onClick: handleMenuButtonClick,
    onlyIcon: true,
    ref: buttonRef,
    size: "m",
    view: isOpen ? 'secondary-on-secondary' : 'primary',
    "data-t-id": "TabBar-TabBarMenu"
  }))), /*#__PURE__*/React.createElement(Menu, _extends({
    anchorRef: buttonRef,
    className: cnTabBarMenu('menu', {
      fullWidth: position === 'fixed'
    }),
    convertItem: function convertItem(item) {
      return _objectSpread(_objectSpread({}, item.converted), {}, {
        ref: getItemRef(item),
        attributes: getItemAttributes(item)
      });
    },
    invert: invert,
    isOpen: isOpen,
    items: items,
    offsetHorizontal: position === 'fixed' ? -8 : -5,
    onClose: onClose,
    onItemClick: function onItemClick(item, e) {
      return onMenuClick === null || onMenuClick === void 0 ? void 0 : onMenuClick(item.original, e);
    },
    position: position === 'fixed' ? 'fixed' : 'absolute',
    reposition: position === 'default'
  }, otherProps)));
};