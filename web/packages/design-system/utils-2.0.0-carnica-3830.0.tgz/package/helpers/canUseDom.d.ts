export declare const canUseDom: () => boolean;
//# sourceMappingURL=canUseDom.d.ts.map