import { useMemo } from 'react';
import { drawMod } from "./utils";
export var useQrPath = function useQrPath(_ref) {
  var viewPortSize = _ref.viewPortSize,
    rounding = _ref.rounding,
    isDarkArea = _ref.isDarkArea,
    moduleCount = _ref.moduleCount,
    cutoutModuleArea = _ref.cutoutModuleArea;
  return useMemo(function () {
    if (!(moduleCount && isDarkArea)) {
      return null;
    }
    var halfOfVisibleModuleArea = (moduleCount - (cutoutModuleArea || 1)) / 2;
    var path = [];
    for (var row = 0; row < moduleCount; row += 1) {
      for (var col = 0; col < moduleCount; col += 1) {
        path.push(drawMod({
          isDarkArea: isDarkArea,
          rounding: rounding,
          size: viewPortSize / moduleCount,
          row: row,
          col: col,
          moduleCount: moduleCount,
          startCutoutIndex: cutoutModuleArea ? halfOfVisibleModuleArea : undefined,
          endCutoutIndex: cutoutModuleArea ? moduleCount - halfOfVisibleModuleArea - 1 : undefined
        }));
      }
    }
    return path.join(' ');
  }, [moduleCount, rounding, cutoutModuleArea]);
};