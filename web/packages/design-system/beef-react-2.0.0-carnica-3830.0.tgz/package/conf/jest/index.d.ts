export = configUtils;
import configUtils = require("./configUtils");
//# sourceMappingURL=index.d.ts.map