export declare const data: {
    name: string;
    icon: import("../../types").LogoComponent;
}[];
//# sourceMappingURL=mock.data.d.ts.map