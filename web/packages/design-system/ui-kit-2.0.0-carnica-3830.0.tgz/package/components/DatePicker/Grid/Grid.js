import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "type", "children", "style"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import styles from "./styles.module.css";
var cnGrid = cnBem('grid', styles);
export var Grid = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var className = _ref.className,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'days' : _ref$type,
    children = _ref.children,
    style = _ref.style,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  var count = React.Children.count(children);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnGrid({
      type: type
    }, [className]),
    ref: ref,
    role: "grid",
    style: _objectSpread(_defineProperty({}, '--grid-items-count', count), style)
  }, otherProps, {
    "data-t-id": "DatePicker-Grid"
  }), children);
});