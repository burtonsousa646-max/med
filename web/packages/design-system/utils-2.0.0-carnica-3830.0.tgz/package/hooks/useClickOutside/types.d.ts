import React from 'react';
export type UseClickOutsideParams = {
    ignoreClicksInsideRefs?: React.RefObject<HTMLElement | null>[];
    isActive?: boolean;
    onClick?: React.MouseEventHandler;
};
//# sourceMappingURL=types.d.ts.map