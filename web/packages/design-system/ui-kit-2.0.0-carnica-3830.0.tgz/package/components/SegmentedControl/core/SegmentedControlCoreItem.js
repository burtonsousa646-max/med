import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "inputProps", "inputClassName", "children", "invert"];
import React, { forwardRef } from 'react';
import { cnBem } from '@carnica/utils';
import styles from "./styles.module.css";
var cnSegmentedControlCoreItem = cnBem('segmented-control-core-item', styles);
export var SegmentedControlCoreItem = /*#__PURE__*/forwardRef(function (_ref, ref) {
  var className = _ref.className,
    inputProps = _ref.inputProps,
    inputClassName = _ref.inputClassName,
    children = _ref.children,
    invert = _ref.invert,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("label", _extends({}, otherProps, {
    className: cnSegmentedControlCoreItem({
      disabled: inputProps.disabled,
      interactive: !!inputProps.onChange
    }, [className]),
    ref: ref,
    "data-t-id": "SegmentedControl-core"
  }), /*#__PURE__*/React.createElement("input", _extends({
    "aria-label": "\u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u0442\u0435\u043B\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F",
    "aria-selected": inputProps.checked,
    role: "option",
    type: "checkbox"
  }, inputProps, {
    className: cnSegmentedControlCoreItem('input', [inputClassName, inputProps.className])
  })), children);
});