import _toConsumableArray from "@babel/runtime/helpers/toConsumableArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
import _asyncToGenerator from "@babel/runtime/helpers/asyncToGenerator";
var _excluded = ["url", "method"];
import _regeneratorRuntime from "@babel/runtime/regenerator";
import fs from 'fs';
import { rest } from 'old-msw';
import path from 'path';
import { convertSearchParamsToObject, encodeUrl, findFiles, sanitizeUrl, typeToExtension } from "./utils";
var STUBS_DIR = 'stubs';
var ROUTES_NAME = '*.routes.[jt]s';
var getRoutes = function getRoutes(filePath) {
  var _file$default;
  // eslint-disable-next-line @typescript-eslint/no-var-requires,import/no-dynamic-require
  var file = require(filePath);
  var routes = (_file$default = file.default) !== null && _file$default !== void 0 ? _file$default : file;
  if (!Array.isArray(routes)) {
    throw Error("Routes content must be an array: ".concat(filePath));
  }
  return routes;
};
export var readStub = function readStub(filePath, isJSON) {
  if (!fs.existsSync(path.resolve(filePath))) {
    throw Error("Stub doesn't exist: ".concat(filePath));
  }
  var result = fs.readFileSync(filePath, 'utf8');
  if (isJSON) {
    try {
      return JSON.parse(result);
    } catch (e) {
      throw Error("Stub: ".concat(filePath, ", parsing error: ").concat(e));
    }
  }
  return result;
};
var getDirectoriesWithRoutes = function getDirectoriesWithRoutes(routesPath) {
  return findFiles(routesPath, ROUTES_NAME).map(function (file) {
    return {
      dirPath: path.dirname(file),
      routes: getRoutes(file)
    };
  });
};
var composeStubName = function composeStubName(slug, type) {
  return "".concat(encodeUrl(slug), ".").concat(typeToExtension(type));
};
var composeStubPath = function composeStubPath(dirPath, stubName) {
  return path.resolve(dirPath, "./".concat(STUBS_DIR, "/").concat(stubName));
};
var createRestHandler = function createRestHandler(_ref, dirPath) {
  var _ref$type = _ref.type,
    type = _ref$type === void 0 ? 'json' : _ref$type,
    _ref$status = _ref.status,
    status = _ref$status === void 0 ? 200 : _ref$status,
    delay = _ref.delay,
    getSlug = _ref.getSlug;
  return /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(req, res, ctx) {
      var params, slug, stubName, stubPath, result, _t;
      return _regeneratorRuntime.wrap(function (_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            if (!(type === 'redirect')) {
              _context.next = 2;
              break;
            }
            _context.next = 1;
            return res(ctx.status(307), ctx.set('Location', ''));
          case 1:
            return _context.abrupt("return", _context.sent);
          case 2:
            params = {
              query: convertSearchParamsToObject(req.url.searchParams)
            };
            slug = getSlug(params);
            stubName = composeStubName(slug, type);
            stubPath = composeStubPath(dirPath, stubName);
            result = readStub(stubPath, type === 'model' || type === 'json');
            if (!(type === 'json' || type === 'model')) {
              _context.next = 4;
              break;
            }
            _context.next = 3;
            return res(ctx.json(result), ctx.delay(delay), ctx.status(status));
          case 3:
            return _context.abrupt("return", _context.sent);
          case 4:
            _context.next = 5;
            return res(ctx.body(result), ctx.delay(delay), ctx.status(status));
          case 5:
            return _context.abrupt("return", _context.sent);
          case 6:
            _context.prev = 6;
            _t = _context["catch"](0);
            console.error("Url: ".concat(req.url.pathname, ", Method: ").concat(req.method, ", ").concat(_t));
            return _context.abrupt("return", res(ctx.status(500)));
          case 7:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[0, 6]]);
    }));
    return function (_x, _x2, _x3) {
      return _ref2.apply(this, arguments);
    };
  }();
};
var convertRouteToMswHandler = function convertRouteToMswHandler(dirPath) {
  return function (_ref3) {
    var url = _ref3.url,
      _ref3$method = _ref3.method,
      method = _ref3$method === void 0 ? 'GET' : _ref3$method,
      route = _objectWithoutProperties(_ref3, _excluded);
    var sanitizedUrl = sanitizeUrl(url);
    var methodName = method === null || method === void 0 ? void 0 : method.toLowerCase();
    return rest[methodName](sanitizedUrl, createRestHandler(route, dirPath));
  };
};
var filterRoutes = function filterRoutes(routes) {
  return routes.filter(function (route) {
    return route.getSlug && route.url && !route.Component;
  });
};

/**
 * Работает с routes в server
 * Конвертирует формат routes в формат msw
 * Не поддерживает handler, condition
 * Не проверялся с model и Component
 */
export var convertRoutesToMswHandlers = function convertRoutesToMswHandlers(routesPath) {
  var directories = getDirectoriesWithRoutes(routesPath);
  return directories.reduce(function (result, _ref4) {
    var routes = _ref4.routes,
      dirPath = _ref4.dirPath;
    return [].concat(_toConsumableArray(result), _toConsumableArray(filterRoutes(routes).map(convertRouteToMswHandler(dirPath))));
  }, []);
};