/* eslint-disable */
/**
 * Copied from node_modules/webpack/lib/WebpackOptionsApply.js
 *
 * All the option configuration are removed except for options.cache
 */

/**
 * Убирает package.json наших пакетов из выборки для buildDependency-кэша
 * @param ignoreBuildDependencies {string[]}
 */
const excludeBeefPackageJsonFiles = (ignoreBuildDependencies = ['/package.json']) => files => new Set(Array.from(files).filter(resource => !/[/\\]node_modules[/\\]@(?:bee[fp]|beefco|carnica)[/\\][^\\/]+[/\\]package.json$/.test(resource)).filter(resource => !new RegExp(`^${process.cwd()}(${ignoreBuildDependencies.map(p => p.replace('/', '[/\\\\]')).join('|')})$`).test(resource)).filter(resource => !new RegExp(`^${process.cwd()}[/\\\\](?!.*node_modules).*package\\.json$`).test(resource)));

/** @typedef {import("../declarations/WebpackOptions").WebpackPluginFunction} WebpackPluginFunction */
/** @typedef {import("./config/defaults").WebpackOptionsNormalizedWithDefaults} WebpackOptions */
/** @typedef {import("./Compiler")} Compiler */
/** @typedef {import("./util/fs").InputFileSystem} InputFileSystem */
/** @typedef {import("./util/fs").IntermediateFileSystem} IntermediateFileSystem */

class WebpackCacheOptionsApply {
  constructor({
    ignoreBuildDependencies = [],
    ...rest
  } = {}) {
    this.options = {
      ignoreBuildDependencies,
      ...rest
    };
    this.excludeBeefPackageJsonFiles = excludeBeefPackageJsonFiles(ignoreBuildDependencies);
  }

  /** Основная часть плагинов не изменена */
  get AddBuildDependenciesPlugin() {
    return require('webpack/lib/cache/AddBuildDependenciesPlugin');
  }
  get MemoryCachePlugin() {
    return require('webpack/lib/cache/MemoryCachePlugin');
  }
  get MemoryWithGcCachePlugin() {
    return require('webpack/lib/cache/MemoryWithGcCachePlugin');
  }
  get IdleFileCachePlugin() {
    return require('webpack/lib/cache/IdleFileCachePlugin');
  }

  /**
   * Ядро всего плагина, позволяет исключить package.json beef-пакетов buildDependencies из ключа кэша, к ним относятся:
   * - @beef/conf/package.json
   * - @beef/react/package.json
   * - @beef/ui-kit/package.json
   * - @beefp/wrongpayment
   * ... и.тд.д
   *
   * Это нужно, чтобы кэш не инвалидироваться при простом изменении версий, если поменяется сам код этих пакетов,
   *   они будут обработаны
   */
  get PackFileCacheStrategy() {
    const PackFileCacheStrategy = require('webpack/lib/cache/PackFileCacheStrategy');
    const excludeBeefPackageJsonFiles = this.excludeBeefPackageJsonFiles;
    return class BeefCachePackageFileCacheStrategy extends PackFileCacheStrategy {
      constructor(...args) {
        super(...args);
        const originalCreateSnapshot = this.fileSystemInfo.createSnapshot.bind(this.fileSystemInfo);
        this.fileSystemInfo.createSnapshot = (startTime, files, directories, missing, options, callback) => {
          originalCreateSnapshot(startTime, excludeBeefPackageJsonFiles(files), directories, missing, options, callback);
        };
      }
    };
  }

  /**
   * @param {WebpackOptions} options options object
   * @param {Compiler} compiler compiler object
   * @returns {WebpackOptions} options object
   */
  process(options, compiler) {
    const {
      AddBuildDependenciesPlugin,
      MemoryCachePlugin,
      MemoryWithGcCachePlugin,
      IdleFileCachePlugin,
      PackFileCacheStrategy
    } = this;

    //
    // Игнорируем все предыдущие плагины, их webpack запустит самостоятельно
    //
    const cacheOptions = options.cache;
    if (!cacheOptions && typeof cacheOptions !== 'object') return;

    /** Наш плагин переопределяет только прод-кэширование через fs */
    if (cacheOptions.type !== 'filesystem' || cacheOptions.store !== 'pack') return;
    switch (cacheOptions.type) {
      case 'filesystem':
        {
          // const AddBuildDependenciesPlugin = require("./cache/AddBuildDependenciesPlugin");

          for (const key in cacheOptions.buildDependencies) {
            const list = cacheOptions.buildDependencies[key];
            new AddBuildDependenciesPlugin(list).apply(compiler);
          }
          if (!Number.isFinite(cacheOptions.maxMemoryGenerations)) {
            // @ts-expect-error https://github.com/microsoft/TypeScript/issues/41697
            // const MemoryCachePlugin = require("./cache/MemoryCachePlugin");

            new MemoryCachePlugin().apply(compiler);
          } else if (cacheOptions.maxMemoryGenerations !== 0) {
            // @ts-expect-error https://github.com/microsoft/TypeScript/issues/41697
            // const MemoryWithGcCachePlugin = require("./cache/MemoryWithGcCachePlugin");

            new MemoryWithGcCachePlugin({
              maxGenerations: (/** @type {number} */
              cacheOptions.maxMemoryGenerations)
            }).apply(compiler);
          }
          if (cacheOptions.memoryCacheUnaffected) {
            if (!options.experiments.cacheUnaffected) {
              throw new Error("'cache.memoryCacheUnaffected: true' is only allowed when 'experiments.cacheUnaffected' is enabled");
            }
            compiler.moduleMemCaches = new Map();
          }
          switch (cacheOptions.store) {
            case 'pack':
              {
                // const IdleFileCachePlugin = require("./cache/IdleFileCachePlugin");
                // const PackFileCacheStrategy = require("./cache/PackFileCacheStrategy");

                new IdleFileCachePlugin(new PackFileCacheStrategy({
                  compiler,
                  fs: (/** @type {IntermediateFileSystem} */
                  compiler.intermediateFileSystem),
                  context: options.context,
                  cacheLocation: (/** @type {string} */
                  cacheOptions.cacheLocation),
                  version: (/** @type {string} */cacheOptions.version),
                  logger: compiler.getInfrastructureLogger('webpack.cache.PackFileCacheStrategy'),
                  snapshot: options.snapshot,
                  maxAge: (/** @type {number} */cacheOptions.maxAge),
                  profile: cacheOptions.profile,
                  allowCollectingMemory: cacheOptions.allowCollectingMemory,
                  compression: cacheOptions.compression,
                  readonly: cacheOptions.readonly
                }), /** @type {number} */
                cacheOptions.idleTimeout, /** @type {number} */
                cacheOptions.idleTimeoutForInitialStore, /** @type {number} */
                cacheOptions.idleTimeoutAfterLargeChanges).apply(compiler);
                break;
              }
            default:
              throw new Error('Unhandled value for cache.store');
          }
          break;
        }
      default:
        // @ts-expect-error Property 'type' does not exist on type 'never'. ts(2339)
        throw new Error(`Unknown cache type ${cacheOptions.type}`);
    }
    //
    // All the following options are cut
    //
    /**
     * Удаляем всю секцию options.cache webpack-конфига, чтобы оригинальный WebpackOptionsApply не применял кэш повторно
     */
    delete compiler.options.cache;
  }
}
module.exports = WebpackCacheOptionsApply;