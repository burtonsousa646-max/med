import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime/helpers/getPrototypeOf";
import _inherits from "@babel/runtime/helpers/inherits";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import React from 'react';
import { getFiberNodeFromClassComponent } from '@beef/react/internals';
/**
 * Точка доступа к VirtualDOM
 */
export var FiberAccess = /*#__PURE__*/function (_React$Component) {
  function FiberAccess() {
    var _this;
    _classCallCheck(this, FiberAccess);
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _callSuper(this, FiberAccess, [].concat(args));
    _defineProperty(_this, "_fiber", void 0);
    return _this;
  }
  _inherits(FiberAccess, _React$Component);
  return _createClass(FiberAccess, [{
    key: "fiber",
    get: function get() {
      this._fiber || (this._fiber = getFiberNodeFromClassComponent(this));
      return this._fiber;
    }
  }, {
    key: "render",
    value: function render() {
      var children = this.props.children;
      return typeof children === 'function' ? children(this.fiber) : children || null;
    }
  }]);
}(React.Component);