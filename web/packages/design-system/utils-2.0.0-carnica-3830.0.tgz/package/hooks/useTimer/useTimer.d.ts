import { UseTimerParams } from './types';
export declare function useTimer(userConfig?: Partial<UseTimerParams>): {
    isRunning: boolean;
    pause: () => void;
    reset: (newTime?: number) => void;
    start: () => void;
    time: import("react").RefObject<number>;
};
//# sourceMappingURL=useTimer.d.ts.map