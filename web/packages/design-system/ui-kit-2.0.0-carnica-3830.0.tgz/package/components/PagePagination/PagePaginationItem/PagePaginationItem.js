import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["type", "page", "active", "color", "onChangePage", "onClick", "className"];
import React, { forwardRef, useCallback } from 'react';
import { cnBem } from '@carnica/utils';
import { IconDotsRoundOutline } from '@carnica/graphics';
import { useMutableRef } from '@carnica/utils/hooks';
import { Button } from "../../Button";
import styles from "./styles.module.css";
import { getButtonView } from "../utils";
var cnPagePaginationItem = cnBem('item', styles);
var PagePaginationItemRender = function PagePaginationItemRender(props, ref) {
  var type = props.type,
    _props$page = props.page,
    page = _props$page === void 0 ? 1 : _props$page,
    _props$active = props.active,
    active = _props$active === void 0 ? false : _props$active,
    _props$color = props.color,
    color = _props$color === void 0 ? 'primary' : _props$color,
    onChangePage = props.onChangePage,
    onClick = props.onClick,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var onChangePageRef = useMutableRef(onChangePage);
  var handleChangePage = useCallback(function (e) {
    if (type === 'page') {
      var _onChangePageRef$curr;
      (_onChangePageRef$curr = onChangePageRef.current) === null || _onChangePageRef$curr === void 0 || _onChangePageRef$curr.call(onChangePageRef, page, e);
    }
    onClick === null || onClick === void 0 || onClick(e);
  }, [onClick]);
  return type === 'separator' ? /*#__PURE__*/React.createElement(IconDotsRoundOutline, _extends({
    "aria-hidden": true,
    className: cnPagePaginationItem({
      type: type
    }, [className]),
    color: "primary",
    onClick: onClick,
    ref: ref,
    size: "s"
  }, otherProps, {
    "data-t-id": "PagePagination-PagePaginationItem"
  })) : /*#__PURE__*/React.createElement(Button, _extends({
    "aria-current": active ? 'page' : undefined,
    "aria-label": "\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 ".concat(page),
    className: cnPagePaginationItem({
      type: type,
      active: active
    }, [className]),
    onClick: handleChangePage,
    ref: ref,
    size: "m",
    view: getButtonView(active, color)
  }, otherProps), page);
};
export var PagePaginationItem = /*#__PURE__*/forwardRef(PagePaginationItemRender);