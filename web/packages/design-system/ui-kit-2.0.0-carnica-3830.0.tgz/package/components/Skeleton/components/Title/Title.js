import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["size", "reverse", "invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
import { getSubTitleSize, getTitleSize } from "./utils";
var cnTitle = cnBem('skeleton-title', styles);
export var Title = function Title(_ref) {
  var _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size,
    reverse = _ref.reverse,
    invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnTitle({
      size: size,
      reverse: reverse
    }, [className])
  }, props, {
    "data-t-id": "components-Title"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    color: color,
    invert: invert
  }, getTitleSize(size, reverse))), /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    color: color,
    invert: invert
  }, getSubTitleSize(size, reverse))), !reverse && /*#__PURE__*/React.createElement(SkeletonBrick, _extends({
    color: color,
    invert: invert
  }, getSubTitleSize(size, reverse, true))));
};