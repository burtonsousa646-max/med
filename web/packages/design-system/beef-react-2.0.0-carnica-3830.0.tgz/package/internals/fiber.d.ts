import React from 'react';
export declare const isFiberNodeKey: (key: string) => boolean;
export declare const getInstanceFromNode: (domNode: Element) => any;
export declare const getFiberNodeType: (fiberNode: any) => any;
export declare const getFiberProps: (fiberNode: any) => any;
export declare const getFiberProp: (fiberNode: any, propName: string) => any;
export declare const isDomFiberNode: (fiberNode: any) => boolean;
export declare const isRootFiberNode: (fiberNode: any) => boolean;
export declare const getFiberNodeFromClassComponent: (classComponent: React.Component) => any;
export declare const getDomNodeFromFiber: (fiberNode: any) => any;
export declare function getFiberNodeFromDOM(domNode: Element | null): any;
export declare function getFiberNodeParent(fiberNode: any): any;
//# sourceMappingURL=fiber.d.ts.map