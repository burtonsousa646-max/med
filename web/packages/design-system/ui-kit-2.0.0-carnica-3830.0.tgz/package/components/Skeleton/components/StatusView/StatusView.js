import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["invert", "color", "className"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick, SkeletonCircle } from "../../Skeleton";
import styles from "./styles.module.css";
var cnStatusView = cnBem('skeleton-status-view', styles);
export var StatusView = function StatusView(_ref) {
  var invert = _ref.invert,
    color = _ref.color,
    className = _ref.className,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnStatusView(null, [className])
  }, props, {
    "data-t-id": "components-StatusView"
  }), /*#__PURE__*/React.createElement(SkeletonCircle, {
    color: color,
    diameter: 100,
    invert: invert
  }), /*#__PURE__*/React.createElement("div", {
    className: cnStatusView('wrapper')
  }, /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 24,
    invert: invert,
    width: 295
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 12,
    invert: invert,
    width: 239
  })));
};