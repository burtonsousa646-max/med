import { isDateValid } from "./checks";
export var getTimePartsMs = function getTimePartsMs(timeMs) {
  var time = timeMs;
  var ms = time % 1000;
  time = (time - ms) / 1000;
  var seconds = time % 60;
  time = (time - seconds) / 60;
  var minutes = time % 60;
  var hours = (time - minutes) / 60;
  return {
    hours: hours,
    minutes: minutes,
    seconds: seconds,
    ms: ms
  };
};
// https://stackoverflow.com/questions/17732897/
export var getDatePastParts = function getDatePastParts(dateStartStr, dateEndStr) {
  if (!dateStartStr) return null;
  var startDate = new Date(dateStartStr);
  var now = dateEndStr ? new Date(dateEndStr) : new Date();
  if (!isDateValid(startDate) || !isDateValid(now)) {
    return null;
  }
  var diffDate = new Date(now.getTime() - startDate.getTime());
  return {
    years: +diffDate.toISOString().slice(0, 4) - 1970,
    months: diffDate.getMonth(),
    days: diffDate.getDate() - 1,
    hours: diffDate.getUTCHours()
  };
};