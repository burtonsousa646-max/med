declare function _exports({ error }: {
    error: any;
}): boolean;
export = _exports;
//# sourceMappingURL=silent-filter.d.ts.map