export var getWindowWidth = function getWindowWidth() {
  return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
};
export var getCurrentResolution = function getCurrentResolution(resolutions) {
  return resolutions.find(function (resolution) {
    return resolution >= getWindowWidth();
  });
};