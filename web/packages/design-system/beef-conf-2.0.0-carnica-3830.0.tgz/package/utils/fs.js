const {
  promises: fs
} = require('fs');
const path = require('path');
const fg = require('fast-glob');
const rewriteJsonFile = async (filepath, contentChanger = async fileContent => fileContent) => {
  const fileExist = await fs.access(filepath).then(() => true).catch(() => false);
  if (!fileExist) return;
  const originalContent = JSON.parse(await fs.readFile(filepath, 'utf8'));
  const updatedContent = `${JSON.stringify(await contentChanger(originalContent), null, 2)}\n`;
  await fs.writeFile(filepath, updatedContent);
};
async function getWorkspacePackageJsonPaths() {
  const rootDir = process.cwd();
  const packageJsonPath = path.join(rootDir, 'package.json');
  try {
    const content = await fs.readFile(packageJsonPath, 'utf-8');
    const packageJson = JSON.parse(content);
    const {
      workspaces
    } = packageJson;
    if (!workspaces || !Array.isArray(workspaces.packages)) {
      return Promise.reject(new Error('Поле workspaces.packages не найдено или не является массивом'));
    }
    const patterns = workspaces.packages.map(pattern => path.posix.join(pattern, 'package.json'));
    return await fg(patterns, {
      cwd: rootDir,
      absolute: true,
      onlyFiles: true
    });
  } catch (err) {
    console.error('Ошибка при получении путей до package.json:', err.message);
  }
  return Promise.reject(new Error('unknown reason'));
}
module.exports = {
  rewriteJsonFile,
  getWorkspacePackageJsonPaths
};