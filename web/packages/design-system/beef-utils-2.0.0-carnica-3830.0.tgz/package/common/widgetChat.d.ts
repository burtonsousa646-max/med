export declare const setChatWidgetOpen: <IS_OPEN extends boolean>(flag: IS_OPEN, options?: {
    initialMessage?: (IS_OPEN extends true ? string : never) | undefined;
} | undefined) => void;
export declare const setChatWidgetMenuOpen: <IS_OPEN extends boolean>(flag: IS_OPEN, options?: {} | undefined) => void;
//# sourceMappingURL=widgetChat.d.ts.map