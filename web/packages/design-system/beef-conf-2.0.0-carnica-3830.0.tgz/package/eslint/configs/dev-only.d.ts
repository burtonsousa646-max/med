declare let _extends: any[];
export { _extends as extends };
export declare let rules: {};
//# sourceMappingURL=dev-only.d.ts.map