export * from './useManyRefs';
//# sourceMappingURL=index.d.ts.map