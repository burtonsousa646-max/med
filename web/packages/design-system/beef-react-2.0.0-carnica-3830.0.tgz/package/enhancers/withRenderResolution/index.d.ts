import React from 'react';
import { TResolutions } from './types';
export declare const withRenderResolution: (resolutions?: TResolutions) => <P extends Record<string, any>>(WrappedComponent: React.ComponentType<P>) => (props: P) => React.JSX.Element;
//# sourceMappingURL=index.d.ts.map