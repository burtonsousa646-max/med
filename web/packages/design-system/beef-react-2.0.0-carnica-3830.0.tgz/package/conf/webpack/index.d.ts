import WebpackFactory = require("./WebpackFactory");
export declare let webpack: WebpackFactory;
export { WebpackFactory };
//# sourceMappingURL=index.d.ts.map