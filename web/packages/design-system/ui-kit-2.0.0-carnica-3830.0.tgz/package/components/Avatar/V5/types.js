export var avatarV5PropSize = ['xl', 'l', 'm', 's', 'xs'];
export var avatarV5PropColor = ['default-on-bg-primary', 'default-on-bg-secondary', 'default-on-bg-tertiary', 'brand', 'invert'];
export var avatarV5PropView = ['accent-icon', 'icon', 'image', 'logo', 'text'];