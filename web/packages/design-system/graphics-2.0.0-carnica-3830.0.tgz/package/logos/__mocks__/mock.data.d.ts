export declare const data: {
    group: string;
    icons: {
        name: string;
        icon: import("../../types").LogoComponent;
    }[];
}[];
//# sourceMappingURL=mock.data.d.ts.map