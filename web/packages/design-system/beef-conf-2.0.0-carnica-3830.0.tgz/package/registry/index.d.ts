declare const _exports: {
    scopeRegExpStr: string;
    scopeRegExp: RegExp;
    scopeMatchedExcludes: RegExp;
    scopeExcludes: RegExp;
    scopeIncludes: RegExp;
    BeelineDigitalScopeList: string[];
};
export = _exports;
//# sourceMappingURL=index.d.ts.map