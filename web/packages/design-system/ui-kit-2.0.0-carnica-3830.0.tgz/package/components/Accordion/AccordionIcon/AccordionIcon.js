import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["openIcon", "closeIcon", "closeRotate", "openRotate", "isOpen"];
import React from 'react';
import { AnimatedIcon, IconChevronDown } from '@carnica/graphics';
export var AccordionIcon = function AccordionIcon(_ref) {
  var _ref$openIcon = _ref.openIcon,
    IconOpen = _ref$openIcon === void 0 ? IconChevronDown : _ref$openIcon,
    IconClose = _ref.closeIcon,
    _ref$closeRotate = _ref.closeRotate,
    closeRotate = _ref$closeRotate === void 0 ? -180 : _ref$closeRotate,
    _ref$openRotate = _ref.openRotate,
    openRotate = _ref$openRotate === void 0 ? 0 : _ref$openRotate,
    isOpen = _ref.isOpen,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(AnimatedIcon, _extends({
    activeIndex: isOpen ? 1 : 0,
    icons: IconClose ? [IconOpen, IconClose] : [IconOpen],
    rotations: IconClose ? [] : [openRotate, closeRotate],
    transition: 300
  }, otherProps, {
    "data-t-id": "Accordion-AccordionIcon"
  }));
};