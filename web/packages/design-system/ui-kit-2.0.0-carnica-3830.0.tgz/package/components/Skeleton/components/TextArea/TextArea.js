import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["color", "className", "invert"];
import React from 'react';
import { cnBem } from '@carnica/utils';
import { SkeletonBrick } from "../../Skeleton";
import styles from "./styles.module.css";
var cnTextArea = cnBem('skeleton-textarea', styles);
export var TextArea = function TextArea(_ref) {
  var color = _ref.color,
    className = _ref.className,
    invert = _ref.invert,
    props = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cnTextArea(null, [className])
  }, props, {
    "data-t-id": "components-TextArea"
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 12,
    invert: invert,
    width: 100
  }), /*#__PURE__*/React.createElement(SkeletonBrick, {
    color: color,
    height: 28,
    invert: invert,
    width: "100%"
  }));
};