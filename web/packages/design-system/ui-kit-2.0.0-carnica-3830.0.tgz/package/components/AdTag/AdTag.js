import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["onClick", "popoverProps"],
  _excluded2 = ["onClose"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { forwardRef, useCallback } from 'react';
import { useFlag } from '@carnica/utils/hooks';
import { AdTagStateless } from "./AdTagStateless";
var AdTagRender = function AdTagRender(props, ref) {
  var onClick = props.onClick,
    popoverProps = props.popoverProps,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _useFlag = useFlag(),
    _useFlag2 = _slicedToArray(_useFlag, 2),
    isOpen = _useFlag2[0],
    setIsOpen = _useFlag2[1];
  var handleClick = function handleClick(e) {
    setIsOpen.toggle();
    onClick === null || onClick === void 0 || onClick(e);
  };
  var _ref = popoverProps || {},
    onClose = _ref.onClose,
    otherPopoverProps = _objectWithoutProperties(_ref, _excluded2);
  var handleClose = useCallback(function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    onClose === null || onClose === void 0 || onClose.apply(void 0, args);
    setIsOpen.off();
  }, [onClose]);
  return /*#__PURE__*/React.createElement(AdTagStateless, _extends({
    onClick: handleClick,
    popoverProps: _objectSpread({
      onClose: handleClose
    }, otherPopoverProps),
    ref: ref,
    tooltipOpen: isOpen
  }, otherProps, {
    "data-t-id": "components-AdTag"
  }));
};
export var AdTag = /*#__PURE__*/forwardRef(AdTagRender);