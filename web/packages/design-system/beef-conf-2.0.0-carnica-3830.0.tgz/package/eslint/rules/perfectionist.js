module.exports = {
  rules: {
    // Отключенные правила после обсуждения с командой
    'perfectionist/sort-classes': 0,
    'perfectionist/sort-imports': 0,
    'perfectionist/sort-astro-attributes': 0,
    'perfectionist/sort-array-includes': 0,
    'perfectionist/sort-maps': 0,
    'perfectionist/sort-objects': 0,
    'perfectionist/sort-enums': 0

    // Список включенных правил из recommended плагина
    // 'perfectionist/sort-named-imports': 0,
    // 'perfectionist/sort-exports': 0,
    // 'perfectionist/sort-interfaces': 0,
    // 'perfectionist/sort-jsx-props': 0,
    // 'perfectionist/sort-named-exports': 0,
    // 'perfectionist/sort-object-types': 0,
    // 'perfectionist/sort-union-types': 0,
  }
};