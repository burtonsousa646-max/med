import { IconBellOutline, IconMarkOutline, IconRefresh } from '@carnica/graphics';
export var buttons = [{
  label: 'повторить\nплатёж',
  icon: IconRefresh,
  view: 'primary'
}, {
  label: 'сообщите,\nчто работает',
  icon: IconBellOutline
}, {
  label: 'сходить\nв офис',
  icon: IconMarkOutline
}];