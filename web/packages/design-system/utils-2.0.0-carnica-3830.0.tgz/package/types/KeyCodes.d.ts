export declare enum EKeyCodes {
    Alt = "Alt",
    CapsLock = "CapsLock",
    Control = "Control",
    Fn = "Fn",
    Shift = "Shift",
    Enter = "Enter",
    Tab = "Tab",
    ArrowDown = "ArrowDown",
    ArrowLeft = "ArrowLeft",
    ArrowRight = "ArrowRight",
    ArrowUp = "ArrowUp",
    PageDown = "PageDown",
    PageUp = "PageUp",
    Backspace = "Backspace",
    Clear = "Clear",
    Copy = "Copy",
    Delete = "Delete",
    Escape = "Escape",
    Pause = "Pause",
    Play = "Play",
    ZoomIn = "ZoomIn",
    ZoomOut = "ZoomOut",
    PrintScreen = "PrintScreen"
}
export type TKeyCode = keyof typeof EKeyCodes;
//# sourceMappingURL=KeyCodes.d.ts.map