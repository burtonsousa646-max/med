import _extends from "@babel/runtime/helpers/extends";
import React, { forwardRef } from 'react';
import { Banner as Component } from "./Banner";
var defineBanner = function defineBanner(mode) {
  return /*#__PURE__*/forwardRef(function (props, ref) {
    return /*#__PURE__*/React.createElement(Component, _extends({
      mode: mode,
      ref: ref
    }, props, {
      "data-t-id": "components-Banner"
    }));
  });
};
export var Banner = defineBanner('default');
export var BannerGroup = defineBanner('group');