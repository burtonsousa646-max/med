export * from './useBlockScroll';
//# sourceMappingURL=index.d.ts.map