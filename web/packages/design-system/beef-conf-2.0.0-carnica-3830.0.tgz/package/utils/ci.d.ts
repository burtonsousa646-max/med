export function gitInitCI(repository: any): Buffer<ArrayBufferLike>;
export namespace CI_VARIABLES {
    export { CI };
    export { CI_COMMIT_SHA };
    export { CI_COMMIT_BRANCH };
    export { CI_COMMIT_TITLE };
    export { CI_REPO_URL };
    export { CI_PUBLISH_BRANCH };
    export { ADAPTIVE_REPO_URL };
    export { ELK_REPO_URL };
    export { CI_MERGE_REQUEST_TARGET_BRANCH_NAME };
    export { CI_MERGE_REQUEST_SOURCE_BRANCH_SHA };
    export { CI_MERGE_REQUEST_SOURCE_BRANCH_NAME };
    export { BEEF_PUBLISH };
    export { BEEF_UPGRADE_SCOPE };
}
export const isCI: string | undefined;
declare const CI: string | undefined;
declare const CI_COMMIT_SHA: string | undefined;
declare const CI_COMMIT_BRANCH: string | undefined;
declare const CI_COMMIT_TITLE: string | undefined;
declare const CI_REPO_URL: string | undefined;
declare const CI_PUBLISH_BRANCH: string | undefined;
declare const ADAPTIVE_REPO_URL: string | undefined;
declare const ELK_REPO_URL: string | undefined;
declare const CI_MERGE_REQUEST_TARGET_BRANCH_NAME: string | undefined;
declare const CI_MERGE_REQUEST_SOURCE_BRANCH_SHA: string | undefined;
declare const CI_MERGE_REQUEST_SOURCE_BRANCH_NAME: string | undefined;
declare const BEEF_PUBLISH: string | undefined;
declare const BEEF_UPGRADE_SCOPE: string | undefined;
export {};
//# sourceMappingURL=ci.d.ts.map