import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["className", "leftSide", "rightSide", "title", "subTitle", "disabled", "offset", "reverse", "size", "form", "background", "radius", "view", "style"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithMotionTag } from '@carnica/utils';
import React from 'react';
import { useDeprecationWarning } from '@carnica/utils/hooks';
import { MotionComponent } from "../../modules/MotionComponent";
import styles from "./styles.module.css";
import { getBackground, isSideRenderable, isSideText } from "./utils";
import { CellSide } from "./CellSide";
import { CellText } from "./CellText";
export var cnCell = cnBem('cell', styles);
export var Cell = forwardRefWithMotionTag(function (props, ref) {
  var className = props.className,
    leftSide = props.leftSide,
    rightSide = props.rightSide,
    title = props.title,
    subTitle = props.subTitle,
    disabled = props.disabled,
    _props$offset = props.offset,
    offset = _props$offset === void 0 ? 'l' : _props$offset,
    reverse = props.reverse,
    _props$size = props.size,
    size = _props$size === void 0 ? 's' : _props$size,
    form = props.form,
    background = props.background,
    radius = props.radius,
    view = props.view,
    style = props.style,
    otherProps = _objectWithoutProperties(props, _excluded);
  useDeprecationWarning({
    view: {
      value: view,
      newPropKey: 'background'
    },
    form: {
      value: form,
      newPropKey: 'radius'
    }
  });
  return /*#__PURE__*/React.createElement(MotionComponent, _extends({}, otherProps, {
    className: cnCell({
      disabled: disabled,
      form: form
    }, [className])
  }, otherProps.tagName === 'button' ? {
    disabled: disabled
  } : {}, {
    ref: ref,
    style: _objectSpread(_objectSpread({}, style), {}, _defineProperty(_defineProperty(_defineProperty({}, '--cell-offset', "var(--space-".concat(offset, ")")), '--cell-bg-color', getBackground({
      view: view,
      background: background
    })), '--cell-radius', radius ? "var(--radius-".concat(radius, ")") : '0px')),
    "data-t-id": "components-Cell"
  }), isSideRenderable(leftSide, disabled) && /*#__PURE__*/React.createElement("div", {
    className: cnCell('slot', {
      side: 'left'
    })
  }, /*#__PURE__*/React.createElement(CellSide, {
    disabled: disabled,
    position: "left",
    side: leftSide
  })), /*#__PURE__*/React.createElement("div", {
    className: cnCell('slot', {
      side: 'center',
      reverse: reverse
    })
  }, /*#__PURE__*/React.createElement(CellText, {
    disabled: disabled,
    label: title,
    size: size,
    type: "title"
  }), /*#__PURE__*/React.createElement(CellText, {
    disabled: disabled,
    label: subTitle,
    type: "subtitle"
  })), isSideRenderable(rightSide, disabled) && /*#__PURE__*/React.createElement("div", {
    className: cnCell('slot', {
      side: 'right',
      isText: isSideText(rightSide)
    })
  }, /*#__PURE__*/React.createElement(CellSide, {
    disabled: disabled,
    position: "right",
    side: rightSide
  })));
});