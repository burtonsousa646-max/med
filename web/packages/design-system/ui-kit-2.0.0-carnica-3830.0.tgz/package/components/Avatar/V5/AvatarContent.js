import React from 'react';
import { cnBem } from '@carnica/utils';
import { Text } from "../../Text";
import styles from "./styles.module.css";
import { accentIconSizeMap, iconSizeMap, logoSizeMap, textSizeMap } from "./utils";
import { getInitialsForName } from "../utils";
var cnAvatar = cnBem('avatar-v5', styles);
export var AvatarContent = function AvatarContent(_ref) {
  var image = _ref.image,
    Icon = _ref.icon,
    view = _ref.view,
    Logo = _ref.logo,
    label = _ref.label,
    _ref$size = _ref.size,
    size = _ref$size === void 0 ? 'm' : _ref$size;
  if (view === 'image' && image) {
    return /*#__PURE__*/React.createElement("img", {
      alt: "\u0410\u0432\u0430\u0442\u0430\u0440",
      className: cnAvatar('image'),
      src: image,
      "data-t-id": "Avatar-V5"
    });
  }
  if ((view === 'icon' || view === 'accent-icon') && Icon) {
    return /*#__PURE__*/React.createElement(Icon, {
      className: cnAvatar('icon', {
        view: view
      }),
      customColor: "var(--avatar-icon)",
      size: (view === 'icon' ? iconSizeMap : accentIconSizeMap)[size]
    });
  }
  if (view === 'logo' && Logo) {
    return /*#__PURE__*/React.createElement(Logo, {
      className: cnAvatar('logo'),
      size: logoSizeMap[size]
    });
  }
  if (view === 'text' && label) {
    return /*#__PURE__*/React.createElement(Text, {
      align: "center",
      className: cnAvatar('label'),
      variant: textSizeMap[size]
    }, getInitialsForName(label));
  }
  return null;
};