import _extends from "@babel/runtime/helpers/extends";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["inputProps"];
import React, { forwardRef } from 'react';
import { compose } from '@beef/utils';
import { withDataConverter } from '@beef/react';
import { ControlWrapper } from "../ControlWrapper";
import { CodeInputField } from "./CodeInputField";
import { dataConverter } from "./utils";
var CodeInputRender = function CodeInputRender(_ref, ref) {
  var inputProps = _ref.inputProps,
    otherProps = _objectWithoutProperties(_ref, _excluded);
  return /*#__PURE__*/React.createElement(ControlWrapper, _extends({}, otherProps, {
    captionSize: "big",
    ref: ref,
    width: "default",
    "data-t-id": "components-CodeInput"
  }), /*#__PURE__*/React.createElement(CodeInputField, _extends({}, inputProps, {
    "data-t-id": "components-CodeInput"
  })));
};
export var CodeInput = compose(withDataConverter(dataConverter), forwardRef)(CodeInputRender);