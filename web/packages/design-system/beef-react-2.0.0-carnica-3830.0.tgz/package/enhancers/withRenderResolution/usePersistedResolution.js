import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import { useCallback, useEffect, useState } from 'react';
import { setCookie } from '@beef/utils';
import { COOKIE_MAX_AGE, LAST_KNOWN_RESOLUTION_COOKIE_NAME } from "./consts";
import { getCurrentResolution } from "./helpers";
import { useEventListener } from "../../hooks";
export var usePersistedResolution = function usePersistedResolution(lastKnownResolution, resolutions) {
  var _useState = useState(lastKnownResolution),
    _useState2 = _slicedToArray(_useState, 2),
    resolution = _useState2[0],
    setResolution = _useState2[1];
  var updateResolution = useCallback(function () {
    var currentResolution = getCurrentResolution(resolutions);
    if (resolution !== currentResolution) {
      setResolution(currentResolution);
      setCookie({
        name: LAST_KNOWN_RESOLUTION_COOKIE_NAME,
        value: currentResolution,
        maxAge: COOKIE_MAX_AGE
      });
    }
  }, [resolutions, resolution, setResolution]);
  useEventListener('resize', updateResolution, typeof window !== 'undefined' ? window : null);
  useEffect(updateResolution, [resolutions, updateResolution]);
  return resolution;
};