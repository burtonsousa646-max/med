import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["tagName", "href", "invert", "label", "className"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import { cnBem, forwardRefWithTag } from '@carnica/utils';
import React from 'react';
import { Text } from "../../Text";
import styles from "./styles.module.css";
var cnBreadCrumbsItem = cnBem('breadcrumbs-item', styles);
export var BreadCrumbsItem = forwardRefWithTag(function (props, ref) {
  var _props$tagName = props.tagName,
    tagName = _props$tagName === void 0 ? 'a' : _props$tagName,
    href = props.href,
    invert = props.invert,
    label = props.label,
    className = props.className,
    otherProps = _objectWithoutProperties(props, _excluded);
  var params = _objectSpread(_objectSpread({}, otherProps), {}, {
    tagName: tagName,
    ref: ref
  });
  return /*#__PURE__*/React.createElement(Text, _extends({}, params, {
    className: cnBreadCrumbsItem({
      invert: invert
    }, [className]),
    variant: "body-small"
  }, tagName === 'a' ? {
    href: href
  } : {}, {
    "data-t-id": "BreadCrumbs-BreadCrumbsItem"
  }), tagName === 'a' ? /*#__PURE__*/React.createElement("span", {
    itemProp: "name"
  }, label) : label);
});