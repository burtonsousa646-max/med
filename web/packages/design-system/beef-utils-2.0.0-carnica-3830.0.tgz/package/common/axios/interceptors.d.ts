import type { AxiosError, AxiosInterceptorManager, AxiosRequestConfig } from 'axios';
export type SecureRequestInterceptor = NonNullable<Parameters<AxiosInterceptorManager<SecureRequestInterceptorArgs>['use']>[0]>;
interface SecureRequestInterceptorArgs extends AxiosRequestConfig {
    secretKeys?: Array<string>;
}
export declare const secureRequestInterceptor: SecureRequestInterceptor;
export declare function softSecureRequestInterceptor(filter: (config: SecureRequestInterceptorArgs) => boolean): SecureRequestInterceptor;
export type ParseFromDOMString = (s: string) => string;
export interface IWaffleResponseSelector {
    id?: ParseFromDOMString | string;
    ip?: ParseFromDOMString | string;
}
export declare const createWaffleInterceptor: (selectors?: IWaffleResponseSelector) => (error: AxiosError) => Promise<never>;
export {};
//# sourceMappingURL=interceptors.d.ts.map