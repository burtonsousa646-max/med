export class LernaVersionUpdater {
    constructor(options: any);
    options: any;
    getHighestVersion({ distTag, pkgNames }: {
        distTag: any;
        pkgNames: any;
    }): Promise<any>;
    updateVersion(version: any): Promise<void>;
    updateMonorepoResolutions(version: any): Promise<void>;
    addUpdateCommitHash(): Promise<void>;
    config(): Promise<Object>;
    mergeVersions(baseVersion: string, preReleaseVersion: string): string;
}
export function getPublishedPackagesList(): RegExpMatchArray | null;
//# sourceMappingURL=lerna.d.ts.map