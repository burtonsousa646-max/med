declare function _exports(configDir: any, custom?: {}): (api: any) => {
    presets: (false | any[])[];
    plugins: (false | any[])[];
    ignore: any[];
    overrides: {
        test: RegExp;
        sourceType: string;
    }[];
};
export = _exports;
//# sourceMappingURL=babelConfig.d.ts.map