type CookieName = string;
type Cookie = {
    domain?: string;
    maxAge?: number;
    name: CookieName;
    path?: string;
    sameSite?: 'lax' | 'none' | 'strict';
    secure?: boolean;
    ttl?: number;
    value?: number | string;
};
export declare const getCookie: (name: string) => string | undefined;
export declare const setCookie: ({ domain, maxAge, name, path, sameSite, secure, ttl, value, }: Cookie) => void;
export declare const deleteCookie: (name: CookieName, props?: Omit<Cookie, "maxAge" | "name" | "ttl" | "value">) => void;
export declare const refreshCookie: (cookie: {
    value: (() => string) | string;
} & Omit<Cookie, "value">) => string;
export declare const getRootCookieDomain: () => string;
export {};
//# sourceMappingURL=cookie.d.ts.map