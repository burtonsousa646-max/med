import _extends from "@babel/runtime/helpers/extends";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime/helpers/objectWithoutProperties";
var _excluded = ["children", "direction", "offsetHorizontal", "offsetVertical", "possibleDirections", "onClickOutside", "position", "theme", "reposition", "container", "style", "onChangeDirection", "className", "coordinates", "anchorRef", "equalAnchorWidth"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
import React, { useMemo } from 'react';
import { cnBem, combineRefs, forwardRefWithMotion } from '@carnica/utils';
import { ThemedPortal } from "../ThemedPortal";
import { ClickOutsideWrapper } from "../ClickOutsideWrapper";
import styles from "./styles.module.css";
import { popoverPropDirection } from "./types";
import { usePopoverPosition } from "./hooks/usePopoverPosition";
var cnPopover = cnBem('popover', styles);
export var Popover = forwardRefWithMotion(function (props, ref) {
  var _window;
  var children = props.children,
    _props$direction = props.direction,
    directionProp = _props$direction === void 0 ? 'upCenter' : _props$direction,
    _props$offsetHorizont = props.offsetHorizontal,
    offsetHorizontal = _props$offsetHorizont === void 0 ? 0 : _props$offsetHorizont,
    _props$offsetVertical = props.offsetVertical,
    offsetVertical = _props$offsetVertical === void 0 ? 0 : _props$offsetVertical,
    _props$possibleDirect = props.possibleDirections,
    possibleDirections = _props$possibleDirect === void 0 ? popoverPropDirection : _props$possibleDirect,
    onClickOutside = props.onClickOutside,
    _props$position = props.position,
    position = _props$position === void 0 ? 'absolute' : _props$position,
    _props$theme = props.theme,
    theme = _props$theme === void 0 ? 'light' : _props$theme,
    _props$reposition = props.reposition,
    reposition = _props$reposition === void 0 ? true : _props$reposition,
    _props$container = props.container,
    container = _props$container === void 0 ? (_window = window) === null || _window === void 0 || (_window = _window.document) === null || _window === void 0 ? void 0 : _window.body : _props$container,
    style = props.style,
    onChangeDirection = props.onChangeDirection,
    classNameProp = props.className,
    coordinates = props.coordinates,
    anchorRef = props.anchorRef,
    equalAnchorWidth = props.equalAnchorWidth,
    otherProps = _objectWithoutProperties(props, _excluded);
  var _usePopoverPosition = usePopoverPosition({
      anchorRef: anchorRef,
      container: container,
      position: position,
      reposition: reposition,
      offsetHorizontal: offsetHorizontal,
      offsetVertical: offsetVertical,
      equalAnchorWidth: equalAnchorWidth,
      coordinates: coordinates,
      possibleDirections: possibleDirections,
      onChangeDirection: onChangeDirection,
      direction: directionProp
    }),
    cssVariables = _usePopoverPosition.cssVariables,
    notVisible = _usePopoverPosition.notVisible,
    componentRef = _usePopoverPosition.componentRef,
    direction = _usePopoverPosition.direction;
  var className = useMemo(function () {
    return typeof classNameProp === 'function' ? classNameProp(direction) : classNameProp;
  }, [classNameProp, direction]);
  return /*#__PURE__*/React.createElement(ThemedPortal, _extends({}, otherProps, {
    className: cnPopover({
      notVisible: notVisible,
      equalAnchorWidth: equalAnchorWidth
    }, [className]),
    container: container,
    ref: combineRefs([ref, componentRef]),
    style: _objectSpread(_objectSpread({}, style), cssVariables),
    theme: theme,
    "data-t-id": "modules-Popover"
  }), /*#__PURE__*/React.createElement(ClickOutsideWrapper, {
    ignoreClicksInsideRefs: [componentRef, anchorRef || {
      current: null
    }],
    onClickOutside: onClickOutside,
    "data-t-id": "modules-Popover"
  }, typeof children === 'function' ? children(direction) : children));
});