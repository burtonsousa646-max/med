import _extends from "@babel/runtime/helpers/extends";
import _slicedToArray from "@babel/runtime/helpers/slicedToArray";
import React, { useEffect, useState } from 'react';
import { cnBem } from '@carnica/utils';
import { motion } from 'framer-motion';
import { Text } from "../Text";
import { Button } from "../Button";
import styles from "./styles.module.css";
var cnFile = cnBem('file', styles);
var draw = {
  hidden: {
    pathLength: 1
  },
  visible: function visible(seconds) {
    return {
      pathLength: 0,
      strokeWidth: 0,
      transition: {
        pathLength: {
          ease: 'linear',
          duration: seconds
        },
        strokeWidth: {
          delay: seconds
        }
      }
    };
  }
};
var Counter = function Counter(_ref) {
  var seconds = _ref.seconds;
  var _useState = useState(seconds),
    _useState2 = _slicedToArray(_useState, 2),
    time = _useState2[0],
    setTime = _useState2[1];
  useEffect(function () {
    var interval = setInterval(function () {
      setTime(function (prev) {
        return Math.max(prev - 1, 0);
      });
    }, 1000);
    return function () {
      clearInterval(interval);
    };
  }, []);
  return /*#__PURE__*/React.createElement(Text, {
    className: cnFile('counter'),
    color: "primary",
    variant: "caption-medium",
    "data-t-id": "components-File"
  }, time);
};
export var FileDelete = function FileDelete(_ref2) {
  var onCancel = _ref2.onCancel,
    _ref2$seconds = _ref2.seconds,
    seconds = _ref2$seconds === void 0 ? 5 : _ref2$seconds,
    tagName = _ref2.tagName;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: cnFile('timer')
  }, /*#__PURE__*/React.createElement(motion.svg, {
    animate: "visible",
    height: "32",
    initial: "hidden",
    viewBox: "0 0 32 32",
    width: "32"
  }, /*#__PURE__*/React.createElement(motion.circle, {
    className: cnFile('circle'),
    custom: seconds,
    cx: "16",
    cy: "16",
    fill: "transparent",
    r: "14",
    stroke: "var(--file-timer-color)",
    strokeLinecap: "round",
    strokeWidth: 4,
    variants: draw
  })), /*#__PURE__*/React.createElement(Counter, {
    seconds: seconds
  })), /*#__PURE__*/React.createElement(Text, {
    className: cnFile('slot', {
      side: 'center'
    }),
    color: "secondary",
    variant: "body-small"
  }, "\u0443\u0434\u0430\u043B\u044F\u0435\u043C \u0444\u0430\u0439\u043B"), onCancel && /*#__PURE__*/React.createElement(Button, _extends({
    "aria-label": "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0435",
    autoFocus: true,
    className: cnFile('slot', {
      side: 'right'
    }),
    mode: "inline",
    onClick: onCancel,
    view: "secondary"
  }, tagName === 'button' ? {
    tagName: 'div',
    role: 'button'
  } : {}), "\u043E\u0442\u043C\u0435\u043D\u0438\u0442\u044C"));
};