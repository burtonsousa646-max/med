import _defineProperty from "@babel/runtime/helpers/defineProperty";
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 * Copies propTypes from Ancestor to Component, omitting some of the params
 */
export var inheritPropTypes = function inheritPropTypes(Component, Ancestor) {
  var _ref = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
    _ref$omit = _ref.omit,
    omit = _ref$omit === void 0 ? [] : _ref$omit;
  Component.propTypes = _objectSpread({}, Ancestor.propTypes);
  Component.defaultProps = _objectSpread({}, Ancestor.defaultProps);
  omit.forEach(function (propName) {
    delete Component.propTypes[propName];
    delete Component.defaultProps[propName];
  });
  return Component;
};